# Modèle logique métier - FR LM Raison de la recommandation (non codée) - ANS IG document core v0.1.0-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle logique métier - FR LM Raison de la recommandation (non codée)**

## Logical Model: Modèle logique métier - FR LM Raison de la recommandation (non codée) 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-raison-recommandation-non-code | *Version*:0.1.0-snapshot |
| Draft as of 2026-04-16 | *Computable Name*:FRLMRaisonRecommandationNonCode |

 
Section Raison de la recommandation (non codée) 

**Utilisations:**

* Utilise ce/t/te Modèle logique: [Modèle logique métier - FR LM Corps document](StructureDefinition-fr-lm-corps-document.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-lm-raison-recommandation-non-code)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-fr-lm-raison-recommandation-non-code.csv), [Excel](StructureDefinition-fr-lm-raison-recommandation-non-code.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-lm-raison-recommandation-non-code",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-raison-recommandation-non-code",
  "version" : "0.1.0-snapshot",
  "name" : "FRLMRaisonRecommandationNonCode",
  "title" : "Modèle logique métier - FR LM Raison de la recommandation (non codée)",
  "status" : "draft",
  "date" : "2026-04-16T10:39:58+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Section Raison de la recommandation (non codée)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-raison-recommandation-non-code",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-section",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "fr-lm-raison-recommandation-non-code",
      "path" : "fr-lm-raison-recommandation-non-code",
      "short" : "Modèle logique métier - FR LM Raison de la recommandation (non codée)",
      "definition" : "Section Raison de la recommandation (non codée)"
    },
    {
      "id" : "fr-lm-raison-recommandation-non-code.sousSection",
      "path" : "fr-lm-raison-recommandation-non-code.sousSection",
      "max" : "0"
    },
    {
      "id" : "fr-lm-raison-recommandation-non-code.entree",
      "path" : "fr-lm-raison-recommandation-non-code.entree",
      "max" : "0"
    }]
  }
}

```
