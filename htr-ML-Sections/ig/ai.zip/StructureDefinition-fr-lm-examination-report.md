# Modèle logique métier - FR LM Examination Report - ANS IG document core v0.1.0-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle logique métier - FR LM Examination Report**

## Logical Model: Modèle logique métier - FR LM Examination Report 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-examination-report | *Version*:0.1.0-snapshot |
| Draft as of 2026-05-07 | *Computable Name*:FRLMExaminationReport |

 
Section Acte d’imagerie 

**Utilisations:**

* Utilise ce/t/te Modèle logique: [Modèle logique métier - FR LM Corps document](StructureDefinition-fr-lm-corps-document.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-lm-examination-report)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-fr-lm-examination-report.csv), [Excel](StructureDefinition-fr-lm-examination-report.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-lm-examination-report",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-examination-report",
  "version" : "0.1.0-snapshot",
  "name" : "FRLMExaminationReport",
  "title" : "Modèle logique métier - FR LM Examination Report",
  "status" : "draft",
  "date" : "2026-05-07T13:30:39+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Section Acte d'imagerie",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-examination-report",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-section",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "fr-lm-examination-report",
      "path" : "fr-lm-examination-report",
      "short" : "Modèle logique métier - FR LM Examination Report",
      "definition" : "Section Acte d'imagerie"
    },
    {
      "id" : "fr-lm-examination-report.titleSection",
      "path" : "fr-lm-examination-report.titleSection",
      "min" : 1
    },
    {
      "id" : "fr-lm-examination-report.subSection.conclusion",
      "path" : "fr-lm-examination-report.subSection.conclusion",
      "short" : "Conclusion de l'examen",
      "definition" : "Conclusion de l'examen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "fr-lm-examination-report.subSection.conclusion.impression",
      "path" : "fr-lm-examination-report.subSection.conclusion.impression",
      "short" : "Conclusions",
      "definition" : "Conclusions",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "fr-lm-examination-report.subSection.conclusion.conditionOrFinding[x]",
      "path" : "fr-lm-examination-report.subSection.conclusion.conditionOrFinding[x]",
      "short" : "Conditions ou observations associées aux conclusions",
      "definition" : "Conditions ou observations associées aux conclusions",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-condition"
      },
      {
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-observation"
      }]
    },
    {
      "id" : "fr-lm-examination-report.subSection.recommendation",
      "path" : "fr-lm-examination-report.subSection.recommendation",
      "short" : "Recommandations",
      "definition" : "Recommandations",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-recommendation"
      }]
    },
    {
      "id" : "fr-lm-examination-report.entry.imagingProcedures",
      "path" : "fr-lm-examination-report.entry.imagingProcedures",
      "short" : "Entrée Techniques d'imagerie",
      "definition" : "Entrée Techniques d'imagerie",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-procedure"
      }]
    },
    {
      "id" : "fr-lm-examination-report.entry.medicationAdministrations",
      "path" : "fr-lm-examination-report.entry.medicationAdministrations",
      "short" : "Entrée Produits de santé administrés pendant l'acte d'imagerie",
      "definition" : "Entrée Produits de santé administrés pendant l'acte d'imagerie",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-medication-administration"
      }]
    },
    {
      "id" : "fr-lm-examination-report.entry.adverseReactions",
      "path" : "fr-lm-examination-report.entry.adverseReactions",
      "short" : "Entrée allergies et intolérances",
      "definition" : "Entrée allergies et intolérances",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-allergy-intolerance"
      }]
    },
    {
      "id" : "fr-lm-examination-report.entry.results[x]",
      "path" : "fr-lm-examination-report.entry.results[x]",
      "short" : "Résultats d'examens",
      "definition" : "Résultats d'examens",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-observation"
      },
      {
        "code" : "string"
      }]
    },
    {
      "id" : "fr-lm-examination-report.modality",
      "path" : "fr-lm-examination-report.modality",
      "short" : "Modalités d'imagerie utilisées lors de l'examen (DICOM CID029)",
      "definition" : "Modalités d'imagerie utilisées lors de l'examen (DICOM CID029)",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "description" : "jdv-modalite-acquisition-cisis : Modalité d'imagerie",
        "valueSet" : "https://smt.esante.gouv.fr/fhir/ValueSet/jdv-modalite-acquisition-cisis"
      }
    },
    {
      "id" : "fr-lm-examination-report.bodySite",
      "path" : "fr-lm-examination-report.bodySite",
      "short" : "Localisations anatomiques",
      "definition" : "Localisations anatomiques",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-body-structure"
      }]
    }]
  }
}

```
