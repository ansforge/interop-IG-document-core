# Logical model - FR LM Allergy Intolerance - ANS IG document core v0.1.0-snapsnot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Logical model - FR LM Allergy Intolerance**

## Logical Model: Logical model - FR LM Allergy Intolerance 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-allergy-intolerance | *Version*:0.1.0-snapsnot |
| Draft as of 2026-04-07 | *Computable Name*:FRLMAllergyIntolerance |

 
Allergie ou hypersensibilite 

**Utilisations:**

* Utilise ce/t/te Modèle logique: [Modèle logique métier - FR LM Allergies et hypersensibilités](StructureDefinition-fr-lm-allergies-et-hypersensibilites.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-lm-allergy-intolerance)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-fr-lm-allergy-intolerance.csv), [Excel](StructureDefinition-fr-lm-allergy-intolerance.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-lm-allergy-intolerance",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-allergy-intolerance",
  "version" : "0.1.0-snapsnot",
  "name" : "FRLMAllergyIntolerance",
  "title" : "Logical model - FR LM Allergy Intolerance",
  "status" : "draft",
  "date" : "2026-04-07T14:45:49+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Allergie ou hypersensibilite",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-allergy-intolerance",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-entry",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "fr-lm-allergy-intolerance",
      "path" : "fr-lm-allergy-intolerance",
      "short" : "Logical model - FR LM Allergy Intolerance",
      "definition" : "Allergie ou hypersensibilite"
    },
    {
      "id" : "fr-lm-allergy-intolerance.type",
      "path" : "fr-lm-allergy-intolerance.type",
      "short" : "Allergie / hypersensibilité non allergique / intolérance / idiosyncrasie : jdv-type-event-indesirable-previsible-cisis (1.2.250.1.213.1.1.5.842)",
      "definition" : "Allergie / hypersensibilité non allergique / intolérance / idiosyncrasie : jdv-type-event-indesirable-previsible-cisis (1.2.250.1.213.1.1.5.842)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "description" : " jdv-type-event-indesirable-previsible-cisis (1.2.250.1.213.1.1.5.842)",
        "valueSet" : "https://smt.esante.gouv.fr/fhir/ValueSet/jdv-type-evenement-indesirable-previsible-cisis"
      }
    },
    {
      "id" : "fr-lm-allergy-intolerance.category",
      "path" : "fr-lm-allergy-intolerance.category",
      "short" : "food | medication | environment | biologic : jdv-hl7-allergy-intolerance-category-cisis (2.16.840.1.113883.4.642.3.133",
      "definition" : "food | medication | environment | biologic : jdv-hl7-allergy-intolerance-category-cisis (2.16.840.1.113883.4.642.3.133",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "fr-lm-allergy-intolerance.agentOrAllergen",
      "path" : "fr-lm-allergy-intolerance.agentOrAllergen",
      "short" : "Agent responsable\n- Médicaments : CIP ou UCD\n- Substances : SMS\n- Aliments : CIM-11 Chapitre X Extensions – Allergènes ou substances non médicinales\n- Agents environnementaux ou physiques : idem CIM-11 Chapitre X Extensions\n- Allergènes pouvant induire une contre-indication vaccinale : jdv-allergie-vaccin-cisis",
      "definition" : "Agent responsable\n- Médicaments : CIP ou UCD\n- Substances : SMS\n- Aliments : CIM-11 Chapitre X Extensions – Allergènes ou substances non médicinales\n- Agents environnementaux ou physiques : idem CIM-11 Chapitre X Extensions\n- Allergènes pouvant induire une contre-indication vaccinale : jdv-allergie-vaccin-cisis",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "fr-lm-allergy-intolerance.note",
      "path" : "fr-lm-allergy-intolerance.note",
      "short" : "commentaire",
      "definition" : "commentaire",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "fr-lm-allergy-intolerance.status",
      "path" : "fr-lm-allergy-intolerance.status",
      "short" : "Statut clinique de l'allergie\nDescription du binding: : jdv-hl7-allergyintolerance-clinical-cisis (2.16.840.1.113883.4.642.3.1372)",
      "definition" : "Statut clinique de l'allergie\nDescription du binding: : jdv-hl7-allergyintolerance-clinical-cisis (2.16.840.1.113883.4.642.3.1372)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "description" : "jdv-hl7-allergyintolerance-clinical-cisis (2.16.840.1.113883.4.642.3.1372)",
        "valueSet" : "https://smt.esante.gouv.fr/fhir/ValueSet/jdv-hl7-allergyintolerance-clinical-cisis"
      }
    },
    {
      "id" : "fr-lm-allergy-intolerance.criticality",
      "path" : "fr-lm-allergy-intolerance.criticality",
      "short" : "Criticité",
      "definition" : "Criticité",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "description" : "jdv-hl7-allergy-intolerance-criticality-cisis (2.16.840.1.113883.4.642.3.129",
        "valueSet" : "https://smt.esante.gouv.fr/fhir/ValueSet/jdv-hl7-allergy-intolerance-criticality-cisis"
      }
    },
    {
      "id" : "fr-lm-allergy-intolerance.certainty",
      "path" : "fr-lm-allergy-intolerance.certainty",
      "short" : "Certitude",
      "definition" : "Certitude",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "description" : "jdv-hl7-condition-ver-status-cisis (2.16.840.1.113883.4.642.3.166)",
        "valueSet" : "https://smt.esante.gouv.fr/fhir/ValueSet/jdv-hl7-condition-ver-status-cisis"
      }
    },
    {
      "id" : "fr-lm-allergy-intolerance.period",
      "path" : "fr-lm-allergy-intolerance.period",
      "short" : "Période",
      "definition" : "Période",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/organization-period"]
      }]
    },
    {
      "id" : "fr-lm-allergy-intolerance.period.onsetDate",
      "path" : "fr-lm-allergy-intolerance.period.onsetDate",
      "short" : "Date de début",
      "definition" : "Date de début",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "fr-lm-allergy-intolerance.period.endDate",
      "path" : "fr-lm-allergy-intolerance.period.endDate",
      "short" : "Date de fin",
      "definition" : "Date de fin",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "fr-lm-allergy-intolerance.reaction",
      "path" : "fr-lm-allergy-intolerance.reaction",
      "short" : "Réaction observée",
      "definition" : "Réaction observée",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "fr-lm-allergy-intolerance.reaction.agentOrAllergen",
      "path" : "fr-lm-allergy-intolerance.reaction.agentOrAllergen",
      "short" : "Agent responsable : - Substances : SMS",
      "definition" : "Agent responsable : - Substances : SMS",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "description" : "SMS"
      }
    },
    {
      "id" : "fr-lm-allergy-intolerance.reaction.manifestation",
      "path" : "fr-lm-allergy-intolerance.reaction.manifestation",
      "short" : "Manifestation\nCIM-11 / Chapitre 04 Maladies du système immunitaire / Bloc Affections allergiques ou d'hypersen-sibilité",
      "definition" : "Manifestation\nCIM-11 / Chapitre 04 Maladies du système immunitaire / Bloc Affections allergiques ou d'hypersen-sibilité",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "description" : "CIM-11"
      }
    },
    {
      "id" : "fr-lm-allergy-intolerance.reaction.severity",
      "path" : "fr-lm-allergy-intolerance.reaction.severity",
      "short" : "Sévérité de la manifestion",
      "definition" : "Sévérité de la manifestion",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "description" : "SNOMED_CT (preferred)",
        "valueSet" : "https://smt.esante.gouv.fr/fhir/ValueSet/jdv-severite-observation-cisis"
      }
    },
    {
      "id" : "fr-lm-allergy-intolerance.reaction.period",
      "path" : "fr-lm-allergy-intolerance.reaction.period",
      "short" : "Période",
      "definition" : "Période",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/organization-period"]
      }]
    },
    {
      "id" : "fr-lm-allergy-intolerance.reaction.period.onsetDate",
      "path" : "fr-lm-allergy-intolerance.reaction.period.onsetDate",
      "short" : "Date de début",
      "definition" : "Date de début",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    },
    {
      "id" : "fr-lm-allergy-intolerance.reaction.period.endDate",
      "path" : "fr-lm-allergy-intolerance.reaction.period.endDate",
      "short" : "Date de fin",
      "definition" : "Date de fin",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }]
    }]
  }
}

```
