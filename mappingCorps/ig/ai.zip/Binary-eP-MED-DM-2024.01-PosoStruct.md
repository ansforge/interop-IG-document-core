# eP-MED-DM_2024.01_PosoStruct - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **eP-MED-DM_2024.01_PosoStruct**

## Example Binary: eP-MED-DM_2024.01_PosoStruct

```

﻿<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="../FeuilleDeStyle/CDA-FO.xsl"?>
<?oxygen SCHSchema="../schematrons/profils/IHE.sch"?>
<?oxygen SCHSchema="../schematrons/profils/structurationMinimale/ASIP-STRUCT-MIN-StrucMin.sch"?>
<?oxygen SCHSchema="../schematrons/profils/CI-SIS_ModelesDeContenusCDA.sch"?>
<?oxygen SCHSchema="../schematrons/profils/CI-SIS_Modeles_ANS.sch"?>
<?oxygen SCHSchema="../schematrons/profils/terminologies/schematron/terminologie.sch"?>
<?oxygen SCHSchema="../schematrons/CI-SIS_EP-MED-DM_2024.01.sch"?>
<!-- 
    **********************************************************************************************************
    Document : ePrescription de médicaments et/ou de dispositifs médicaux (eP-MED-DM_2024.01)
    Auteur : ANS 
    **********************************************************************************************************
    format HL7 - CDA Release 2 - selon schéma XML (CDA.xsd) du standard ANSI/HL7 CDA, R2-2005 4/21/2005
    **********************************************************************************************************
    Historique :
    - 02/12/2022 : Création exemple avec posologie structurée
    - 15/09/2023 : Nouvelle version 2023.01 : Ajout de la Section FR-Document-PDF-copie [0..1]
    - 17/10/2023 : Modification du code de la Section FR-Document-PDF-copie
    - 19/11/2024 : Nouvelle version 2024.01
    - 20/08/2025 : Suppresssion des attributs author@typeCode, author@contextControlCode, assignedAuthor@classCode, serviceEvent@lassCode
                   Maj des codeSystemName en fonction de la nouvelle règle de nommage
                   Maj des références parties narratives / entrées
    **********************************************************************************************************
-->
<ClinicalDocument xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="urn:hl7-org:v3 ../infrastructure/cda/CDA_extended.xsd"
  xmlns="urn:hl7-org:v3" xmlns:pharm="urn:ihe:pharm:medication">
  <!-- 
    ********************************************************
    *              En-tête du document                     *
    ********************************************************
    -->
  <!-- Périmètre d'utilisation -->
  <realmCode code="FR"/>
  <!-- Référence au standard CDA R2 -->
  <typeId root="2.16.840.1.113883.1.3" extension="POCD_HD000040"/>
  <!-- Conformité spécifications HL7 France -->
  <templateId root="2.16.840.1.113883.2.8.2.1"/>
  <!-- Conformité spécifications au CI-SIS -->
  <templateId root="1.2.250.1.213.1.1.1.1"/>
  <!-- Conformité au Volet IHE Pharm suppl. PRE -->
  <templateId root="1.3.6.1.4.1.19376.1.9.1.1.1"/>
  <!-- Conformité au volet IHE PCC -->
  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.1.1"/>
  <!-- Conformité au modèle de document eP-MED-DM_2024.01 -->
  <templateId root="1.2.250.1.213.1.1.1.39" extension="2024.01"/>  
  <!-- Identifiant du document CDA -->
  <id root="1.2.250.1.213.1.1.1.39.2024.2.1"/>
  <!-- Type de document -->
  <code code="57833-6" displayName="Prescription de produits de santé" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
  <!-- Titre du document -->
  <title>Prescription de médicaments et/ou de dispositifs médicaux </title>
  <!-- Date de création du document = Date de rédaction de la prescription -->
  <effectiveTime value="20231201093000+0100"/>
  <!-- Niveau de confidentialité du document -->
  <confidentialityCode code="N" displayName="Normal" codeSystem="2.16.840.1.113883.5.25"/>
  <!-- Langue du document -->
  <languageCode code="fr-FR"/>
  <!-- Identifiant commun à toutes les versions successives du document -->
  <setId root="1.2.250.1.213.1.1.1.39.2024.2"/>
  <!-- Numéro de la version du présent document (entier positif) -->
  <versionNumber value="1"/>

  <!-- Patient -->
  <recordTarget>
    <patientRole>
      <!-- INS-NIR de test : 1.2.250.1.213.1.4.10 -->
      <id extension="279035121518989" root="1.2.250.1.213.1.4.10"/>
      <!-- IPP du patient dans l'établissement avec root = l'OID de l'ES -->
      <id extension="1234567890121" root="1.2.3.4.567.8.9.10"/>
      <!-- Adresse du patient -->
      <addr>
        <houseNumber>28</houseNumber>
        <streetName>Avenue de Breteuil</streetName>
        <unitID>Escalier A</unitID>
        <postalCode>75007</postalCode>
        <city>PARIS</city>
        <country>FRANCE</country>
      </addr>
      <!-- Coordonnées télécom du patient -->
      <telecom value="tel:0144534551" use="H"/>
      <telecom value="tel:0647151010" use="MC"/>
      <telecom value="mailto:279035121518989@patient.mssante.fr"/>
      <!-- Identité du patient -->
      <patient classCode="PSN">
        <name>
          <!-- Nom et prénom(s) de naissance -->
          <!-- Nom de l’acte de naissance -->
          <family qualifier="BR">PAT-TROIS</family> 
          <!-- Prénoms de l’acte de naissance -->
          <given>DOMINIQUE MARIE-LOUISE</given>
          <!-- Premier prénom de l’acte de naissance -->
          <given qualifier="BR">DOMINIQUE</given>
          <!-- Nom et prénom utilisés -->
          <family qualifier="CL">PAT-TROIS</family>
          <given qualifier="CL">DOMINIQUE</given>        
        </name>
        <administrativeGenderCode code="F" displayName="Féminin" codeSystem="2.16.840.1.113883.5.1"/>
        <birthTime value="19790328"/>
        <!-- Représentant du patient -->
        <guardian>
          <addr use="H">
            <houseNumber>28</houseNumber>
            <streetName>Avenue de Breteuil</streetName>
            <postalCode>75007</postalCode>
            <city>PARIS</city>
            <country>FRANCE</country>
          </addr>
          <telecom value="tel:0147150000" use="H"/>
          <guardianPerson>
            <name>
              <prefix>MME</prefix>
              <family>NESSI</family>
              <given>Jeanne</given>
            </name>
          </guardianPerson>
        </guardian>
        <!-- Lieu de naissance du patient -->
        <birthplace>
          <place>
            <addr>
              <county>51215</county>
              <city>DOMPREMY</city>
            </addr>
          </place>
        </birthplace>
      </patient>
    </patientRole>
  </recordTarget>

  <!-- Auteur du document -->
  <author>
    <!-- [1..1] Horodatage de la validation par l'auteur -->
    <time value="20231201093000+0100"/>
    <!-- [1..1] Identification de l'auteur -->
    <assignedAuthor>
      <!-- [1..1] Identifiant de l'auteur (Id RPPS du PS obligatoire pour les PS) -->
      <id root="1.2.250.1.71.4.2.1" extension="801234567897"/>
      <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
      <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
        codeSystem="1.2.250.1.213.1.1.4.5"/>
      <!-- [0..*] Adresse du PS -->
      <addr>
        <houseNumber>25</houseNumber>
        <streetName>Rue Berthollet</streetName>
        <postalCode>75005</postalCode>
        <city>PARIS</city>
      </addr>
      <!-- [0..*] Télécom du PS -->
      <telecom value="tel:0158432300" use="WP"/>
      <!-- [0..1] Identité du PS -->
      <assignedPerson>
        <name>
          <prefix>M</prefix>
          <given>Romain</given>
          <family>PIOU</family>
          <suffix>DR</suffix>
        </name>
      </assignedPerson>
      <!-- [1..1] Organisation de rattachement du PS -->
      <representedOrganization>
        <!-- [1..1] Identifiant de l'organisation de rattachement du PS (FINESS) -->
        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
        <!-- [1..1] Nom de l'organisation de rattachement du PS -->
        <name>Cabinet du DR Pierre JOLI</name>        
        <!-- [0..*] Télécom du PS -->
        <telecom value="tel:0158432300" use="WP"/>
        <!-- [0..*] Adresse du PS -->
        <addr>
          <houseNumber>25</houseNumber>
          <streetName>Rue Berthollet</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
      </representedOrganization>
    </assignedAuthor>
  </author>

  <!-- Personne à prévenir en cas d'urgence -->
  <informant>
    <relatedEntity classCode="ECON">
      <code code="SIS" displayName="Soeur" codeSystem="2.16.840.1.113883.5.111"/>
      <addr nullFlavor="NAV"/>
      <telecom value="tel:0647150100" use="MC"/>
      <relatedPerson>
        <name>
          <family>NESSI</family>
          <given>Sophie</given>
        </name>
      </relatedPerson>
    </relatedEntity>
  </informant>

  <!-- Personne de confiance -->
  <informant>
    <relatedEntity classCode="NOK">
      <code code="SIS" displayName="Soeur" codeSystem="2.16.840.1.113883.5.111"/>
      <addr nullFlavor="NAV"/>
      <telecom value="tel:0647150100" use="MC"/>
      <relatedPerson>
        <name>
          <family>NESSI</family>
          <given>Sophie</given>
        </name>
      </relatedPerson>
    </relatedEntity>
  </informant>

  <!-- Organisation chargée de la conservation du document -->
  <custodian>
    <assignedCustodian>
      <representedCustodianOrganization>
        <!-- Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
        <!-- Nom de l'organisation -->
        <name>Cabinet du DR Pierre JOLI</name>
        <!-- Coordonnées télécom de l'organisation -->
        <telecom value="tel:0158432300" use="WP"/>
        <!-- Adresse de l'organisation -->
        <addr>
          <houseNumber>25</houseNumber>
          <streetName>Rue Berthollet</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
      </representedCustodianOrganization>
    </assignedCustodian>
  </custodian>

  <!-- Responsable du document -->
  <legalAuthenticator>
    <!-- Date et heure de la prise de responsabilité -->
    <time value="20231201093000+0100"/>
    <signatureCode code="S"/>
    <assignedEntity>
      <!-- PS identifié par son N°RPPS -->
      <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
      <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
      <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
        codeSystem="1.2.250.1.213.1.1.4.5"/>
      <!-- Adresse du PS-->
      <addr>
        <houseNumber>25</houseNumber>
        <streetName>Rue Berthollet</streetName>
        <postalCode>75005</postalCode>
        <city>PARIS</city>
      </addr>
      <!-- Coordonnées télécom du PS-->
      <telecom value="tel:0158432300" use="WP"/>
      <!-- Identité du PS -->
      <assignedPerson>
        <name>
          <prefix>M</prefix>
          <given>Romain</given>
          <family>PIOU</family>
          <suffix>DR</suffix>
        </name>
      </assignedPerson>
      <!-- Etablissement de rattachement du PS -->
      <representedOrganization>
        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
        <name>Cabinet du DR Pierre JOLI</name>
        <addr>
          <houseNumber>25</houseNumber>
          <streetName>Rue Berthollet</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
        <standardIndustryClassCode code="AMBULATOIRE" displayName="Ambulatoire"
          codeSystem="1.2.250.1.213.1.1.4.9" codeSystemName="TRE_A01_CadreExercice"/>
      </representedOrganization>
    </assignedEntity>
  </legalAuthenticator>

  <!-- Participant : PS remplacé (obligatoire si prescription faite par un PS remplaçant) -->
  <participant typeCode="CON">
    <functionCode code="CORRE" displayName="Correspondant" codeSystem="1.2.250.1.213.1.1.4.2.280"/>
    <time nullFlavor="UNK"/>      
    <associatedEntity classCode="PROV">
      <!-- [1..1] PS identifié par son N°RPPS -->
      <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
      <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
      <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
        codeSystem="1.2.250.1.213.1.1.4.5"/>
      <!-- [0..*] Adresse du PS -->
      <addr>
        <houseNumber>25</houseNumber>
        <streetName>Rue Berthollet</streetName>
        <postalCode>75005</postalCode>
        <city>PARIS</city>
      </addr>
      <!-- [0..*] Télécom du PS -->
      <telecom value="tel:0158432300" use="WP"/>
      <!-- [0..1] Identité du PS -->
      <associatedPerson>
        <name>
          <prefix>M</prefix>          
          <given>Pierre</given>
          <family>JOLI</family>
          <suffix>DR</suffix>
        </name>
      </associatedPerson>
      <!-- [1..1] Organisation de rattachement du PS -->
      <scopingOrganization>
        <!-- [1..1] Identifiant de l'organisation de rattachement du PS (FINESS) -->
        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
        <!-- [1..1] Nom de l'organisation de rattachement du PS -->
        <name>Cabinet du DR Pierre JOLI</name>        
        <!-- [0..*] Télécom du PS -->
        <telecom value="tel:0158432300" use="WP"/>
        <!-- [0..*] Adresse du PS -->
        <addr>
          <houseNumber>25</houseNumber>
          <streetName>Rue Berthollet</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
      </scopingOrganization>
    </associatedEntity>    
  </participant>

  <!-- Participant : Exécutant et/ou Date d'exécution souhaitée -->
  <participant typeCode="PRF">
    <!-- Date d'exécution souhaitée -->
    <time xsi:type="IVL_TS">
      <high value="20231202093000+0100"/>
    </time>
    <!-- Exécutant (obligatoire si prescription de TSO sur ordonnance sécurisée, nullFlavor possible dans les autres cas) -->
    <associatedEntity classCode="PROV">
      <!-- [1..1] PS identifié par son N°RPPS -->
      <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
      <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
      <code code="G15_21/A" displayName="Pharmacien titulaire d'officine" codeSystem="1.2.250.1.213.1.1.4.5"/>
      <!-- [0..*] Adresse du PS-->
      <addr>
        <houseNumber>12</houseNumber>
        <streetName>Rue des produits de santé</streetName>
        <postalCode>75005</postalCode>
        <city>PARIS</city>
      </addr>
      <!-- [0..*] Coordonnées télécom du PS-->
      <telecom value="tel:0158410697" use="WP"/>
      <!-- [0..1] Identité du PS -->
      <associatedPerson>
        <name>
          <prefix>M</prefix>
          <given>Lucien</given>
          <family>SAMPAIX</family>
          <suffix>DR</suffix>
        </name>
      </associatedPerson>
      <!-- [0..1] Etablissement -->
      <scopingOrganization>
        <!-- [0..1] Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1750512302"/>
        <!-- [0..1] Nom de l'organisation -->
        <name>Pharmacie SAMPAIX</name>
        <!-- [0..*] Coordonnées télécom de l'organisation -->
        <telecom value="tel:0158410697" use="WP"/>
        <!-- [0..*] Adresse de l'organisation -->
        <addr>
          <houseNumber>12</houseNumber>
          <streetName>Rue des produits de santé</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
      </scopingOrganization>
    </associatedEntity>    
  </participant>

  <!-- [1..1] Acte documenté : prescription -->
  <documentationOf>
    <serviceEvent>
      <!-- Identifiant de la prescription EPU : root="1.2.250.1.215.500.1.1" + extension calculé selon la règle fournie dans les spécifications de la Cnam -->
      <id root="1.2.250.1.215.500.1.1" extension="01S2TBPZ2JCNZZYGHZ"/>
      <code code="57833-6" displayName="Prescription de produits de santé" 
        codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"></code>
      <!-- Période de validité de la prescription -->
      <effectiveTime>
        <low value="20231201091000+0100"/>        
        <high value="20240730091000+0100"/>
        <!--  <high nullFlavor="UNK"/> -->
      </effectiveTime>      
      <!-- La personne ayant exécuté l'acte -->
      <performer typeCode="PRF">
        <assignedEntity>
          <!-- PS identifié par son N°RPPS -->
          <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
          <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
          <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
            codeSystem="1.2.250.1.213.1.1.4.5"/>
          <!-- Adresse du PS -->
          <addr>
            <houseNumber>25</houseNumber>
            <streetName>Rue Berthollet</streetName>
            <postalCode>75005</postalCode>
            <city>PARIS</city>
          </addr>
          <!-- Coordonnées Télécom du PS -->
          <telecom value="tel:0158432300" use="WP"/>
          <!-- Identité du PS -->
          <assignedPerson>
            <name>
              <prefix>M</prefix>
              <given>Romain</given>
              <family>PIOU</family>
              <suffix>DR</suffix>
            </name>
          </assignedPerson>
          <!-- Organisme représenté -->
          <representedOrganization>
            <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
            <name>Cabinet du DR Pierre JOLI</name>
            <!-- [0..*] Télécom du PS -->
            <telecom value="tel:0158432300" use="WP"/>
            <!-- [0..*] Adresse du PS -->
            <addr>
              <houseNumber>25</houseNumber>
              <streetName>Rue Berthollet</streetName>
              <postalCode>75005</postalCode>
              <city>PARIS</city>
            </addr>
            <!-- Cadre d'exercice du PS -->
            <standardIndustryClassCode code="AMBULATOIRE" displayName="Ambulatoire"
              codeSystem="1.2.250.1.213.1.1.4.9" codeSystemName="TRE_A01_CadreExercice"/>
          </representedOrganization>
        </assignedEntity>
      </performer>
    </serviceEvent>
  </documentationOf>

  <!-- [0..1] Prescription bizone -->
  <documentationOf>
    <serviceEvent>
      <code code="MED-1096" displayName="Prescription bizone" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf>

  <!-- [0..1] Prescription médicaments d'exception -->
  <documentationOf>
    <serviceEvent>
      <code code="MED-1097" displayName="Prescription médicaments d'exception" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> 

  <!-- [0..1] Ordonnance sécurisée -->
  <documentationOf>
    <serviceEvent>
      <code code="MED-1098" displayName="Ordonnance sécurisée" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> 
  
  <!-- [0..1] Prescription grand appareillage -->
  <documentationOf>
    <serviceEvent>
      <code code="MED-1132" displayName="Prescription grand appareillage" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> 
 
  <!-- [0..1] Exécution à domicile --> 
  <documentationOf>
    <serviceEvent>
      <code code="MED-1094" displayName="Exécution à domicile" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf>
  
  <!-- [0..1] Prescription en urgence -->
  <documentationOf>
    <serviceEvent>
      <code code="MED-1095" displayName="Exécution en urgence" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf>

  <!-- [0..1] Affection militaire -->
  <documentationOf>
    <serviceEvent>
      <code code="MED-1159" displayName="Affection militaire" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> 
  
  <!-- [1..1] Contexte de la prise en charge -->
  <componentOf>
    <encompassingEncounter>
      <code code="AMB" displayName="Ambulatoire (hors établissement)" codeSystem="2.16.840.1.113883.5.4"/>
      <effectiveTime>
        <high value="20231201093000+0100"/>
      </effectiveTime>
      <location>
        <healthCareFacility>
          <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
          <code code="SA07" displayName="Cabinet individuel" codeSystem="1.2.250.1.71.4.2.4"/>
        </healthCareFacility>
      </location>
    </encompassingEncounter>
  </componentOf>

  <!--*********************************-->
  <!--   Corps structuré du document   -->
  <!--*********************************-->
  <component>
    <structuredBody>
      
      <!-- [1..1] Section FR-Code-a-barres -->
      <component>
        <section classCode="DOCSECT" moodCode="EVN">
          <!-- Conformité FR-Code-a-barres (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.223"/>
          <id root="F28128CA-1D38-11EC-9621-0242AC130002"/>
          <code code="57723-9" displayName="Numéro de code à barres unique"
            codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
          <title>Code 2D de la prescription</title>
          <text>
            <renderMultiMedia referencedObject="Code2dPDF"/></text>
          <entry>
            <observationMedia classCode="OBS" moodCode="EVN" ID="Code2dPDF">
              <!-- Conformité CDAObservationMedia (CCD) -->
              <templateId root="2.16.840.1.113883.10.12.304"/>
              <!-- Conformité FR-Image-illustrative (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.103"/>
              <value mediaType="image/jpeg" representation="B64">iVBORw0KGgoAAAANSUhEUgAAAPUAAADZCAMAAAG4BraMAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAI6UExURQAAAOzs7CwsLFNTU6CgoO3t7cfHxwcHB1RUVO7u7i4uLsjIyFVVVQAAAKKiou/v7y8vL8nJyVZWVqOjozAwMMrKyldXV/Hx8TExMcvLywsLC1hYWKWlpfLy8jIyMn9/f8zMzAwMDFlZWaampvPz8zMzM83NzQ0NDVpaWjQ0NM7OzltbW6ioqPX19TU1Nc/Pz6mpqfb29jY2NtDQ0BAQEPf39zc3N9HR0REREaurqzg4OIWFhdLS0hISEl9fX6ysrPn5+Tk5OdPT062trTo6OoeHh9TU1GFhYa6urjs7O4iIiNXV1RUVFfz8/Dw8PNbW1hYWFgAAALCwsP39/QAAAD09PWRkZLGxsf7+/j4+PouLi9jY2BgYGLKysv///z8/P9nZ2QAAABkZGWZmZrOzs0BAQI2NjRoaGrS0tNvb2xsbG2hoaLW1tUJCQo+Pj9zc3BwcHGlpaba2tkNDQ5CQkN3d3R0dHWpqare3twAAAERERN7e3h4eHri4uEVFRZKSkh8fH7m5uUZGRuDg4G1tbbq6ukdHR+Hh4SEhIW5ubru7u0hISOLi4iIiIm9vb7y8vElJSZaWluPj4yMjI3BwcL29vQAAAEpKSpeXl+Tk5HFxcb6+vktLSyUlJb+/v0xMTObm5gAAAMDAwAAAAE1NTefn5ycnJ3R0dMHBwQEBAU5OTpubm+jo6CgoKMLCwk9PT5ycnOnp6cPDw1BQUJ2dnerq6ioqKsTExJ6enuvr6ysrK3h4eMXFxVJSUg9nUzYAAACidFJOUwD///////////////+4/////////////////////////////////////////////////////////////////////////////////////////3b//yL///////////////9Y//////////////////////////////+W/////////////////////////////////////9z/////////////PJ60fsMAAAAJcEhZcwAAFxEAABcRAcom8z8AABfLSURBVHhe7Z2PgyTFVcdHOZGIk2SVU+QMRu5AQmQBjYTEH6fHSSQgOLmJdozb3hBWQ8SQH65kOE1yCdGDaEgCLpIThrE2QSAGJODpGf433/u+b3VX9fSPme3e251jP3AzVa/ej3r9o7q6p7u3B5IyrAlQEsM2hZIYtilJ4jJS+yq2nzhzJnEb7oxLXKLFmXYxwX+p/NNCWbtI04r2VDC5FQvtK8CtulUWi/YuzXO4ApHYpkg7RNKGougW2mmty8W5q0v6N3HJZOImSbI1mfxNKt9xu2Eh6IdtSib2H7P+ZcFIAxZ+eq+Ui+1cvlxOFe3svzLj31oYRmtsU7yRoKrvnl0+JbBNoSSGbZ5hrzfWL9frDTZNVEpJ28C5kZj3nDroq2Sz51RguN5InKKgH31VmfadVbuACRVgo0BBATYKFBRgo5AkB2zZ64ftf8V22edOueTUfW4jPXrmjOyFxXbnTsrKPSf2R0vt0a5rt7zd9jl3XLaP+233i9rfsH3O/fLqiu1/RXvx+Kz1X53P2B+QwCd1K5M9TeJjc2SjoLuf2qoYW7fqxfZbE/cJ2f/uStYmkzXZCQrtRD1YDwQ2CuifSrFs30Sx2D/L/x6JfT96X2y35cvdb9a/tau8Yv0J0n5OPiS+1qL2V81IW9JfRRpxexlsFCgowEbPuNeX/cLpTjE1yZwMdUeSPW+EPXPUc4Oh7qTwZOhuKS3Y46a9wQDVoL0TmNU80CKCTfNAiwiV20oybDMTsDl4as0PWLNg5rItwPxoLlVoEaFyMZcxXjYzKPqtTM2tuIi5RH1NzRBdpfOY6y6Co4f+/2taR/RMWm+eo7rHbV+iRKk1jwgNYmgRofIDTg7aa2tr751MJmYuhcmWe8/E/fNakk4aomO0gRk6r+mqVKtXy6fmo9AiQuVY776/9i25W8W+AS0iVM5FJ8OrcU6FKCU36CKkB1pEqNxGbiNZXZVP5+T/1dvgwsloXmt+QNMFoivdvUdsNPOPpOm90mTLpjb3mY02o7nzs+ZQF1SaVWgRoXJd8nKwPHNKzZ3b+A2RbSTpmavUWBvOqFaNeU4eEDusLPlsndIiAg3zQYsINs0DLSLYNA+0qEBH8j5mazLs+xF9MKybvrVGDk4Syh9SBg6d0PJIQk+1It1AT2SFLHgo22m4UOeBFiFsmQdahLBlHmgRwpZ5oEUIW+aBFiGQY/8y8uNCKH21lTUmYLQIMetH8ZUkR806kWm0WlOaNlrbWCLWyYYMLPe5UxtqvQZpszU6CGsr2tDyRS2eWNA66/ni1pJ48ppWtmOdHdAWscZhxVu7a/VYItYmbbL+DtTkZIXWeuIi1pQ2Wed4a/Q8o9bajqVAurm6KidFB3lWZLxRZx3CLRWLLoYWIZBD376l5xEifbFpO5d5z5bMg2TyY9a36TxIpHe7tbVka6txjaHHWob1cUhtfTfuJTpR8PnKMhdU6utNW0vBmiJfF+vXVUSLEBWz5zegTGtLw3pOaBECuS61p8XazxlFhEU4+daaWG9pXaBFCOToo1jbt4VDJqe1Dy8yPC1CrCEAPT+n+XpOsIUWIZBze1SSVDbSlZfdwYO6xdK6fks1LSCBWZKifTfu3/Eeqp3mh3zq2sRqoEWIWcejQ2xN21pr0RVFjooRjct8xvpOdCVN/0GlC8fGXiLYqMgKLUIgD625pao0p2kPzY5EqXtwQ0QbGyKCpTbgVJMWISpWawPW0gcNjA+rGLQIgRxaBqyz0cE+FhqRhStNyo+0/ug/H7QIYcs80CKELfNAixC2zAMtQthSymf5TWhRik2nh73eZl++cXl17MZDTrmbGOPakFj39bLuotbKjp5JxGTnL6PedKyXqvTUQU82+lqcuqElIkinrF/BFSy36cQwO/swZyNcB+tN5cxkOMZlMmuTT1scHhOKf9cTP/LpT1ukQYtiq+tAPe5TDjfmjqHzBqjcMXTeAJU7hs4boHLH0HkDVNaJQiklLbXKBp03QOX4ClAATpZiSkQGDnuAzhugMmJfz+57Pin+skDXpentVjLRJ6nkEVGb2DoZoCcsP/3VKIv9ozT9kZVMpPMKqqpyB7Fx2Q+c9LEFhleyusTG1Aqc2NnYjxw69Ih8HT58+MLHPqeTf5At852PrV65ToVMdOFiW2BbAllsXQdGJ7EjotjH8+m7jx3SNnYZhdhW0c8SljJ2JXEg6cUc0HkDVE6S5896rH65r8SxnzOx56Apm/R5qwh03gCVw2VuqfH3nMoFbFwB3fRFVNqs7++gwFiyjxl57OJ2zv0bfVXRtmO/7txfocBYX9Ud2u/SxrVoF1S0xhNtid36WJKRx1Ky7TwkV5FlrpWWY0uU912WtGD1LDYr1hbmzXGP0HkDVC6sb7vuZZTFNsL1HUPnDVC5MLZIbP+7pQe/Xyoa3jitP6hpbN3Oox7QeQNUDvdv4V3Z/n327HPiXvbfdyTJsfV1OT/OY//U+vp75Gt9fV3U6Mag8waoXEO+mPX4Xb6/++tCHjpvgMo147kwE06kuAXG0/4YWoZEkQ2YlQwRvcQiEKW7+dMOoPMGqIzYTcdvJVvmdvy2bW0GOm+Ayj52Pm/5eDZfK8k7omT4ofMGqDwbuzhXrMb6tsOxs2MJCeeKMXTeAJVrYqeHDl0js3Lha1RVkfJnpilY/T/Y3GFsfEZUrIM2+5jE5lFCkHIeW7AxlR2R9nz/Nn0BGoDOG6AyYl9/LObT6tjH/tljxzYk6Pnz5yWGNH5ISufPPwkV5Y1jx96GgkLnDVAZscvIYgsl8/Ns/1bRtpc5l1uRqMU0haySS/OSQOcNULlj6LwBKncMnTdA5Y6h8wao3DF0vjibuB4sX643HNhV5oF+6AXlvnxog3NDveW53xtM3QLX2psQ124qvvUu0eFAokiooYaTtrFeqtYGKbmRdLFvN4F2xqbDpW/LW9Md9jRd5K1htaEn3bO8u419UYPlJutxOOrJ//rrg190/DFD16atZP+vpzfbT0f4BWM6HGxijViLfPSnw7GuAXUQWc0i607WmDiRELpSIdS7x1CSjzy2lLEpozwd4T4vjatb4lh3iQG2DzVA/32PdWstxZqFEfYRVGVZyEale5hUR1o1Fd3y3Vj+jbC45KOPnMey63kstrax/zCA+T57B46/XUPvtVC1a+i9Fqp2Db3XQtWuofdaqNo19F4LVbuG3muhatfQey1U7Rp6r4WqXUPvtVBV0Cl9CSUNNboeeq+FquINx6AZLk2Sx1n0PJ4kl7JYYLGzEapWhl5JkrMses4myQqLBZYzNFdZhojy0FYXGNpUMjZURF/bCc0yKYT2C8aHphY5FonovRaqZqGZgzATuph1oCz2rUOnH8UNbIplKaFv2dh4WUoiks+XNzZu8aFTUxS+1EVou01OyUILayYS1lBnaBMJ0s+LNPQ1h66RzxcOH/7+BQ+dhco2s4s6tOw8D2Z14QKGfsK5b9q+K58vXdDQMqTw3mlhsnOhvwxXSjG0Jf5vpaG/3EHoioFUQgftPnSk3D50SFlog6FD2oYuUBJaxQwd80C70CUUQz+CCZKGLmFnQ+dbeAnLFzp8uCDgCEK/bxUPGcjn6ysrP58kR9hagJ4Eeq+FqnVI6Bw7aDZC77VQtY6dD22/ZAt3hHVZulHo3zRxhuneElYUeq+FquFmdiis22ZWjW1ZOhPOKgq910LVXQ/9MX3OZ/KNNbCFyskwtIkEfS56a7Iln6L4TJJ8dzL5c6m0CG2mh6UU+slDZyIbw7lgDkPUyeFjD4Q2qkP7s5GbodUiNKcCAkMbcn4toV/STvh2IR9IRfozzv1lq6lCThQ6G8MjgtBJcqjtBKk26zy0JZ9fVbCsP5Umv6UVKrVa1xrBKIT+inNPWAcEje3XtdapI9B7LVSdCY2SEYW2g6bB0LaFx9B7LVQNQ38gKxmvOfcKizsXGqPZlt5LKDsthi3lJ6Uu45j15vK1tU9QjkdFLbSMZg+j2UPvtVA1S4GEk2ySLYh1CryWhJYx/DxbDXqvhaq7Gjo/Xith/YPO/Z58Se/W19ffFYaWunz+9/r6D587G8yOBHqvhap1ZFu4piizlDx0hgwpMfReC1Xr2PnQnFUWkBnpL6yufgjlgxLkL1ZWrnXuKpuhZkjoG0WBngR6r4Wqxc0sw9zll3GM1YJ++5PcEnY3tAzOX2DNc2s2gBufT5NT8tUitB4CQkQkoR937utWEU6n6eetlKncLl/qoIPDRwZD2xbO0PkWDmWVdnX4QCogC92UtYTWEv0Y9F4LVX3o9G/hVrFR0tb150xUjoR+yLkn6ceg91qomoWuvmRXSSeHj+2F/kCa/pNzz0LRQ++1UHW+0LpKQ0wqfEYqUPTQey1UnTM0Khl56HZj+J4MfcehQ9+wm0upmiQP4F5SvT5uXHUNBHkH6L0WqtaFjmakRn4KELGsoZMv8Tec4BcfCf1Hpzb09QXCd/GLz69LO4Ipd5u+0C50PpKayEIr5pfzcGk3qXDY9AVoAHqvhap56ICa0NZodHL4uMPu4PXcIaI8tDSK2sPnz4voRmnEnbznpcFCp2KAAqD3WqgaZhGRhxaypYJTey2olYV+f9h+YUN3P0GKfrXPXOv5dRb67RC1yDqYJESEDdQ0UaGUixR6r4WqXUPvtVC1a+i9Fqp2Db3XQtWuofdaqNo19F4LVbuG3muhatfQey1U7Rp6r4WqCxPP+Geg94WxW27HAzeV4kDvT4do4Aa9vhsOsgZIZfyEUSeIK731eKw3n1t5rHdID/W1MHrXOho2e9In1ZWP8A0w7ZA89HZjcYhQWhXZyF6KrqG1gaHRuQ5D4391CMd9Wwh6O/lIoiH0TmWNVahLGa7xLIKIhrKux1KX0NowytZ1p6GNSoedR9pnZxnI5jEYjlxvNMWd/bICsc24nj5qMLBHAnSjQsE29qGuZYjlf32KAC380K/N3hQPA6genkPAkwpFBoOB7h54P5QTG9H2Dy2IhKFHCC1DSPAchAWxZxK0lD0HgQaVDLLQ5c9B6F6JRzW8B/nfdiqNgtA6lPis0TK1rFHGt5TMu+74I316wmL55x9Ms4julYXQVhmpNbMe+peFwYcuTC2iIp/6mi6reAn7gC6KGxPPIGH1dV5QVhXR1mXb07EqCz0dWWjE1D7JiCYLC43SvMluMIR+6T8funRFC5oxQvuxKxu29JMLnA/UQKjPo9hLwfSBFJGpHAM8nj0Re5XYM2AWWsWQ7bPPPrsMZ7PLAfvcHvpbDtjn9tDfcsA+t4f+lgP2uT30txywz+2hv+WAfW4P/S0H7HN76G85YJ/bQ3/LAfvcHvoLeeDAAuA98cnzrFVhr8Z7g7W5eAAmMexze+gvIK14oUw5K/oLSJr/SlTOWWhV/DRazoHgpxUP+9we+gt4a2d9/WOP1vDY06ZVkvVlavjYb7MGoqyfrnf8XtPanayfKokaYH8DsjTrcxBdzhqIsj5a6znVX0uF3cn60dq+NWfN9+say5b1iVkgL2T9IjDRa2qEP/ojWENJ1qk5CzH57mednshvSMv4OFrCrPmbtz5jWeRBa4JSmHX6MauE3Kd574ms81thMk6iJcoapGW3qa0F7VHW+Zv6Ms5cNFmfrlrXF1vW1yHP66xiPA6Tizrrucbw/aw9S5Z1evAK5XduukE5ol6SIyjfZEP1xZm1zVL4cE6I/tVaYT/rvZ91kpw6OcPvQqsy6/TnnlVuN/tnYHIjGsKsk2+jIeIUtPZC1lXUZG0vbD4+Yx9nXcV+1kXY5/bQXwCzfvpoPS9AqzHrc1D+LzQw6xcgqkRfQizsTtZz0pB12Wg2H/tZe9jn9tBfQPo6487FpUHWfGJcXwrg3D1W+SYqT0Cr4g1t5bx+YbMObhCfB1hY1mUE59fbcFyAfW4P/bWjJuvg/Lo97HN76C+EyzqCTYAiAkl11n9PtSrgkVBEKAxhn9tDfwHpq+xwwJtBH4KnHIVwv94G/xk6fohC8GpJ2uxze+gvoGwMDx5YS9LoD7WEY/g2uCJ0vMHLjWAPHLl+mlsd+DsKQct1fTV9InC0rncn61f+kB1SboaI/COFBkxKsv4o2wP0lR/C/ah83SrG280NYO67k3U4D0+jF5vgTDOiLOuGeXh8pnk4V947Zx9vgayT759T+IwoiLO++s7jOXchBcv6ThiS95tpgM/6e2p/5/tQftaUH4bLy3bxqkIJcdYRs/PwSsrm4TaGp4dQ2c1rKSW8FbKu3sLfGW7bRriFl2V9F5y9Q4vpXbRRyrbwm6G1gfbjn7uwWdeMZjeU9ESpzjo804yoHM3qYJ/bQ38Bb+mso1nKL0HErCkL+Vc033rEanBjpPZHYV+zhpDoRUOWNVtgWAr73B76C2DWZSDr+OyjhB9EaYM72RTwL2i41yrImrOyJ6vTZp/bQ38BjVkX/0xkEfzOFRGvWOM0fOkfABMsazv70D9OVgH73B76Cyg70yTvRufmW9dYlQLKJVn/O1q5ro+i8gzKu7Ouy/ZbT1X7D9DfV1iDkoncn2itLOsSPpWbl8M+t4f+2lEyhvtfcnEFac6sMUupg31uD/2F2BKfF1g8gV7ra8cz9MVswhdQ+WurNGBZw0BQxwXY5/bQX8A2rgyzp2X3IIXoa9KEy1idwWakPAu/wFeGa8bwEjAPN0rvxglZtSUU/VnakN2ch+9e1p9B1voSGGF3sl7o171jbwqXPGot37MW4/8g0jcJOXfbJVD7NETGn6LBPYXK/1r8Y6h8FZUY9rk99BfArNv+kktKxvDgl9xoltIM+9we+gvYzzpJ1r44w7eRSJh18hOnha99y9rtzJlcAdFtrIF3QmR80EQ2I33+Kyr64+olwD63h/4Cwqy3db/ZNtgD8/D9rLef9VW48a6aX6Ee+H29P++m01dqwyXLnPXs9fCIyvvN6mCf20N/AftZz5u1TbCj1xNfOZuBaZHody7jSTYZNAphn9tDfwHbyDq1Fw7qO4Jz1FfEYvel7M7v1wtlXXmNNKTsV4BqdmcezqzvQyVi9mkXZh1eS/EEovgRryb+J3JjsM/tob+AMGup8amjAJOXZM3nmMKrhekWRLwebuYl51y/OPsEFQwKsM/tob+AOOsqyrMGUdazvwKUnWnumXn4U9w2q/gItMqyXjEFc2ZDNe6y81v7DyGKiLKmGmsh7HN76C+AWc9JSdbGrUw7T8Hv139AmcLLRUHW6fM/DtHu7NdzUpl1w70KRsmZ5vJcQboIsu7oDQMPoiGCbxgIrw39mInCH8vfZqIL/IaBPQz73B76Ww7Y5/bQ33LAPreH/pYD9rk99LccsM/tob/lgH1uD/0tB+xze+hvOWCf20N/O8hD7sMsKYc/myQfdg+xtiDs8/KxiffsLgduU1+8O2JtrFV9gzxe2juc6vt3x3jjuDT2pU0rQzeQ70FvaAVaIOsBdLUCaeR7D9HHC5xH9qJiSUr6qd1FZrJI8HJiEY6cphIq6mJA1t7CZz21NDf7WtHCHtwEpHMhY1QlJWRtqWdsumlJ1t6imPV4D2eNLXyaZTd2koTfirUBmUyxcUOu/3oizbP2Fj5r+Sdp2xa+Z7OOse11ERa32Hu8NbPeZznQv9hi3xxn8Qb8bKDq26iCV+HrUCSDkiADD96LD2SIBjosmx7MfRGjlHx5jxytp9qkzoc6MuJ7gMhAxnQiBXvJ/9T08Kb+7Aig9PVIAF1zOA/Se3jTrJ3MIDh8juDS++GIKl+YePiAmFmobnZU9kct7QkYS5sduPxiRdasDMW9Lh2196aaAgv6B3TUr0a3WJavqOAQYOUs1ijz0IjE156hH7IERtIr5EAPlvVY/7ZLAA5Jvic+a82mkPXQ91LwndSsub6BmOBQ503zvkOsyHrRY5oka3GNYtb5wmpGs9VAflVkOYRZK7oRoUV6w1zirPvy5TdrSwqL0/DbsWUdTjiRrbQy68KKNnQmq1hgRJgWsl5gRQuWrdvMsh6iR/bJrJmW6OIjWxBx1ra55rGDFT2yIjYjrOd8uWFarnmh2yUrWsk7EKyaKOtFVrRAR8E2rCsi673Ftkx1+hR1Js5aAwdZY7IF8vR1z7C9QzcMXWvZUCCjFv4QlpaFYDMRfNaqpV999RhkHfVqn3322WeffZabXu//AS3VCdC2i9MjAAAAAElFTkSuQmCC</value>
            </observationMedia>
          </entry>
        </section>
      </component>

      <!-- [0..1] Section FR-Prescription-medicaments : Prescriptions de médicaments -->
      <component>
        <section>
          <!-- Conformité Prescription Section (IHE PHARM PRE) -->
          <templateId root="1.3.6.1.4.1.19376.1.9.1.2.1"/>
          <!-- Conformité FR-Prescription-medicaments (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.171"/>
          <id root="4A402640-1CF6-4153-B5BA-D56B623004C8"/>
          <code code="57828-6" displayName="Prescriptions" codeSystem="2.16.840.1.113883.6.1"
            codeSystemName="LOINC"/>
          <title>Prescription de médicaments</title>
          <!-- Bloc narratif de la section (Prescription sous forme textuelle) -->
          <text>
            <!-- Médicament 1 -->
            <table border="0">
              <thead>
                <tr>
                  <th>Durée du traitement</th>
                  <th>Médicament</th>
                  <th>Fréquence d'administration</th>
                  <th>Dose prescrite</th>
                  <th>Rythme d'administration</th>
                  <th>Voie d'administration</th>
                  <th>Substitution</th>
                  <th>Nombre de renouvel.</th>
                  <th>En rapport ALD</th>
                  <th>En rapport AT/MP</th>
                  <th>En rapport Prévention</th>
                  <th>Non remboursable</th>
                  <th>Hors AMM</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>du 01/12/2023 au 06/12/2023</td>
                  <td>
                    <content ID="med-001">PARACETAMOL MYLAN 500 mg, comprimé</content>
                  </td>
                  <td>
                    <content ID="med-001-frequence-1">3 fois/j à partir du 01/12/2023 pendant 2 jours</content>
                    <br/>
                    <br/>
                    <content ID="med-001-frequence-2">2 fois/j à partir du 03/12/2023 pendant 4 jours</content>
                  </td>
                  <td>
                    <content ID="med-001-doseMin-1">1 cp</content> à <content ID="med-001-doseMax-1">2 cp</content><br/><br/><br/>
                    <content ID="med-001-doseMin-2">1 cp</content> à <content ID="med-001-doseMax-2">2 cp</content>
                  </td>
                  <td>
                    <content ID="med-001-rateMin-1">1500 mg/j</content> à <content ID="med-001-rateMax-1">3000 mg/j</content>
                    <br/>
                    <br/>
                    <br/>
                    <content ID="med-001-rateMin-2">1000 mg/j</content> à <content ID="med-001-rateMax-2">2000 mg/j</content>
                  </td>  
                  <td><content ID="med-001-voie">Voie orale</content></td>  
                  <td><content ID="med-001-substitution">Non (Marge thérapeutique étroite)</content></td>                                
                  <td>3</td>
                  <td><content ID="med-001-ALD">Non</content></td>
                  <td><content ID="med-001-ATMP">Non</content></td>
                  <td><content ID="med-001-prev">Non</content></td>
                  <td><content ID="med-001-non-remb">Non</content></td>
                  <td><content ID="med-001-horsamm">Non</content></td>
                </tr>                
                <tr>
                  <td colspan="4">Précondition</td>                  
                  <td colspan="9"><content ID="med-001-precondition">-</content></td>
                </tr>
                <tr>
                  <td colspan="4">Instruction au patient</td>                  
                  <td colspan="9"><content ID="med-001-instrPatient">A prendre au cours d'un repas</content></td>
                </tr>
                <tr>
                  <td colspan="4">Instruction au dispensateur</td>                  
                  <td colspan="9"><content ID="med-001-instrDisp">-</content></td>
                </tr>
                             
              </tbody>
            </table>
            <br/>
            <!-- Médicament 2 : préparation magistrale -->
            <table border="0">
              <thead>
                <tr>
                  <th>Durée du traitement</th>
                  <th>Médicament</th>
                  <th>Fréquence d'administration</th>
                  <th>Dose prescrite</th>
                  <th>Rythme d'administration</th>
                  <th>Voie d'administration</th>
                  <th>Substitution</th>
                  <th>Nombre de renouvel.</th>
                  <th>En rapport ALD</th>
                  <th>En rapport AT/MP</th>
                  <th>En rapport Prévention</th>
                  <th>Non remboursable</th>
                  <th>Hors AMM</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>du 01/12/2023 au 06/12/2023</td>
                  <td>
                    <content ID="med-002">Préparation magistrale :<br/>- 30g de diprosone<br/>- 70g de Cérat Frais de Galien</content>
                  </td>
                  <td><content ID="med-002-frequence-1">2 applications/j</content></td>
                  <td>-</td>
                  <td>-</td>  
                  <td><content ID="med-002-voie">Voie cutanée </content>(<content ID="med-002-region">visage</content>)</td>  
                  <td><content ID="med-002-substitution">Non (Marge thérapeutique étroite)</content></td>                                
                  <td>0</td>
                  <td><content ID="med-002-ALD">Non</content></td>
                  <td><content ID="med-002-ATMP">Non</content></td>
                  <td><content ID="med-002-prev">Non</content></td>
                  <td><content ID="med-002-non-remb">Non</content></td>
                  <td><content ID="med-002-horsamm">Non</content></td>
                </tr>
                <tr>
                  <td colspan="4">Précondition</td>                  
                  <td colspan="9"><content ID="med-002-precondition">-</content></td>
                </tr>
                <tr>
                  <td colspan="4">Instruction au patient</td>                  
                  <td colspan="9"><content ID="med-002-instrPatient">Diminuer la posologie progressivement une fois la poussée traitée. Par exemple en appliquant la préparation une fois par jour pendant 5 jours, puis 1 jour sur 2 pendant 5 jours environ avant d’arrêter.</content></td>
                </tr>
                <tr>
                  <td colspan="4">Instruction au dispensateur</td>                  
                  <td colspan="9"><content ID="med-002-instrDisp">-</content></td>
                </tr>                           
              </tbody>
            </table>
          </text>
          <!-- [1..*] Entrée FR-Traitement-prescrit : paracétamol -->
          <entry>
            <substanceAdministration classCode="SBADM" moodCode="INT">              
              <!-- Conformité Medication activity (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.24"/>
              <!-- Conformité Medications Entry (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7"/>
              <!-- Conformité Prescription Item (IHE PHARM PRE) -->
              <templateId root="1.3.6.1.4.1.19376.1.9.1.3.2"/>          
              <!-- Conformité FR-Traitement-prescrit (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.83"/>
              <!-- [0..1] Conformité Posologie structurée : uniquement si posologie structurée -->
              <templateId root="1.3.6.1.4.1.19376.1.9.1.3.6"/>
              <!-- [0..1] Conformité Mode d'administration : Doses progressives (avec FR-Traitement-prescrit-subordonnee) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.8"/>
              <id root="AADC9C14-F1CA-4177-B2C8-A5178D5B3CA0"/>
              <code code="DRUG" displayName="Médicament" 
                codeSystem="2.16.840.1.113883.5.4"  codeSystemName="HL7_ActCode"/>
              <text><reference value="#med-001"/></text>
              <statusCode code="completed"/>
              <!-- [0..1] Durée du traitement -->
              <effectiveTime xsi:type="IVL_TS">
                <low value="20231201"/>
                <high value="20231206"/>
              </effectiveTime>
              
              <!-- [0..1] Fréquence d'administration : uniquement si posologie structurée -->
              <!-- non renseigné ici car doses progressives décrites dans des <substanceAdministration> subordonnés -->
              <!-- <effectiveTime xsi:type="PIVL_TS" operator="A"> -->
              
              <!-- Nombre de renouvellement(s) possible(s) -->
              <repeatNumber value="3"/>
              
              <!-- [0..1] Voie d'administration : uniquement si posologie structurée -->
              <!-- Voie d'administration : Terminologie EDQM - Standard terms / classe ROA (Voie d'administration) -->
              <routeCode code="20053000" displayName="Voie orale" codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="StandardTermsEDQM">
                <originalText><reference value="#med-001-voie"/></originalText>
              </routeCode>
              
              <!-- [0..1] Région anatomique d'administration : uniquement si posologie structurée -->
              <!-- valeur issue du jdv-human-substance-administration-site-cisis (1.2.250.1.213.1.1.5.686) -->
              <!-- <approachSiteCode> </approachSiteCode> -->
              
              <!-- [0..1] Dose à administrer : uniquement si posologie structurée -->
              <!-- non renseigné ici car doses progressives décrites dans des <substanceAdministration> subordonnés -->
              <!-- <doseQuantity>  </doseQuantity> -->
              
              <!-- [0..1] Rythme d'administration : uniquement si posologie structurée -->
              <!-- <rateQuantity>  </rateQuantity> -->
              
              <!-- [0..*] Dose maximale d'administration : uniquement si posologie structurée -->
              <maxDoseQuantity>
                <numerator value="4"/>
                <denominator value="1" unit="d"/>
              </maxDoseQuantity>
              
              <!-- [1..1] Entrée FR-Produit-de-sante -->
              <consumable>
                <manufacturedProduct classCode="MANU">
                  <!-- Conformité Product (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.53"/>
                  <!-- Conformité Product Entry (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.2"/>
                  <!-- Conformité FR-Produit-de-sante (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.43"/>
                  <manufacturedMaterial classCode="MMAT" determinerCode="KIND">
                    <!-- Conformité Medicine Entry (IHE PHARM PRE) -->
                    <templateId root="1.3.6.1.4.1.19376.1.9.1.3.1"/>
                    <!-- Code CIS du médicament -->
                    <code code="63107752" displayName="PARACETAMOL MYLAN 500 mg, comprimé"
                      codeSystem="1.2.250.1.213.2.3.1" codeSystemName="CIS">
                      <originalText><reference value="#med-001"/></originalText>
                      <!-- Code MV Médicabase du médicament -->
                      <translation code="MV00002306" displayName="Paracétamol 500 mg comprimé" 
                        codeSystem="1.2.250.1.213.2.59" codeSystemName="MEDICABASE"></translation>                      
                      <!-- Code CIP du médicament -->
                      <translation code="3400933516390" 
                        displayName="PARACETAMOL MYLAN 500 mg, comprimé, plaquette(s) thermoformée(s) PVC-aluminium de 16 comprimé(s)"
                        codeSystem="1.2.250.1.213.2.3.2" codeSystemName="CIP"></translation>
                    </code>
                    <!-- Nom de la marque -->
                    <name>PARACETAMOL MYLAN 500 mg, comprimé</name>
                    <!-- Forme galénique : EDQM Standard Terms (0.4.0.127.0.16.1.1.2.1) : Pharmaceutical Dose Forms -->
                    <pharm:formCode code="10219000" displayName="Comprimé" codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="StandardTermsEDQM"/>                    
                    <!-- [0..1] Équivalent générique -->
                    <pharm:asSpecializedKind classCode="GRIC">
                      <pharm:generalizedMedicineClass classCode="MMAT">
                        <pharm:code code="N02BE01" displayName="paracetamol" codeSystem="2.16.840.1.113883.6.73" codeSystemName="ATC"/>
                        <pharm:name>paracetamol</pharm:name>
                      </pharm:generalizedMedicineClass>
                    </pharm:asSpecializedKind>
                    <!-- [0..*] Substances actives -->
                    <pharm:ingredient classCode="ACTI">
                      <pharm:quantity>
                        <numerator xsi:type="PQ" value="500" unit="mg"/>
                        <denominator xsi:type="PQ" value="1"/>
                      </pharm:quantity>                    
                      <pharm:ingredient classCode="MMAT" determinerCode="KIND">
                        <pharm:code code="100000090270" displayName="Paracetamol" codeSystem="2.16.840.1.113883.3.6905.2" codeSystemName="SMS"/>
                        <pharm:name>Paracetamol</pharm:name>
                      </pharm:ingredient>
                    </pharm:ingredient>
                  </manufacturedMaterial>
                </manufacturedProduct>
              </consumable>              

              <!-- [0..*] Entrée FR-Traitement-prescrit-subordonnee (pour indiquer les changements de fréquence et/ou de dose) -->
              <!-- si doses progressives (tapered dose), fractionnées (split dose) et conditionnelles (conditional dose)-->
              <entryRelationship typeCode="COMP">
                <sequenceNumber value="1"/>
                <substanceAdministration classCode="SBADM" moodCode="INT">
                  <!-- Conformité FR-Traitement-prescrit-subordonnee (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.83.1"/>
                  <id root="C93DE620-3722-11EC-8D3D-0242AC130003"/>
                  <text><reference value="med-001-ModeAdminProg-1"/></text>
                  <statusCode code="completed"/>
                  <!-- Fréquence d'administration : toutes les 8h (3 fois/j) à partir du 01/12/2023 pendant 2 jours -->
                  <effectiveTime xsi:type="SXPR_TS">
                    <comp xsi:type="IVL_TS" operator="A">
                      <low value="20231201"/>
                      <width value="2" unit="d"/>
                    </comp>
                    <comp xsi:type="PIVL_TS" operator="A">
                      <period value="8" unit="h">
                        <translation>
                          <originalText><reference value="#med-001-frequence-1"/></originalText>
                        </translation>
                      </period>
                    </comp>
                  </effectiveTime>
                  <!-- Dose à administrer : 1 cp -->
                  <doseQuantity>
                    <low value="1" unit="{tablet}">
                      <translation>
                        <originalText><reference value="#med-001-doseMin-1"/></originalText>
                      </translation>
                    </low>
                    <high value="1" unit="{tablet}">
                      <translation>
                        <originalText><reference value="#med-001-doseMax-1"/></originalText>
                      </translation>
                    </high>
                  </doseQuantity>
                  <!-- [0..1] Rythme d'administration : uniquement si posologie structurée -->
                  <rateQuantity>
                    <low value="1500" unit='mg/d'>
                      <translation>
                        <originalText><reference value="#med-001-rateMin-1"/></originalText>
                      </translation>
                    </low>
                    <high value="3000" unit='mg/d'>
                      <translation>
                        <originalText><reference value="#med-001-rateMax-1"/></originalText>
                      </translation>
                    </high>
                  </rateQuantity>
                  
                  <!-- Produit de santé à nullFlavor="NA" -->
                  <consumable typeCode="CSM">
                    <manufacturedProduct classCode="MANU">
                      <!-- Conformité Product (CCD) -->
                      <templateId root="2.16.840.1.113883.10.20.1.53"/>
                      <!-- Conformité Product Entry (IHE PCC) -->
                      <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.2"/>
                      <!-- Conformité FR-Produit-de-sante (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.43"/>
                      <manufacturedMaterial classCode="MMAT" determinerCode="KIND">
                        <!-- Conformité Medicine Entry (IHE PHARM PRE) -->
                        <templateId root="1.3.6.1.4.1.19376.1.9.1.3.1"/>
                        <!-- Code du médicament -->
                        <code nullFlavor="NA"/>
                        <!-- Nom de la marque -->
                        <name nullFlavor="NA"/>
                      </manufacturedMaterial>
                    </manufacturedProduct>
                  </consumable>                  
                </substanceAdministration>
              </entryRelationship>
              
              <!-- [0..*] Entrée FR-Traitement-prescrit-subordonnee (pour indiquer les changements de fréquence et/ou de dose) -->
              <!-- si doses progressives (tapered dose), fractionnées (split dose) et conditionnelles (conditional dose)-->
              <entryRelationship typeCode="COMP">
                <sequenceNumber value="2"/>
                <substanceAdministration classCode="SBADM" moodCode="INT">
                  <!-- Conformité FR-Traitement-prescrit-subordonnee (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.83.1"/>    
                  <id root="3FDCAA46-3723-11EC-8D3D-0242AC130003"/>
                  <text><reference value="med-001-ModeAdminProg-2"/></text>
                  <statusCode code="completed"/>              
                  <!-- Fréquence d'administration : toutes les 12h (2 fois/j) à partir du 03/12/2023 pendant 4 jours -->
                  <effectiveTime xsi:type="SXPR_TS">
                    <comp xsi:type="IVL_TS" operator="A">
                      <low value="20231203"/>
                      <width value="4" unit="d"/>
                    </comp>
                    <comp xsi:type="PIVL_TS" operator="A">
                      <period value="12" unit="h">
                        <translation>
                          <originalText><reference value="#med-001-frequence-2"/></originalText>
                        </translation>
                      </period>
                    </comp>
                  </effectiveTime>
                  <!-- Dose à administrer : 1 comprimé -->
                  <doseQuantity>
                    <low value="1" unit="{tablet}">
                      <translation>
                        <originalText><reference value="#med-001-doseMin-2"/></originalText>
                      </translation>
                    </low>
                    <high value="1" unit="{tablet}">
                      <translation>
                        <originalText><reference value="#med-001-doseMax-2"/></originalText>
                      </translation>
                    </high>
                  </doseQuantity>
                  <!-- [0..1] Rythme d'administration : uniquement si posologie structurée -->
                  <rateQuantity>
                    <low value="1000" unit='mg/d'>
                      <translation>
                        <originalText><reference value="#med-001-rateMin-2"/></originalText>
                      </translation>
                    </low>
                    <high value="2000" unit='mg/d'>
                      <translation>
                        <originalText><reference value="#med-001-rateMax-2"/></originalText>
                      </translation>
                    </high>
                  </rateQuantity>
                  <!-- Produit de santé à nullFlavor="NA" -->
                  <consumable typeCode="CSM">
                    <manufacturedProduct classCode="MANU">
                      <!-- Conformité Product (CCD) -->
                      <templateId root="2.16.840.1.113883.10.20.1.53"/>
                      <!-- Conformité Product Entry (IHE PCC) -->
                      <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.2"/>
                      <!-- Conformité FR-Produit-de-sante (CI-SIS) -->
                      <templateId root="1.2.250.1.213.1.1.3.43"/>
                      <manufacturedMaterial classCode="MMAT" determinerCode="KIND">
                        <!-- Conformité Medicine Entry (IHE PHARM PRE) -->
                        <templateId root="1.3.6.1.4.1.19376.1.9.1.3.1"/>
                        <!-- Code du médicament -->
                        <code nullFlavor="NA"/>
                        <!-- Nom de la marque -->
                        <name nullFlavor="NA"/>                        
                      </manufacturedMaterial>
                    </manufacturedProduct>
                  </consumable>                  
                </substanceAdministration>
              </entryRelationship>

              <!-- [0..1] Entrée FR-Instructions-au-patient -->
              <entryRelationship typeCode="SUBJ" inversionInd="true">
                <act classCode="ACT" moodCode="INT">
                  <!-- Conformité Patient instructions (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.49"/>
                  <!-- Conformité Patient Medication Instruction (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3"/>
                  <!-- Conformité FR-Instructions-au-patient (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.33"/>
                  <code code="PINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                    codeSystemName="IHEActCode"/>
                  <text><reference value="#med-001-instrPatient"/></text>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Instructions-au-dispensateur -->
              <entryRelationship typeCode="SUBJ" inversionInd="true">
                <act classCode="ACT" moodCode="INT">
                  <!-- Conformité Fulfillment instructions (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.43"/>
                  <!-- Conformité Medication fulfillment instruction (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3.1"/>
                  <!-- Conformité FR-Instructions-au-dispensateur (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.34"/>
                  <code code="FINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                    codeSystemName="IHEActCode"/>
                  <text><reference value="#med-001-instrDisp"/></text>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Quantite-de-produit -->
              <entryRelationship typeCode="COMP">
                <supply classCode="SPLY" moodCode="RQO">
                  <!-- Conformité Amount of units of the consumable (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.9.1.3.8"/>
                  <!-- Conformité FR-Quantite-de-produit (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.86"/>
                  <independentInd value="false"/>
                  <!-- Unité issue de EDQM Packaging (30009000 "Boite")-->
                  <quantity value="2" unit="30009000"/>
                </supply>
              </entryRelationship>
              
              <!-- [1..1] Entrée FR-Autorisation-Substitution -->
              <entryRelationship typeCode="COMP">
                <act classCode="ACT" moodCode="DEF">
                  <!-- Conformité Substitution-Permission (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.9.1.3.9.1"/>
                  <!-- Conformité FR-Autorisation-Substitution (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.87"/>
                  <!-- Valeur issue du jdv-hl7-v3-ActSubstanceAdminSubstitutionCode-cisis (2.16.840.1.113883.5.1070) -->
                  <code code="N" displayName="Aucune substitution permise" 
                    codeSystem="2.16.840.1.113883.5.1070" codeSystemName="HL7_SubstanceAdminSubstitution">
                    <!-- Motif de non substitution obligatoire si substitution non autorisée -->
                    <originalText><reference value="med-001-substitution"/></originalText>
                  </code>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-ALD -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-ALD (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.13"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130003"/>
                  <code code="MED-574" displayName="En rapport avec une ALD"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-ALD"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas liée à une ALD -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-accident-travail -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-accident-travail (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.14"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130034"/>
                  <code code="GEN-180" displayName="En rapport avec un accident du travail ou une maladie professionnelle"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-ATMP"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas liée à un AT ou une MP -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-la-prevention -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-la-prevention (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.34"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130035"/>
                  <code code="GEN-295" displayName="En rapport avec la prévention"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-prev"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas en rapport avec la prévention -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Non-remboursable -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Non-remboursable (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.15"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130026"/>
                  <code code="GEN-181" displayName="Non remboursable"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-non-remb"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le médicament est non remboursable -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Hors-AMM -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Hors-AMM (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.12"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130017"/>
                  <code code="GEN-179" displayName="Hors Autorisation de Mise sur le Marché (AMM)"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-horsamm"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le médicament est Hors AMM -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
             <!-- Précondition -->
              <precondition>
                <criterion>
                  <text><reference value="#med-001-precondition"/></text>
                </criterion>
              </precondition>
              
            </substanceAdministration>
          </entry>
          
          <!-- [1..*] Entrée FR-Traitement-prescrit : préparation magistrale -->
          <entry>
            <substanceAdministration classCode="SBADM" moodCode="INT">              
              <!-- Conformité Medication activity (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.24"/>
              <!-- Conformité Medications Entry (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7"/>
              <!-- Conformité Prescription Item (IHE PHARM PRE) -->
              <templateId root="1.3.6.1.4.1.19376.1.9.1.3.2"/>          
              <!-- Conformité FR-Traitement-prescrit (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.83"/>
              <!-- [0..1] Conformité Posologie structurée : uniquement si posologie structurée -->
              <templateId root="1.3.6.1.4.1.19376.1.9.1.3.6"/>
              <!-- [0..1] Conformité Mode d'administration : normal (sans FR-Traitement-prescrit-subordonnee) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.1"/>
              <id root="AADC9C14-F1CA-4177-B2C8-A5178D5B3CA0"/>
              <code code="DRUG" codeSystem="2.16.840.1.113883.5.4" displayName="Médicament"
                codeSystemName="HL7_ActCode"/>
              <text><reference value="#med-002"/></text>
              <statusCode code="completed"/>
              <!-- [0..1] Durée du traitement -->
              <effectiveTime xsi:type="IVL_TS">
                <low value="20231201"/>
                <high value="20231206"/>
              </effectiveTime>
              
              <!-- [0..1] Fréquence d'administration : uniquement si posologie structurée -->
              <effectiveTime xsi:type="PIVL_TS" operator="A">
                <period value="1" unit="d"><translation>
                  <originalText><reference value="#med-002-frequence-1"/></originalText>
                </translation></period>
              </effectiveTime>
              
              <!-- Nombre de renouvellement(s) possible(s) -->
              <repeatNumber value="0"/>
              
              <!-- [0..1] Voie d'administration : uniquement si posologie structurée -->
              <!-- Voie d'administration : Terminologie EDQM - Standard terms / classe ROA (Voie d'administration) -->
              <routeCode code="20003000" displayName="Voie cutanée" codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="StandardTermsEDQM">
                <originalText><reference value="#med-002-voie"/></originalText>
              </routeCode>
              
              <!-- [0..1] Région anatomique d'administration : uniquement si posologie structurée -->
              <!-- valeur issue du jdv-human-substance-administration-site-cisis (1.2.250.1.213.1.1.5.686) -->
              <!-- <approachSiteCode> </approachSiteCode> -->
              
              <!-- [0..1] Dose à administrer : uniquement si posologie structurée -->
              <!-- <doseQuantity> </doseQuantity> -->
              
              <!-- [0..1] Rythme d'administration : uniquement si posologie structurée -->
              <!-- <rateQuantity>  </rateQuantity> -->
              
              <!-- [0..*] Dose maximale d'administration : uniquement si posologie structurée -->
              <!-- <maxDoseQuantity> </maxDoseQuantity> -->
              
              <!-- [1..1] Entrée FR-Produit-de-sante -->
              <consumable>
                <manufacturedProduct classCode="MANU">
                  <!-- Conformité Product (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.53"/>
                  <!-- Conformité Product Entry (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.2"/>
                  <!-- Conformité FR-Produit-de-sante (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.43"/>
                  <manufacturedMaterial classCode="MMAT" determinerCode="KIND">
                    <templateId root="1.3.6.1.4.1.19376.1.9.1.3.1"/>
                    <!-- Code CIS du médicament -->
                    <code nullFlavor="NA">
                      <originalText><reference value="#med-002"/></originalText>
                    </code>
                    <!-- Nom de la marque -->
                    <name nullFlavor="NA"/>
                    <!-- Forme galénique : EDQM Standard Terms (0.4.0.127.0.16.1.1.2.1) : Pharmaceutical Dose Forms -->
                    <pharm:formCode code="50015000" displayName="pommade pour application cutanée et nasale" 
                      codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="StandardTermsEDQM"/>                    
                  </manufacturedMaterial>                  
                </manufacturedProduct>
              </consumable>
              
              <!-- [0..1] Entrée FR-Instructions-au-patient -->
              <entryRelationship typeCode="SUBJ" inversionInd="true">
                <act classCode="ACT" moodCode="INT">
                  <!-- Conformité Patient instructions (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.49"/>
                  <!-- Conformité Patient Medication Instruction (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3"/>
                  <!-- Conformité FR-Instructions-au-patient (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.33"/>
                  <code code="PINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                    codeSystemName="IHEActCode"/>
                  <text><reference value="#med-002-instrPatient"/></text>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Instructions-au-dispensateur -->
              <entryRelationship typeCode="SUBJ" inversionInd="true">
                <act classCode="ACT" moodCode="INT">
                  <!-- Conformité Fulfillment instructions (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.43"/>
                  <!-- Conformité Medication fulfillment instruction (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3.1"/>
                  <!-- Conformité FR-Instructions-au-dispensateur (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.34"/>
                  <code code="FINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                    codeSystemName="IHEActCode"/>
                  <text><reference value="#med-002-instrDisp"/></text>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Quantite-de-produit -->
              <entryRelationship typeCode="COMP">
                <supply classCode="SPLY" moodCode="RQO">
                  <!-- Conformité Amount of units of the consumable (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.9.1.3.8"/>
                  <!-- Conformité FR-Quantite-de-produit (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.86"/>
                  <independentInd value="false"/>
                  <!-- unité issue de EDQM (30067000 "Tube") -->
                  <quantity value="1" unit="30067000"/>
                </supply>
              </entryRelationship>
              
              <!-- [1..1] Entrée FR-Autorisation-Substitution -->
              <entryRelationship typeCode="COMP">
                <act classCode="ACT" moodCode="DEF">
                  <!-- Conformité Substitution-Permission (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.9.1.3.9.1"/>
                  <!-- Conformité FR-Autorisation-Substitution (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.87"/>
                  <!-- Valeur issue du jdv-hl7-v3-ActSubstanceAdminSubstitutionCode-cisis (2.16.840.1.113883.5.1070) -->
                  <code code="N" displayName="Aucune substitution permise" 
                    codeSystem="2.16.840.1.113883.5.1070" codeSystemName="HL7_SubstanceAdminSubstitution">
                    <!-- Motif de non substitution obligatoire si substitution non autorisée -->
                    <originalText><reference value="med-002-substitution"/></originalText>
                  </code>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-ALD -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-ALD (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.13"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130003"/>
                  <code code="MED-574" displayName="En rapport avec une ALD"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-ALD"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas liée à une ALD -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>

              <!-- [0..1] Entrée FR-En-rapport-avec-accident-travail -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-accident-travail (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.14"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130034"/>
                  <code code="GEN-180" displayName="En rapport avec un accident du travail ou une maladie professionnelle"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-ATMP"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas liée à un AT ou une MP -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-la-prevention -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-la-prevention (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.34"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130035"/>
                  <code code="GEN-295" displayName="En rapport avec la prévention"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-prev"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas en rapport avec la prévention -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Non-remboursable -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Non-remboursable (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.15"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130026"/>
                  <code code="GEN-181" displayName="Non remboursable"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-non-remb"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le médicament est non remboursable -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Hors-AMM -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Hors-AMM (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.12"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130017"/>
                  <code code="GEN-179" displayName="Hors Autorisation de Mise sur le Marché (AMM)"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-horsamm"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le médicament est Hors AMM -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- Précondition -->
              <precondition>
                <criterion>
                  <text><reference value="#med-002-precondition"/></text>
                </criterion>
              </precondition>
              
            </substanceAdministration>
          </entry>
          
        </section>
      </component>

      <!-- [0..1] Section FR-Prescription-dispositifs-medicaux : Prescription de dispositifs médicaux -->
      <component>
        <section>
          <templateId root="1.2.250.1.213.1.1.2.222"/>
          <id root="5D743612-F997-4BCA-B990-B06A33B27B19"/>
          <code code="46264-8" displayName="Dispositifs médicaux" codeSystem="2.16.840.1.113883.6.1"
            codeSystemName="LOINC"/>
          <title>Prescription de dispositifs médicaux</title>
          <text>
            <table border="0">
              <thead>
                <tr>
                  <th>Dispositif médical</th>
                  <th>Durée de location LPP</th>
                  <th>Nombre de conditionnements</th>
                  <th>Nombre de renouvellements</th>
                  <th>En rapport ALD</th>
                  <th>En rapport AT/MP</th>
                  <th>En rapport Prévention</th>
                  <th>Non remboursable</th>
                </tr>
              </thead>
              <tbody>
                <!-- Dispositif 1 -->
                <tr>
                  <td ID="DM-001"><content ID="DM-001-LPP">Lit médical, lit + 135 kg, forfait de livraison du lit et accessoires [LPP 1215702]</content></td>
                  <td>60 jours</td>
                  <td>1</td>
                  <td>0</td>
                  <td><content ID="DM-001-ALD">Non</content></td>
                  <td><content ID="DM-001-ATMP">Non</content></td>
                  <td><content ID="DM-001-prev">Non</content></td>
                  <td><content ID="DM-001-non-remb">Non</content></td>
                </tr>
              </tbody>
            </table>            
          </text>
          <!-- [1..*] Entrée FR-Dispositif-medical  -->
          <entry>
            <supply classCode="SPLY" moodCode="INT">
              <!-- Conformité Supply Activity (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.34"/>
              <!-- Conformité FR-Dispositif-medical (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.20"/>
              <!-- Identifiant de la fourniture du DM -->
              <id nullFlavor="UNK"/>
              <!-- Référence vers la partie narrative de la section DM -->
              <text><reference value="#DM-001"/></text>
              <!-- Date d'utilisation du DM -->
              <effectiveTime xsi:type="IVL_TS">
                <low value="20231201"/>
                <high value="20240131"/>
              </effectiveTime>
              <!-- Nombre de renouvellement(s) possible(s) -->
              <repeatNumber value="0"/>              
              <!-- Nombre de conditionnements -->
              <quantity value="1"/>
              <!-- Durée de la location en jours -->
              <expectedUseTime>
                <width value="60" unit="d"/>
              </expectedUseTime>
              <!-- Description du dispositif médical -->
              <participant typeCode="DEV">
                <participantRole classCode="MANU">
                  <!-- Type de DM -->
                  <playingDevice classCode="DEV" determinerCode="INSTANCE">
                    <!-- Code EMDN du DM -->
                    <code code="V0806" displayName="LITS MÉDICAUX" codeSystem="1.2.250.1.213.2.68" codeSystemName="EMDN">
                      <!-- Autre Code du DM -->                      
                      <translation code="1215702"
                        displayName="lit médical, lit + 135 kg, forfait de livraison du lit et accessoires"
                        codeSystem="1.2.250.1.215.300.4" codeSystemName="LPP">
                        <originalText><reference value="#DM-001-LPP"/></originalText>
                      </translation>
                    </code>
                  </playingDevice>
                </participantRole>
              </participant>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-ALD -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-ALD (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.13"/>
                  <id root="7FA00C4C-3721-11EC-8D3D-0242AC130003"/>
                  <code code="MED-574" displayName="En rapport avec une ALD"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#DM-001-ALD"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du DM n'est pas liée à une ALD -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-accident-travail -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-accident-travail (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.14"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130034"/>
                  <code code="GEN-180" displayName="En rapport avec un accident du travail ou une maladie professionnelle"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#DM-001-ATMP"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du DM n'est pas liée à un AT ou une MP -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-la-prevention -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-la-prevention (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.34"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130035"/>
                  <code code="GEN-295" displayName="En rapport avec la prévention"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#DM-001-prev"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du DM n'est pas en rapport avec la prévention -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Non-remboursable -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Non-remboursable (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.15"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130026"/>
                  <code code="GEN-181" displayName="Non remboursable"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#DM-001-non-remb"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le DM est non remboursable -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
            </supply>
          </entry>
        </section>
      </component>

      <!-- [0..1] Section FR-Commentaire-non-code -->
      <component>
        <section>
          <!-- Conformité CDA Section (CDA) -->
          <templateId root="2.16.840.1.113883.10.12.201"/>
          <!-- Conformité Document Summary (IHE CARD) -->
          <templateId root="1.3.6.1.4.1.19376.1.4.1.2.16"/>
          <!-- Conformité FR-Commentaire-non-code (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.73"/>
          <id root="E9BCD936-DDBA-41C9-AB5B-D9B190A8DE81" />
          <code code="55112-7" displayName="Commentaire" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC" />
          <title>Commentaire</title>
          <!-- Bloc narratif de la section -->
          <text>(texte libre)</text>
        </section>
      </component>

      <!-- [0..1] Section FR-Signes-vitaux -->
      <component>
        <section>
          <!-- Conformité Vital Signs Section (CCD) -->
          <templateId root="2.16.840.1.113883.10.20.1.16"/>
          <!-- Conformité Vital Signs Section (IHE PCC) -->
          <templateId root="1.3.6.1.4.1.19376.1.5.3.1.3.25"/>
          <!-- Conformité Coded Vital Signs Section (IHE PCC) -->
          <templateId root="1.3.6.1.4.1.19376.1.5.3.1.1.5.3.2"/>
          <!-- Conformité FR-Signes-vitaux (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.75"/>
          <id root="362B214A-8414-4547-8B56-EABDCAB587AA"/>
          <code code="8716-3" displayName="Signes vitaux" codeSystem="2.16.840.1.113883.6.1"
            codeSystemName="LOINC"/>
          <title>Signes vitaux</title>
          <text>
            <table border="0">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Signe vital</th>
                  <th>Valeur</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>01/12/2023</td>
                  <td>Poids</td>
                  <td>
                    <content ID="poids">55 kg</content>
                  </td>
                </tr>
                <tr>
                  <td>01/12/2023</td>
                  <td>Taille</td>
                  <td>
                    <content ID="taille">1,70 m</content>
                  </td>
                </tr>
              </tbody>
            </table>
          </text>
          <!-- [1..1] Entrée FR-Signes-vitaux -->
          <entry>
            <organizer classCode="CLUSTER" moodCode="EVN">
              <!-- Conformité Result organizer (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.32"/>
              <!-- Conformité Vital signs organizer (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.35"/>
              <!-- Conformité Vital Signs Organizer (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13.1"/>
              <!-- Conformité FR-Signes-vitaux (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.49"/>
              <id root="0B9FE5D6-8A5E-46D6-87BF-D9E19F73B956"/>
              <code code="85353-1" displayName="Signes vitaux" codeSystem="2.16.840.1.113883.6.1"
                codeSystemName="LOINC"/>
              <statusCode code="completed"/>
              <effectiveTime value="20231201"/>
              <!-- [1..*] Entrée FR-Signe-vital-observe : Poids(kg) -->
              <component typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Result observation (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.31"/>
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité Vital Signs Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13.2"/>
                  <!-- Conformité FR-Signe-vital-observé (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.50"/>
                  <id root="C4815527-3DBA-4907-B3B1-EC6F9F8D1224"/>
                  <code code="29463-7" displayName="Poids (mesuré)" 
                    codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                  <text><reference value="#poids"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201"/>
                  <value xsi:type="PQ" value="55" unit="kg"/>
                </observation>
              </component>
              <!-- [1..*] Entrée FR-Signe-vital-observe : Taille(cm) -->
              <component typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Result observation (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.31"/>
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité Vital Signs Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13.2"/>
                  <!-- Conformité FR-Signe-vital-observé (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.50"/>
                  <id root="80E7B7B1-353A-4870-B8F4-F1176A23F1DB"/>
                  <code code="8302-2" displayName="Taille"
                        codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                  <text><reference value="#taille"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201"/>
                  <value xsi:type="PQ" value="170" unit="cm"/>
                </observation>
              </component>
            </organizer>
          </entry>
        </section>
      </component>
      
      <!-- [0..1] Section FR-Historique-des-grossesses -->
      <component>
        <section>
          <!-- Conformité Pregnancy History Section (IHE PCC) -->
          <templateId root="1.3.6.1.4.1.19376.1.5.3.1.1.5.3.4"/>
          <!-- Conformité FR-Historique-des-grossesses (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.77"/>
          <id root="573B13F5-2C78-47E0-BE1F-55C02B6F40B2"/>
          <code code="10162-6" displayName="Historique des grossesses"
            codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
          <title>Historique des grossesses</title>
          <text>
            <table border="0">
              <thead>
                <tr>
                  <th>Statut</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <content ID="grossesse-001">Enceinte</content>
                  </td>
                </tr>
              </tbody>
            </table>
          </text>
          <!-- [1..*] Entrée FR-Observation-sur-la-grossesse : Patiente enceinte -->
          <entry>
            <observation classCode="OBS" moodCode="EVN">
              <!-- Conformité Simple Observation (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
              <!-- Conformité Pregnancy Observation (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13.5"/>
              <!-- Conformité FR-Observation-sur-la-grossesse (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.53"/>
              <id root="889E8A7C-ABE9-426B-873C-BDF23B505006"/>
              <code code="11449-6" displayName="Statut de grossesse"
                codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
              <text><reference value="#grossesse-001"/></text>
              <statusCode code="completed"/>
              <effectiveTime value="20231201"/>
              <value xsi:type="CE" code="77386006" displayName="grossesse en cours" codeSystem="2.16.840.1.113883.6.96" codeSystemName="SNOMED_CT"/>
            </observation>
          </entry>
        </section>
      </component>

      <!-- [0..1] Section FR-Document-PDF-copie -->
      <component>
        <section>
          <!-- Conformité FR-Document-PDF-copie (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.243"/>
          <id root="770B0DC2-A6B8-468E-8432-632B18D35F68"/>
          <code code="55108-5" displayName="Copie du document"
            codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
          <title>Copie du document</title>
          <text>
            <table border="0">							
              <tbody>
                <tr>
                <td><content ID="titre-copie-pdf">Copie PDF du document</content></td>
              </tr>
                <tr>
                  <td><renderMultiMedia referencedObject="copie-pdf"/></td>
                </tr>
              </tbody>
            </table>
          </text>
          
          <!-- [1..1] Entrée FR-Document-attache : Copie PDF du document -->
          <entry>
            <organizer classCode="CLUSTER" moodCode="EVN">
              <!-- Conformité FR-Document-attache (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.18"/>
              <id root="88BEB395-3B4C-37F5-9A31-03BEA73A8D8B"/>
              <code code="55107-7" displayName="Document attaché"
                codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
              <statusCode code="completed"/>
              <!-- [1..1] Entrée FR-Type-document-attache -->
              <component>
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-Observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Type-document-attache (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.18"/>
                  <id root="0D1629B3-CC69-4632-81F3-2301FD4C318B"/>
                  <code code="69764-9" displayName="Type de document"
                    codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                  <text><reference value="#titre-copie-pdf"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime nullFlavor="NA"/>
                  <value xsi:type="CD" code="55108-5" displayName="Copie du document"
                    codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                </observation>
              </component>
              <!-- [1..1] Entrée ObservationMedia -->
              <component>
                <observationMedia classCode="OBS" moodCode="EVN" ID="copie-pdf">
                  <value mediaType="application/pdf" representation="B64">
                    JVBERi0xLjQNJeLjz9MNCjEwIDAgb2JqDTw8L0xpbmVhcml6ZWQgMS9MIDk1NzM2L08gMTIvRSA3Nzg2MC9OIDMvVCA5NTQxNi9IIFsgOTE2IDI2OF0+Pg1lbmRvYmoNICAgICAgICAgICAgICAgICAgDQp4cmVmDQoxMCAzMQ0KMDAwMDAwMDAxNiAwMDAwMCBuDQowMDAwMDAxMTg0IDAwMDAwIG4NCjAwMDAwMDE0MTIgMDAwMDAgbg0KMDAwMDAwMTY0NiAwMDAwMCBuDQowMDAwMDAxODI2IDAwMDAwIG4NCjAwMDAwMDE5NTQgMDAwMDAgbg0KMDAwMDAwMjA4MiAwMDAwMCBuDQowMDAwMDAyMTE3IDAwMDAwIG4NCjAwMDAwMDI3NTMgMDAwMDAgbg0KMDAwMDAwMzMxNiAwMDAwMCBuDQowMDAwMDA1MDY1IDAwMDAwIG4NCjAwMDAwMDcxNjMgMDAwMDAgbg0KMDAwMDAwODQ3MyAwMDAwMCBuDQowMDAwMDA5Njk5IDAwMDAwIG4NCjAwMDAwMTEwNDMgMDAwMDAgbg0KMDAwMDAxMjI1NSAwMDAwMCBuDQowMDAwMDEzODgxIDAwMDAwIG4NCjAwMDAwMTk3NzYgMDAwMDAgbg0KMDAwMDAyMTA0MiAwMDAwMCBuDQowMDAwMDIxNzQ3IDAwMDAwIG4NCjAwMDAwMjQyOTQgMDAwMDAgbg0KMDAwMDAyNDM3MyAwMDAwMCBuDQowMDAwMDUzMDA1IDAwMDAwIG4NCjAwMDAwNTMyNzggMDAwMDAgbg0KMDAwMDA1NDE1MCAwMDAwMCBuDQowMDAwMDU0MjMwIDAwMDAwIG4NCjAwMDAwNzI3ODQgMDAwMDAgbg0KMDAwMDA3MzA1NyAwMDAwMCBuDQowMDAwMDczNzc0IDAwMDAwIG4NCjAwMDAwNzUxOTEgMDAwMDAgbg0KMDAwMDAwMDkxNiAwMDAwMCBuDQp0cmFpbGVyDQo8PC9TaXplIDQxL1Jvb3QgMTEgMCBSL0luZm8gOSAwIFIvSURbPDQ0NDI1OTVBNDM0MjMzNTQzOTM1NEQzMDM2NTgzNDVBPjxFRERBNENGNEVBNkEyMTRDQjEyNjVDMTdBM0E0M0ZEQj5dL1ByZXYgOTU0MDU+Pg0Kc3RhcnR4cmVmDQowDQolJUVPRg0KICAgICAgICAgICAgICANCjQwIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9JIDIxNi9MIDIwMC9MZW5ndGggMTgwL1MgMTE5Pj5zdHJlYW0NCmjeYmBgYGJgYKlgYGVgENZkEGRAAEGgGCsDCwPHBYbu3Q0vGxgY5jxDkmYQEnGTUda8tG2f8dodKho9Fm7BS3Nr0qMLgFIVHSAA1MEBZnQAhSCMBqhJSEAGihkYlBn4GfuYXJhesF5gYJjmyMG2SUBO+I2qReCFyYq9p4tYzrPaqDswpv0OkD1w0UHsRDjjHa4V2gZLFkANYmVgjBQA0oxAbATEnAyMRfeg/MMAAQYAUbAzRw0KZW5kc3RyZWFtDWVuZG9iag0xMSAwIG9iag08PC9MYW5nKHgtdW5rbm93bikvTWV0YWRhdGEgNyAwIFIvT3V0cHV0SW50ZW50c1s8PC9EZXN0T3V0cHV0UHJvZmlsZSA4IDAgUi9JbmZvKEdlbmVyaWMgUkdCIFByb2ZpbGUpL091dHB1dENvbmRpdGlvbklkZW50aWZpZXIoQ3VzdG9tKS9TL0dUU19QREZBMS9UeXBlL091dHB1dEludGVudD4+XS9QYWdlTGFiZWxzIDUgMCBSL1BhZ2VzIDYgMCBSL1R5cGUvQ2F0YWxvZz4+DWVuZG9iag0xMiAwIG9iag08PC9CbGVlZEJveFswIDAgNTk0LjcyIDc5Ml0vQ29udGVudHNbMTkgMCBSIDIwIDAgUiAyMSAwIFIgMjIgMCBSIDIzIDAgUiAyNCAwIFIgMjUgMCBSIDI3IDAgUl0vQ3JvcEJveFswIDAgNTk0LjcyIDc5Ml0vTWVkaWFCb3hbMCAwIDU5NC43MiA3OTJdL1BhcmVudCA2IDAgUi9SZXNvdXJjZXMgMTMgMCBSL1JvdGF0ZSAwL1RyaW1Cb3hbMCAwIDU5NC43MiA3OTJdL1R5cGUvUGFnZT4+DWVuZG9iag0xMyAwIG9iag08PC9Db2xvclNwYWNlPDwvRGVmYXVsdEdyYXlbL0lDQ0Jhc2VkIDI4IDAgUl0vRGVmYXVsdFJHQiAxNiAwIFI+Pi9Gb250PDwvRjEgMTQgMCBSL0YzIDE1IDAgUj4+L1Byb2NTZXRbL1BERi9JbWFnZUIvSW1hZ2VDL1RleHRdL1hPYmplY3Q8PC9JbTEgMzggMCBSL0ltMiAyNiAwIFI+Pj4+DWVuZG9iag0xNCAwIG9iag08PC9CYXNlRm9udC9ER0xaVEcrQXJpYWwvRGVzY2VuZGFudEZvbnRzWzMzIDAgUl0vRW5jb2RpbmcvSWRlbnRpdHktSC9TdWJ0eXBlL1R5cGUwL1RvVW5pY29kZSAxNyAwIFIvVHlwZS9Gb250Pj4NZW5kb2JqDTE1IDAgb2JqDTw8L0Jhc2VGb250L1hITFZHTitBcmlhbC9EZXNjZW5kYW50Rm9udHNbMzcgMCBSXS9FbmNvZGluZy9JZGVudGl0eS1IL1N1YnR5cGUvVHlwZTAvVG9Vbmljb2RlIDE4IDAgUi9UeXBlL0ZvbnQ+Pg1lbmRvYmoNMTYgMCBvYmoNWy9JQ0NCYXNlZCAyOSAwIFJdDWVuZG9iag0xNyAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDU2Nj4+c3RyZWFtDQp4Xl2UTYvbMBCG74H8Bx23hyWRNLJ2IRiy+YAcui2b9gc4tpIaGts4ziH/fu1Xr5ZSHxIea8YzjyRmsTlsD009qMXPvi2PYVDnuqn6cGvvfRnUKVzqZj7TWlV1OSgi/spr0c1nU/7xcRvC9dCc2/lstVKLj3H5NvQP9bSu2lP4Nkb96KvQ181FPf3eHKcXx3vX/Q3X0AxqOZ/luarCefra96J7L65BLZD6fKjGiHp4PI9p/4T8enRBmfhCx67Ktgq3rihDXzSXMDayHJ98tR+ffD4LTfV/gM9i4ulc/in6mKDz8dfqPJKZyCxJdqJMSNlEu1eSx5olCciRXkBb0ivIkNYT+URvqJ5oA0rVt6BUYYfONqQ91tiLXoLWJBiZNxKMhA4aRrInoWthn9qB0jdhKzsSbB13ScPP0VbDTxLBT1Ik/Bz9NPxMqgc/oZGGn6Othp+jg4GfY56Bn2Qk+GXs2sQTY9cGfvaFBD9DdwM/60nwMykynl+KhJ9nnwZ+WSL4mVQ9nl/qDH6Op2LgZ7lLBn6ep2Lh5+luox9vgYWfTxT9uLsWfoa2Fn4Zq1v4uZQHP8/qNvqxMws/m3qJ55d6gZ+kSPj5RPAz3EELP88dtPDLuCYw2rEXgZFjPYGR4w4KjBwdJBrxmwIjT3eBkaQKMPIpbzQy072MBIcduxY4ZLxZEu8g76fEO8hzFzjIVH0cJWlkTFMFU/BrbJX3vh8nFoYlJtU0o+omfA3Uru2Qx59P4eg22Q0KZW5kc3RyZWFtDWVuZG9iag0xOCAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDQ5Mz4+c3RyZWFtDQp4Xl2UzY7aMBSF95HyDl5OFyPwT8ggoUgUgsSiM1VpHyAkhkYqSRTCgrdvfHzuqGoWQV98r+/9bOzF7rg/du2kFt/Hvj75SV3arhn9vX+MtVdnf227NNFaNW09KSJ+6ls1pEnIPz3vk78du0ufJpuNWvyYh+/T+FQv26Y/+y9z1MfY+LHtrurl1+4UPpwew/DH33w3qWWaFIVq/CXM9q0a3qubVwukvh6bOaKdnq9z2j8hP5+DVyZ+0LGrum/8fahqP1bd1c+NLOen2Bzmp0gT3zX/B2TrmHi+1L+rMSboYn5nyyKSCZQbkg20ykgOY5aUYUxoBVqTckTKnG8gR1oj8kDagkrS10BG8nYYk7w9aE86BCpZTy8xpkkwMqygoxEddDRakaLRGwlGjr1oGDmZE0YZe9EwMuxFwyjjmmkYOakOIyd9wijjmmkYGalegiQSfo71DPwc65m4Y+zMwC+jn4GfE4Kf25HijgnFHctJ8HNcFxN3TCrAz0gk/HL2aeC3ooOJfjJL3DGui4FfLmPwM1xrG/04i4Wf4ypZ+LktCX6GDhZ+ln1a+FnWs/Cz/C9Z+FmZE0al1IORlQowyoVgVMosMMpC3ny45BCFc4Z74fMg149xnM8wrg+c3XBq285/XjFDPyCPr78ziQl4DQplbmRzdHJlYW0NZW5kb2JqDTE5IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMTY3OD4+c3RyZWFtDQpIiexXXW/bNhRlbNcFYmTJ8rWlSRt267p2WxiSokTpte1abA8DtgTYw9yHtmuwh9ZD0wzD/v0ORcqmZMuSFztxV8GwxCtRvF889x6+W1sVlON3ZG46kfTV27XVd9lTQYViirureXX85PXZi7/eXPzy7BF99X5tlVMm8cfb968Ga6uPTjHlaUBjenrmLS00ZzyIqIhYrBQ9xUK/PSArpEXapENu4N4lN0n/JW79C9IfkB7pn+Edbudk3Yy7mLVhpLZ5jZkdvGybwafmk03vCzO5Y5a7wK1rV91K5+cX2yTbD5/T0x89O2UsYGBMZcB4JDI7e27a8VNRdExKzWQYUZkwqeO8Y8aljlFvXergYWpdascnkDBet05h1DKOnOFTXPpnmUYX7WfnL/5x4U7DbCwRMm8Kp0HEQqEzI1puje9PcwmVLNEhDRTTUmfJNkmMAwpBJBHTSWzlNyM5YbF9wP1hNuvXtdXB+NZgcQQVLFGwVFi73SejVSNOz1+vrcKPn3NWHjGhJMVFpDaah7gdpQ/sNTVOMx7L8Qc8Mz1RNF0IYrZgKvxRtDkN8OMTo+nk8U+I33Ms8ju+Mub+nWlmnPPQhskqsg+w4EnRgZH2zANhk2R+nksmmsoanDDtmXg5e/nIVquh0lIBhMowNe3I21M5YxcXXz5LbO3m8Ay2NWY8uNzbGnb2UF583J3GghslBVKyOFBUMyGH+N1J68a5V9gGKBamtHVM0RighrU9iOdDJDm0h+U4N4VOosJlCM7kWXA+LEp5cI+Wmg3cXrLMEqEKxx/wTFA8mH/GMi3lO89Tveywzkytg+tlCW9tYF9TeP8b+ZmA7RWySz4jn+O/R26RfXJQDuS0XSsFMCUfWrteknbRtOLlasU2ClfYiSeGfRawtsyxYeD68W303zuX68plcF7CrrwsraHpvE3nreq8ogaYN8kW2Qa33sXfdOA9gHs77cE7GB8A3Vt4ugOE7zkYD1cTPGaRjPLrtcihmzehmAgRMK4LFhxCG0317ZO75Avy5fD7MftFmDCJxpv7nlZwhVAxlYiGKzRcYcli+zFwhQNwgu0aDKAMpA0DaBhAwwAWygDugq33X5rG6zXfsmYaKRbooGmmTTNdsth+DM30kGwYpLZJj/TP7G2AR13SwW/DCDdqtNoyCDettmm1TatdaKvtkXvkK4Pd/jnuK2Sd3CfrFR1XKybDsOm4Tcddsth+uB0XTlhwChZYMOkAWIud/GYox0y7XphOL4jD2bVB5X+nBfwz9UH5wKpPBu6h77fJ5lQuQHpecXlXcNMkOZQsDEaOOHnoZzEMxTDVdjz3oY5ZGMrJno9VUfdlzvWvyU3SfwD3OqRFdsguuUP28GuR/kNcbuMY07/Au2/w65JvKwlRWYVtCFFDiBpCtFBC9J1hQj1bwxx8t8ktckS2gOt9YPpOBTuKFROBrs+OpE4PPyli/fFl+RHW4sn/mCClsXI7DWMZLGCrOR2VxmJeKD4kjuQZXIMjuTAU5WsIfX0yQg3leAn0dkE7NnG2MYRkHxg+qOy+ZQgu676zIbii/84M22XpELUb8FIAN7O2DnKXJcK1oXt9EZ5bG+6R+2Td9GB0Y0ZWIK+k93t4av4tcuh49gGupjO3HPs+xpXjSh3OC1pEwAIccpyaVsmkiAlQ/MKk8YqhTM7QawPFtBxWjOl49eoqCk2E6PmyilzeMA7kAvLmdJbvspHi6TC2Vg9tt+eOgshHw/k4YtfPUcGgHmtVlax1aK42KpyFfG6UdczOyVtJYSuFxZ3kcsKnJoTnoy+LIh8N5+9dNeWws6qScNVmTk5CCJAEssnC9WYhUuh0qsnC9WZBI95J1GTherOAeEswkktmISVtckzm3ni+HmaLVnNaM62S0169qSV8L8S0JMtGbI090pzFoaYBC7mmWqY3M+X4h7eSPvlzwnqSJWj2QmDV0XKjA6dIIqahLjtIZrKQTAttXffHkw+cGRdncQSOyhIlQIlyZ09vXQX2O8PhUyQ4rmYQMcskav6UNVNSvotGmqdz1jRYsbMWCdLRAqy1OiqNxbw4TKafPD3omiBIGeQfXEnojdZKij1ypgzAhfOCC1NRnn9qCkeGyemxB9OgxsF01xxK7Vmzg2vPiOnt3D3bwMm1jRld0q5zAu2VHi4lx7klnFIeJKqRjMQQ9pk8W3lI42fqQ74meIvNWBPMl6EKXamGoPi8jn9+uXZaynempzq1j/4rwADiEUSnDQplbmRzdHJlYW0NZW5kb2JqDTIwIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMjAyNz4+c3RyZWFtDQpIiexXW48ctRJ2dia70kbLQjggAoHTCigkwDq+tN1uruIu8YDEyUrngeGB5LDiISARghD/nq98mel2T0/PrGZ39qDWJNttt+0qV9X3VdWhKGRxIgvhf49/OTqkJx5S8Uo6vD/x76ayBZeloqF/psHPR4f/PTr89ejwwRc/nf34x5NnXz/98a/i84d00MPPvz06/P4HHPI/7FJOF3/SNBdCmIaMMMZZ2PTd0eFv+OC1kYVykpdCF1joTO3Vi7rGR0NhzEEnSefQNlOa7oRIAzp069dJUvrvc+LFNG7jL3KlrJ8O+s/XnxWPf/cbFP6Xovj9MeR8doolX8nCFadn6V64Am6ky6LiUlXFKc7+/h67we6yYzY7Y7OnjLNrGF/zz7cwS/8lU0yzB+wOm7I38SzZ7BET+Gk/nGLCsNmv938oTr/pSJKa67JMovbioi9Pc4OX5JLaFVJKbo23cOOrK7lWcm755UBoxJV3nGuNK1k1vGTmjhHbchEJ7A+oeIOoyEp8BK3numNnaXVnLOI7nbqdiAsS5leKctbASLrRSowsrE/vF4ORKtf2uwUOpGoDATfQhtfaLIvNJrPxGtECy3ClVYpLwhpUILm15RXi1o+fLMZSl1wpHSKsNUgrl1yVYMydgjwP4bh2caTmdVk8/eno8Gy5L7wD+yNJ1hUXTnUnRNIcx19ILCVB/cG0kC5XgjyYsowqY+CP3Xo0RSmD+tJCHfmqF9AXZ2axiYkjXhsa9wG2yaRxeWvichxAYrPbBDDrNZLay+w6pakJex0J6o3etKOE4MKswDeU4BWgm1CbxufGt2xhe3Hcpthu+Ehbi1fXnhAiMi6JcNZs30dJbH/ENUSvRnVOVDHGLiPocqYaRH661FrQvzxPkJRtYH+nBLu1mtaiIAXwBTuglzuoYKl+nd1DxboHUpjir6IvmJmwCp8eYG36kirbfby/jVL4Lspg1Mb4d5u9x97dpNDtwD/eJN9cc2Nl2kwa5Qf0WGR+DsTXJj/omr/SPowwJTKcPQtW2UOJj3L/Bt3oOYzwfsyex2q87LEX6OHfZ2fr3kIqg8BSmfg92PE8N3G8EjY7i+xP2jnvrXfwm8JD85vU610kMzu0riqX+yxbpCWv63mVeJO9hqNfo8CBRTV0oYiy7CX2InvFx8v7mIWl6UNQ0bszbrS+i6LAC474ANtex+aeoIIpFBWuSyvUQdhJgEsoQl44rQT6q7qZ1eJMll97AGbABapeC2H+/h+G0dRb5V/sFkxwO/jjuB9GVnBV2gGXgO6oNVlLk0eI/wnGB+SWR7GFDVj/CKOPPThaWzrK3u1TtlLcDoVP5bir57z0Iqk4CZLe9DRzECmHUFqFC9BgqdXe6lPEGS5lh3yyRbXkWsu1rPYJzZF2Ew9ihZ8O6wP2NFbkGl4jjN7o0xDVqSmHbCWF5pWdY+0WvBPM0lDtU++6AD/y6h1PBUuMVfcytah57TqoyldJVDd1vVKXqf/rvfaJHxwsV4X3qqIUL+VQuEvluNXzeH+VGfymENaOc7IEJTIipUgvbf9wqNKbvUruzDKiyeplXqM7RYfKS2SbTrWcWtVUA6cxrqllFerj5vtArcwdJLXq5caBQm9UL1+RJmzdPtdbyQVt8S4ru31to4xBZSlITb260G22jDACdUOtiUsxPUkdqoEbl+krgbNuJJopH2/fNVkrstw9IUXrNWrglwF80MIEjz0UGVP2Rj+sheDCrAB2KhgSYNP4nMCWLVA3DtsQ1FelvVq70RWtMKJAvPiwaiOeZA5fZB3IZzBJVupMXIBzMqQMO2ht7O+Odwf6o5WleQv3l9uiLO97V/a3m7WlqfNb0s5FIkumoU6paxstYO66X0OBFQapo1OcxjYrnaK5Cc2TQSjXaj7zZDEDW8gwk1rHfGKxZzUztpcbq5FAbVFzKxr0uFbE9GQKLQUvlW67ZMqu40mO8W1TcIx3yiS45Zje97HKu2XiowQ9VTRY5zJRkRW+kRW3tq/BTWssV7VtWj7OLCyPM7iw1cLQnYnGnrUsH5cny+sSKaqSy3OT4sZIv0VI3SQT2m1NLHxooG09T43+mQb9dCJ76QQUaJpSwsQy9jPgRyV0puLyDKVLizYxsTYGAvXA1nVOUoZ1Jk9qszoTXRU7h0BoaNyXZa6KkTVXxiEsHBQ33aqvRPBrNdclDlUNSOhY8zXeN27m0nmOO7FJ1ZcVHjgGgd0Zi/guq427jR7TZlVHlNNfdCyED/R6ZMQy1hwO3ZHaksLNmiPIGFQW65QagNuFGVhsYNxY0S3U7cNas+QOq5vjyzA8yTxPsddJ3YabumoXe//23d1xSNBn7GZe3Wi/BbxfLfYgZe8hg++H7nCRyHvbQ/CIqdT/HU+IHXDEJiE88sNV4IfdWfd8JICL4fwWCRTLC/NePLuaOypqRzyPeB7xvGM8K17hkBae3/YpfXYPud1D+Tqb5Hn9xHGhdJ7Yz9jsPlHAGbHAPm3dZ9OU7/HA1DPM9hKD1JpUHolhJIaRGHZNDBIWNTov9wHgaZcOLICTl/kHQP0Ei6/jGWr9ftxXqPBlOQJ/BP4I/J0D33Fls4rgFnuHEPyur+4vpxZQEl2CciMnjJwwcsLOOUGWvHQZKbxHCN6/ND6w2htl5IORD0Y+2DUfnHBd1206uM1uspMAaV/u31wH1VpYXho7onpE9T8P1cXfAgwAjocYBA0KZW5kc3RyZWFtDWVuZG9iag0yMSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDEyMzk+PnN0cmVhbQ0KSInsl9tvG0UUh0+cKJFsmUtJgwBVjBIiCtTjuV94qUh6kXhAglrqQ7cPTVqLhzQSbhHiv+fMrtf23rJbiLATjTbe3dmcM3Pm7Py+ndMXnjKnCCMXw75w1CtBKMcTNtNr3vh92H8+7F8O++NHb6av/rx4/3T26m9y+mzY5+TZ6S/D/ouX2Mlr9BJOkr+GfUYoY0yTt9hvNkbWxr7Q6ddlR789PSHn71IHgT/FyLtzHOdkgiZPJHFkMg2DMDxGnFjqRDhzYckE+35xH+5C8h6SGYygB9vfvSSTn1fsuaPCaMINtUuPZFo11DhTT4ShcmmH/UFyGbq/AxTvj2E8d3s8SefwR94BJ1J5ai2ROKDWmpy/Tf8bJoX5wIaSlEmRNS8WzTQ16QNWuM/NanIecoVJsDrL09w2789Rx8jszbA/LQc4yt8nT4MLD9PLKH2UhSS5qbTZ/J5bdf1LYz5GaWmsRL0cOA+bh7fF0mNlHutbx9Vg0U6IbAmMFuurFO9GJDdbEivhZpLZpOz+O0rwGkwcoZTLosepSFmCQw8+gT08UPU9SM4qQFHUclkCxQF8A183o8HLdGqRDZENkQ23mQ2MKlfeRBzA5/ApENhq5IOS6OBd5EPkQ+TDbeaDwFqEl/CwhZYfp9VFqDTOYDetZi6bYWGxzuAiwiLCIsJi/bDQlGtbhMXdgoIXpiNJNfcVYKDuZzAKLnewtYMAGcExbDfqXwsUoDA3XP8Kk/Z/6z+M+d/1n0W9iH2+mMrt61/A2QgRETcOEbJKCJZtEHZggNUBAdIodkmFxrpAWWqk7Sp1ztBc8EzfhUar2A3GWCP20ImU7kPkvhFrqqumsySJLNrQUO76o80HaQ03GFojb4xmV+NtEu0K/fM8VB6sI/udJM1rJM1Lkt4GW/7gZ1bF730yxQ3/Mf4GeB6EJp5m9Z7FOkE2DSA19YUBHjQOUFNNGKqtiISJhLnphLkVFDHwJXyFvx/hCzjB6z58Bve6cGUfTuEeOhx0QQkNWMC/HiRn8BA+6sKVPUjuB3OBlQ0chrvdRqg4T50zESoRKhEqGwCVZIZK10G/h1h5HIPD5k9doCJw04FqHwe9X6JT4x6niJcP2eMUISOwJDrCYSSexzjgoN5JaaqXTi7MzIYIWb25xosRuXmvwchRJ3mLkTFUGZ0bDTqn1RrKln6d0+o0NUu3wOxZ17x6TcXqiMW8+oa3zxSyVDcntop6LmVYlRH1EfUR9etH/RaKew9EWd7cUSFLpgirKuYEmkhZNBzU9zlHhsLEtrFVMKpa2YrfEM5abBA2Vqpuky3aXjXbomVxujXEQ5hrriLyIvIi8jYCeaVy9rjL1taVjXDn42XJqBYaHGnhfMkSN2ZZDMm00w45jbMaxIJyvpWp0iN92piKG2XZxlQtqF9laj6PlnQaQfXSrSGdRaOr0lm0HLRk0woEt2rIZhXZgnvqhIvIjsiOyN4AZD8KheUh1qS9cIP1pYTvYadZvkams4ryjfKN8l2/fA+Cao+67LK+hX3UNgr84ULeV+6LxvAYdjMgCMSDxQeH8ASvDd5SU7/03kVz9E3ZMkb3HxqJIpmhSptIlEiUSJQNIEoya5aq8tTaqNSo1KjUDVBq4dtfo1aPanEqyjXK9RbLlfwjwABwdlzrDQplbmRzdHJlYW0NZW5kb2JqDTIyIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMTE1NT4+c3RyZWFtDQpIiexXTW/bOBAlkqIBBOi4eyh6IJqLewhNcvilQy9J2wA9LLCtgB7iHIo0Rg9pgE13sei/75CybEmOUisJFRsgDMcchqKGb2b43mRMKEnDn6s8+5Znn/PsOs+mby/nX/67+vf05stPevIpzwT9dPJXnp2dU06/5hmTDuj/ecYp45xr+h1XcMuMlIsJ3Ayf+nu108fTY3rxIzwh8as4/XGBLzouccl7QR0t5/4tHD9HggITwlLLhLS0xM3PJuRPMpuQw9fntPyQZ+/KsPk/9SOCKjAMCkdBoRtg6cX38G//OnQVDQWMg6zMq6VZeS38DG8b9cJbAPHnYM6gb+EMi7WNHQEcvbnMs3nXy6MabhEc9JOVayAMjiu/hFXLiDxaeBbv6ESnBWD94to34SPBw6fhbB3n4K03lHt8b3uSad1dv9AaCA4eLdOn4/JW4FuFvulvcHXLEB6tXG3BrJCpXFO5pnLd/nLVEqtFmlSuscuVh0OIOpV8yNcmUimnUr5/KQOT2lGlNf4uC3mDCtLLKPpxnCjq36UdYBjxItIbZJ1uZB0sXeTjOFun3NLXvoxr1HvBnFNdk1dD20D50SCv3tA5RAd0wxSIvmzht2eKamSKioH8mtPtNPELNk6T8Z1t++t8cHVCOB7CAlA66GIgxE96fawu2bvVwhPdEeue3uNWHpFF+ghQQ7FSspUAsJIVdgFpbRTM8Cr4qxHfVLziG5vbrHTrQ/jeMKdUzfeGzK7Jc3IQaJ/sk1dkit87NYCwhmmsm6QCtkMFbAXXS4EZ6myionhUJA1SEU96KiLEwE2oygRxPIgVXhRyqKBKEA+BuEDNoCBBHA9iBSZAmyCOB7EtmLaJ7iJCrKVEZTeU7naiueVBP4tKFHv12jFT2zuo7W32fOuNLzgsVbUAtTYe2Pi2tonQ+L7s7W8Ba8FRZTQTq5O2u7LU3Y7W3W5dIXdAN0yB6MuWRFIPJynng6sTwvEQFgCM62IgxDshAxLZ34PsVwSopOhQvbDYW9oFpLXxQKpvbROB6v8gh4STKZldE0sOcPCKzCY4t0cAJ/aIxF8/+Qznpr2yYCmBkjDYCmGwFfQvBSats4md4rGTNMhOPEmsiBADN6EqE8TxIFZ4UcihGitBPATiAmWEggRxPIgVGNSGie5iQmwLpm2iu4gQaylR2Q2lu53od3nQz6ISxV69dszR5fL6Ge7RhozYNvX3fEqKOlMWXoLDUlULUGsjNLEhMVaj8HOLo76rZc5IW3W0fmFrm5vLPJsHn+rHPp4eh6fwHBK/ildPHmO3On0vqKPlvPYeUcVUFZYa5nDDEh0+m5AXod+dXYdmd78a7BEgFv8ekNkEBzjH0donb9A4xFFYJHERf31Oyw959q5c416kBYd3l8bYim5BHdUxu6uoRoxxOyd9NW+Sk43SwqeUNi07+v3gX9h/jgrixjHCCW65ICqfR74kqv3vvig6cTFMgehLqB0nQd7JHLVmPy0/Oh97ncB/EvAFAOO6GIj+ToiTnZIg3TzRvdf9QOaivwQYAEr/bkoNCmVuZHN0cmVhbQ1lbmRvYmoNMjMgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMjczPj5zdHJlYW0NCkiJ7Jfbb9s2FMZZ23EADUI3A+kwoECJdcWSbWZ4k0i9JmsD9GHAWgN7iPPQZjH2kBqY02HYf7+PlBTrEsXpGtsLQOQiUTqkDj/yd87h8ds4EvTt8S9xdHpGOf09jpi0iv4dR5wyznlCP8SRVkyJpGhfxhE6/ep//3S9OX4EVUwmlmqTMMUVPf/gX7pXuBNGssxoNC6XjYylvs0rd/7yWxzN4+jw54vZu78uP54s3v1Dz6/gl02loVfn89ywNsziIo5m3qOy25uTI98Ls5D40zzveTSByStBLZ3MSt/HznkhDE2Z1ZpO4PDpPtkjzwknh2Q6J4bs4uZbMt3Hsx5ReNAjfTzgRJKBt1MwGOD5dH5wRiev4+jlpCmQMClLhPYScSlKicrXYya0pPiXvymUK5T3upSr4OzQLO19448bZTv+jNWtuAYDYRQVHH4n3rvxtXLuUvGX+3mIirvNdjkVN2LpPd/MPHKJK9PwM8jf1maRMWuL3ZoxU5H53jTPv3ArUFJga1vTtV/4zXtFV/aKXofALa/rG8UZ/JeNolvtTc+joX6q8F4E9beivuKpZzmovxX1NSKPzIL621E/Q2GjVVB/K+prlaKQDVl3S+qbjCUmZN3tqJ9IibL0U7PuVkv65ZmodEyUwndJX6zUdXv9xX7xxZWzuMseyt2+6yHr/s6L+RdWLEz3gVdxVW6nYiLKAnVdCF82UHfwfPcs7/zlBmfPr+CdTaWhV+fz3LA2zOIijmbep7Lbm5Mj3wtLI/Gned7zaAKTV4JaOpmV3kN47GdhaMosBpzA4dN98vTgjE5ex9HLyWeMC8YUREGWV1KVI/eKkVtWhmWZbFq571crBmQsSxMuGNdiKbNfunytuJJ58/K6KTPG8we8dl+adSouTVIq7m3L8SyzVdEr/o3LrSdW7eS01V7GFr3GnZzeDmfx8dtDjBex2M8QI1tHJCm+sdJZ2MlVkWRtAjfj923i5luj4q739PYAXlhX25sQXrZDeE64ahKesCQz1DCB2FSQ+4yMSI88Jn3yBZnOyKiJu/JdRMrMss/0Pbp8SYbupk+mC/dvjkY9CFUXH/HWyAcXCJpl0SaCwKfs0RAA/g8BYHvqdlAOzzFAjXIKwkH3kOyA2zsAa13tmQZgA7AB2PUDK5mBVQ3Y731Snu4jO3tWd0i/mZnHFocy1UzNMzI9cIzPHOZD13VIBmXGxgWPPuJpJ/lCKXdWCOQH8gP5aydfQLJENStyEDpo856CjGYlvgus+zDewTUvx7vBNijChQ5kB7ID2esn2zKZNnL6N+QHh+iPvgDfTDaXAoW8tAH6AH2AfgPpXDNtG9T/5BAdbgz4VPlZB+AD8AH4tQM/ZirL6rw/JSMyzpn1FfnoLtgqnjKdpAHbgG3Adv3YGhAg6tjueUIXQLfXztUir+ZbubplmGAqGZIwU0s7jOfyOIYfEYb7F+SwOw7ojBkTwkAIAyEMbKBcvyEOPF+m6Ws7+Kqalbqrx3fxA6x7yPCtiKGZEaoRCZ6Q78izbvYz5X0P8Af4A/wPGn7OtG2WAU/I1+QrQsmjzgCgFTpkNgSAEABCAHjQAUDiuCAa/D+C5WN/AHCHgfdk6A8c8+5oYHAUEDJEgxANQjTYQDRImEhMPRrs1RC9Nh0rloisFREA9oKMXZcRWgNEiDF5QfqdgCcShMn0ngGn/wowAHVMVeENCmVuZHN0cmVhbQ1lbmRvYmoNMjQgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMTQxPj5zdHJlYW0NCkiJ7Fddb9s2FOXiIAEUCNjD0Kc+cC66dh+l+U1qLwHWr2EPA4YY2EPdhy6rsYcsQNIORf/9jijZkmUpVrfaVR0isE3GvOS5R/ccXie/p8llmkyevJ6/+ufi7fPrV+/p+Zs0YV46Q9+c4ztOmfSKasW4klR65jm9fp0m8zT5LU2u0kRQjj9BHzGhJcWboOd/53Gcho9H4V8XaYIttHErcyUslhVj4TQNW2C62CpM/kqTFpiPz/Kjzx7/miYvXmKTPxGVA30XIHPOTX58eWYxx15nTdTVwQvYyKT4ktfzKFAvscuMca/X5iEXcJTV4P+/XIoTlvmU52zMB+ukNCGBMpvyo5bSjvjPz+jGW1RNDW5A2vIAtsYw38TuT1Ns9kxRT6fzBXBgBGOoLMeEdHSK4BcPCSezt+SAHJITcodQQr99Sae/pMnTaTNrxaTx1CiOaBWyvFoqrWAtF1uYXiynDtqTodr4ynixrFPLFghbtIw9jPIfIuZBVExfxQaKZAEWY+s/PtbyiI1YsS6z6rNRYw1ulxprtl6S0JzvnvdCp6JFp6Kh0xFxpTQbq4Rlrlo2m5MvyH28TvB+kk/xdt0eKS1TVaTqOkAZlq0c8EPnAeuuoS0zTkbbiLYxMG5728Zn4A2WzC7JEZHQMAaKTMiYzB6Se70M4w8EnCKAIyxEf4dm4IB82Qy2TCo0aZopKxfBBx2OIViW2cWiu9htdp07xSlGI3LYHqQFM1XQCIhkjmcWWhQksx5XINLow5TYgMhYeIOpI/pmIyBrma5ifgTBJbkH5OtiCNLaQ51lvAodBUKfB2rHGN/rdEufMe9tdMvolgPjdp/c8qSPLSq4jwx6Pa4ZKqzofp9eyncqXCj8juJR4VHhA+N2nxR+t1t+uJmN0FF/UX8D4/Z26E8KdLjSR/1F/Q2M233S35O8WR13/a5dbXSPiUN7q9DbHnUFrPa2D5qLDHNeNBb9jOM5dj1d31OCYt5c/323Y1gVKI2OER1jWNzuk2PcCT9v+/jFA/IVdD27bJN2m11MyFM4C9YrIslhMJsxeYbPjmhlWFZFH2E5YoOdTRDe7ROKW6aNjT4RfWJg3O6TT8zm3QLUGXMu6i/qb2Dc7pP+Vu7pFg1mUIHXUYRRhAPj9haJUCs0wJmPIowiHBi3t0mEDt2okFGEUYQD4/YWidBIqEDaKMKtipCHJERZJvnzbM6jPqM+W38uMmk8tRy56qU6eyjDLB9RPt7OIzKbSkpRweEupkdJmVpJqSVEvhuwBY81rF31VNNxxrzXzSkvhq7G8kejvDihkUSDdMu0El3VwtsrRdcqRW+D+TXQq2WSL+hdJrsHu4rX5w/XRIa3x7BQ6AhM9oEUf1L7qEz25i7gE3nEOtL/4Mo7vEXaL8CMyRLy1RKjcJJlrqR0McmY5cXDr0a8b0+KE+vbVP3ojRe6ZV7rxYVuyeySHJHjcK+TERmTCV43XvLCWWYgjHjND+OaH8RlLgVK0Lt412zvrpEWdw0fUMNE/xVgAPAQXGUNCmVuZHN0cmVhbQ1lbmRvYmoNMjUgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxNTU1Pj5zdHJlYW0NCkiJ7FdJaxxHFC7LYwvadBKc+OZDI10kg0u1L5cE7FhRHAgED+Tg0cFWLHxQBiw5hPz7vNp6GfUsrajdI9JITG2vqr76+tV7X2WCY05FgQkhsrjIszd59luefcozWhD4o0U0oAQTJouzP/PseRiKhetxJRTRlLh10rpUMNckZe1jnv2eZ/M8O/rxw/m7vy4+/3T57p/i5Ru345uXv+bZ21NY4Y88w8zw4m8/1YOrNlgA28TLiQIjWShisBXc46sNeyB0C1DfZYqFxYrZkeIeKbbMUztS3BvFgivMpB4p7pFibbHUdKS4P4olY9iYrulOlqip5n2glusolnVgNLHb4Bc49zawhoUzisUmCVUNkBNuX97GIcIOa8+wsZvImpvI24fbznkTMtUKS3AnRSxmEfSnEiU3cFVFJDU1IM2T4BhVzRctQM+uAJlRTBdXZ/Ng2Fjm8kOenXtML6Yw9ZgWppieJ3hAG/gihWiMDcyYAqK3B+jp4WkxfZ1nr6bX8iOEblMoarCpjpIGnydeVzn+F/wOTb9xN446AdXNbwa4qIHHGlYPc/VNBWtRv6qxTWKd93FZ4x6rU5HCgtNlHrPNmWhTVxk6ExkXiuXIcH8MU84xkbYjxXci1w8XJlqSevfgPFhST3nQYkr0QkqnGt6QOpEaG2DJYiavVTsk9eZCN8nqT9A+IugIzeZIo12o7KHZAfTtIA4dO4hB6Ton0He0VAGUcmbUAFuhAbYl0TOH1egxD/WXh5iCPERGMdUjxZwofzFHivujWDikXdXUSHEXii1oBcFHivujWHAFEnBMd31SrC2Wekx3PVIsGcPGdE13d+JlS7yEplEWO/m62B4fvR0fvdXTr+3Zyw1cVxFpTY3//OxtLnSTZ+9j9859Dz/78MqdoNkcnrrPEPcP3tkBIu7nmfv5AWwmoXse2lBOwIDAwImb+h5+9tER2Ggona10hntg0VhT+0kPvcWRW4WDzZHvENCloO1hTND3YVkGsye+Yx9+ObRdzx46hqV43LJcfw4LsbAEh5E9t+P+4WkxfX2NCKqwqJhoAc0SFBNw+zrzOO6XO+PGOEFfeRsdl7i3MJukyqMNlgpHPnGH8JyH45+U9vfRzwEh/P8CPf77iXjYV9NrwgdysikUN5hX/pkGn6fLsiqifcHL1QwGLpRSgsm6YFCLazBLSNVo9x6c3YbLzxEorh3Dn6AlOgfMJXILWUgsNkmo6lsLz2H98jRhl9USBO4Pp8scapsVSGdPcrMW28OKE+O+vRzJH4R8yjkm0nZk/04ow56iC1kTWVq03w38RC4N94PJwirpSmMXRCHVDFudtHZsgOSNQrCqdZCEjWVuogifgLggQZhptFtKKC89tBcdTtkE6UK8xpp4vbJUdpTC+P8jPFZ54gB3f2PhMdDlb6Jl7tVn9JjaBkltTEFqI6OqG4Z9TpS/yyP7g7AvIPKwrrJuZP+W2LegXAQf2R+EfcEVKNUx6w7EvrZY6jHrDsO+ZAxkadesO6ikr95ECRhNxC+jPn6pst2/2I87rj3FJj4UYG/6yLq992LYYc2HWf7glcYmd4oH4QauuojEpwboDhK8p6r5ogXs2RWgM4rp4upsHgwby1x+yLNzj+nFFKYe08IU0/MED5gFh6UQ6LGBGVNA9PYAPT08Laav8+zVdNVEuCUcjiUlbGPT1J049ZoV+JdaZ6QYVlYsWjkUQFhlwz33UklsWeq4qDo0xdZ3xBmL7XLCEjZpYLJhLd07CA7QSilfwoyymFbHuYd20H00QQ+gfIh20ew9FLPPaDZHj9DsHMZ88RBMdl3/xA07m2+hCkOX6Osw/gB9gx6j7yI71+CTAN99MMpacYFDCs5X06wlJkrXeY49FdFaGmyVqZi91lGbsxHX0TyRbTi28Pas6K4/TLGUkCC1wBrCVi0yuMlKsnBfXIMrW/jrexGvcWrcJJbB7Zf1XUJHWzCTChQU4QsQ28OyEVjAuT1kqFMwv3XEcY/1gDVcVSbp6vi7LSwHN6hD9mi3lWMOMA24hMacqSoT+KWgoQmmpIISm9RiETpIo57MWuAW/wowAAk2M+0NCmVuZHN0cmVhbQ1lbmRvYmoNMjYgMCBvYmoNPDwvQml0c1BlckNvbXBvbmVudCA4L0NvbG9yU3BhY2VbL0lDQ0Jhc2VkIDM5IDAgUl0vRmlsdGVyL0ZsYXRlRGVjb2RlL0hlaWdodCAyMTcvTGVuZ3RoIDU3MjgvU3VidHlwZS9JbWFnZS9UeXBlL1hPYmplY3QvV2lkdGggMjQ1Pj5zdHJlYW0NCnhe7Z1fbBXF98D3++RDNQETjAhqsCEYMfL3JwqCxj/8qfwLoPLnwZAYY0kUTHjwzSejxBgMD/gAGoIRJYBBsCBQQS2GtqKIoIGUNiikYFWMEjAmes5vwqSbuXNmd+eeu9tux/N5aLb3zpyZnfns7tyd/YPFA4IAgIECgiB6C0GDgQKCIHoLQYOBAoIgegtBg4ECgiB6C0GDgQKCIHoLQYOBAoIgegtBg4ECgiB6C0GDgQKCIHoLQYOBAoIgehOwNPR9xfq+RE+ACwYKcOno6NhUAnp6eqyKdXd3byoSFd8qUdVhUwlQPQJcMFCAhcq4cePGqAQcOXLEXAu1fODAgahIVHyrRFWHqASoHqmlQ4MEWKiMancRlYC2tjaslO3gwYNRkaj4VomqDlEJUD2ConclwAJFb6NE0bu0AAsUvY0SRe/SAixQ9DZKFL1LC7DABL2XLl36wgsvPF8AKmxDQwMtka33okWLzKqq5RtvvDHywFNvVdvimmLZsmW0RNGbAizQpbdyG4vk448/pn3K1vvrr7+24u/YsSPywFNvVVssjM7OTlqi6E0BFujSe9WqVeyAmajI27dvp33K1vvw4cNWxtbW1sgDT71VbQtqDRX2xIkTtETRmwIs0KW3Om4iDmC91SeRB6L3AAJYoOhtZBS9SwuwQG+9kQuNk6/eX375pVWi+iTyoBa9kQUNInp7AizQW+9/udAS/fX+H4FmbGlpMaunltUnNBkNxdZb/fsvCxpH9PYEWKCH3nitN6dOnTqCRVdXlxXNR2/F1atXOw1UnA0bNtCMQ4cOtUpUn9BkKq+KYAZU8c3i0E9vtbxr164RLNatW2eVKHp7AizQW+9bb701YnHq1Clk6U3XsampKeKi8tKAVnGeek+bNi1iobY7cx+Oorc3wAK99VY7n4jF6dOnkaW3BV7bbUZcVN7M+J56P/bYYxEL1YaiNw9ggaK3EV/0Li3AAkVvI77oXVqABf5n9N63b196o6HoXWKABQ58vR999NElS5Ys7kUtq09ostWrV2+p5OLFi1Z80bu0AAsc+HrTS6rUJ5EH9GY00bu0AAsc+Hr38aQ8it79AbBA0dvIKHqXFmCBoreRUfQuLcACRW8jo+hdWoAFllhvuo7OSfmWlhYrvvOSKoroPYAAFlhWvdVye3v72EqefvrpY8eOfVPJ5cuXoRL1iZVG5aIXiojeAwhggSXWu7m52Uoza9Ysn3V3ppk7d64VTfQeQAALLLHe9HaG2bNn89ZU5VJ5rWii9wACWKDobaQRvUsLsEDR20gjepcWYIHeet9+++0Ri6L19mkN9cnjjz9uRWPr7bymxQfVhqI3D2CBHnprurq6TrP4+++/rRJz1Fv9+9RTT42sZMeOHbT+58+ftyp25coVK5SP3opz586dZqHa0CpR9PYEWKC33lgDVpx89b733nutZBMmTEC/+lsJPPXGGrDiiN6eAAv01jsvMG+9J0+ebCVTnzDqj9565wWK3t4ACxS9e0HRu8QACxS9e0HRu8QAC3Tp/eKLL2KR7N69m/Zp0Xo7a2IlcOqtaouF0dHRQUsUvSnAAl16NzQ0bC+S1atX0z4tWu/Dhw9b1fj555+tUE69VW23F8batWtpiaI3BVigS+9+oVC90XWy2vNmtL5H9KYAC/zP6M2etex7RG8KsEDR20gjepcWYIGit5FG9C4twAJFbyON6F1agIXK+Pbbb0clgL50m+o9d+5cuuIPPPCAlUx9QpPNmjXLStbc3IyVJZbkpduqRxBF7wqAS09PT1sJsO4pQ5fegwYN+j/C9ddfbyVTn9Bkypn29nazxD/++MNqClWHthKgegS4YKAAFywNVq2o3rWQ+Xzv0jZFVWCgQFhg3npnPiE2DDBQICxQ9GaBgQJhgaI3CwwU4II1AB6gN1aufPX+5JNPsEjAA/QGuGCgAJfu7u6DLE6ePAketLa2HvTAOo+Beev9yiuvHDp06GAxtLe3gwdXr171qYPqEeCCgQIsVMaNGzdGLBYsWJBZrkrg+Uo1n/PepeXOO+/0aYozZ85EHqgewRo6NEiABdYwa7l48WL06NORI0dGHrR5zFqWlrFjx/o0RWdnp/PNsxYya0kBFih654HoXTTAAkXvPBC9iwZYYA16P/HEE+jBbbfdFnkwoMfe48ePd6671dSeY2/RmwIsMEHvadOmzZkzZ3Yy6tuVK1fu8mDZsmXpoTSnycOs2HoPHjzYp0QLlYVenaWYOHGiGU0tDxkyxEpzxx130BU/f/681dQXLlywQj344IO0RNGbAizQpfe8efP++eefrAJx69atkQc//vgj+mFVjK331KlTkcV3331Ho9FbiWfOnBl5sHnzZiQrZeHcn4veFGCByXfKZ2bcsmVL5IG1W/YEa9C70AdBoPcjNFX7pFcD5UEQ3gAL5D7nBEXvLETvHAEWKHr3gqJ3iQEWKHr3gqJ3iQEW6LoZ7bnnnsP89D579iz6YcVn6+18QmwmmKD3rmuXGprMmDEj8kD99M5cR9HbE+By8eLFw5V0dnZmZapC7/Hjx0+ZMmVyFt9//725FujSW8U57MHx48ehejBB71GjRpn1V8uDBg2y0owcOZJWY8WKFdaKL1q0SB5fzwO48KKht96eHOHeSuwEqgdruFPeOa3z5JNPWsluueUW0ZsH9C2Yt95trAdB5AjWoDedlFf/Ll682Eom79ZhA30Lit4GonfRQN+CoreB6F00wIUXDbEfxt616J25mljDY3w8x97Dhg2z9HZeBiCP8aEAl3zPnIwZM8bnPAnF58xJLXqr+NZq/v7772YCFVmlyapmTWdOtm7dapWompoWsWfPHhS9KwEWmPd5b20pDyt+jnqrXNOnT7eiWQ9hA2838jrvnVIicMFAARaY96zlN998g8jvnRjMW+/ZWY/Q9ATzm7UsAgwUYIGid5Wg6N0fAAsUvasERe/+AFhgDdd7b9u2jfZpjnq3tLRYwefNm4eidyoYKMACa7hb5+WXX6Z9SvVGLm+99ZYVfNKkSZcvX6YpIQt0vTpKbT7I4qGHHoo8oHo7o0GuYKAAC2Tda6m+amhocN70bemtlp999tnZ1aOKuO6662h8685HhXVGMYnW1lbrXkhVMd4tmevXr7dCvfnmm7Sqlt5I7rVUrFixAjFPwzFQgAXWcKe8E6q351Oq2HzxxRc+q09bbMqUKRGLTz/91Ar1ww8/0GRUb3pnZX19PaLonQ2wwOL19nzOCZvDhw8zVh+9xxiUffv2Weuo1pomo3rT55yMHj0aUfTOBlig6F09onffAyxQ9K4e0bvvARZYwxNinRw9ehQr+7Tvx94+TYQ16P3ZZ59ZkZ1jb32Tpsn58+etNDL29gS4sJ/v7eTPP/+04ns+39vi0KFD9913nyXD/fffT5+PTa+MOnHixEOVNDY2WhXDGvS+5557rPgTJ06kye666y4r2fz58/WqxZVva2uDXMFAAS6YN3nFV7tlSxg9rUOxiqMZFR999BFWHlbYerMZNmxYeuVrBwMFwgK5k/IqgRqNU7V2Vb5bB/tDb+t2hiLAQIGwQNGbBQYKhAWK3iwwUIALlgarVs3NzZYes2bNQg/a29upWnv37rWSPfzww1HfQvXGBIALBgpwKe075b/66ivrvfDLly+33gtPUQk2bNhA1XrjjTfMvGp5woQJVpq6ujr6MvrBgwdHOUH1vnLlCl0Feac8BVig62a0fsG6lRhcPdXU1BQVyaRJk2ihixYtinKC3ikvtxJ7Aiww71lLNm2VD4JwVlWNn6MiUftqJJvYggULopyQB0GwARYoehuI3qUFWKDobSB6lxZggaK3QdF6Dx8+3NL7+PHjNJnoTQEWWGK96Tru3bs3KhLnT8u5c+dGOfHII4/o9YpXsKuri75nTV66TQEW6NK7oaFhe5GsXr06IrSRZwyqA/cCg4ULFz7//PM02qhRoyIPXnrpJSvj6NGjrTSDBw9WpViFrl27dnsWr7/+Oi1x1apVVrJffvmFtr9aTSvZ2bNngQsGCrDA5Dvli2P37t1UBqr3gQMHrDQzZ86k0Zwvo6Toi7RN1L408mDnzp2YhfOC2B07dtCUzi7wSeYJBgqwQO5zTtioyGoHRWVoYz0hVv07efLkyAP2pPz2ynfrUNDvdoa+AQMFWKDonYXoXQaABYreWYjeZQBYoLfeWANWHE+9SzL2pi/dpvg8CCKpDSFXMFCABXrrrfZ+j7E4d+4cVnrro7fit99+22ewf//+9evX0/j0adtOxo4da2X0vFZqzJgxj2VB75uLXLcSd3d3T58+3cz4zDPPYK6GY6AAC/TQWy3/+++/7DuCT506hSy96Tru2bMnGjjIY3xyBFigt94jRoyIWFhvJUZvvS2w+FnLfJEHQeQIsEDRuzBE7xwBFih6F4bonSPAAkXvwti2bZvVRz/99JOVZuTIkSh6ewAsMES96+rqxhbJDTfcEHnw6quvHjt27Jte1PK+ffvGjRtnhlq4cCGK3h4ACwxR7ylTpmCReL4ZjTJ8+HAaDXIFAwVYYIh6T548GfPWJga9Xz5CkQdBsAEWKHpXCYre/QGwQNG7SlD07g+ABYreVYKid38ALLDEetN19LwZbdy4cbwGQT9mzpwZsdBT8D4AFwwUYIFl1Vstnzx5crHBkiVLVq5cucWD/fv3Q/WoEjs6OhZnoapx8803Ryzq6up0hPQiPv/881o6NEiABZZYb88LYp1A9ahcR44ciUqA3EpMARZYYr0PHsztpds+qMiqDlEJkAdBUIAFit69oOhdYoAFit69oOhdYoAFeus9dOjQiAXvdgZ06e3zbp0kMjOqf1tbW6MS8M477yCK3hUAC/TQW7Nu3boRLLq6ujAnvW+66aampiYVsNPgr7/+Ag8uXLjQWcnVq1fNBKrEb7/9lta/rq4uYjFkyJARLDJvXk4BAwVYoLfeeG0fzoDGYeut+V8lPq9tVQnmzJljZVTxaUZaefYzBt977z0a0AeoAQwUYIHeegO36WiQGvW28NRbjdutjE69af3Zem+5djsDA6gBDBRggdXonQtYbr1pxhr1hr4FAwVYoOidlVH0LgPAAl16r1q1Cotk586dVAa23jqjBV1NeqFIc3OzlRJdzJ8/P2LhqbezUOCCgQIs0KX30qVLT548eaIYVOS1a9dSGdh6v/vuu1ZtOzs76WquWLFidCX0Iq4rV67Q2i5fvnx0FvX19bRiPnqrBD09PVahly5dAi4YKMACXXr3C2y9Kfop9HRN0xsNE857f/jhh5iF8wVnmXrjtedW3X333VZGOe9NARYYot68670xYdZye2GP0ER5+Yg3wAJF716wP/Q+Ia+O8gNYoOjdC4reJQZYoOjdC4reJQZYqIwbN26MSoD10m103c7gCe9mNEy4neGDDz7ALEuPHj1KM27evDkzo3PsLbczUIBLR0fHphLQ09NjVay7u3sTi6amJmCh6kCj+byn7Ndff6UZ6flJyqVLl2hG1SPABQMFuGBpyLFiwIIdre8zJoGBAoIgegtBg4ECgiB6C0GDgQKCIHoLQYOBAoIgegtBg4ECgiB6C0GDgQKCIHoLQYOBAoIgegtBg4ECgiB6C0GDgQKCB2fOnImi6LXXXstKCFu2bGlsbNTLKr3KpfJC6cFAASFX6uvrY70HECgIHmi9UfgPYz5br6WlJSmZ8kSlXLNmDU3c2dmp/o2/UgvxhzFmKDNIylc6ji56xjX053Fx6bUyi1BZdBq1oL99//33429VZKsCKkj8bVwNYcARGa/Z1T2u/jpTKpHMxLEGaJisv1L/aj3iPafOq9XSGeOwSq04ppnMcjgythr6lbNWWLn3NvWmyawInm0ilBlrh4a9O0NnYtM9jUqp93vaN3MYYEobJ9YJ9K4YCTqIKVK8IVhFU72dtcJkva3amgEt81FGOAMWfcQ3P9E7K9OWGGp+rJ+phyYix/Q4ezwqsAZC6UWbO3w6ODETm0cHp976yGLtkOONgm7yovcAxflEay2eNipGdTfd6ybpbY26TZwJtGlsvZNqhQl664KsjUv0Dg/zOJ4JFSm2zqm35y8yvYkp2fLS20xc1d5bpxS9g8HSBl2dm5LYGnubPtMNh47GNfGQm469Y+HT9U6qFdYw9ha9wyAyzhLo3VrSXleLFJtj/qajeltnTszfa5bnZhxzGQ0JM/V21gqzzpzEm1L9NWgyGkQYcJgj8JQzYI3XfsQ1GmPy+CvnaMQaYJvCxGew6VdrjDPYsVTpeifVCit/xlrepp/3Fr3/azQmnzPsR8pZK2HA0Sh6C+HSKHoLgiAIgiAIgiAIgpAreo6AzgOmzH1rzEmHpGnEGTNm0OkGazIlqpzmwMqL/ONJHHMyhRJfEGJhzobQcjXWhShOzNlDmtHCecWIefdB5Jpwp2dXzLkh59pp4mtUnMRf0dtA9FdWudZ8VsrVMjSXXq5PuAquXyaeYm0sk02947aNO9S8pM05IYi9TWGtFL32XiczQ8VZkqbgzQn0GOdVdpHRfc56WlPzFN1ZejkyutuqqgnVW/e+WTfdnno53qyck6pJG5H+NuV6M3PdI9fmY070Y4LtevVjN3z0pphd3MfEelvrZeqtF3R76m+tWWCtlpk96sUSwDl9HH+4xrhSVONsT3+9zWv8kmxJ6RqzX+jlgkkHOEtvZzJz6zCPGmb90/U2tzuKXilrft9sedqGUcLGUm9cAMbQWxedtBZFEw9OrDqk6N1JLpyzPol3C5FLb/8LXNElPFavt15OP8pQSzP7hQqvsfSOEnbyKoF1+IsqdzIpeqfvD9dUXo6lMY8g9NCTtKnqr+I6VKt35iGmaOL1slrMXN94D69bTHcfHQbQjqA929h7ZZGzJSnOi1T99TZ7uaq9t0+/JPW1qTcdqFDiilkjpaQKp293KcOtqHfzsYYlzk+cVKt3+iGmD7D20vE6pmzOSSL56I2G4ZqUcW9SP6boTYmzO21JKiKzX1IsMpWmvzUoZsXoLxGrbpnbXeQaZmvMJqLd57OPtfrOwpm4X4bcMabGZl8Xp3dMferjHbQkzjb333vTIzKFupfZL50J5zo0teiNhp9OvasaclP0qjl7ympqq5V0a/jvvTOHdn2DpXHcsyl61zI4oThV0Y2TtD/x19scZKYMZU0y+6XFdYaBJjAHJ+mFWhWLjwu0wowht4WzlTB1cGJm8dQ78xDTZ1CNdd+l6N2Z9dMyxtI7qW3XVP5+1P+mbBfF6Z3ZL87tztreTb0x+bgft3CSxtaGxh5ym6R3QebB2lPv+v4ecsfQ9Wox5giSDnP1rhODNDFtcGcHNRqXjGa6jdXobZrmo3d6vyQdU6yt27LdWVs0tE8ZhMSfZ253UeoBJSZJb0zeDKvVO3No15c4N9v4F0SS3uaQMkUbKiq11zykeu6C/PU2dc3UO/3gni6YeYaHnu0xfwJozOZ1VizeyejP0wfV/kal6B2XaH6oy43XOlNvzx7sM5KOSmb7O3nf+Bme5IxzTTvJT7z4qxmVM8IxVnek6G1hapapt/lT12LGtasLnF/Fm4OZnQa3qmduJkkVi38G0hYzWdN72taJ1f4pemusaNZ2mql3UitpUBAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEIYv/BzSNDOYNCmVuZHN0cmVhbQ1lbmRvYmoNMjcgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMTk1Pj5zdHJlYW0NCkiJ7Jfbb9s2FIfpSxNAgda1Q7OnIUQzD11Rn5AUb3oa0G7rMAwDthjYQ92H1quxhyxAnRTF/vsdUpIt0xbstE5sA/RFJmXy8PCIv4+Ho6s0ASuMolejyzRhFITNqGHAWUZ5DoLRybs0GafJH2nyPk04ZfjmtA9cCooXTkf/un6M4k/f3yiuF2mCZjJrFuqsLAupqDeD1cqcr/yTJn+lCbpz9uO78ZsPF9cvJ2/+oy/O3fDnL35Pk1ev0cjf2Ms5+7EaFxhjyrlRjlPU0d556P1s8Mp99Lr4k9XngwGQVhYOYzmr+fh5DrOZs+UYK53Fdloo713pavlT8/fWAsxuENxiadTc9Z4uiS6brYyydb1+F4F3YwYTqQz9+fI5HV0VisCvZIVAng+wyc8ZtXQwrqbsZmcx2JIa4MLQARp/9YSckAPSJYdkeI0/B2T4Fi9fff+aDn6tdRQclMFoaTCznsMJuU+GY2x/j3xJemWfnwYLKyMDLTOqjYFMaB/a91MNF4/KydhXL6ZVH1t/g82Vq2ZLAjraKCXYFghxkwUc6bALdNhedD8RAeijEiECHpI2arlDjpyeO6H6ucCnEIi/54DhdO+BgeXhJfb+lrRIqxEEXEpgwkYSRBJEEmyfBAr3dD1PgkdeyRPSRx400UCghnlAg3slAXw2UCMCfjrOXsdX3pJuIxsElyB5zBIiGyIb9pcNErQN0NAuxX+NSQZguYfvdZlgJZg85guRCZEJ22eChpwHB4fTIutv4zHgEN+o8bZT9BE5xpPASaOuM6WA27jXR11HXW9f17hdCynXEfbCSUDiUUAG+/0x+Zo8IJS0GuUvBWYXOm7rUf5R/vssfzwkmFwH8m9h0/s+0S+y+wN/arhshkGuIFf7ngsoYe8cBm7Mz4dB4fXU93JlhfXNr+ZihMiLveOFsKDz4BzwaE7kM0AwYDwERNuhYUL6rstDrHURMn3SI53m4wIIhdlCrsEyuy4gpK1usLnySkBodHUJIKS9CR12YgmuiwAfnnIFYpnfxgosx1jpLLaTq/S96+gtlkRtJk3SD9hbxiisb/65BOxd/mzWogMP6ZAB52YeDt+Qx+TMJxCYDHSwckgy8pR8gbeeln89CMlRmAkzC8QGYOvfyA++tyLDJy7LUGivsNMh3eWWhMbkYmrJDfuL6+n6MWfl1Hc2NZe65Gy5qQzzlZmpzCdIXbTi7Tx2Vl2tTU5w4pro5UYknoDqMzvCL5DvyHCMRdpIQpOBlllEYUThnhxJ10bh9gK/Mc49c+ptE+s4YBwHWKOOuZTARMxpopCjkHdPyK1G3QouQfK4AUfdRt3unm6H42bhWgkmjxtuFG4U7u4J99ilzKeN4s2UAm7jrhvFG8W7d+LFCIDSceeN4o3i3T/x5gpyFXfe2xNvTQzliqvX72J5uTE3ouvC8bvXdjFC1Pe6+v404wJsJqlRAhSvrLdLwwuNNBi9ulUOKldhq0UIcel8MzoHlpsKQQuhZkGoWe5eRbQ5LjeuXbiVRqCJ6sZCvKcoCmKh52OhlMT1KynHGWRZNYNWOE+lDCgbtGqT3mJElMaw2tDgcDIfE/zQ/wUYAAJHaloNCmVuZHN0cmVhbQ1lbmRvYmoNMjggMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCA2MzEvTiAxPj5zdHJlYW0NCnhelVNLaxNRFD4TK25CFdFQurrLIkkYHwvrLiZpmrTEmKZoRNBxctNMMy/vzEQTuurGjWhX4sKN4A/o0kUXLgrdKAql+gtc1AeIQpfiNw+TsVXUC/eeb875zjnfPZchGltXbFtPMCLDdEWpnmtebV5jR95QgsYpSViK6ti5Wm3ex6Zlcjqw9t6S5NvtjF+L/m8dbnFHhX2Bbd1xbZdIkoFPdBv1PHABeFy1he9vAM+2HNUAfkJ06HiU66+TJW5yoamsJJQ+qwmrrelxrX+L/9PyZxOib5eDO0upl6onelFYkl4Rufyu63/kLbsvtKWOy05PT59nGXZGls+yHCbEWd4ybM/lgpVNNZtmiq6zgOowwR0ueryVJUP3ft7tKHaSm4sLsFNEiQ/cKUZYsltKYQ74HPypFi8UgS/Av9nWZsrAWezNtphZhD0FP9PcciP0JzZMvTof+hMV06peAk6D89h2L9aB8Q6J+05voRjV+bqsVGqwKXAqXWvO50yA4w46jSvAx+C/Oejkq6Ff+k5N0omTRiZOkxjNkkKCDJwKZcgGtqiNuAaeRqWAxeHVyKEu+CXg9wFWgkqjDJ1qMewzd5G7G+TeJg/cMBuVqrSaltflT/Iz+Z38Wd6RnwJ9XJv0pmz70YNVcUNTXz/8gnp+51G9UAWLVIWVVXT8k0oXMXOfxhy2TkvwGsM5OFGGApUOsjxw/YqZ+I3a5trkkNcn5ivk96p7se58qHPU+1ZQvxto6wUMB2cupiF8h/B2y4iO1IK9tbIxEe+6M/b8+nZya2XfbFrBdPPBfQZgHpxR/G2sYb8lbGvI5r+dqBrv/0sd/K0/AJ+x8FENCmVuZHN0cmVhbQ1lbmRvYmoNMjkgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAyNDcyL04gMz4+c3RyZWFtDQp4nO2ZZ1BUWRaA73udEw3dTZOhyUmihAYk5yQ5igp0N5kWmgwqigyOwAgiIkkRRBRwwNEhyCgqohgQBQVU1GlkEFDGwVFERWVp/DG7NT+2tmpr/2yfH+99de6pd859daveV/UAkCEmsBJTYH0AErmpPF9nO0ZwSCgD8wBgAQkQAQWgI1gpSZ5+Tv5gNQS14G/xfgxAgvt9HcF67jlSTNEHHcNjMy6P3040b/57/b8EkZ3IZQMA0VY5js1JYa3yrlWOYSeyBflZAWekJqUCAHuvMo23OuAqswUc+Y0zBRz9jYvXavx97Vf5GABYYvQa408LOHKNKd0CZsXwEgGQ7l+tV2El8VafLy3opfhthrUQFeyHEc3hcngRqRw2499s5T+Pf+qFSll9+f/1Bv/jPoKz843eWq6dCYhe+VduWzkAzNcAIEr/yqkcAYC8B4DO3r9ykScA6CoFQPIZK42X/i2HXJsd4AEZ0IAUkAfKQAPoAENgCiyADXAEbsAL+IMQsAWwQAxIBDyQAbaD3aAAFIFScAhUgzrQCJpBGzgLusAFcAVcB7fBPTAKJgAfTINXYAG8B8sQBGEgEkSFpCAFSBXShgwhJmQFOUIekC8UAoVD0RAXSoO2Q3ugIqgMqobqoWboJ+g8dAW6CQ1Dj6BJaA76E/oEI2AiTIPlYDVYD2bCtrA77A9vhqPhZDgbzof3w5VwA3wa7oSvwLfhUZgPv4IXEQBBQNARiggdBBNhj/BChCKiEDzETkQhogLRgGhD9CAGEPcRfMQ84iMSjaQiGUgdpAXSBRmAZCGTkTuRxchq5ClkJ7IfeR85iVxAfkWRULIobZQ5yhUVjIpGZaAKUBWoJlQH6hpqFDWNeo9Go+lodbQp2gUdgo5D56CL0UfQ7ejL6GH0FHoRg8FIYbQxlhgvTAQmFVOAqcKcxlzCjGCmMR+wBKwC1hDrhA3FcrF52ApsC7YXO4KdwS7jRHGqOHOcF46Ny8KV4BpxPbi7uGncMl4Mr463xPvj4/C78ZX4Nvw1/BP8WwKBoEQwI/gQYgm7CJWEM4QbhEnCRyKFqEW0J4YR04j7iSeJl4mPiG9JJJIayYYUSkol7Sc1k66SnpE+iFBFdEVcRdgiuSI1Ip0iIyKvyTiyKtmWvIWcTa4gnyPfJc+L4kTVRO1FI0R3itaInhcdF10Uo4oZiHmJJYoVi7WI3RSbpWAoahRHCpuSTzlOuUqZoiKoylR7Kou6h9pIvUadpqFp6jRXWhytiPYjbYi2IE4RNxIPFM8UrxG/KM6nI+hqdFd6Ar2EfpY+Rv8kISdhK8GR2CfRJjEisSQpI2kjyZEslGyXHJX8JMWQcpSKlzog1SX1VBoprSXtI50hfVT6mvS8DE3GQoYlUyhzVuaxLCyrJesrmyN7XHZQdlFOXs5ZLkmuSu6q3Lw8Xd5GPk6+XL5Xfk6BqmClEKtQrnBJ4SVDnGHLSGBUMvoZC4qyii6KaYr1ikOKy0rqSgFKeUrtSk+V8cpM5SjlcuU+5QUVBRVPle0qrSqPVXGqTNUY1cOqA6pLaupqQWp71brUZtUl1V3Vs9Vb1Z9okDSsNZI1GjQeaKI1mZrxmkc072nBWsZaMVo1Wne1YW0T7VjtI9rD61DrzNZx1zWsG9ch6tjqpOu06kzq0nU9dPN0u3Rf66noheod0BvQ+6pvrJ+g36g/YUAxcDPIM+gx+NNQy5BlWGP4YD1pvdP63PXd698YaRtxjI4aPTSmGnsa7zXuM/5iYmrCM2kzmTNVMQ03rTUdZ9KY3sxi5g0zlJmdWa7ZBbOP5ibmqeZnzf+w0LGIt2ixmN2gvoGzoXHDlKWSZYRlvSXfimEVbnXMim+taB1h3WD93EbZhm3TZDNjq2kbZ3va9rWdvh3PrsNuyd7cfof9ZQeEg7NDocOQI8UxwLHa8ZmTklO0U6vTgrOxc47zZReUi7vLAZdxVzlXlmuz64KbqdsOt353orufe7X7cw8tD55Hjyfs6eZ50PPJRtWN3I1dXsDL1eug11Nvde9k71980D7ePjU+L3wNfLf7DvhR/bb6tfi997fzL/GfCNAISAvoCyQHhgU2By4FOQSVBfGD9YJ3BN8OkQ6JDekOxYQGhjaFLm5y3HRo03SYcVhB2Nhm9c2Zm29ukd6SsOXiVvLWiK3nwlHhQeEt4Z8jvCIaIhYjXSNrIxdY9qzDrFdsG3Y5e45jySnjzERZRpVFzUZbRh+MnouxjqmImY+1j62OfRPnElcXtxTvFX8yfiUhKKE9EZsYnnieS+HGc/u3yW/L3DacpJ1UkMRPNk8+lLzAc+c1pUApm1O6U2mrH+nBNI2079Im063Sa9I/ZARmnMsUy+RmDmZpZe3Lmsl2yj6Rg8xh5fRtV9y+e/vkDtsd9TuhnZE7+3KVc/Nzp3c57zq1G787fvedPP28srx3e4L29OTL5e/Kn/rO+bvWApECXsH4Xou9dd8jv4/9fmjf+n1V+74WsgtvFekXVRR9LmYV3/rB4IfKH1b2R+0fKjEpOVqKLuWWjh2wPnCqTKwsu2zqoOfBznJGeWH5u0NbD92sMKqoO4w/nHaYX+lR2V2lUlVa9bk6pnq0xq6mvVa2dl/t0hH2kZGjNkfb6uTqiuo+HYs99rDeub6zQa2h4jj6ePrxF42BjQMnmCeam6Sbipq+nOSe5J/yPdXfbNrc3CLbUtIKt6a1zp0OO33vR4cfu9t02urb6e1FZ8CZtDMvfwr/aeys+9m+c8xzbT+r/lzbQe0o7IQ6szoXumK6+N0h3cPn3c739Vj0dPyi+8vJC4oXai6KXyzpxffm965cyr60eDnp8vyV6CtTfVv7Jq4GX33Q79M/dM392o3rTtevDtgOXLpheePCTfOb528xb3XdNrndOWg82HHH+E7HkMlQ513Tu933zO71DG8Y7h2xHrly3+H+9QeuD26PbhwdHgsYezgeNs5/yH44+yjh0ZvH6Y+XJ3Y9QT0pfCr6tOKZ7LOGXzV/beeb8C9OOkwOPvd7PjHFmnr1W8pvn6fzX5BeVMwozDTPGs5emHOau/dy08vpV0mvlucLfhf7vfa1xuuf/7D5Y3AheGH6De/Nyp/Fb6Xennxn9K5v0Xvx2fvE98tLhR+kPpz6yPw48Cno08xyxmfM58ovml96vrp/fbKSuLIidAGhCwhdQOgCQhcQuoDQBYQuIHQBoQsIXUDoAkIXELqA0AX+j11g7T/OaiAEl+PjAPjnAOBxB4CqagDUogAgh6VyMlMFq9xtDNa2pCxebHRM6jpGWgqHEcXjcBKyBGv/ADUmExsNCmVuZHN0cmVhbQ1lbmRvYmoNMzAgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMD4+c3RyZWFtDQp4XvsPBwA20wn3DQplbmRzdHJlYW0NZW5kb2JqDTMxIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMjg1NDYvTGVuZ3RoMSA0NzI5Mj4+c3RyZWFtDQp4Xuy9eXwURd4/XlV9zfTM9PTcZyYzmWQSMkAgBxCIZJBb7iskwCzhvoUAsooooHIYUNFdz/VCXQUVHUKAcLiyPqy7HizseuzqrsLug4ruRnl2WVaFzPw+VT2dTFz3931+r98f3+ePZybT/enq6q7qqs/x/lR9qoMwQsiCNiEOTZwwpazceV3yDkj5I/wa562Ys6p4w2UZIVyDkHHyvHVrw/tePXs3QvIuhMTrF65atGLAT91xhGyQ3ZRatPymhde+tP5phIIphJoTixfMmd/r3acIQs9ehAz9FkOC9FJ6IELPlcBx4eIVa28c7ck7DMdjoYzE8pXz5iDXb64itGcnHA9bMefGVWKLew1Ce89A/vD1c1YseH1r07NwDPcjG1atXLMW6g2fF5fT86tWL1i1u+XCF3AM15vLEMdtx7uQgAzCI0IF3DGg7bnfoIXEbhCISeQJ/fDnUO/MCXTjTLiLkd5v6rihYZRA4cxV4Z30JFwhDcYtCYQzmQxCfEw4RktDLthy2V+QtSPiesMRUGIC8ZwdEh6BlhWRH3IXoxLUA8VRT9QL9UZlqA/qi8pRBapEVagf6o8GoGo0EMocgq5FQ9EwNByNQCPRKDQaXYfGonFoPJqAJqJJaDKagqaiaagONaAZaCZKotloDpqL5qH5aAFaiBahxWgJWoqWoeVoBboerUSrUBNajdagtegGtA7diNajDegc+hx9EfbR5/kfXbf/qZ9H/sd+CboG+jMOIqkAV1aiImQGjjSBjFdD3/ZEMVSIrEiFHvZDzw1EduRDEejNCcDPg1AeciI3ckCve1AAhaC/vdDfQ4Ev8oFPxgNPGJEEPM4DZ9QCHxQAb4xFpciAosBD5cAXMnBPGfDMKDQY1QBXDQH+HwOcgv5XItD/SsT/je//SkTyfyXi/8Lnkf+x3/+5EoGEo8gHP7/wHPLxMbgzynwGvwt0n16SuUDP0z0BlIfasj8AjGgfXoL2oVfRa/giXPUyOoJa0a+ghsPQo8AvP0bboIwZkHIncOBkwITD0I+xL9MK9dgNdd2NTkHe6ehWdBS5sTfzOdqItnDvwFVboFUKoIYTgRPvwmMzN6BZ6Cx/O9R+LHDnKrwpU5+5O3Nf5hn0U3SE+1WmA9rRD9w8D53KfCn8PvNHaJdZ6H70MDqL7zMeBAmZDvJ+hHsMePoRLsnjzKLMt1CDCPoh1IGH9j6FT5A43H0B+gx78QZuKNzl6UwqcxJyBUFeFkMPHsVVeCSJCLMy4zKnoDd6gVxsgjJa0CH4tqFX0IfYLFzMPJO5CH3XE9p2I7THr/EJLt2xOV1LGxpaqQf092h4rp+hX6IzOIp/TlYKZqFcSAjrM+9CL/cFOZ2OnoMrP8X/JLfCdyP3Oj8icy3wzRZ0L21t9Av0J+zHZXgCriM9yEryOLcaeronXNsXJHoJtPdDcPePcRwfImZymnuaf4G/Iualz2UU6JEY+gl6DP0cW+BJw3gNvg2/j/+TDCWzyU/In7kf83v530pz4Kl/ALrgLvQC+ie24wF4Ep6JF+MNeBu+Fz+MT+Ez+AIZQqaSZeQrbjHXxL3CXwvfKfwa/nZhq7BDvJCuT59M/yb9z0x5ZivooA1oM9T+fvQ4PNkRdBp9AN+z6M9YwCaswDeMI3gavhm+t+K78FN4D96LW6GUM/jP+HP8N/wPfIWAEBGRBEiEFMA3SlaTH5Ifk0fJafieIX8l33AeroCLc1VcDdfArYRabeN2wfcg9yfez5/mM9DO5cIDwhPCHuEF4TXhomiWbjMgw9tXn+4o7fg4jdLb0w+kW9KtmT+B1PmAp4IgXzVQ+znwXQr9/QBw3MvoHWyGtvPjUjwYj4WWmY2X4iZ8I7TkHfgR/FNW95fwcWil3+GvoM4WEmR17k2qyLVkAnx/QBaQJrKL3EdayfvkW07iTJyVc3Gl3EguyS3g1nI3cQ9wKe5t7iPuz9xl7ip8M7zM5/MFfIyP8yP52fwN/OP8Z/xnwizhLeETURZXiFvFNvG/pH7SYGmiNElKSvdIh6R3DY3Anf+BDqLDuYoSn+M2c8O5g+huUsH7yK/Jr4GfZ6P53DgCnEr24O3kFtxKCoUbxUFkEB6PLvIxaOvXyRPkMhnEjcNj8BS0lPTV7iY6+edhV8P/B2rnj8Oz/RrufKNoxreSr0QzasGIVEOZv+D68HHuLfQhdxZL/G70B17GHtxOnuMmAhe8wg8W6lGEexS9xDXhW9BBMhy83iuGncDH4/HzoBem4nL8NZdBHBkPXNSf+090O1pGfo/aQY63owfxfH4RuhtV4A3oM/QsSEUP4XqxVHThN8gSvpk4cCsi/F54umpciDnBie7ASe4R8SvyAVi507yMPuZehNqfJi9x4/iLwmS8GCTgFrQVNWU2o5uEev63eBHicB0qAuf1x2gDV85HYL8RtMos0GmHQLqPgh4Ywo2DFC9wzljgi2mgIaj+fwj0BA8ctARkfDposV+jVnEqaUOLBAWD1gFg8lZ6MpqReRY9nFmErs/ch3qBPtiW2QB33IM+QfegPXhL+mawzCGQnI/xWGEEOS2MyPQizeQDMoU80L1/obWLsBd9Ad+X4GAw+M/N/O8AB9RmdmbeA+4uAQ37MGCA69B5eMovoYRR3AlUkR5P9mdGcKvgec+iSZnnMvlYRoszy8EOHUc/lQQ0R4pDH6fwb+F5b0YLyOTMWm5Begm0wz3QCglorRtA/9zJN/G389+gnSDzD4C+eRLk5nmQHCr7KDFzy9o1q5tWrbx+xfJlS5csXrRwwdxk/fS6aVMnjB+SqB18Tc2ggdUD+ldVVpT37VPWu1fPeGmPkuJYUWG0IBLOD+UFA36f1+N2OR12m2pVLGaTbDRIosBzBKOew6MjGsOpWGOKj0VHjepFj6NzIGFOTkJjKgxJI7rnSYUbWbZw95wJyLnwOzkTWs5EZ06shmtQTa+e4eHRcOrUsGi4Dc+YVA/0XcOiDeFUO6PHMXoXoy1ARyJwQXi4d/GwcAo3hoenRqxb3Dy8cRjcbr9JHhodukDu1RPtl01AmoBKeaKr9mPPYMwI4hk+cD9BBgtUKuWPDhue8kWH0RqkuKLhc+anJk6qHz4sEIk09OqZwkPnReemUPTalDXOsqChrJiUODQlsWLCS+jToB3h/T1PNO9sU9Hcxrh5fnT+nFn1KW5OAy3DFodyh6U86897uw7h5vah9dtyzwa45uHeJWF62Ny8LZx6clJ97tkI3TY0wD3gWlI0orF5BBS9ExpxzJQwlEa2NNSn8BYoMkyfhD6V9nwLosNpSuPScMoYvTa6uHlpI3SNvzmFJt8UafH7E0cy55B/eLh5an00kqoNRBvmDAvud6LmyTcd8CXCvu5nevXcr9q0ht2vWLOE2ZJLLOg8xyiWnVJjJne2LKY1io4GhkiF54WhJvVReKYBdLNgAGqeNwCywacBw1Wp+dAjS1LGoY3N6kCaTq9PCUVqNNz8DwQcEG3/a/eUOdkUsUj9B6Ik5ZNOVoPzOp2Kx1OlpZRFpKHQp1DHwey4qlfPdW0kGl2lhmEHzYcmQtvOaRhYBs0fidAO3tGWQHPhILVpUr12HEZzAy0oURZvSJFGeuaEfsY1jZ7ZpJ/pvLwxCpzcyobjXClDrPPPqrodwxcPTGH3/8vpBdr5MVOiYybNqA8Pb27Mtu2Yqd2OtPMDOs9lqZRjaD0XIFmKBDh2FphyVmdmelBvTvFF8Ccypp7fJhmAK1kKDo9IqY2jtG2DHIn8Ny9qy1ykV7Fd12XZaqYGxrsfD+p23K165mYOKgzmdczUGc3NcrdzwGpagaOzO+B4NLU+Eh6aQtNAMovgry1zYgD9NQRSCWiyoTQD8J+WlD3sljGQpRvgQ7mzV88RoOiam0dEwyOaG5vntGU2zY2G1WjzEfIaea151fBGnXHaMkd3BFIjdjZAWy3GA3v1jNIzzc3z9yOuCIpJBPZjRvQfuqMhNSHeEE3NjUcj0foF8Cz7ByJzZGrjUKAIunZ/FG+ftD+Bt0+ZUX9EBW93+9T6FoLJ0MZrG/YXwrn6I2EwFSyV0FSaSA/C9ACNwdA0LcTA8geOJBDaxM7yLIEdz2vDiKUZ9DSM5rURLU3VCoqxghIALOe18dqZhJ6bhzSDlrZJy12SzW2AMyo9cxSBxUHspPbZDwdT6xNy/8TAxKDEYFJLoEVoUgukHIW8gzA6MBjX4sB+uOdkltyGN+0flAgcYXeanM25CXLStE2daVBzmi3nRlCe9uDTup5g2oz6A4MR3J9tIce19EM1LVQiV4aYYqJ8Pj1ebybNY6YAB9KT8oCAnHM6TC9M4WhqdvTGCH26VF30pggkRlNh0NaQaT8aGWxobg7DNwqtMq+uXtvSU7hnEO7UkNo0V88bCAJPdB2a4VLGVweCVId0lnazXtpqKI0SzXpxqXnfWxrUPoVn0i37Y9Xf3w9FtfLBSmuFNs9qngH8GEnl0YKz9YBDJdjA7gA1eYjVBDPjNA8wwUIqS2Gq5EBNRq/bT8bH2R6zffN10eHzIQf9gdGtgs6KhOc30FxRKjSU8f9tJpyTiRoSdvNmdZB+hLNHmvg2pxZ1P1zceTiC/gCjFPXW1AQ8CxPZSGppILW8Id6ZZQ595maQ7YFUwAeyi0fSXyOYnZGpTfPmQBXB3oyeF4WE6yAhXD9Xa0FqqJspcpo3By6jrZwtKXV9vNstQSdgUFFwI/o4qU0Tw40N4UbQIXgSNHYgnBJgH14I8Ck6h+qNidrzTATlD7s5zVPgWkS7LZCSQJ8tnLMgSpVrivK71vq0jjzUDk2pT6FAc3MUeAiqWDQCMsPtYykxNpru4G9VPDpnAUV2CymwW6BBDqguax16t8DwaKQBspAi1pbQcCBoc+lmXjPFjcnGOLSErdneHK5uBoFPqnQ6al5dI+i1sBoeEWZdPScAR9AIo+lRA9xIy2gsohnhevYXS62I709KRV0p7G9lXMtsYHdlICI1Uc8isT8gmuIp4hkAJ+nD48kzmF2AjqKNJxSNhuZNAFcF6NUgRVOzZkO7fjS9NKB3mHYZpDToBgD4fX8R3j4xVxPOStnHTJ4ZgIbtBXrzLOimK8IJJGMltSVef0A2m81tONFah3RCVkwmLUUnZIPFoqVoRCJSxyUstspl/EZyD3nYwL/IYyMSBcIZBWwm+E0ZgVVKyJFoZR+Ew1BqW+Zcq6qSaUB8kbBZrUAFzWbYKhYLS72Y8Fmt4jSkms10a7HA1m8WEhZrpUDvpdB7CTgsJAQi+ExHcQ3egrzx8er5ZFM8rl6Oax84qBnXUYNqaz3V2Fbdtw9OomQcaycDCaibUUwIghGbjQLy1tbaq8v8p2z26j59GyJRmyhKVf369a8gV1qHvDP1wT+XreVvHrwh/6WRb86G1hyRucCdFY4iG8ojDtp2iQ0y4S1FlkrLMItQ5awKTidT5cnOKcFFZL6wwDjP2Rg8kf+u8J7jI98njk+cX3n+4vsk71x+Jt+dnx/317hr/GP8q/J35Uu9SaGlt3sgqbKMIcMtI5yjg9PlOssiyyfiZ+5v8SVFxS5OMalW0LkmyYZkV5AzeYfIma+RBVlwAtUhL9BmZKZ95K3A6Fjmb8iETKzLimzWIWpOVmvmkpaV0dl8icI6a5GqnrFh1ZawNdo22fj8hMlEpuUnaAfZ7LTzbG2ZS1rn2URFga2XnWvL/A2ymsRpNkVVRXr8ZSvtRSC+bqUdaTum1+5QnW2tXWcmu85wdo3PDtXZCyU1myapGqcNqntVOi2dlTISny/VShMkTgrRekleyj5SiNZAMtPSJTMtS/LToiVfqHIi5Y5LnWwRH9cOREe865NsqlFpmtoRrzkfj6Pa9toa+rNVA0P07YOSuCmJmgL7OVcbV5aQl3MmrChINgXgsHW5SbIiykHx2gp7dW2cMlCVGC2Ixaoq7f0qyt0eW4UNO90V5f2qKmPRApEbsODkxvduWPru7Y0PlB3oCL94w7qf7rn5xt1bH9955eknMNc8aQhRvh1B7G+/+fPXP3z7JDDcmMwFPsQPBhc/j7gZw3nyUdBFpnFJIWmcZlrALRNWGheYDK62zHmtpYFITKZUXpBui+0fCN86L/v5vvaBvr7BIfZx/iHBSfZZvsnBOfYV/jnBG8UbXZfJZa+K3Nhq8Xgmuhvdq9ycO2jdpT6pElXlA0FZQkfJ8whnTjARxkwcaU+rGOP7HUHe5AEGu9jJVB6dqRidZbwDdZ6EpS3zx1baYRbKIrR+QHzBeMVCb2osLq1MWbDFnw9HB4pilXR/OASCn4/z3ccyV7VbHapzV6iGLJ+ouo5Ss6rJUacWSonC0kqdXXQuo/xBM8TrpHAOBwUZBymMg4KMd9yMj4CD+udwELBLfBzlnvOQBtx0uYmmMZ4CxulIwonadtAmyZqOphoMDFRt17VPPI6bVgcSeQhNRKvQJrQLCX2yxAl0BolghVQ3ZTHLchWpfVTi4FSZdzAu400yZbeW5dAJXuC1uL169g+SZXFbRVmyCXgOe0RgOmRTUUU5sjmliJtyHI7EihnP/eBozy+PfJ7+Cjv/+B5W8NULcsuWeTs7PiSTzAPq7tywF9d5nm7F+ZjDZlyS/jj9jRp++ehifP/WoYufBa39Mf88mSC8hji0jrLfEeCBXx3w+CoJ7R/Yc7TXYkBsxJvIWcyt5DaijRy3Eq3EZAKeSAhCnMoRbhvmcRtpbCFbuTYy5SDy8R88x9p2XMelDlTbkayhTQUfqqTBLcXIC2oZHs/hqOA+3vLXP/LPY2/6QiajiQTU6GnA9PBJIG2Lb0cC+nvXMQokFHIucjFCIjIaFSc4coQU0Ak4HE9WwYNNBFXeDpLlJ3Pogx0HPr2o609ZZy2jTlg7mU0nbEAcoQy+nzAvoVLZaMVWyvK0iznE20FRe0EysOKSDFRXUu6jW8ZzKuO/MspBp959nSqedvVkspz++vYJJEYazTg/ONQx1DPFMcXT6Gj0/IT8hHvE8oz6jN9ssPjkpWQJt1S4wbzKssnyrPmg8ZB80Gx2m7ea/5NwSsFs60rrRitnhSZ/PhHrg2ilGqFau9CT6By6iIzIajWhrjoGoepgTL7PKljrrIWKgcqDUhCAduuWDWW+7MyGCk3xfIwRaISEEmdthBNZPY8T2VbD/ZisJsKQROUNJ6gWwaOo1GE/LQWPDrp08+DSBdeliTiADlfhaQlTuSZZgZXpDSQ7E1tz9rqswB+qk/oGKk96dWyQbGK6XgcK8eTqrA9FuRo8aDi7+lKcbll/gCjbqsvU5Hn4o7agCSebGjpxhAxum12xWu28NyumJjsTU1NWTOHaCvrLEdGsWZBiVDJdzDJwNfvzvnrpw/Q/V39+574/5r/s2zhj+/PP3LH0brzFc/g0zsPyi5hsfnl3YNny/3jn/ddugx7YhpAYA86Ncisp5w65Dzly1K2aQ9tzaFsOnafrUaCDOXQgh/bn0DS/3uXBHDqQQ/tzaHMm3Ulbcmglh7bm0LT+Oq3m0PYc2pZDO3KwTC6usefQthzakrnEbI2hLUsY2zK/T4wzWSqL+PP8eeOfPJ+EhfeEy2HiMYSjRm8gbOS4aCgouoLAYxIWo36fKp8pwruKniwiRR6PXynaZcM2nkEiL4NDbZm/JkwMEjmpgMPxhYSHCrmNMGBkZsBIpAgXzn37HXjUhpMHvLpq8eoGzctr9spS5y3aFcABVlKgs6QAKwmOv0zYaEkBnpYUYBIBqemEid47YKZlwvFVVmYAijqESEVULySqS1tUk5qEsy5ahM8gTJUFyUe1aAKoM3q7PFooBeaEgXTYmmmxyE2LRbQAWjKiENHJkLzMkLzCkLyvsKgN33ggMhJAWXx8p0kFoVxdo1lVNSeRCmrXYTzZMX74gmGfNoFg1tTU1NbWjFPb1XYbBfh2ZmWH3pRQzE5HzGm2BbDd4gpgqujjm3XrG/83H5BjVfbL4AqJJsB4fQ6B+Bo5MQRky3KRSXJ5OUgzfECOK2wVrn5MhOnGZYvaKjVRZhQQQG3bXf7s0nUP5t/65uPPH4jOGrzqx63188duHsjH7h8/e2790ZcPdRSTx5bPHnj/Mx0PkpYbb5z4yL0dHwDU2wp2LR98CxWgnp1BvZuxYLYWClXCcEGozU/lk/z8gmBF8Nog9RjEgQ7qPox1j/UnDUlLvTXp/oF/qWG5ZbH1evf1/hP5H5g/9Hzo+7Pjr56/+v6T+Ry+sFBmLXP2EWqtCWGsdaKwUPgw7x/8t6pZdSm8SMC3AGYH10IB1yJXrrw5Kt/baRkK6ryFZ0xYNSVMjaZNJl7zE0xmyqQm5heY2jKXWymjAHGxlXKJiUog5Q0TdQcpe9AUjVFNa7GNZHnRZshqcFsFsuu+KK/DO8Qz7uMZY1VwupXgsvjPV8cVEXIC4134SZzCFzGfj2vxBIA4wMU6gL2qsTNmRhkzdsZ2ys6YuRKYiiazTTSrm1YZe5mVcjIr5QuN7I4Ns5wMnoTGuOeZV9F5KosSa+Gvy7mAK8C7aMWyqlAH4+ByxcSLmm8hSkTzLcCxKK/VfNMKG7BdiLhUFC0o5pyeLs8C93qudfX+uS83JdJ/e+X4MlI57d51L/70hnUvCkc7/nHPhHveXJP+Kv3+Y/iBV6ftOPXWmddPgRnZghB5HcyIDUuM2waVObDK4yhfyQ/lp/AL+bW8aLQZjAajxWEzWhBnwCbKHyKSjSW7DNhQEHZgBymw6YrEpisSm94htiLMRgHUin6VF+mUQRjA7jnAbVrjMq//64SNqRWtS0WmULqpEtb2SGSqhOEQNN4+ssuoxzWPX9MgyUurz4PjX9tuq66GPwbCkfrGNuWWk7TBV+Nk4DCVdRBxUxvXL0fEc8UbDDS0qQTCvOWpwUtqZ/5g8LXXDvqBM8THdjeNGvhc8cjaxtUd78Lz1ACEkoQTKESKaRPuFxkSNNpUi9fhYB7NpVabjRFfJoz0iSwhpxBipoFmCIXo2VBQgTMh5ruG2sixhJnIHk84X7UREs6HRyh7l45PlJ1CZZSL4rV0e5LCxCz0pAWa7XbmVF1KGK02opdzLmGyO8i0kJOm0Xu3wK2h+FbazB5qSNjgy/eVBriUlUdLO6lh0kHCIPGY8Kp4TPql4Y2gNNrcYJ6qLDPPV9bb1zvutB+3f+L/JHDRb37VdNhBQrJqEMU3g35nMOg3BP0cJgZ/kLOE1DbyzIEJYD3bsPcgrSeiFTuAiVkGpdOlaOQcwNI5zgGmUF7jeQchnIhEK/Exshl4SsUDEmbbwVoym6wkGwlPjpJClI/v2b+DcknyUjuwSo16SRPBmo4a6qydt9mZ9fBUb1N6x5Vb1JOYSWWKDE0lJkKbBtSgmqeGVPFn4BdImXPIAHsj/AbAB9NNA5Xg1Q0NAdq1loAkWQjYjYrW5cTstDAo6BR0KGirgCYFFityRWL9+/WDP01wpWJmT1xOEfhNlHjpan/iKXr6ka/2PHzzbY/iI46vf/PO5VHPvfbUrNC+fUNq5p249eQnC5f96NFmx+kPvthX//zxZ7bP6QvGY1rmM94GnAjGA6cZL2qsIftDvOAMWSweI+12qpopkfDRbjfaEFPWyK0Zc2bYqUtyivU+xcCUycR/vZOmw4H4VIdTXyZ8VG3CLbWBu+wgHkMG+i277pkYz4vbyHbTdusbimCUTF4y3DHWdZ1vaGCqY5Zrlm9yYJm0zDTPsdy1zNcYuIn8UFxnWm/dJj4kPaC+4f2QvC++b/qD1d9ZpW6M872DDwlbnWeNkTJNHyNGRtVIjMyT0TMaMxe0jIfrjLvyuzTYd5TbgTrbGqbSzHAnusKBdI6ZIoNup7Ssh+rQrtAvd2QVVTKu+x6grXRj0E593iaUzDJdqxj2qUEwlS0kbPoZsJwbfnb4WeE3QOe7BuC4/RYnsxIWC+9nnMZnOY06zCrzMtx2l0rA6yiOOVRqKGwq8JskTlv2zpPrWtZeu/Sd3e/edO+RvRs27N1764brkuQdcNCveXH2gXTmw3Q6/R/7HjqMH0s/+NVFvBgv/XLJVtB2dZlPeTfwWBxfzuEwk8/L7L43iNiwUNxM7WmPqGyxmq0hWe7hCgX5UI+g0MMStZi9PozsYWZtw1KMsiTNHiuj/HGqjH6Rvbq2lqI7EJj219XX7dXqyXg5/VG+6SNY3Jbhlq0Wfrhtum1dgJvsXq4udc5332C5ybnV0uy8M/BTi2wyWxRewlAepsqGzhUewzRaz4KrAHS4eO9R8gzykcUJI9ROgOpZ7N1YKNdxsuewkH3N7PDKMAl7KY+HN0ndLpJyLpJyLpLWxBjfxTCKqTECT33pML0+tquXtw0PaPG9g4/iAeBLn0iYOrlqV882fF9WgcXbmQrLMs4lDR0z/uk4T1V1u8r0mabOOlVYixDmwAIAyzRQFIybqKIC75yPmi1WmcENqzXYgwfq8PIeFp/XG3QxXgoyXiovq2A+bLyivDrrxjr6uzshh9S/C31klRjVYhLdAjyJ1bXm379s48tP3VIx1mk3rWnbunTJTmdr5IuXbnxz2cL5t+1KX3j/5xl8u/fhbanbNux2Pk5uvGXebXfcET74y0Ut82c/2jv0yt0n0v/4FHru+fTH+HZ0CsloPmW7gzKHpBfENjwxEcNcDSFYxjVIJhwcIHGANHACmo1Woo3gvAjoSdPuh6AJLyUvnVfba9QaaDTYAnd1tGvqPnBQEjGdA/bW+oH7KAioqqDPAY/U/9CpidPLq/txp0417YiN882ZmVW0PmryUSmZ0WX0D5vyvRgV2bwU8VLd6NVdTS+d2Cih2tBrYybexlSjzWvrGTeVhKxKvjJB4RTFiSZizCTIogIowHwoaCmg1pH288l4spyOLLaXM0gDupSqU/XUu6fUj37RCQRyKvEFU/WUSJQy6bSxYad/U2r3sr5TVFluQYmRA8HlSERnuqdHF3LL3Sv8i6Lr/beEdvp3hB5x7/Uf93/h/jR8Oey4xv24e5+bG9hjvkhKQhOU2QpRlCAtBL8zkc4GkcWttNj8IcU5IpSfI0L5OQ5IPq5Gppx8pszlznymnHwmQAI2L5M2aAmv6iXeXT0xCNlBdLBIV9RFuk4v0nV60RqbPsEUtiVsxLYr/ktd9KjEgfRlha9zsDc71NveKW7HUDFo6Wjm3IFIWAzrAKEJJ0FdH4QmNiklGsRXnEGeKe+gxVnwHZhQFi/XcIImaoNJVWUxHTqCPQIJs9uYSo/hyq4BpFX73BvmTLllYj/c79iKQ1ex9Po97Tev/6+nXvyQvPXTtTe27N1wy248RV1//diNv19l9tYtw4bfn8XqI+n/TP8t/Vn6wEuvcpU/OXTy0Z0vvwzsfQSQ1VY+Bg6/hMYztyAMpkWUjESs4bkaLPIyqSlDtYjQKb3dhqx4NbUD6gadnR31ZoIl8AaU0IZxa9lALggWB78jp06d4hpOnbr63CnqhqxG7fxA/hB0ZwMrLx9dbyTfGLjrBUk0Xi/z8jcCvr6WTCCE+MzTZzCfKznuUg0I8vmaGlR2CQDdJSjvMIi7IEscAQi2fzkH5YLmKq8oY6jLFqmKgPsUcUVsBKeb8D3P43vSTe34vj10vyd9PTz64wgJM8D/tgKE0h7dHs7HQw3BvBDBxKaGrMhAgUb63wCNy5BOFX5+nScWNmLNGzaGqZtjlBnwYj4xRU8JM1UBRn9+XtfchZx1ntTsKIxSp4bZvGk46yhdZiLNiOyE6bfMtwbin8yTZs6UzNBXMjRoVpeHlGTeUY0+CtqFg+HHhk76cQHJIBoEA2/gRZ/X7yWiSTbLFpkTXW6n2+HmxADniWC7AhuvIRjBbtkWQWxcpRQ+m8Gv2o9UBn6RAecB0bIck05IAi1f7nF7AJI4iUKiRZHyLAIujkUjj+NvXphxa8PaNePX33tqS3o/rr73p32Hj3tw+fh96beFo668sXPTp08+l07vnVO+r1/f4Z8/++k/S0N0ajvzmfCR8C5SUABPZR02xm/FTtXpDHgCAZ5XeafJYwrwez2HlNcVzuPxBkg4L2Gb4JjgSfjrhXrjdHWabbZjhme2t84/PbDD8zBRfSGOs4dMRle3nnbl9LRL7+lDda5YWMLSz3JgpASIhvaXpE1vMeIi6yaJKmU2Yq1bBiC+TShs4Nq/KQ/nWYk+2aAzhVU2swENuc4ao6zQiTDNZn0kRGQIW/OOfcF5szrHJJJsYmq8muycFx/3XdiZTDYF9tNR6/LW5SYj5wOiZTnH5SBJFCnnaafx0YJC0l+bYaokoHzQPLwd93sLj3ihNX3o1dPpo3t+hfN+9wccuOnze3+d/h15E6/Aj72W/ukfz6afPPgrPONn6X+mT+NKHDiATT9KfwLP8hBCopUOd3ETWRCCodSkCQABImdi5Qg4XpcTJtqEBsUCbixhTQuEQL2OEkqZ7fS0YDVzAHCIwWhSkMFIZJNIu8KkZoeivj3EhqJURN0WffRBF6qrrd28H+qq1J44oZ45c4KCqngcmoy2nu4N5dMJRHGayLYc2/JsK7CtgU6IRylF2GgSxzqIsM42MuGX2VbSB4ANVHbzGSoUsDks2yutbCOYOYQVEzIYMJHpg9O7yfr0unyMAD5FKqlLWJA5hxP02yJMn+VS2SUm8bU1NdrDJLWnYR/EtoHERkSsBicJGPh15q3mX0FTmkebR1u5HnyRpadSz83k11luVLZZDCYiGKot/ZQJZAw3TEoYxlmuVeSHyMPcA9IDhj3cc5JoJ1ZF6SMQpyAQA2CePoIBSIN5snUyTmBCDAajbDJZLIqi0n5qtG+yE/tRsgeEqi+gVkMb7nvQbJRlPfRE1jSisU4OJ8wbTdh0FB5bwSbIS9pgZ2WzUl2IADEJNVNfDoWtq1SstpG6w2GhUdgkcEIb2XPANqjBG/dRXJis8XZQ3dju96ntcOTPOTyfpCNwNRQxdn79anv7NqF3fNstJ7f19tJd3z5oTMo0ZUwqNGlG/SvInLkCHPs+Ipn3KQTAY1JmOFcyaYaGE+hkkyXz9X5FpieHzmKH7x6KVCs9I9WWNiD7Vyvl/Rl5sBek9qrW+qlhNQ1FSFI8gWh/WUwGZBAUg9lArEzVVrCvNo4FCtrTrz+O2KI2HMW2h3AhntnH7avCs7FwLF33crpeOHrlb/eOmvgT7uq3I/i3rlTx565QDfMq2P/NIJUc1qSS6DqJ0wkiZbuFA2KIBrtw5pucxv9GjzshglkTaQ6IzqxXNO3Jsl7RNSk8gYHQKJ8DA65h0T4HKiq1fa8+2r6kh7aPFmn7vJC29/q16KBSi1oZFnYJLwscF8YI3QMOQArxZWzu8yy6iAR7GBJ3IY5lNzFx92bVwF91NfClblsvJ7QZDibO6Cn+/YYcewrd1rIJXKlkQ9PqGjrxr31ozFGOZEEvHQBrSPsmO7poe/U14ei3I6CdHwWwQQf7jYSwdua8ZvPPWKMYMhc05m2ps5tYCJXDVWnwmt1kGsf8ZY24lIjabNdOM5jZlsAzSwanJBmIxHEGI0+IUTLwHBixK51GjMsxYpyefrCOC4uioDeBwCJ5aBsImk4FcJHwM8WWDJtw2DTR1GhaZdpkEkwGo26mjLI+XR7WxnstUOX/A3TRNDris1NH/4pg5EE5LR5PshHeGjXZxIxbDRtar2E6zU7Heaurt/FMKDX9fAQe8Nxhs63SEIYNyEsD1eAUr0DXtRoSI6pp3MKhEdWGRLlGlldLBb5qsC0fH/IBWa6RNDXKyIQpWi0pTvg56PGlQw4g8zQyD0gXJb/e78pKqz7jxLSrJrBmzoCwBELLE40namspWtY4AwNzgKA++kuOHP3l1TRI52Z+I0jmpiubAOnUZ+4WvgSk40IlhGNI5/7ZsSdixOft7yKmIJ/PRwNBZ74zKpYKvTzx2CChxjMwNlYY6xkdSwrTovWxlcLN3HphJ7dTuB89wj2DXuDeQ++5P0GfeD7x+oNCHJUKgwQ+KdznfSD2XowvcpfGKt3VsdHe0cHh+cOjY2J1hnrbNNeM4Iy8uvzp4ekFS4SFrmWxm2N3B++O/cH7x5jP5MUu0FktgWroxXcTfQLVvNfpLRUGCjzh3CWcVBLzusGViHAOv0DoARIKQyErRwyFIcno74a3/Dms6u9E1nKdP+Zgc6AOXVIdTCTMjNBmmBw6vKJEgsUFOK4j/nDpplJSGtG1WETn3UgnxIrEgMFNncjK5GXzVcyemnw9upBVF7Aal5386ZrbsXmq7dqcpKca2SrUN9Q3NFubTKLVTWzCJ5BwCQhJVm8sVhgqcbsLrSTBcVIhQ2GS0RpiKMyaRWEVWmxiGd0Ai9AN9WdoDEGxSEFZVaW9sEIDaZDaL4vOWDBQ/1gx/49tq6sff+zpX/wyffzlFB7+BkVs13d8umfFCwDUPkj/GQf+uHjWzAWPJePbqm+eeQLP+vADPP/oz9M//fBg+uxdZclHcXULln+U/l0aMqd/XTzIR90+AN4FoLyceBBjRjlmrefrDW8YeDeVfjdIfyU/yDCCv86wzvqscMEqmRGx0dkH0ejs1s/OnH526v18oM4ZI7pCIp0KiTCFTOikBlNIJBl247B7opvQeLVNbs5t0XvXoveuRevdQ3WWWFjGsq5OZaaYZF0xybpikjsVk8xngZammOROxSQnXVQx5QaF0e4fpwKYZsqqE2WzgKY4As9ItIFDdGi5aETEpEk+Rde4wpYF1lXQs042tGbjG1+bn77y7q/T3656beS+W94/JBy9uv+j9NWn78aWz7kJV1tePTj3NeyETngKIZ4u5jahdtYJLlEIGQyShDie+quyMQSoUaJP7FTtldJU7rqwHLYQ2W/hjXo75Wpwi+Z0Gv/bTue3rUZjZ4qoBfBmdbd50MzcJkpqE/w149XL4Lmf73I+gbFBk9fQASzBAG10cLkgYGTU/Ui+mx9JR0c0cANevPZ7ii+8+jgXv/oed4dwdF+69sW0ZR8Arw4wrg3QNBJSSDMLkckD3PF1zsxSV6iKMSddyKH5rmhagx6XIfJ6HKFBt9ZC5lsd7RjAFftZ9tpLnRDIrCfirkRRR7aSu9OhyxJU3+SC3tY6odO4Kno19BRJSzlchxWrqolKa5bQ4D+1TomGLqdDYNsytY+6yLDY2Khu53apbwiviyfUi6rJIDTgOjJRXWxKqX83/93yd8XIm3kLr3Am2SjwvNmiGERJMgNtEM0SQCwqFFYNJUlmAB9mgCE0zUXTuDBvdsJVxhBA/5DIiW1kVcKIDObPE8Ce5Cg2AYAygYIOowUSN3kif5o/y3O7eOh1jBOmieYT0lkzt8uMzfRYtUqnJbJR2iQR6UfW93+njTr54Ad/3nYNr7cDo9T422vP19DBXgbT47eoDKfHsxN8dFZ4m3rypHLy5DZB24OYduJ3HaO38lbOIB3NXASM+jUbysOgvuP/L5/AfoPYxvVNmJcbwMzzYObNWVRey2ZTgXOjuAJHObB/EQ6Ut8SRit+Q+o9e6PjJ7g/wfz08oiBYQcEhPp4eRmbgB4788K4dYPp3Ay/vA172ogKykQl6xG5SsL1fcEb+QsOKfN7I5tsMbCuxbSEIPRNSNv9MCbNOmHTC3pb58wG7vxL2Fw8UFFfa6HFecaWa3Vuzezj/+wN5Me085Feze3o+MRqIIuW64HXhKaZZwRXB1cYblZusW+Tt1gcte61t1gvKZ1YVeDRsszptNqvNajbaAyTid8uinU5ZC16j0e3x+0Ken2VO5IyknUi4qPb1eFCkIMTAEhh9xRDqZjpCOaYjpJuOg3WhmPKoqE91irreEqnV8NEHF0XaRGIyXLiqcFMhV1jg1ZVhV9RVpzL0/h+VYRbGiv8WxkYH7fk+VZgdlvGd92ZH46hvmVWJ8XgHHFSXsQlqbX5aAPZl5iT3Q7EldUUSsiFhrbaqA232gZDUgJuYW6kAaPX7qm0Aa+3wUxLBarXACb98+HXi1IZAi9HnAcyRMC33gXG3AufiAoZBsopX49/q7DBedpbH4/Y4olxvUhyLgh8SKdfmsyO7SfPJt9e/+c64kmljM5dem3b99F6RMX/Cu7c8MP7Bp9N9hKMTfnXTo+/nFRWOvyHdhPvesXOASeq4gavof9PIxXSKcQhuI0vJCsShaxiv+1aRVRwZh8cRgqOI+IVVkMnHr7pLW/ahforKxrWDA96Ek3SVa1fQcFXENYT0wG0HD8IFD4CpLAUZEtAz7K4gmTwXEpAhTLUNee6gRDrdW07nAq6TC7jwf9ckXv6X7he/bxz206RmAandQ5xu7RgyiGcdxYjrgdfIb0Ef/H0fFD0r8xn/F+Ed1IcbwsyZDRXnTHrEcuginQY21tdR+HTCD8SQfJbPAl6mLj3mHNqUQwdz6IBOQ8N4sy1EdAJrRKKkbh43j1/DreX5ouIqrjo4lBstjc0bnj+scETxFK5BmpU3veROhxKlhoq2ZqFOFOlETCeKdSLKGlrLrBFFOhHTiWLqr4+gVIklVkgKueKiftbK6LCi4WUzwnXRaUXLTUsty5SFzgXem0zrLeutt6g3FK4p2so1m+60NFvvUrcU3l50n+UB6wOuUHaAr1ckZg/E/MZYDxxDqIffzpf3jaEFoJEtvW4K3BkggSK3pVeouAgXCW6hc0xfCPUyhkJujg2zxkFykhSza7skm58ta9e+gUSvokLFYhIiwbxQwCCJPEdEXFRYAGkA5QK9/AnKVff4sb/djXqxmUHmkqs4jCfiRrwK78IibsOphLlXKOxwXDuNFixQTWehR7Qq8ATXGbtNUhtz1KZRZ5ZDdcYY6oF70CFqGozVg8Xk0cJ6+Msj+rxZl8+kBzhAG+GYnUJ1epVdFwl7JzCwT6WS4+s7b2Z23uY8CEC7qjlQl3Vf6lI7NBcNNFI7kvHzdHOJthToPmqxMZANLP66S/Xh3AOmCAOHcQD3Crh7CUyeepncIYYe3ZyOHkGLaTNrIVJRnp19KCymi3W02evOsGyPm/cwNUcdrNisw5bZv7pl5fNTJs4alF4+acmiW//246e/2Socte7bm9pdPQB/UL9p/dYrj/0y/feH8e/U6++afu2aYcMXRT1z4v2fXrDy5/OXvL1Z2XH35pkTKiqWlQw6uO6G02vWfg6tsiO9hHgZSl3EtFKc5+KYqIIYR5KdI0QSX+KFIkxHdEG5GCjYpo35ouGxxdrUZJzOfNWwWe3OyRxQKAKbXEQKhc9loMVR13g+qJWorcK1A9/1wQfpJdKk+7/54H64ZXF6CW5lNWnUlhjxQlwSVY7EEbaLAMnJSzxXJNFxsoTMavOi8SczKAT7/ipgwqqAFVFgVRC7qoAjVRW2aFUEt6bXfPABviu95H6xmNZhD+joLXRADL3D6lDA3Jl7JNzp0YA382iYhE2E+E3/P12YrNU2Z612+l8cGHnQrH/rwNAAQ81QJ7s5L4eZ8/Idr8X+XadlD/fR1U9IqmMidVgG7utYCBplO0K4hg66IonI2rCr3GmFskSXzwDEEF/WpbiaM+zaRQs5NK/ToK9Nuo3TCVEnJCA6b9rRqSxQDi3k0LxOw0357LwlpxOiTkhA5NRUN1EohxZyaF6nE/3rjP1ogOIE4y7jk8aU8YTxrPGiUULGfOMq4ybjE9mkc8aMUc43YoQlnnBGkTsGKFK7Q2kddytIjiDysigVCYh/gn+ST/En+HO8eIK/yBPEh/kzcMTzeigqT/nCQ/UYz0JReZlWgXeyqR2qGGn4Jk+ZhbIIT6OCWXg7P95AQ9pzo1FX17DlpzWg0TSfg82I4+TqXKXV/RM4zMuCSBEMi0RhA8ZswhywwPbW1lb+L6dPX3HxsSsfIrYAhPuUH4zc+FMmKw6BEx1kj9qm/if3meMid9kh8pSZC0yWyptU/JB6xnvOm/HyYYNTcbrtQUHCotsiWxSz0i3MW8mxDYpuMxLBOqXQm6BN5GXLQU0lbFbNSZvKRFWCjc2vsUYzFbAczHyw4TMnbTU4/iYb4i1nY78vayNzpkRFv8qMCcOfabyXmjh/Zb/KlPeil6zyPulNeU94eS84Si63Hlvs1uXdrZslNwsyvtxqs2XBWFbus72ZDSxmvdk53PwtXcMKFGGCr8WRMwP73UDl8R4W+tH50RDcJToQHe92Iq4NA2qqkAUg4+y6BLdoM8oGWZI5UY3ZRCWArbI9uz6Bzpw3IWCZQMJokd0yFjnBztYeCFpgcs66A2ajui062PbUDR817p6oyq2ly0ateY6PPfjy8FXjym/pWEO2Xr9iyH1vdxwHnTIlG7HkQVHUh7zeFbrXakaBUG/62B6Hg0zr3dseCYlCSchuCRlZtBANVTjEYhbiVjq8SvWoVY8epgQ7afVy9CRtdU7PxSYoWIwpV+hii0Rc7I4uFmPq6ppl7R5tSrVlO4seyUZVhbRxi2xFRK0i51mAFSVYWrZ8msZRqSygibRYeqWLhVy52JN2PZ9eGJRFJ0hP5f5okNO4Kjfu4R7tHh371Px5H8HYB9+CbsEb+LWGJtNq8w2W9Z4dqBnv5LcaNpvuMG+13OV52/a6w25GIS8yQ0lP9sY5jdkNf3V3WzvxV2jNq0ZsHGIni1A8J3c8J3c8J6QwvsaaCEcr+1gxsqpWYm3D97aWe3WJ6PJkdaDmXZPiMNdGFh0o1DMV6pkK9SiowjWuzigoV8JFXLv6douCYgOddNgl5zDbkknWlJqey8ZDHUEFmXMtwbAfAGlLOFxGd73CANnP7e+hhUdp4yqgFVFTQ0PgALRcbxYhFQiI9hKGIOwWMaIhiJwIKTZlghlu0yKn9ZhDBCmO3OXWzq5wRREvXbX801dPfLFsxba70pcB/ly+d+7WZYu33Llw0faBo3dN2bxn320bn+MCPR5a+uSHZ59c+GCPnie3H88gjE/c83M8dfEdt8+et+2Oq5lxuyY8u+m25/dQJZH5jFSDV8ZpgYl0zunjFqc2WxR2Vj/IYcI9wb3MEW4dwk6w8QRDXpm7gMgFwO17DwLkObAeGpjGpqvtbDKLjlklO519aBQjxtn5QxeuwHjvrnS9T/jrt3QEeA5c7xaeA6bYwcyActKCefgjBt7IWRBdSdCHYN5otqzhOEKD4iawCHmO+K2GNca/oAl4Np5NuFrYrcQbMY99SjbolGL1pppxl9oB8dDXKdDaUdBTbavW4iZxUzLQajRzoHoZ2uFp/1TUZl1vEXGiFO1nt/efwx3cmW4f0896hLvt73fy3+7beX/anr7S9od9+Av8y0fhKTakJ5FGaEU1G28mFwNTq3bJoKptuOIAekIxwD5hk55QfkCXEoc5jnvR9thOxpgdl9vVy1rL0RaD9rJKenvhGLFV9u/Xv0KU6FoOFeOz9/963Izjm28qviYKyjc96Tj+Gitffthx5UxD8wPHXknnp8OAxoZlLvDFYF0tyIcztEqHXN7sfNIFZvup5kssoJSPnbBLss88UhxlqBMbDIvEJQZDpTrQPtBd5R2ujrGPcQ/3zhJmGSerSXvSPdm7QlhhnK+usK9wz/f+ELuMomCZyU0Vpsozzcu5BcICeblZ9gR5yRY0mehkSe4ESZdicHYqA7XOWRhgsWYBZp6lztdrSCzeLLvSWJ8eY0Q2+khTmtkIJUaA9BcWVfaBNpRUKSxx0jEoM6uipL5nAzjA5s7penygFd0oK7pSUbLrdIcAZkBmheJuOwPdTPujIDPCbN1udlUgWxVJ1x/ANgFF0+WGBOnreLti67Xx8UN1qK+frsnPhtTnWl61KZ68HE/mDJHlhjvR2Ak6VGacIkwxzhXmGnmcbGCTs4H9Jpv2NgcT79Fi6aWcCKj+oGSQ5guiXOUy7Jk7f/EH7L75LzvOptuPtGzb2nJgy7YW4sDFd69L/6nj1F9uwyFsefutt3/zi7feBDY/np6EG5iyGJpVFvjWhBcjYTchupJAYYzxbp7GVFIBpIvJwMX4EtXSMS7K2526wAGw8Phj6UnSbV/fCje/HZRLfxa1sflf3YfOwIvvcRa+4xR0Zv0eF+A7UD/nrv8C7A/XCQy/s/iM/gO0OI3KKm3fp6+2L9DiOBJFLk+lVcgXnhDOCvwE2FwUuHxhlbBJyAg8KFmZcNoqMnonBtJcFVWVTyB8Al0EVvm+JWXfZleq5iI/huORIbuqTAPxQGR01y+L5tF4vjuap3CeedpabAc7+u4HukZmwF0P87i9NRvm0aXc1mkjjyWkRCVGWcXIbqTqTX6CA1NQ0Yqe4H6g6DBK0ePSFO2lHoz4a8Iqy4C2lHyFKC/aswqQFv8vShBbjZ2MEkW2yuIYfCsoeFRJx2aAnQXXFK/ffHzGuNPAlOfwn44feaB5xm+vdHz4ZfpvaQM06jiAjC6AjHmoFH+es9Yj34rzwVhwOFASSliwxeIUQgGhIOS0yCGMitRO1KeGPCp9AA+bs/Uw1OfJYj0aS/4LHYEl6VsPKOTqtcyHh0kJ1zDfsPAM+9TwMm6+NN+w1D4/vNZwQ3CLYWvwfcO7bpsUph1XTBePUiJKR7sClIqwE7RaEy0EKhbA78xGLMw8YdQrSQPBW9DBom6ArChHwxblQKyiNSqLI4euUqFT4NkuHqYcou7qKcN9DoR03RTSgVQI1OExDdjh6oSl1jPbs9Kz0cN71GwGaI3sEIWHaTwPe82Ip40UHoh3LhTS5pNz13u0a0s92BKP3IjzI3RZWmtxOBqOaOs8AE7RG9DVHizmXJAtWsy5xRJgoeaty52WgDYmE/jXmHMssVeG0HVodETMntV6NqYD3TgXTXFXDnh7jl5WN2TaXDLk+KLWjh+eueNP6fOP3Xlh30cd/SfcPX71M0/dvP55foqytM+4PoO//OO8xvQ/f9vcfisegzfgvT/f89rVj5LPN7Q9/tDLL0Mv9QAkkwL9ZcZTKLcdRwa9U3IGeLLvpGqpsytUC1gttspReKRhlJGTDSYjyY7bKmawLNgUMhsMQkgkqLajprZDm/oLJOIv8JgjGDCRzBtkOZYXqSyR8TcylsOYd0K6XGIKVmK6MdCJL9jz9E0BDpoKlwghSSQmOWRGBvkYplMLPD6YCCCpjyFhIIbrzLXgx/oV0OriJOSzHHpYe8MJuIts6AgAVVONel692jlaVgN4inYZg31NNH5JUU9ug99JvLqBma04s1qkIFKNvZFqcIQ+PuirJgU+Nn/TQMc+Ay0YyWzyHBkMdMQN8JhINO8xXk41UhXu1z8CsAxLEVcP8tXEUVd/zfuvvtHA7WnlXph/3b59V6VFdJqBrm2JCM+iEGErgg84Ot/OpBMOfZ7arhMO3VbbgegWtotpIBgVfBxU5JDLFbRTRGqy8nTZB7SR1G2ZClNzXuaEnSrTtUPHSfVknGqHSjvz46xsO8Z/U15z3gOO5xz/YX7f/IeAwejwKqV+ziG77A7Hm4rVqTicitXSRp5JOGjRCeVJuvrEmnDhbDUOW3n8Dl0W1oa9CRutkG22ulLdqN6j8up/e1lX94Um+rIu766w/TiuAmt9P+Qc0KIc/L7lXfndl3d1W+CVrMldYgISmlTb1fPbDNo8ILLlrFNtNfYR+piOZs7RgDdNBVCmiTdkLVPCjFDQ4lAAbfEubdGXy2XtXIBitTN2sfJdyoC9toRGGnUtQ+lc5uWIuCKcBogkug5l2iuuh5ff1rpv5/SdJXvvJh90HJ5wx70nsGHtXZd+1YE3qc07Tj71SMuEWjf5rxfT62alL//ml/e2nINmL8z8jZQKDyMPvp5NaIW7vTLElEMbcmgphxZzaJmGhcYqjVQtFAKxyYcRNltkzCG3aoxbZdEd5ExWtQAVYEvXu8d0xWLPxhcX1NmLzDgjGYYbhzdKq6RN0i6JRwCDn5RS0gnpDLgRNOwsG95/ibGuRKep2Mt9tJiLLEGtnqSNRWkAG/ieQm0xi7M1R0I6SpYiL+63f+F3EAdbrabNFZ6/VMOCiTpq6AyGraJCfSNnIjiwn3OzwDHORD2x8oRxOZYtFpsiG9u4Xi3LZZH5ZeXlZVlAW+QR2QvKbNGqClt/W4UrqkUeEdU/tmbu8p533HHg4EFHvCS0+wl18IKnyLydWFqevmtnx4/G9fRDx9VmLnD7wTnqw4eYivB0DjXohA+IIf1Zv5TkSFHuKq9YN/PbRRfm0NEcuiCHjuTQ4c4xyg11fIGzYKDxOuOwwrqCBQUbjHcb7yh81vFCz9c4i9Hj93r6jOn5vkcIkGmEqOVY9s4yzDLOkmeZZplnWZYalhqXyktNS81LLa2x1mIrnRgq7NGvcIbcYJofm1+yNrq2cFPhj+RHzfeVPNjz/j7PyHvNTxc/U3Ig9ouYu0QPOCzQiahOFOpEiRZ3kc1DiahOFOpEHh03sIeqZxiKi8wy7w/HXLypd56fvsKpwNeTvYnPV+ub4Jvte9l32idaffm+lb6zPj7fd4+P+F4BkOtCSHtLW8JJs6s02l7FZzBBWMWETiEecLor2VSiqtgqMe49K295HskLuiSeVoONeGurI9gQ96cJB2VbPtjblO/H/kJfwuGtLKeXl1Pm93m1LWV7H1tD7gvTK31hepWPrXP0MYxDzw4xsk7zkZldKvVAnVRYCvc7GKw+U4pLadH0NqV6AEepFt4pUuIL1pKlx/ROP1BX6md1iRSXVjaWnygnteWbykk5fSVdIWKVyq5FD2vdQKYxgtaQEodpJcNZh9VdFy60Mk/Zyh7EGmZDm9SXcLJhT7Z0Q7M/Vi1GC0yAteAswvT9OAT5+mbfFZds0sNCmTKPq7BfPZ6NF7PEJhohmPPWkHb6sqk4fc9CE4v9oB4GnQOlO23uOLusd+hNiURxr1BUcPaM2VS76lA5scASDiBjiRTAQi/YhJxwGFGiAVQQtZgNPeQALik2ymKcD6B8NY8OOtPRphptw5BHaXzz5s2oszZ0wSJdaNCZQDMFEjLCOM8Ui+X11pYL9zb5/H5XHkOSLm2kWlsubNNfedVpOcD16E2qKumCr+/MssI3RDSQGattsd5584Ybq4p+9PrDE4YMKL13yi2vzLClzGuWbFjqdpcF7nj1wbolr99y+gN8TXDZ6gXDrol6i8pHbx4/8qaS/Piomxd5J8+a3D8azHPIhRVDNsya8cT0F6FTVoKH/J7wHhqJpuMq5oBN5yNq2B2JFFVZKpThymjvsMiIwhGjR9ZNVdb3UNxFPXDMWJoX61Hl71c9tKjO25A3M1LXo250Q90C74KihT3W+dfnrS7c4r3DvzNvR2RbzKeoExXETaHQRrYW9zFNNBGT5D5GRqGhaAw51jp0ICfnU8QxEIfjq+IkfhSPQ8Xk2KGyUYVWCUtt5PaEVZ04GBXan7QW9lFXgatxFO9FAfJ4a+2A0kLIb0RR8njCGK7CVb766TuzM+ntHRQ2JNsvdVBuaUdl7e1JMBTn29X22uT5dnt1dqSOvqQikAiUlpYNtBaXWRXrlCkmk3vgGM6A3O6hhvyBmEWpgc2vZVa/wl5dXltRlgUARaKY+0LL/hWctuy0fz97VSUpjBbw0IN2viJc2L9CFGk0a2Ex5O5vpyvHqMPJcEJxjL0Gky5nhc5XCH/nkN2TGvYsefpvq6c/Xl1wYFeoR15V3eotL6T3nfoifct77+Ef/QOLeG79wYqv08//18fpO9NfD506fz3+OU58jXesnvP2od8Pn+a0pN23TR2woWnUtjmJpqWJp8fMXPz7zU/g2idnJn/SMWenNVB8zURsuec5XPDSH9KLvvhH+vG9qVuXfLhx9Sf3v/KHSx9hKw6/9ca+t9If/+nN0mIfHnvnQ0PveGvh9geG7Po1MM+29BI+AqbODu7ce4x51prVXuo16hiVrw2nwiQ/3MMczSt3leddm7cqvCtsGOgZGLjOc12gwTDTPMszK7DUsMy8RF3hWRY4EX7H+ZH3I/87ofPO86Fz4UzYHeVBNbiq+IHqCP46dYb6iekveWnVZFM4d5C9ZscdVExI8XUbAvTlWD9fJxYN1vkKz8hYlRNyo7xJ5sNsIDCcyIY0f0rBB1BePcSZ6djc1WTa6zxkOq5pZeHOa7GjglR8D1TKLk71AVRC6PvfsKS/WIktu8u+WEnt9mKly999sRKbqsF2qlyxL39kfy/u9malzhcrxQEY/cs7lbTA++rur1RCik1xM1WlmLDIiUEGh0R9Ui1enR1Fc+lvLmDrqottXM4Q37ZnBt63ePuZpTecvXnGPb1tz6678YXn1q7Zn14ivNI8adLOzENPp6/sGDuw4wr3zKmTb7331pu/A665LnOBDwLXlKD+XAHjmp5Gi7HUZ/GX9rCUllZb+rn6BwaWji5NWpKlSy1LShv7NFu29njE/RP/XourRJtdYyMcF7Q3qjzre77kkO9YyUnf6ZLfuj4qMQxz4xAdaLHRRrPbu+J6q+hgyARK5XvyvfGepZXVfHXP0fyonnWGhvhCw5L4OvM28xvmbyzfxG39KxXMq2WFlZ7yiNM7u8fKHqRHsEypVe5RnlAyivCE8rLylcIpx/QA58N1ijk7JvWFPkp1KcHmdxVmFhX2bjslpo8JexmrHKxTlCDnARBzwNtTs7VKnbenLF87zXu/MxikUSXZZ0HDi+VyAOo95qhzELB97oK+rsDszlHGhAm8AGbliyKFNAYpG1H2V225QCEb/SukI2iU+Qo1fMPw1h8TJlrtQlbhQv3FeIVtZGZCKU7Ql3SEY31iL8eEahpJS5k51pZ5XyM6B8QP1MX6VrPFTnQ0vPpENXmyGld7KLCgN/doQeMJY52nyFtQpktSme5Jl2WBh62urPBV8bRI8sVakYhOPdzDqUdTZO/Tu05UWEgrG0sT2YtrRTazKjKxEtl4usgwl9h3QI47kRUU+vojHYWA1dBPMjcj/skn1Mk4DyAEDtk4U87FTRoM0XEIe6FenHmZIGmHERePm81KDxAwEDYlWCxz5YzmTF6PJ+jUXinShRFq2Rwe8zA77QsNwerPvhQvMFdzMMnOd4O58URjnCgpRHvhAWTiauYfWfry8ZFrRlUt+3ARrhi+feNNeSnv9Wfu3P78RNXoKTge9Mw9uXJW+Yoli5+K5d0+bcQLW8ZvHu9ULP7CIvn6Xtc0NHmbdoxJzLmu940Xr2y5ZgD+qCSolowrG9U4c8I1PwQ/5yhCeBs6hTjUnwmxl9B3jNRobxZ5GfFPQp4n2Ug9OPBJOkJHR+ix/iaRPtp7RI6eYq84cAAs3yS8A97uD9jNQk4jtvrKfH18Cd8q30/Mj1r2Wgx+S4kl5Tvh432UqfL9+ZV5BgtntgZl7CJxp4PnRCQ/4cTOjENjncN1jgTf6X95dA7zZFW0CRiPRxy5D2uj532zo+fxYH7lLoR9CYbdExY6UO5kA+clLE6qgA2d98yGSv0tGyrlzAZOfKG/l+1TZjLoYDsbFUVPe33H8VEUQZexjLzxeA7/0YmaGpUOgrF5mvZ4e5LOJtawN3FV2zRo61RtolESDSADqtEeQDbRGsCAPks3b8ZxAKSrAweR7HbQ1zv0AndXlK0sRlnG2shFRbk29g5uLaCPrpe4uVzUxW154gmH//Z1Y2cFBpRPHnb6NPfIzqZllSOm2x+TRzTO3Xl1ofb6B75DOArC7cW9tW5aYFvmJGPUMc6Z6kwnbzKHrIqCPF4tGM3eLRr9e18YdKDOHjMcAz2m6SulziDTZjWo2SXi2eVpBn/Yj+HP7/23C5jgWsv/16i2f12W48sNRtajkcerTcnchUv6upyOGu3d1YH9iplFtykKjW7zfn90WzmD8iQSYcHg+psdSI/7xi2/r+HL9Bvp7fjm448nx/a9I32ncFSxLzi04li6o+NFDu/cOOt2l4VOYmUucOfof6zEh7UZMj9wq9HlqSRhh5suOLiY8NmdlXEHLjQ43GbscJtAImxgMFCFu1sckzunM9w5cUz/T2tfHthGcTU+M3vvSlpJliXZli3JtuRDTpzYThzFJl7nJDFg58C10xwOOUhCIIcTAgWCOBPOBOhHgR5JKeWjUBpfJE7gIyGhUFIo0ALtLxQaSjjC15BAKeWy/XszuyvLgX7lj8p+M29nn3ZXM7Mzb968wx8LBqjCUS7TZgowPaaAl/b3QHraCLBpI5DWYAqwGS5ANVqZBlOAeVMNUA0mJ63foQA+GMCB83KZ5RtVXso9nUvW5e7K7codyuWps2bzvXTYTeowX9DeVkeMSayYc0TqkyyivKQcU3jF3slS0s4RFfZQ1Gie6cJ8arJNCtNeUgh9LOW8nBH7VpYo8etqSqajRGatWG8vEeD1y+XdLqfuJKLpB4QT3bwjDzllTx6iikrl5dcAbwXfBM5KxZyHeUrlNL/IBEwNtotK0/s9LACoQVuALQDHU5xruPLVRT9rdmt9mueS2bNvr+v7Ud/ZFzeP6yR3DvTeNnbG7Lnbt5Hkl0cRGbp/cDaeyHQhvfhGczMzrZGfrsH022Ej6Q1oYiNpp6AOG3Gmaewm4dJtYyNOy4NorJUXYkIdXy3cKAgBWRAknie8kIWwUyOcz8F7BE3K0DcsYvqGmiiFPPoOGKMDgVyHwxlT1R0aDmsNWrPGUQcURi1TmjMdUjDOWGNTuFbAlOXYZrgmM8U4xlJpOVm+R8/0mEsVM9wD8N4yj7h0c7jBVDU3LU/ZVO2prt7qlk3nLi7Zrcdlt5qHFZdkNif1i5vI/OR1eyRoU0NZ49G1TDVEtgkOMxk23X3RdqUruhv7BlcWjg/Xju+rbvzBTP7Eyy9/fsW9rpl38gu+3PX0uctgOM2lLu2hHVXkJCFzU8cBrKS1ley0zdwEu1FEG1FsJB2VRLBbWUzr+p6xJ2Ra5DEkbawn2c5SZDlNY7WybCOCjYg2otiIFe/EqG31tjlWOu5z/AI4Z+Ec7hzn93nOi4mMHCInCarGSdQbi/MIx/s4jueciDicPPQN8jjwAgTvMlTE80CCjqh8P1mxVxBUIz9co9rhUFTTiaK1IKOtrvbjWsMpGYVFNVIqOk7aoROmdeH01SDiJhHCEXP/k1n6mUpw5DFXP76VbSj8jU64dCCwLOXfdbPNa5iAP623faJuHZ3gr3I/res6DPKWE4o3e7zM64ShVSe5wlFJjs/Pr6eXaIdZgO5C+RyGlnSkWpIOI550FIYgt5xT2F7RR3xQIm+Pg1dEzglzdtVe6qsQOXg75EqiurrKjLniiY7D1UwSzXkwuXvgevLju555pm9wHF78c27PV7N+PvhTwpP/GrgI5ogVQ+8JlwInlY8raZ96bClZnU/lmuaiCdFF02KKRVCVcylahzbmp9D1+TvQfcIj3M+d+7g+57POl9Dx/L/ne1zefE9+PlculnrKQ5HwDGer7zvZrTkrhYvyr/De4r2Pu9d1X+gh/AB5yPOqKwv5UK7b587lqXZXT2mSyVAjpUm3jjCfl1Xg4PIKeMUd12ehONXiyA0H7Ll8mEVLm5oH4hEZy5apubNVZlO2nFOQNjK3bcw/BcTa//VQ3ptZkq+nHDjeYLqg53W328HnsU0AXnFkMa7IYRk9eEe4oOcz7MUtMRwV3tAXm+87dNbg4XdODv7xh7vxlEN/xhV1B6oP3fWLtxdc/O6NP/srIWNPffkUvuT37+Dzu4/9dtSuO+8fPHXH44Mnbn4CGqV26D1uCQ2Kg3MY3+ReTi4UN5JN4jbnNmDqmNy5T6Mr/H6c28cX6IoygncaaZKStuRT4qoqjyCUMwjlYWtxOa7Za1LN3knUTK1+hrxve54eNNi2u7YwkoUjWUZWS1ZHFp+F48h2IoDsWCSILhJNrqnJu8d2RHHSbdl4W6q+loLRyUQDXRUBg4qxovPM/gR+o2nPNVIcao6gbM1Tt1tat3Tm6tJD7U9d+9QLeFfwoSundG7hPv4qp//I6jehWksR4l4BfsiFP2TzIP66ixBgC7395DmZeHGVN0D3rH9nKIDgSQVRenTImAVIGSlVKt2wOFVn4ulkujxTaXYvwPPIPHm+0uJeg5eSpfJq5Qq8Ub5CuQXfIN+kfI4/IXk5chyXyQklKf9c/iOW3NCKe93ZNaTCS7ehXzGKYL4hExWVyKoaw8SHMcHURJgsodYjoroEpkbKRim09p0Jl0r6sd4ny5IgPk6+ixCSqHNnppNW6NwFzKXLcHW4Uq7TLoGJForpKddGpG7BeDfCzbD0GgK2gLllQDm6e2P0yqfNiZHNiCfdAxQ5nmArDfcAlarXu98BdvYd5nDbctrjdj1t+XKypNwwsj1WhuMy7aZm7cm0LuHo0F5ai7QqGSFe344XsrFShiFAZ3vxZvb+3rykIvvzzlKo79ZAkjFuqj9JfAC5ftvU0vQD0gtvLTDUYx5bg1TZNpAxt+moI2q2csRikblfP746ml1KHuhsG2zmlg08tfby1fh/7+Rk8c7NA4uuUH4IvWQ+14tLmG1jPXv5spHAYeFDgrhrIngHNMlqcf1/s1UqHUYsFd28x3iMDGJO8kyfNot65uO2jX5hDFzP+49/DH4I19ahB34EPdBNEuYM7hxWy6CO654c+fqaHFpmTJRsHWsiTxRY1DlVpOpsv0ivpKuMhgY2oOXt1b1YL8xJinT3qyUnOV+/m79bhrFXPygcFA9Kv9UV3fAnc7ksJduZ6x6HJ2rX4Ns1udL7Hb5datfaXD/A96j3aHtJv+M32hHX8+6j3KvKy87X3e+oXq+lFKI5kNejB53AXlHbYMNFMV1ExIlUlYhMdYrWTCJhKYqsEGFylxUFi6Ii8Byn6Trwx06s6063Bqw6cWqcw62KOtFV9zPoGYW4Y0jxIaRwxPmMEztjDuASHZyqKBwHK1onMJ9IbfZi70znFkehqi8RlS0GTPR5ew2xRUwx8/gphivCbSGFzVD1Mz1XPm05r87NGVg4kBs86X7H/clJZjpq2grTlOmNWK6oFlq6AUld3yozJRIzhUxyuevr5fp2c7LvcwXzkxrzaZMP83gAZvsAO+6JJulbbqjZSVwYTSpGaLjrMjMFqlvENAvyDAerPmhU2rhohDcbjKsD1P1ULWBFXAnW8fWD9771s9GhiljvHwfvwLe8cXTi4AlSigc/nzFmcvWXg46B3+FZ7YMLgW2cPDib+4CfxNyrlrEO3aFpgq9Ci/nO0ab5RCU/J79Ci/sqipLaeN8sbbqvVWrTVmpfqP/Ido0uqiiZVDSp5JySHRW7KqTx0fFlDRXTtenRaWXzovPKVklLo0vLOipSFUdL3o9+WHSqxBPwi9n9pLuvNJQlsVg57ggagzpYaCYamElC/eQqwy2EQro6rTDkUP3Z1bFqdYRMnvopH9ZEsGXyxa1qLBh8KYDdASPQEUgF+ArohuT8CiaVD7BgamyVyVR1AyyYGtUHY6UfWGtPr7X2NL29BUwvdYA0qjYrjai9/BfWPR2tgY06jqHCsM1yhG12NmxJhQKt4eID+ov6X/QhnQ/rDXqzzuk2o61bAddGt+osPJaey7ZCC9lWKI2EYm+AsgBrek6iYmO05szFiWXROSynN4tNj03HP6XaDMct7ZbjpsIi8DPr6RYjwn4OoayQwNRUoMYdhUyCD7UuZmeVspEyK0OCT9mbxYsWQpcL0M1EJhqkTnGIuVsVGGdPtZl6uyt2a1VTNl61LejCl3a9fvqSl2974nsPLn9915Mf3PvgVVc+9Oj3LnuoLXd2rGrZ/NquW3D9G/dgfOs9qa9Wf/biZY9w5S8fPPD84WcOwwvazj+MXxZoXKz1rJtq3AQaFcvQPUzMlg6NlevPqWnBLRwxuBYEnDsyt+K3AtJP5vZgGg6ro5fk8Ov34Upk6osxlo+q/poxsdgL14NTxLZuh7eqGr98x3sf0ZhYQ0PmnoNAI2JVnxERy0BfDB+ziFg7k6eSJBlSaUSs5MiIWGOAm9xPzUBxgDEcos3BSjYi2r7fpH/r+020fb9J/8b3G/AwAingOWrfKQq80k86eyOmF5C9YgSTSmq4gvFjGJtBJN+nwntg1WRL/vWxzbn91RaEfWWzcLaWL1xRprp4w3b4VLvaPXB84btuZrBlGq5mOm7rQ7LIXMn2rOEsXTprrcJ8yGYN5vM3D+YJzkcf/eLv8FgiQsJ0qsBImAVtrybYkgXBmfnrnRm/3jLTT3t8cYgZCtjDrzcaXjXzPNR6FiuVMrS5ZXuL5ozJWLcaS7NbzfFvWm1vq6xM5Pg64F/e6zX5yfcMFyB8DiQcTWjgpN4gYy7/ZNQBwpdC4o3zZXK5WuniV+KV4krtTZGns6YoSwpMoCKnqA4qz4qomk9VNZjsFI5JsWgpFyHYRwgWHZqIoa6x1k9yDEVVYSqFPuHqJ0FDcShzDDWlEpgxHzOcmuaIIG5OM9lOCKEl1EjGZwtGzd1OK5oB7RZm/yDBPU7XoWjHQ7ZwmnYCGKbM7F1TIg28I4sL4aUr5IQMM6rAvMdQbCv1GQPs49NNXYG5TV2hDG8xskNx8PuHPkHc0CemEp65F8l0NxXgbmQAHmbYbqa32Z7uZ19fN8OLrolUk0tdA0MwdY9JTJdRbM3M+iCuNr07VmMPqRv47d9wtGXa5EU49NeBveRi7tzB6Vde2bkD7/6qd+Au6JqK1TVVwgwPeoUKW5piu2/gAbHcQsgjVluZnTDTxW3mKmwE78cuR+V1Vi9Thj5Id3nZxvtaVZ/T+aR13XftQlxsvTLERtRce8FDyax3ABfbUrzikfH3vNT4mknmVSQosoCJUPnGC+43XvBUVyOTO6GapMWVAi5HpVxMrXSMcXQ4boLlzg7HQcdphxZxtDgITzTZ0iXeq2CHxhxzNDRYfGExMHQRWfDJsgCLvQgRoOcKCtzqRESFtlou4+VEZsKa0mSLjFPyDhmOMTacxChNLiZ4O9nJ+iw2PBGhRSBjhA5hh3BQOC0IQj/Z1qvR/kkdk66nQW0pBN2mbVhuzsmgaR9muTSiHo1Mx0W+4a7Yg3S1f+ijHsWLaSb7qLdc29SuqasUqMezgHeIhYxn0y9VF/96R2ROFfYISJZtd4Ws9w13PtI48Jvf46tGhwtH4VufGTgk7P/yj6l1l13GlzHTB2qk/D5zEvecKc73w6yYHaCz4jGDbVbG+HHcNG6/k2dF2TBjBmSPw+PjoCX1kCD5NNUxQq7vyOh5jrRcv4QK0pkdsYIPKtjPlB/8TMSvMBG/wkyVlbSpsiVNz6V0TJrOmC2FCfqVtKBfUa0QJ5/uYWL285hvuwCV8PtP+8k6/y5/l3/Iz/uJz2ayfDYj5bPfBd+/DoD0L+yU5TPslP0ZdspM0o/Oyz7T3tyySqbC/gzFsvQmAGIxbT3JYZNkl+iSYi7RkYedsm6HSqP8PYYm14Cp5wQdlqh9awQJ21GobNsWU18iM+BZ35aDl/6qqW/TRS231Qv7Bz6+c+EDPxpYTH669Yq5t1818Dhw9WcPruKOAVfvRiH8JGOX1mgkQcqDdaSJXO4QG7IbcppydhTsKhBqsmryGgqmZk3Nm5s1N29p1tK8joJUwSviq953xROOD4LuMlLoSGQnyTjHTDLdMZ+sIv/P8Xrwbf+JnHfzviI65p2+3JAmuURfiNeQK+CqRiPYdZShQoMy2HVEYx/r2K0beoee0vkCxq4XMHZdZ+y6nmbXdcau635LR3DQ3HnT/bQH6bbKIiNnMiR94zeExrL2/wOtnuKvhTc+I46lUdoqFTMrPsaQS4whl5gsS2IxM6Wc/IIzWXGLE89gw20mnGoUn6k0Y+rMYN7HOG5ec4lOLZfpzGgjdWawxwplOd5isUcEOK4o/8H5/zN4au0ftvx6/f0D0V9e1vng7ks3/WxwFZHrzsOjsbRr8LoHb/9iCvfoCy8cfvaV156Fd+LiofeEfcIfUAz/N+sauXm+vGzSUYIXyVnYyxUXo6g3QGKogAkSqXM58XyMxUCBi4sWiDD1x0tixSPkhMUZzV2c9h7qbC2OcMBtREo6mAT9eNq/pC1KP8pYBeY0j6l7kg2pElySb3O/+fZbnZ8W5OYzt5JpQa7K1C/UnPjS744Q5J5ruftaaKkxUWFD2siBGpd5bEVPO5jhVOrRNTeUE+JER9wdy46H43KMjxfFgs78KPLrWVEg9mVFJDgqFGJRHNICUezzQFKgRKOomIPEFFtZKp/2p5zFRMzbyxnFxVEXs999bA3GLmppXbV3jah4s7JcASZGdnEZmp2VdIvJWn+Mi3lGSJP9AWk0oaOBJDJtQFiJebhzyMXbB1/a9afBnX29uOX1nRjfGd8dvWDP2hsObY5O2IrJHVtOTyINv8QDxzZ07sOL/vQa7uy7sP/7Y9alzp19ffO2nU8PfpZaUos90Edy6WTCx4GJWfo1A6EMfgN9M79B/GkmPPPtl4cD/lLfopnMRECQqXQOi2leoph2FqEykclSMI5i7ziYrgo9SZUKVJyepOL3hmpkmkBH+qAXcmzlKuWZFSpOLIWEadsphbEa5IcEjo4aW0pH16AIJLqjDJUqcTWJxqlnoxlqK24l7XKbsgKvIKvkVcplaDPeTC6XL1M2q1thLXkjd5O0Tb5Z+TG6R7lD/SW6X/0ftFfqVp9Dv1aPolfVv6G31S/RJ2oF/Bw1iPxqKYqrtWozMlRFMLz+GgHmvBo7fB1lpEQa5o++CDrbkUJs3U/rgmkt0ANaK6yUCIJDo33jjQTUDcALiRcSqDLNcdWqkizHFNWnKCoCnh6mRB/w64JKhUfAXQDrLwGzj7BQ6cCOQtkwDCWlEKUf5z1mCCmBCIAZSoQYuFD74Pd06jNlYgtzgyePU8daNOJIWizmSY50z05ZcUtdafiTyfFQJoe1dSaTk0WZnKxqjH81uObJ47FwMPG3fYOX8PGB6y9cO+9Sso35YVnDncBnCc9BR7yJjVzxP0hvS6RbOiyRj2V8l/xTmXTK18rkfHk5/EwZyxqH5EckGrqoAHOfwy/XUD1GhKtH0gS5BDH73xzHjy9P2/9Sfcd6asOWEbQIPQe/aMN6+OD1MGrLSEoxv3fPm4JcGr5IMuMXXflUOPHdivHjOP6zl39+Y93sshn+xXMRdaD3MLlTOASr1lXsuX2CiOnOIiFb0TKeQ0K9eBZPx1qP4qjhl6Fl3NW4nuRIv1gJvCk8WfDcgZxPgwMDCUgpa3pyYCGsnWhbOwgSUzp3NUd8NI4EFc9Yz4WloqzqrCLctv53fzr41vPCvH8fznsW+kuG8KLECJKIUTcuYoyqqtEjOyMERYpUtZHg4rQYY0MiQQUZ22C0+Iy6xuVYHNVeujSx1s3KNy1eEHU+lB5P0tHi01vS1ia1EWoVWY+XxFZxvsLpzr8Ln8Li1kGZA7Hf8qyp2ohiI9Rtu8EsEc7nNqvEK0ay2AL6dK+3hC6oT/dB7hVYQZQVGNdDicjDIlqsVWbwQkwcpbapm7lN6lHubVF6UMRFYlyKyUlxgtLgbHa28+1im9SuXMVfLtyrPCP+nn9NPC6ekP4pfi5ne1VV4DiewOisKDIcwEsXk0SfJIkcz8cE1SfAuwirdJ4udXhBlOiOOVL5fqzDYMAzBdNCmR5lR1jgbbfJeexwYqdmz4mazeFoZmXtbdViKK26kVa5sPQzDFcrjAN4h209QXmosV+LLmxabnsZL8w0paz4nzkO51vRGStGcjt0CyjB1Mvoxun6T+nU+0niZHpcgJEhwIYGuvENeZAFfZTccr1cz7HUGv+cTQoOK9dzRAk6qe/4hestuTkMlhX5SUXOz6+nuxU9+XTT4pWeCMu6o9ZWOAvSsB6xjaV9SBw62BNlHuZ7/DR7s8fNtjogY0cOlnVrdpAHOirRW3nf4LHs88PdfL56llBfpj1B+uW/deeZ5NSFwUILs3R8mKd5XeUUkUc8rIRVXjQ5eDocByxn81SCgIuw5NnWhx8+MbgaH3hz8KdXC/u/egJ3DV46sIyEvzf4XcQxv5kn6MYuMwR/01zG8TABlDGnWPz0otaiFUWdyvWKuCp3k7BO6dSuE67TxBK/wgVLygv8+XSj9/2Mjd5hh5LpeItGsFVRsrwF5eVlZciMtRQuKPAgOTiCpwtmvKzBDI/wwbhov3/vGjGmIcs8TojMbZ4oM91Yph5NVWohnRcbcd2R5t/2dd2tsbgjRK/rYCp71IGuwXbpHbkV8IzWwDBs+p1W0yv4t2p6trzy6/p5iW9wFsrcJJq6eZlmRWe60GYKu2yfEzMlXRb3Oq9H8ZYz/s7rxajgm8Mzeb7u3BVSFynC0SozSFO8KArnapn1BuB3k/hDv+1cceEN27+TeurWwbvwWddMmNU0/dqfDL6OL14UnzJ/4rz/unXwUWF/+77lix6sLnkidWF3x1hujse/4tyZa8u+3CU5Jlw0fc7lYxEeemtwFX/z4P9CXzM3exwwHpBcAWaoKY3Mxavt4TWvG9FJjs7O3Lhodpj/xeCqa6+FsgcQYr7oNTzd7J/OIdMDPc8VKOou9SWVqAIhmiwL30KZ4LFWOQLjIt1xsfwHW87nRTYiMTfCzDexiFmXWpiCMZBodn8YHg3N/gCDYMQSW5uO57+F+qZsLf0zXAn7ze7hiDhxxNni7HCuc/LUCf3C9RlSAFsGYJZkBshILrS0Oam5KLUUN5w0yhOWaQCZzFgUlWnvszQaBaQPHCJfHDo0IMKq/kEy/4vppHfgXCrFsD+L9fp/ICQz/O0Lyq/LzGWzXAQwvwGpNGnwPIarQz9Cy9CZnxbSBiNOJ/oLSbJ8OkATeRi9SXPgDlrEh9FWwG+Eshsgrwc4H6AV6B+mOOT7+F+iDcKz6CdiEi0F+nug7AAc/wiO2yD/qdCK7hdahwYoDtdphO/dDWULgO4WgBL+bfQQfhZtg3J6r7nWsywB2ishn0p86Ak4f511fC7Ql1n3LoZnbJDDaK313VlQth8gC67/Ezi+Dj87dD/kuXDvFUBbC1CKt6L5kOtQPhmu2U6/B9ccA98RARTrWmfD818MdLlw7zVAl2PVyTaguZvvHHoLrvnAcFXiiSZwj0ATVAA8CbUvIKQcQMgJ47ob2sUzE6GsPyDkr4UZ4lcI5dQjFMoDuA2hfD9CBc8CR3oDQsVQFoM2LelGqNyAVeWvEao4hlDlLxGqug/gNELVcK72RoQmuAG+j1ByB0J1BxE660OEGmcAwLUmw3WnFCA0bSPAywjNWI3Q2bBKnXUHQucEETrvWmjiOoTmnUDoO3GE2hcgtLAIYB30tGyEOuC5L/gRQsug56zYj9DKZoRWPYjQRc8jtKYUoUt+iND6qQAvIbQhgFDnHIQ2nUTosuUIfW89QlfejtCWHoSuORshuBW6Fp7nWvgdN8J3t90MANe52WC9tQX67mUEqgB4Ezdwn/DLhICjkh0jGCruTvfpYmT3b4IkODJxDrCEhfOAN1u4AENOp4WLUL4FKDGvQMnZ6H4LJ8iFPrBwDso/s3AenQ2DlYkLyI+3WbgI5T8Zs3RJ9ZJltclRy8bWVo+qgRlgVHLZ0uWjasbWjpkwdmztBWPHVs1ZfuGmNUs2fBvSb0PTunxD56q1l0TGjh77bcjRGLQULUHVAMtQLUqiUZCPBawasBo4HgsUoyBfBnTLWRk9OwZNgJxiF7C8Cs2BsxeiTWgNXGnDf+yq/6nrtMLZDdDGq9BadAmKQNlo9t3/zNU59H9+uufd0KhxFfQPlkT5KMwluHJUD3l5j5gf7udKe+PB8EtPcGXoGADhynoS+eF9XAmX31MXNvq5ol5vdpXeOIqjk1YlSyOQrgXYDXAAgEeLuQIod0N6NUAKYDfAAYCXAGBggZSejQCsBdgJcIye4fK5UE8k7G4s4XLguznQ1XUugE4BDAFw8JwBuGsANQMsBtgOsBNAZHS0ZC3A1QAHAE6zMwYX6LmzGp490HMLy3pXr6lih0vMwwUL2WHvd9rN/NzZZj51pkk20SQbW2MWj55s5iUVZu6NVaVorjqrDjb6OT/8SD88+DpIMXma+eQKo11cNuoCIJxolRict7c4XrXzAMcjzBEOQ9uGhw5yuMfpqWpUyRA5hbwoTD4kJ80z5GSvy1O1s3EW+SvaDXAAgCN/hb+3yFvoakLdZrghbQDYCXAA4EWAUwAiOQZ/f4G/N8mbSCdvoEqABoDFADsBDgCcApDIG5C6yZ/pIMRSijcAEPJnSN3kdfhZr0Oqk6OAHSVH4dH+0FObrNrHkESlhYRjFhLIsxCvv6qf/L7n8zLoUXFoaehRj3OFaBKq5gp7YmOh+wV76leF+8nbvZFEeFfjGPIK6gKAIRVSN0AEoAWgA2AdgAjYa4C9hlIAOwB2AXQBQC+D1A0QIUcAngd4DY0BMABaAGTyUg/cpp+82BOfHG70k9+RZ1EAavwF8huWP0+eYflvya9Z/hzkBZAfIc/0FIRRowbnEXzHDbkb8ko4L5Cneou94aFGDzkAdReGtBKgAaAZYDHAdgCRHCCFPcvCXrjI4+gITCZh0oNOsPxBdL+MjNVhIz4FOmCEJvGJZwEGyc7Izjgx4nffC4c0id9+J2A0iV9/K2A0iX/vGsBoEl9zKWA0iS9bDRhN4vMXA0aTePM8wCDpJz/ZW1wSrm2+CEcadbIZamkz1NJmqKXNiCeb6R/6nKfP9sOe8nKosfuMRFl5OLUfp57AqTk4dT9OLcepLTh1DU7V49QinErgVAinCnDKwKnH8QSoihSwvSMOk0YQp47g1KM41YlTcZyK4VQxTkVwrdFPoj0zq1k2jWW9jfSlg/ysSTD66CQKNRqFPh+FMeEApC8CDLEjA4gihSZxTgHNC3vLG8zj0ROr1sLrcxi+eBia4TDwkYdhuKqEtAPgRQAOuvVhuPhhaKrD6CDAKYAhABGoC+HBt7NUh7QSoAFgMcDVAKcARPY4pwAIWms94m72YPShK60HbwbgyWH4K4S/KIka+e6QO+E+m9sewnoBbi4YKiC1yA88FvJ6ZE8/du75p/OzfzqR0qiQ28l2OnSTHVa+vedzGLrxPT3xx8ON2fgHqIDHLCB2HMcgn4A62fE4FJJpXoNC5BHIq3pCrfA1vSdeEd6PXfRbe8Kfh46HT4T6CaDvhx4P/zHSz+Oe8KtQ8sie8Cuhm8LPVfbLUPJEvB9Dtj/CSPeFJoQfPcJIr4ET9/WEt9BsT/iq0IzwRSF2Yrl5YlEnHBl6eE58fvhsuN7U0AVhoxOuuSfcEFoUrjepxtHv7AmPgUdImGg5PGxZiN20qABK+sLjzj+/th+vNCqku6U2qVkaL1VJFVJUCkv5Up7kk72yW6bRL1VZlkWZlwksOHx0fZagDJlPdNNM5GnKM9xNda8Y/0aHPiwTNAt1ZXFNpGnuZNzUdXAparog0vXp3KJ+rM6e3yUUTcZd3ibUNG9y14REU780NKerNtHUJbV8t60b49vbobSLbOvHaF5bPx6iRTfkdXmnUM9X2HPDbXk0L73htvZ2FPRf2hBs8E7yJKdP/Yakw0oTw5/gCDx/ctfdTXPbesY9/HD+5PauKoYPDQHe1HXX3MiCtn34Y3x62tR9+COatbft4ybhj6fNoeXcpKnt7U39uJXRoQj+COig63zE6GSYpSkdisgFJt19Jl0Mvg90xTQDOkVBMUYXUxRGx2NK191ZPG1qd3ExowlEUCej6QxEMmmOxIAmFmM0/hQ6wmiO+FOUpmsSIwmFgKQgxEhwLgoxkhDOZSStwySVFslNaZKb2J04PEwTMmmcx2wa5zGgSXzbz/LJiQTurWtfumDa8qJpHUXTlgN0dN1y6cpgV+qCSKR7aTs9Eeni4h0XLF1J8yXLu9qLlk/tWlo0NdJdt+AbTi+gp+uKpnajBdPmtXUvMJZP7akz6qYVLZna3jujpaZ2xL1uSt+rpuUbLtZCL1ZD7zWj9htO19LTM+i9aum9aum9Zhgz2L0Q6+otbd0ymtw+ZYGZ9xJNhW7bkRdtn+x3r5vE+nBdNLglbz+wLg8hLdHe5Sia3OUEoKdGNY5qpKfg1aKnXFCsW6eCW+qiefvxQ9YpNxR7iiajxMZNnZtQcNqqqeZ/J3ygaOMmWuFmmuj8Vx84N63LWDK1E1aNTV3lc5u6GmbPb+uWJCjtoD+pa6JdpmnT+ocOmoWjoXAiLeS4NCEtq6dlimIRfr39N1k5k96myOO92CjAG1FnO9dV0DSPwIgwbz781gXz2/YDY0Xnis52+IGdOIE77WtYj23HVk4g+ptt2LjJwqy62Gjl5jfhK512laQ/tLIS6RrbyC7LqjOxoK3RxY3nKlEj8M5jIB8F+SjIqyCv4ioNbzzMkdqwIteGNXVqWBKnhu2rtifQ/wfegyXFDQplbmRzdHJlYW0NZW5kb2JqDTMyIDAgb2JqDTw8L0FzY2VudCA3MjgvQXZnV2lkdGggMjc3L0NJRFNldCAzMCAwIFIvQ2FwSGVpZ2h0IDE0NjcvRGVzY2VudCAtMjEwL0ZsYWdzIDMyL0ZvbnRCQm94WzAuMCAtMjExLjAgMTAwMC4wIDkwNi4wXS9Gb250RmlsZTIgMzEgMCBSL0ZvbnROYW1lL0RHTFpURytBcmlhbC9JdGFsaWNBbmdsZSAwL0xlYWRpbmcgMTA4OC9NYXhXaWR0aCAyNzcvTWlzc2luZ1dpZHRoIDI3Ny9TdGVtSCAwL1N0ZW1WIDgwL1R5cGUvRm9udERlc2NyaXB0b3IvWEhlaWdodCAwPj4NZW5kb2JqDTMzIDAgb2JqDTw8L0Jhc2VGb250L0RHTFpURytBcmlhbC9DSURTeXN0ZW1JbmZvPDwvT3JkZXJpbmcoSWRlbnRpdHkpL1JlZ2lzdHJ5KEFkb2JlKS9TdXBwbGVtZW50IDA+Pi9DSURUb0dJRE1hcC9JZGVudGl0eS9EVyAxMDAwL0ZvbnREZXNjcmlwdG9yIDMyIDAgUi9TdWJ0eXBlL0NJREZvbnRUeXBlMi9UeXBlL0ZvbnQvV1sxWzU1Ni4wXTJbMjc3LjBdM1s1NTYuMF02WzU1Ni4wXTdbNTAwLjBdNFs1NTYuMF04WzgzMy4wXTlbNTU2LjBdMTBbMzMzLjBdMTFbNTU2LjBdMTJbNTU2LjBdMTNbNTU2LjBdMTRbMjc3LjBdMTVbNTU2LjBdMTZbMjc3LjBdMTdbNTgzLjBdMThbNzIyLjBdMTlbNzc3LjBdMjBbODMzLjBdMjFbMjc3LjBdMjJbNzIyLjBdMjNbNzc3LjBdMjRbNzIyLjBdMjVbNjY2LjBdMjZbNjY2LjBdMjdbNzIyLjBdMjhbMzMzLjBdMjlbNTU2LjBdMzBbNjY2LjBdMzFbMjc3LjBdMzJbMjc3LjBdMzNbNjEwLjBdMzRbMjIyLjBdMzVbNTU2LjBdMzZbNTU2LjBdMzdbMjc3LjBdMzhbNTU2LjBdMzlbMzMzLjBdNDBbNTU2LjBdNDFbMjU5LjBdNDJbMjIyLjBdNDNbMzMzLjBdNDRbNTU2LjBdNDVbNjEwLjBdNDZbNTU2LjBdNDdbMjc3LjBdNDhbNTAwLjBdNDlbMTAxNS4wXTUwWzU1Ni4wXTUxWzU1Ni4wXTUyWzI3Ny4wXTUzWzI3Ny4wXTU0WzY2Ni4wXTU1WzU1Ni4wXTU2WzIyMi4wXTU3WzU1Ni4wXTU4WzcyMi4wXTU5WzUwMC4wXTYwWzUwMC4wXTYxWzE5MC4wXTYyWzUwMC4wXTYzWzU1Ni4wXTY1WzU1Ni4wXTY2WzYxMC4wXTY3WzY2Ni4wXTY4WzY2Ni4wXTY5WzU1Ni4wXTcwWzU1Ni4wXTcxWzc3Ny4wXTcyWzUwMC4wXTczWzIyMi4wXTc1WzU1Ni4wXTc2WzUwMC4wXTc3WzY2Ni4wXTc4WzU1Ni4wXTc5WzcyMi4wXV0+Pg1lbmRvYmoNMzQgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMT4+c3RyZWFtDQp4XvsPAX8AI+EH9g0KZW5kc3RyZWFtDWVuZG9iag0zNSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDE4NDY4L0xlbmd0aDEgMjc1NDQ+PnN0cmVhbQ0KeF7svHl8VEW2OF5Vd7+971s63Z1OupM0IVsnIRDJDQkRiEhYTdBIWALEBRIUQUchKjsq4AIoKHEDREeahCVhGeIyOjrjE8dlUMcxM4OijnnyZhAZJd2/U7cbxHnL531/3/f5zj+vO3VPVd06tZw659Q5VdVBGCGkQx2IQfUTJucX2RZfH0MI/R5C8+ybZ7bd1nwPRHEFQsKU2bfd6k+88vMrERI3Qrp5btu8mw+HTTsRMpxBiB8576bb59646NhyhOwFCI2cOb9l5py8954iCE15GCopnQ8ZwovxbEj/BtKZ82++dal8zj4Z0oCPzt+0cPZMJGo3ITT1C0hfuHnm0jbxmTQoP+0UpP0LZt7cUtH8918idA2LELmzbeEtt0K/4dPYQd+3LWppYyaUvgjpToRM3yKGeY8cRRwSuce4YhiFJwmZd9BcYhY5ohFYQj9sPxqa6ENLr4VaJFrflPHVfgTfxAXu3fhEXCyMxF0KwolEAiE2xB2mrSEbPJlUSFPpiMgKSEGM/RqxZD5kLEUKtD8MSodRNspBQ1AeGoryUQEqREWoGA1HVaga1aDRqBaNQWPROHQVGo+uRhNQPZqIJqHJaAqaiqahBjQTzUKz0RzUguaieWg+akU3oZvRArQQtaF2tAjdgm5Fi9Ft0OLt6A7Uj75AX9Le/hNb/ud8lv6TvhqgsRelA2WdQGUTKkVRVILKgM52oLgPBWEeCpAHaJ+p8o4b+CSAXMA5DpQBs3MFMsIMcUgLHGRBIRRBPMoCyZSBIwWYQYJYJCIzzKEV5aIRqAKVIwOM93/57J/zWfpP+v4vn4X/l8/+H3z/SXwGa2uaGnahNDYEtaHEqYsh3po4Rd9RSL6C9dybDKlPF3oB/Q5nYz/qxt9DL85jFy4ETmDRd9CHvWgQPQJtTUGbsRn6bAduGItZKBNB9+FtidsSX0KfH0RPJQ7hexJ74P0G9Bo6Dz34A4th3FdD+anAM18yn6HGxGPQ99VAoxFoErYDR30A32+hDw+hh9Ev8J2J89CqFd0D9VUAX1YlXkpcgFHex27kTkoH0CZ0BPOJ2YlWoG8GWkciiQ8SnwKNGtHT6AXoUwT3sWOAmjeilWgrdjGvQewR9AyKYy1pYqq549DSWODlBWgJWof2oDexGddzJ7kziZ8lTgOdLUDfmcDXX+ISPJ48y2oTIxMfoWtRL/oVjJd++9hr2V3ctfHKxOOJl2H2DmEZH8UvcUXcA4N3J55MvAjzFoJ5vgLGPQ3k5V70EnoD/Rv6K1meWA7yNRla/iX2Yj8OAcU/IC6yjCxj3oXZrEJN0NvFaAeKwYwcRkfQMaDNxyBHn2Er9uBxeBbehP9KtGQOeZvZxuxn3mMx+xzQOwj8kQuy9yw6iH6D3kJvYw7qL8D1+Aa8EG/Bj+N+EiNfk+9Ykb2X/YEd5ELx/vgPiasT3wKPukHe70DLgbZPo260H/0Leh/9Ff0NncNGPAzPx0/iGO7HXxOJZJAJpI1sJs+SnzNXM5uYl9gSdhR7I/sW+xG3ilsvzBTiF3bGH4r/PP5O4lDiHeAdPdQfAr3Siu4GrngWHUfvQu0fok/Qnyj/QP0j8HR8PbRyC16DH8Y/x7/E7+CvYJRI/WaQEaQGWl1IFgGd7iEPkYeh9bfhe4J8RD4hfyHfMhyTwZQy7cyTTIzpYU4wn7NGNsQOZQvZCex0NgEzU8RdyU3mdnPPcy9zZ/gKfg7fxn8h3COsEH8zmDv4hziKz4/H4t3AuyJw0h1AiSfQU8D3+2EO3gSK/gv0uB+dhVlw4wAOQ7/LcS2uw+PxNfg63ILvwavxg3gr3oafwi/CCGAMRIC+R0gVmUxmkhaygqwm95P98D1M3iAfkJNkAHruYIJMhClkxjLTmWuZBTCGW5llzAqg7CZmD/M28y5zmvmCGYBZc7Dp7GL2DvZRdhe7n32Hu4q7Gb5Pcce5Pu4d7gJ3gSe8m0/j8/kb+N38nwReKBXqhbXCe8LfxDachnOh5/7LlSNxgQymkz3Eyi7HA5DhxSxokU0oAvMwGaTib6iSicO86Ol76JuNuFgLxeQVFvwccis+gkrwL9FynjDUbu9HXfj3pJ99hVyB3sfN2MXuYhZwb5IAeh600UZylBzBo9B+UkGmke1g6n+Gd6PPgN+XoofxjfgW9DwewMPxXbgML0fvETszGa9AFYmnCIslPBafQdADdDc7B12P/ssPLgcP7Mv4E6yOvRP0Uw/aDDP6AvoUP4e+x1zia9BuDGijmaBl7gN+X4mo1msCOVsO8ugCDXIT/zbaj3nw0sr4kewd6Az6O/qSOwwcNQo06el4K/sE++dEWSIPJAykDO0GuZuPrgSJ+Qy45Bikaeo6kHQZdEkRSHU9mg5r5l2g9TYlYontiXsTtycWol8D7vd4CP4ed4JE9ABGBfoVfDegD/F6kMMr0f+vT3wO6kNfYSfOwkUgDwPcbdxGbg+3n/sF9xZfCNRegbYBR/8JuFmGEcxG76Cv0HdYhLlxwdoThf4Og743oJtII3MMVWM3rO3vwkjK0KjUSG6BWu4B6m0HeT4GsnEG9MR16BfoJCbYASOaDe2LUE8d0HkGlN4JM3gv7oacOaC1c9FfYNx6PIzcCu0pUNNm0Fp90Kffo8+B2gm1X0NAL9TgaVDXd+gaNAdaKEX1eB/MwEFY7a5GNcxvgN6Z2IhG4Qz8DOA1g4TqYd0t5/6MCRoSvzoxjLQyx2CNSUB+J6xeHnQFbodeGGAcg8iGJ6CS+CTow7uYYWP4t2ovHiUtidXMkvhN6NfoOZgThb1NqGEXsSvZH5RRU6colSOvqBgxvHxYWUm0uKiwIH9o3pBIbk52OJSVGcwI+H3p3jSP2+V02G1Wi9lkNOh1Wo0siQLPsQzBaMjoYG2zPxZqjrGh4JgxeTQdnAkZMy/LaI75Iav2p2Vi/ma1mP+nJRUoOfcfSirJksqlktjor0AVeUP8o4P+2Fs1QX8Pnj6xAeL31wQb/bEBNT5ejW9U4zqIBwKA4B/tnF/jj+Fm/+hY7W3z141uroHq9mnk6mB1i5w3BO2TNRDVQCzmCLbtw46RWI0Qx+jh+wgSddCpmDtYMzrmCtbQHsSYrNEz58TqJzaMrvEEAo15Q2K4enZwVgwFR8UMEbUIqlabifHVMUFtxt9KR4PW+/cN6Vt3X48RzWqOaOcE58y8riHGzGykbZgi0G5NzHHHKeePSajcXN2w+vK3HmbdaGernybXrVvtj/VNbLj8bYA+GxuhDsAlWbXN62qh6fuAiHWT/dAaWdnYEMMroUk/HQkdVXJ8LcHRNKf5Bn9MCo4Kzl93QzNMjXtdDE26PdDldiu9iX7kHu1fN6UhGIhVeoKNM2vS9lnRukm3d7sUv+unb/KG7DOakoTdpzekIlrd5ZGWS+/UmFqcxuomXaIspj0KjgWGiPln+6EnDUEY0zD6aBmG1s0eBsXg04gBKzYHZqQ1JlU3rzMOp/kUP8ZlGYP+dd8i4IDgwNc/zZmZyuGzjN8iGqV8conV4P3FeCwSieXmUhYRqmFOoY8j1XRJ3pDbekhpsM3oBwDkQ/VA25mNw/OB/IEAneD1PQqaBYlYx8SGZNqPZnm6kJIfaYyRZvqm7+Ib21T6puPim0vozUHg5P3qLpMtJoYu/RmMdsvo+cNj2P5fvG5Jvq+bHKybOL3BP3pdc4q2dVN+kkq+H3bpXSoWs1Q3MB6SihEPo74FprzuUmGaaNDG2Cz441WmnhNjgCnVDOyvjRmbxySfjXIg8J/i9AjiZUg9iTMUSwU/oqV6GRse+Wl6xE/SP+mddh0D/WVDpG7K9HXr5J+8qwUFtG5dbdBfu6553cyeRMesoN8YXNdLdpFd69pGN1+c0J7E4fWeWO19jTCI+Xg4MCtBo/YF8ZqJ+xS8ZvL0hl4jOKdrpjR0EUyqm0c17suEdw29foQUNZfQXJpJE36aQHUY+LyLiGp5T6+CUIf6llUz1PTsHozUPPFiHkaze0gyz5hsKKQ2pIClObuHTb5RLpZmIU9M5nUkS2enSovwxkjfHEag05H6MvmhSqN6SsPl7KDKWGMesBcBTwSx58EPM8BatETJ4rlea6+TuZLD87gPOGI2Zen0euQxZgEdDEi0h/cKWOhJ9HVLmqjQQ+5T7D5vgbfZ2+bt8HJeo8GP/eBIEtRD1nenFU52Rq42nm2qGD9YMd7Yfi7SPn4AVVZUVgxWmMvz4VlYgJracVOxKeB32GF94nmBDwZdpLiotLQkGgqHgo/gj7F+0rI9s7ZcfcMbLz2197bq68eUdHKH7YFP9q7uaTXZBn/HvhxvHjqrqn6+TgZyrkaIKWNHgr+6W8newmFJjydzc7nFHJNvbtDP17eZWVkyaH1askGb0JJK7QQt0faQJUqOIGAkM4SXs5FklAqkNomV3MvNO8xkhnm5ea/5hJk1G1EIMz04R9EQ0oE7wbpwmSp7cRpSB9oOoxwwDlZcbWxqP9fkGn8KOeloKwea2heVw9KMm2C4qC7mmFwXK4HJ2CcXDWtETYGAKWArLS0ucgihYAbPm3Bn/DTmqm+saW685sorRkzKZ0Nbbqwp+XZo1Z74vwFxqxJfsGEYoxWl4ad7kTFxXqnVlD8qPabbbNzN7ZKPSEd0PW5RtOIx5Eq+Vp6Qvlt3kD/ofl3+lfYD+aT2vPCdTpdmSLMpHm/UpuhNUYPtuO1tG2OjM2tIr1Sh3gGQ3K9oDXpzvb5ZT/ROM4YXB12eKC42I1rG64+qMCMnCSN5SehMU6Fi0BuinVSRGaHbM8zmHnJrN6sxOwEqmRoBBXC+LTBBj/Xu/PQZ6QvTd6Sz6YaAqOgMUdHlba1SyRoZPwAUPdc0fuAssM8A6BnF6lSyrZVOJd0AD48RHmmmygh8GisH4X0vMkMnoISZdgYKqRDKUdh1sejZpnYKIyoCghfmctrpLgcFsW5JHqkmqwKVEUTLn4qYzOVNavN6Baikp43qafN6BYiF1EqBrSORRZFIBTYV0xlvR00RzPF80B8OlRhRcRFiAnY7MLglBJMt8A7yPXaWfrk3/peVrdj67gA284MKc8/MUdPDzNJp11VUYDwp/7EnD2z6BAziSPz1+LG71o/BN92xvLr6FiBsAbCCEVghl7ys9PEmPiiGHSZHcKt5q3VL+JFcSbDWWon5iK5X/3rgs+B53bkMPkc3Vdeie0Szxbwro1crVAWVzJrQvIw5odXm1dZVGfdmSmWh0XytZpxugqE2MCpDyMgMh8q0JYGSjJJgSabAy5xJCjh1YW1GRkZQyMxQhtyiXWq93XZbzuLcNbYVuY/ZHsndn7E/qOvAGxz3OR/NfS43NoR3BOxKIBi1K2m+qM+OP7Vje7EYqM/akEWyFKc3muUeQjnGYZIr64fggiE4fwgekh4oMGJjMQ6oXGWQKlUIRVTukiRdFLkiS3som1wA6gOHtFNeaV8UUZXNWYhEBtA+nmpApYTHmMd2HMooDdQGpuBGxxzc6jgHxr2DsO5ABsm26LQk2z2DxWxttqbejd21FqFysAn+TGZH+cXQ1O7pRRmJX3dn50YDPUmY0ZPo707PpOn+bl9mMu1yq2nFA5Ebdbg0ozZjq+7hjFcz3svgAxlaHcu66TgOgEChYipa3Y68SpziPTWdkRWlUPG6QaBwAVZwPWabcQc+g8FfNUKqGfxDWtJih5IYK+MRi2ewZ1hCh2BXoGp7sUOBeh0KVOpQSsqiDiUyFB5ZOfCAeg0On2OGY6GDdUx1KxmZUYMb17sTbpIafHvkbJMqJpFTEZo8G6HkVZNJYiRfNgKztzehdvg0NakSlZl4Q5E05kpDNjyADl8f1JVrrdpyGu3SlgOFvtqnKVelBgM+am+yZFHJKAPVHw6FgelKoqAU7Q4uKSk2q8POUi+GD2aECrDbvGD2zWVZVtvY+AvXLvvos4/ey45/Z5rRsLDAnxbCLzU2nP3mw0GcH5k0NTst32+zmupGTnt03dEH1heOHOWzB9NtaXPH1a168LcxkKKpIEWVIEUu9EdlYoOh0dxon29oNbfa73Le7tpCtmhfM77m/J3xA+eX/Jfil5Yvbed5yzDLMNs48zh7rbNR26oVhpvL7GVOZgm3xLCaW2VY69pt3mXvNR+0S3pVIXqiFB4wW6P6Yh3NcaVHVWgwRXWHMYtkUIlmkwYpUBQpUA4Vb8QYH8YYsfDK7xAwzQVRyNfRiC6pNz1CwOpyNyQ1JVWUVE9Gzg5EUOXg2aZTEZizs3SuIsm1tr0Jq+QEalIlVEY1UwYyUcVkZwvjf9HPntB61/Ib6+fasDVy9q0v43/B9oGXPyNfF02esmnPse3XLsz/xcs4BEwn4KxdoNQfQgi/APYDgwS0pBdJwKyVIJ+KVC+RDikm9UknpG8kzic1S8ulTsjgGF5A4HoaEFbQCfCQGdQEJgvP8QIrEwGqVkU7kBllXWJlRXIFoBaEajmA7dDUXsFwxooK+FN5blHEYgqYMISHsAsWThd7ELPxCz+MY0M/fAQ9XB+/id2iWgRp6DFl6DDLGAsxR5lyXbkl6qlhxurGWmo8f/dI0/hpcqN5mn2aszHtnPB3jwidcsNC1cUJVrpe2TUacJ4dAdHdlo7TTTl6vSFkNGLVGmhDHdCSy1uZnAdQPRVgBxhPXQ1WT9LmGYBvRdIEwNUNim4uP1duNc+1z3W2pvFNYAVYkjYAnQvg77ApgNUZAjMIZms95otfvKEXk/iF3oYNE2CU9gfmzrpn1ex5a9jQ9vo58T/EB+Pn4h/WTh38kuntfv7x7l1P7QDG9iW+IJu4x4Gx31Jy/MiPg3KOYbh+nL7RILhsyMnYbchhtlixw0ys2MlIgixonVSPGJCj0xFzMM0A+hyMowezXcATdAFHNl6gBNFrNVK+nI9QPp4BlhCUULKdTMhhnmqrtO6w7rUyzdYO60brCesZK4esRqvfWmBlgVuXdibtwvZFdbEysIVGgC3Ui6yJvmGNFeMvgF0IJqPxrIuaTwPUWKRFT8Haayo2wIcSEduCJquqLBxUG4ClWGIKlhSXZJnIHX2acFp4nHPWnVfdUa6R7r4bu9lQf3zKPZE0z0e5xRNHFz6C3+5/95n4WpixSSD4jwFv6IBCW5QxX+DT4neW72zs6+QLMH5dnEsijcZplmn2RucWspXfKm7R9kjvk4+530vva09zp/kvdMZd4q/Jb/hXxNe03GJxLb9CZEyUa2SNgxLJygrWcsHd7GnzEI8+gH4iq0nmANYA4QTJbGoHzpBajXOBL1qdLKZsgZssUTPlC5sV+CIzlHUZV0xaN7j933A0/sbXD8a/W4f9mxcseOSRBQs2k4z7ML8u/vo3/xZ/ZUVi9xO7d3du370b2GETGPuNMFw72qE4BYvDMl2cL7I9LI6KUWONWGP40sjxtNdek6DX8VqNBkxigkN2pPgzo3sRTkAlbicVUDusFBudnU7S5jzjJN84sVPWhLR6kIYunU6r2n6A0qnFZ7RY63KkBBlWjstsZFil1QxVtkGeqZhQNQVCDTZxVNVTvM2kmsfFRenExjbGT2dOLB97a4QayOvfbXpsgo+kv9AyrH5FV9wHkrC/ev6Kn8G8ToF5nal6NWloo5JnbuQbL8n2VuFR6bwktaV3pJPhTFQ73BZ1jWNqtONsNa5HJcmqirzGrXK4RtCDnkKyI0evC6mibjAg9waQf2MADNSGisumsmL8wGDF50ktNXBpIFTWW/nWy2U9EChJaV0z2PxU0B0/zik7M/5D1b7ph+I/xF/uuge7Bs35NXfMXLNi3pzV269txGGwAvXY9TAxXmjbc9WCZ5859CSV82UI8VthYsN4RC/KAeI3gQ4G3a618XZtlIHpdUaDNWS0ONpZE9T6mfycyVJzTkfOjpxn+F3CTu0B/oA2lnMipz9Hj3Lyc+rhxfGcT3P4HGogVEK6Q33JCQFWcHvtKn8LAUqidFYwmkxhT1paKCyDxjQYQ2aTMr2k2YQXglLuIbWKwe0JedMgb2Eabk7DaZC3PwtkltKzC6FwyrSjUCmFfoehaFipglABITMcDSvDr4jmh98OfxpmDGFfuCPMoLA/XBBOhNmwK/vPFRfVSdIUuchi58A2Ae1xrr2JAnVigMnol84PBoWCIIA6WRRpp2o5YlH5zO4oVZ92ynlgiVxkwh/5cRlm1vfN3VxQ+9R1i5/K9sZPe8MTR8wfGj+dXllaNT8vfpoNbXpuytSpU2ZcV7N1sJHMeGJoxZj1m+OE1G6bPqR2xaODF2DOjrC7SQf3Lqx/1YoF+822KPaDBVnPYMQYGQJuZqMiQfwzZATnu4fMPIQXIBf7+Z1Jnjs70GSkyqOpHUYQiVgsAXxkHR4RH2B3g5/wfiKRdBOhgaeT16oUlHzie5EeffFjGhUqJtLvP+Mnfv8EfypG50IDjqFfkz0mQrC/l5SgHEQNtab29hKQsLFQ+VDguCAqwu3KfMEtpnFeu3ucZ0za2KyPjZ+apFJXreua0FzXvNCq0IOuh9w73b2e192/8mh5Xmez8y57mM+xNbqWkFVkJ3+Af43XHo9+aCTezKJC0xBdJjVSM5WMbHi4vNGFmRcySWatl/arAJzKK7wYeY3emPfvXtbrHYKLkQK5BuSDrk0NUMcsQB2zgOKkNji59QAraHUy9TC64d2QlDuoQigxhHKyYtWkF4bEHClb1+jT7tASnxYnQHkpentU654QxdFmmLUHCsAoK84JzHDgTx14gmo5Mw5XccpXBSZUnZAm6rFGkqlTlPkGgC+BA8E5pPb0KXN5PnBn0jHpyvfi9saBZILazX2HwC+fkjknkzRFGqnxDWzK6MHeSRo81I4LqzxqtzFWuyMAy1+YahRqMJeWlZYlNQmmuymqmQdZpSW4JRH57dtHe+oYT1b8K41RYMY80/TMsWnbHvzlVfUL66bg60u/yixrqLlqdLFRQ/409LGHG9ceivfct/KqtDKXWFvbtWb6/XVpWf60iaNHxH9rLnKGK0ZMKwqVZbbAsjCYOE1GqLw8TPEijMcSxkoIPV5gkIz/Qtwc8xfg3Ydu+tFMTW0FreaGRu4yvlpYIOBizOAb341vcnFff28FUt8PLDaZDcFqtV1xXGOaZ9rMMRLv4itIhamO1JlOE8FAJ87EauxItlmtssRbrCGbDVFFrbera5YdJ8DT/C/WLEm8tFiJ+IyIxZ8uVpevVEmr7h/WqqakNg+BBRJI2iSlpTTKXD38WOuNe67CLt+kyjGLcrFrx9RZ1+/ZTDrjzv6WERMWn8J9YJ9i5ESIfA60s6MepaiUxbms3+g3NbIdTk5kjzuJzW4iVrPdpLcYkFFvwaAOrJJo0OAZmoSGaCgFZB6bDMmRqjrZCEb5GagayCFLxZXiBLFeZMRsY75phomYqKGm01tCxDoDddr77MQOFDgoaaN2l2NpL2lNbmZF2pO22IUmMMdcya0sML2p+U3dwPKilC1G+dFSTDnv4gaWzVYM5lnAFHRuL3908dJbQtUjryj57W/jp7ezofpVKyZnvmosn1j3yYVDzFjooxZskmaYZQ3eqqzPFn7Fkq1CL/49fl84o+NEwc06+Wy+DA0Tx+BGfCdeLMghHBFK8XChFo8TtmrO8+cFKYsNCblylB0uV7NXy6+w4lXyFLZRnsPeLC/Fd8kPs5uFw/L77O/lC7KOYQVBku2sn82Vi9lKuZaVbKxLHi5fLd8o72IPsW/I51hJ6Emc6TY7o+CNnOy2OSjsV2xaUxSzssAiogIRSSLDwJuDOXnRBINpVDHYM6NMiEggABLHazSp12c0mEYVB7zWhBBnRYjjOY4hvChJGsT1kJu7+GIJgKIRWyboduj6dYyOodmkWEOzzWeSO2l0h5VFLdpXwYx2qTrHSbfGXONB5agxlJ/kUHhQ8Yq0R1bf9erqoc5UDFO/HdFHUuUckP1SQB1gF0Ck+vLULQdNvwjTRzHGAbq+4ADDaPHy+CZ8zdHX8Lj4Vrw2vuvkRyRImPjvcWZcGnwHj40fgl5uhcEFwf6S8L8oeonhRRfjEFmzSCi1ULdZU8lQ1XttU5RCJXfylChTJIhWQQA+JURgJBaoBwlWgTKsAu/ZIv5tDgOZ1isuRVOvadYwbZoODenU9GmIX1MAoiBKqUopVPSTJ0elInU/ug/UEN2RlgsXX9qRVs2EJhDtc6mUqo6oVVCOIKweSi0JoNZFtczA3En6cFT0w4P2+pCki4oK3YJK7X9Uq6U6DmpKxA5NiTqwK9xDo+JkeHCMnSliFIatZVaKG8VOsUs8xfCvMm+LH4kM2GNilBkBYvogs0PsZPaKMea4qBFURxhEiyjwECjz6PKLosRPH4K1BHK2gKM8NEqmwEMtXZvuhxQ8RCIITsI4hCEkLIwgxcLVRBGuI9MEYEuPMJ6MFh4Tnhd+TT4kX5DTwt+JJkyyhXHCUmGN8ALhYdYXXTSmIhHUlDKtwB0pBnOVGuTYtBX7SQO2xH83uI87fCGPeff7WubohRpYf+HDHYfJF0D1V/UiIXFSkcrKo3w2PJJjyi6J8kq2OqaTSn0gDO/gkYNy2VwuW87XDkNlXKX2BnQDaWHmcvPFefIXjGEcj4koYUaWJFaQMEysADIk8BLL+jneynG8KCtu70hZtV3c3qicBezGs1IPPqroeYFwLIuRqHU43MAMMxWND6s3kjpg2ekhmYrkk3CB1CER6TDJRCyUkPzAcC7N9bOTTDN+0AUmJRW3watHt9R8fnEhGD9gUo8zgIeouKVkDYAAS/bqV1MctF+KqrxCN8rqYhpwe9NVt5dJxLtEVj6ciAOlLuzj2WH00wh6NUn9QICBLwggw3DH47/oGDx4e/w1MgKX5775Gh4f7wbiryP+wX6QuiGgSntVwi9SgvlSAVvA1UttMKSNksBjjmSxDBGQKAEF2OVUlnAeLB0CEAEtp2c2kDQx+nrSRjrIRsISlzj4QnLodRMb9hGFuucgO6p/DgQ4lTrLUc2SJmCKkoAtYMKfxsez98evZl8+f/6HkdCrW/Bqso10gggWKQG6hUlwGaImrp8pYFimhktqNAbsg2dV++BU03jj500of6CpsIBu7dxCsvFqurUDfdwMvHUUhmhDAXReuafcMNZwjXCD5gbtHmmXvjN4UH9SknmRlx2iXS7V1+prDYJolExWvdVgNZbqSw1XGhbrbze+K2uWSktdt3nXSGtcq7y8ZLdKWoN+sn6xfoX+Yf3Tek7v12mt4MkatDadw55lMVpxs7XTSqxW5A/Q0zCdXm9Dop4yVxjpjDqie88T7uRjfB9/gmf51W1B7A8WBEkwYLv8UCyjcPaPh2LqOdHA2aaBi6ykHozRVTapiEAJNenBOsKmlKuiupRUCIvU4zLBbndYAsxQEgyaTD8emgU3k4V/eb/j5Zea77qhO/7EB4umXD+34uP3b6iYMCZz/2nu8IQ373n2d2nDVj0f/xOufL4xMLiduTqzYdS4a7Uc9LIxcZo7DfYIPRF8Spm6hdsibtVu1bMiFvSiQXCGnUulJWZhiWmpbRW7VlyrXaVfaV5rXWNb41jjXOXWCmbQ426b2W11O21uwZKnk1x5AmMP7wX/UDbKfpmR6cmhv8CrpE4OO72833vGS7zGcCfC1IovUDX2fd1py15J2dXjB8ar5Gq/tGWCm+jpiiVaRo3eYj/dOQv4EbaaLznTjdVFP5+3thvX4JXxZfFj8d74Mlz4+b59f/7k0KF+8l7/1rauyPD4gvhj8cfjC/EGPP/v8UQiceH8D8C294ENtV/d2FzYizhYV4qiUY6uL8EsFSqVVkcUcQpXz3Vw/Rzn45q5Nu4Mx3ZwwOGEQbDYfQjrdYxucfahM4hQJqAbnixawBbuuOguXNraVE+LqJ6F6TXdh7O5w9/XQj/GJT5n/wrTMQSfUK7oNfV4D2a/NoQVLILNYXHYnJEWriX7Vn6p7tbsD7UfBLWN8lT91IzG4HztXPO8QGv2vCFLvKu8mwNac1A9ovBFKVRaXO7oxIyJwZcyXgqy7Rntwbsz7g7+MeOPQT4i5+oyMzKD5bposE6u09VkVAdv0LUEb9fdkbFWty5jp7xLtzvDIsmSjs/ggy7ZpbNnCBlBWcdixzSn4vJHFzrxQucOJ3EeJi3IA6TSust9HuzJszJojHqeMdbtjyZPM5rxRtyJY7gPi/hfWcVdbmQxm5crOb9JOLBDsTiijjohHHIP9YU7jTEjMdbhb0xJcXLl/TZ1wFw3uWEfAvU0nsqS6lucjSwCNhlUDy9OJeEi8Loc5cm1TD2gyAB6eLwjgR4nUvDPXRZ6LtEPAFJvdJlp6oRiMJfr/OZyWQ0GmveFotdCnq5cdtJgKY9c/mlMHTjZhsvDdfTUrE4eq6vOqA3ulJ/LkFFTY+rcO3nekRRa+lWNaD/7kwMPVc7ZoB+Nw373jtUbNl1xVbT3X5tXL//mOWzFDiF+0nLXXXePzR8yDMfeXnxfAh2PfxX/AH+StmnN7ROjYz3moSOm3f5i2ytz//qmrn12SUZ5NCt/7s3H1i/7/Y0YA3vdGJ9I5gN7GVGtos827GLoGoskIzKLx3AGksCZywAH5WFFlv6m3eZnC1jC9pDN3aZnb3RGjKC9Bs8O0H2ISrqvom7NBkOkxGgpLSsmxGY1O+yk5aVHO2dPW9G3dt4VJcH4xNP4r1/iACb9x+LvxK/512fiu7fNhY5UQ0cUtSNjFWeYhOV5ZJ68hewiu/WCJBoR/JmNtEsIrEq1S/vFv3HbtLQz5huqaWcGBk/9tC+WkQxYT0yx3WyzCoQZPblmeNrctce37BpV90J8Ytcvzn+6+F/xczj/d/H08+98Ez8b/wHY6mFYYujeoRHU0HKlOBsskisdLWyLlst1lDvG2Bvt8+1cuaPUs9rzKLdZw/lMWRgRiznLYBRd/+5+hKUjgP2BggAJmMx+5DcWAAvTdcD/08sRTZduRwyqy8BFDgkUOexq73n6DYLdBe78SAIsQxX9w8R7qPnunua8srnj7531zOC7OPuTO8vGzKiouGnyyAPc4bTQy/HT/3Lg3s7Zdbk+9uULJXrztF/u2XNwrlmf3A3mXTBQLXEqGg0TEkMaWI+pE9OhSGnDo7J/+AhqSvd3p6DyTNpQyIUHL4nyn6WvZZaVZNlC0lij5JODZAjrl/Jh4uazLdIN8hKylH1G2iMfkA7L56TvZfsOdqO0Q35NekP+HTnJfiB9KJ8mX7CfSV/JuiXSUvlech97r3SfvJEIDZoWcgM7T5ov30ZuZ4UaUsfWSHXyNeI1UoMsOOV8fZQMZ6PSCLlSLzBEy/KSJNuIm3VIQkr4fIQFU5HTCkIRr9cWqRYHAT9YF9XQhzpKvYaa8GDPa5SkUb9dMdKIRmQwYjERZCTSpbmygnpLSeFuwvkDxvcGaIanJzFCyYNW/Cz4cEUMa2UYlmhkuYghEAWHBPwlcGS0MtisgujTYzAXdN305uVhMkxdVMBZURcTB3g4XJGgCMtFLB5bDrNwTOPXaEkPGaaYYRWhbhCibhAq8mmxllajo86M8Wz7QCRirPhXY4XbZRxsH2yvcDuNYIpChvFUO3Re3e+sgN7+1DZN2aGWyaAIxUT/Po2fGp1N6idp7aNIu2ru4wA9XgPO24SPYBkL+Gh8IP5J/M/xP4Dp6WS++L6WveeHZTSoxsPNfDpIsQ1lY4Ny1yrv6sBj6DHrdvt2B7/UeJdjiX+VvEq/xrjGutYj8l4py+2xeq0BV9aNjjuQeCvCjcJ88EJud9+efrt/nbDWtNa9yv+o8Jhms+k54aD9NfsHdlOZp8HUKrTKd6DbBZ7BV6Hr0E2IzbRnhMOZdgExPAml5RmYcA+56kBoQkaeRFLnrKQHT1YMzHuSFAr5XGFStzcXm1PCak6aJLlKbnNuW25Hbmcu7889k0tyYd3RYnphqEDLaKlJkvOPJgkI7qlBU3k+qjw7EDEOxpOby6qLXV6unuyoVltTlt0hqFt1wYu2ignkOqs0ZazYjHSrLhQus3OFN3fcXK3oD23cG38xfjd4KGNxLV5Wkh0/XF7ef+DAH//4glI+vWnyg4evHvqONSj8rBI/gOfjeXhDvD3+6C82LlCqf/Gz+A8XBsGasY0IPFcEwv4QWHWZIOwutE4ZJoiCJBjBRpauFK+UhGukacbNxi2mrbZt9l3GQ/bf2T7jz/EanVYLik3IskhajV/3NuVecL4zFE+9p9nDtHk6PMTvKfB0evo8rAeDeeN3Fbj6XIyL6jf3Za62qt+SfjbdCVVtXdXasQRMsMZd2jIz6knqMO8hnK2xbLhzWYcbZxfcffLF3364zOoFdvv82LDpN8/b/CITuRCPn/9oc+PMbVOXnYPh0WtsZ2B4GrRRuULkWEHM4s0+DhdweznCcRLDUptdlrI0SBT4OoaMkZEGa9x+XYFO0TE6VrrcSNderpzVu0fg+FScrbiknk3USleNCBDiLm85yHBHl1sF+1RjoBEKqafUhQUgQ7ZAKjzCVl74kvQP+pli7vD5+JHv4u3fQe8fh94/y72IOHSF4q4XqP3IMlkcElnODevW5V3jC3sv71qc9mn8YMp8LFbPyh7H2aSfe/GHsbTqH8/nJ6udVXLo6TwYraSDi3F93Anum6TtupzrhAwuuWVLmBBGF8/hwTH7d+fwqZP34uSpu2qqEjQlPpFtVs8E8vHVyqwl3tVeYtbq2gpX6ToKWT8GZ4gpwMWkmFFwNalmrjU0WhuzpuVMizTm32g4bzpvMY/QFdtHZBcPAbvTXpddM+SMdtAhPwAaT6PVaXK1urDe7rDl6bRgGTkzqSl5QL2Npl4L0pvUC1vdGm0SZucmL6OBwa7CwmjyUppk86hb+TM4eo7lM4Qp0Mt5dOtUYxOcLj43RxNyO+kusuRyud0bCnEh7sE9ioyKMwNmV8Glc7+zqZM/et506uIx/+DZ1N7Jxa0jpHZObbxL0kbVq2Q/aggawEmtuOwMWNdqaLW2Zs3LmRtpzVdvBzg4u+PiTn4JH8xIXSZzlIAEgdT4wXa0XHYyfDuuEr3Z0xaUZVl0y/o+uGsWxsd/2YGFkW1HNsT/+qcL9zbPe2DN/JZ7a8PDbOkBe2Hw+m0vHNjwPtZg988fuXDl0cM3VPQ+oCf3Pvf4k0882/k4EGsLsOgKuqOHFimVIGA8lyX4xQLxuPipyOaLG0UiiigpZRKIWCU/gSf8JAZB2p3cnfupiMn/kYg1Vfx4PVT1gv+dCG1hBgZHkDmD26n4PHt+cBNUd238JnYWsJ0JedHjSpm5gkR1UWtF2jhSo6uxjksT23zYK9oc0UauUb5GN83S6Gh0T/PulHemnZfO6b6zak1I76FMwGpslAksGsFg5J0B0ZVuzgErOWQyGVRm2GDERrcvOfvnLrvkcfYf7nhE2lO3PFq5VnmupdXR6prrhXnEJl6du+R9Gzp5OPrjZRxmbNkzMw4sXoeZvhu2VWAmfmblnLlrV8yc+WD8JmK/cvKaHdgIJrtv+rWPf1/L7H96x1OxvdtehLm5jtmHH4C54dBIxb6K+44jPDeXu41jEMdgzJ0liOnBoqKhu10E/5EfX31xQwtVjh8ox8l1Ci9qtzAlARuzqQQXDYUqTefPx7+B6vUg1pPYELLg6H5zNoct1BR0ag1R0a4zRAX64OmDs0MeXWsVn3t4lON5VqfR80aCLDxrAYUGfUG8pRlo2IP3KmaNQZevz0Z+W4Gt2cacsWH11mlGKEqhYk5Lj9roRlU5ozhdUWoR9eCwIhE1RQ9EIWXG5UhJK42m/EHrq6mLJZHxgy54wl9qqy4SaV803nj2FD0vzU/aRNhcntxVoSJYLuhVAaQHnNTGq4sZJ9fFhk+c3tDFGtHhxBmEE2f2MUas7s2lFD84gTpTpcVoccHD7Kzk6JEBJCjsgnSyrkaLuncu6BmY+bB66UqPI/HzOBhfW51Vfc3y+olXu0aVzLrexYYG9eSvF0hv06wrMky/193SCMR/kF7ZgLm1oy4lYsA+XE4VqHEUHmX6A/47lgTOzmWSBtN8E4cxsVhNZgtjJVg9GPMyApjnVptsR0gjh0RJPRGTcELC0n92IoasIbs6AeqJmA3TefnPT8QurQfqoToQ0qEeVIoXbzqZkvc2fnJ6bsLPrzk2c/sEb/y0f+IVtQuK46e5w4Of7RjTtmbD4CZSuGt6Sc3aVYNfw6Ax/ak2NwViPNZ3IwaLdJ01l6vG+xRgsj7xA/wB+ZD9kOOoo7CU24I3k0fZrdwOUWSQhs8XqTPSLC7BggvZ+RwU4seiK/lrEJiJhPgxslKeZC7tIDM9ZJai4REoOLDbMeEOk5mIpdQwl2tYvJztYD9l+1mW7cEaRV7OdDCfMv3gNNGFCEoAkx7GGkTo3jE9J3YJl+0dAzc2nW0Clhy4ZJUP/NQm//Gooa/bmDxkOCDpolPAGWm6eMOyqYkyKWoKYGqZY6IZPIur8C1g/A0f/Bt3+IdX2CvUtXh14gv24dQNmMfpfejzSqGmvMxzpYeY6U235F2Y7wS+hB2hG2Ep8Yxm63R1ltGeh4VHJVmrB0WBLr/9ZtFoDEi+ePvNmAMWgqoTtfgf774l78H8u5tv6uIGOlFDb74l78JwdGVTbQhgE3Pq4pvNcvl1mNXYdU/Xy/H4YO+1+xRzdOztTfeumNeyChjmzMPx0/G/x8/EP7q2cTvJfXZC247nDz5JlyoNiMx09UTRo9i4bHd+VKAPnj5E+mDomR5A9aahH9joMRbz4PSJslYD7E7MjFtyyxkoT/O6Rgur9hnF7vVHZcRprMilyUK5migarlmNpNTOvox1WrUujeSIshhJmEcyqqReY3lE1a4eUHdIZjXgBwJb8RCXyuntT8WZlh3V6HyqFcrqQN8Z5Up5grpDWqBoWAJcV8lOYBlwGAtAHDoUg7YEYT9WMINdP54ARpzjB5rABmlyqepOTatySfnMXA66rlxln0gTvY6ePFfAAYuD3hagB3uH4lNw+FfDHbze+CYOxIF6g386MNqel0fS1TNq1YrELjANMxUbuK4yCdFd2uRJpIudd9vlC4q6XlOzUN2zx+qefa5qmz+tZEksJzNEkrNY814QFwbx1OYkgiiCZc6Jfv5tuoGi+hm6el2zjmnTdegINdM7dX1AIqLx/+RIT/uf+hmXzkCpMaGqbEa11alYga1OwT/Y6hdtjUvfzWBJ1+Ds+MnBo8Bxx0nV97Xk7sHlMKaZ4E5dD36uG32gXL1KWmtda9+BtvKvS+8x72m+ZaQsKVubrcux5tgXc4ulVZwoWASHw+Jw5JBcsOyFbO5Rbov0BvNLDVeJJ4CwTTIi3E93iZM33J1Jk1XWAcTTFYczjxX1it4c1dfNMOAJBnCubc4oSGC2kmHOkxnDN/ppCBZrWpW7IA2n2cKdAjYIPqFAYOhGVLdn2eRLbutlP6cYpPe5TyVvCUOkKXmnATxWTt11VP1UR+oONm+iLmopW4l9o+JvfR3/fXwNvgNHsW73nKL4x+5nb3v617/qvG0P8Vx75ku8AU/HC/AjO66P1S5a8VX8+/hXX28GwgUTp5m3gBnMaLqS2Sru0pEp0lypVddqbDXdYVxrFOQxmrsNeYIEricy++nFp/WKuc2KC6zYqvnGJ2PZZRlMzTl1wNup/Z1chQbPnkp2HweoZ01vZYSz7EltQnbisD/yp94Pv8LYwfkLZs2eBP5k88FZHdv+9hf/suiE9i7o3eJ4L34W09+hVx6QRA0vCz04XfHw2/EwjSwvwiEh8zK+117i+1ODA5Tzzw6qJzXUmrIE1J8zhUtLy4L3YVfu4ullU8eQNdj1xh33t/lvTZs1FZp7CiEmxPWBUT1NkW4kPyPrCUNgbcnpnqEedV9/SJQ4jLQSOoIbgB6YNCk6DrE+1s/GYBVyyYfxLtyJLkrAuYv33M42DainRYGAiRdKSjPLiplQ/PRj7yzApOAUG9w4OpH5xiroQDGoSi10wIsrlRkHnAfdvZ432dedJ5wnXCfcYrWnOq3aO821jX3EuYfdmSbybj/K5svcY9hqZ7Wr2i1mOjNdmW7GHmKnsWuc2z3b07Z796Tt8YpmejvL7y303uZd4d3o/cArqle37FZb1EuMWoOXHvqpJyIKFWRgdbMdWJ082U2wFth6mhL0afO1RKtAvnanhZNO2u14AnTZ7TOcNC4hrvR3X046YdQHO9deQZ0wYOdI+ylwIICVqfLFpuJIUvS9IPOmctqHLoMKFL2xnBWN5ZxoAmgq/+nOvUbyuDzEY8H0/wvQm8fmcrprj+lB6DHkSfSjNAjeRH/qqBbkxRQoNavumbpuCVmlmWDi0zM6nuUFVnshbOz8+heR4S2NDfPF+BcuLL724fkrxxfHz11px1z8h4ex9PG+ymumXt9yw8/Svnjzqxdnd8+qOlsfglmfljjN6mGS9ECyh5S6pfIaeRfeI9ATz0PSryRxmqnRDg6Nb55pvn2+e55PLCflfKlUqhtLxvKjpVrdLunX5A3+VelV3YfkY/496T2dyej0O4lqAmYBgZ07RZ3PkG8gBkpuw07EeU9OYDHrzrCe1LgCFyk9kPR66GW2dhqSRl4TLnLYTUYheaW1rNQBo6eaQjV1S03GUIgUvb90w8Yl738Q/x6exfV2b3RCcRJwfVv3x2fEmw9uxmPxTvzEwc1fVk25OQ6fl5SqKTfRnZCXqmDWxwMNPECDHPShUrTa9oaN/CxtfRrZyTzH7bIeZA5zB60fOT9xiXYrvt9+v4MEZB1iscNiD/h0Rq3cgzMV7QQdVnQbdESnw/YeTBSDz5JvIRY6ZMtODwce/rQDRpAsoq7lRZDN7gzrYto+YEOt3XhyuW+Db4dvr++4j/P1CycnZOJMd8R+0rEEn0Su3EtEOpsiE8gg3SZK8SR9qLtG6sXTpOeRYqykXYcuOw4KZghl9kucNJKAow+sJNCzIHoJfDw26hZNvGbJokmldb5FSxvGjpmriQ96bn7l9rfvmvfusi3xz3/7evx7vDIwf8GKthvutH3GtF4zrmFO85CVO65dcdOal27xHF35UvzMZ0DXXHY3/ka9uHelesWl22yLqreYtPQqKj0hMqpX+xsVGdTPZ2iBkTpiZOYB4mKffj454sGms5ddRMVBMEu/2Rf/Go+gN1H/y3uow9CJy+6hFnSDbZR+8aZpUhJ7Ep/vT0/XaJSIR9Ea0n3plelMukYeAw5dI72G+gYYJn8CW4/+/GSo4mGGYZ4fxsrSXjDv+RD2cwUc4faKbz2vHlbR3xJUnEsdH1/81cgbyV+NMDoKL/wtZbRkgGr+ACo24vH7zW+wGPckEkqh0RSVMTwELMrkO3xeJmWaK+UrtQ24gbTiVrLcLH7KntB+w/ZrWTmffVI4Qm5FIpLxFEWSJJHH+donVdfMYDQieQO7A5jNHxoKliiO7JfkYqOhJ3kZ2qCKJv2hm8Fo8BsKDIphuYE3uMHl7TOfMBOzIBajDu1G+uNVejEJ6hC0DprCkS6M/5Ofy2mjyGVa+jM6bfTnclRlNkUWGc+CR0ftJppztmIgsog6KIPfgiKl+1rfnsLtFz0TnDih6CVnFIMvUABQFkTKyPSCquqf0LupwALJrVEChrOsKdcYtRB06i+9GlFxCS4t4wWuJGDDQmlxwJaBH5iVX1gfX8ssiN+wYXEa7v4Yv9GWz2Dy5evxIduE74CD1MvGKgcZ/x0HfXQZB9mAS3GURWPCAC5dWUb0h/SIm0xNUDxCedLEeuSJ7HSZfZ7bKTwvPaP5GL8n8Cs1W/HDzGPcFuEx6WHNbvwMI7mxTciGNb8RTxNWMuu4dZIUxSME4pL9bL5cw14lXyuvYO+TN7E75E72PfYPsq6MHSY/xG6TX2ffkE+wgkwkXiMwIq9hGZGD9Vvi1CuD/h+vB/ovuwpIUlcB8dFDvGKxRfk6enmpW3TrwK88CgTtOwC5pE5Db51oUrseWupjql4AvfwXGYDouWTsH+4B/uho0qubl+7+mcPq3b/uJHzzkAQ8XgqPi9fa1IPI9vZ2tKgQJ51O+oe/jQ8HCw9EDF8THwapbfEj8cNkkByL5+DfDQ4b1OMf4hwlvEr95GeGoeJbBPJAP3+elXvv5VBM5vOXMOApjIxfrcblxHY0B/3jZyRpAMpNQ48wXrSavQVVQSiAMJWUo4fYP6P1ZA/yAZwEYRPkIYBTBC9aBvlHUuXHkvLEIOTfD3lOSGu519FWCLTsEMi7BeKb+XLUCPj3QVvjIO9GCNWQ/zC/B22i7yD+EO0H4DyeansKhC0QrsWn0XVQrx7iD3LTEgmAtK8aWo7WDWEmpIOQXgzwKQjFEKZBGA/t5NJ+AnyDRSiD9hfaufxzgl5TAV11HKgF5BYVCH9CSPoDEC2OkGYAIe0HyaB7DSHDHRA+Rsg4DCFzLYRtCFnuQch6N0J2qNk5GSHXbxByz4KwF6E0M0JeF4QnEVgfENYiFIC8wA8IZU5AKOsLhEJArfBKCP0IZV+FUG42hFcQiryK0JAgQnmdCA3dgVD+SdDx7yJUFIIwG6HiMoSibQiV6CHcBQH6W/Y0QsN2IVSeQGg4lBkO4xrhRKjiWQif0/9Dq3LHSOCVpQShdBAAI8pH0HOhzvStmobBos2XeCgTXeQnAktEZioOfixK6QUw5DPRhFScA8v/llSch/xlUBKzEuSMAWM9GSdgiH2VijOQfz4VB7WDlVScQ3a8JhXnIf+JmdGCYcNaSlryioqGFeRFi8tn5c0sbSnLKywqLCgtKigqmjNn9qSWeYtvmrnov1P0v1NmWsuiW1oXLvAXDi387xRHM1EUFMow+LagEgh5qAi+wyAvD94Uo3I0C2IzUSm8K4MY/U+NhfC2FGCBWnYOfGejSfB+HlqMboKyi/7Hav2fqmcavKf/FbIVLUQLgKUL0VAI/1O1M+i//FRp0RRmL/3C2uRFPuZF5ueoAuDPu3mvr6NKx7yA9kIApoanH0InBAYpzAvdgq5I6QFotqqwyx4p6k30QWR4sZqf93BRx1HmeTQDFUP2811Tafbz3UpNkQqLRyRhfqEKu8Tka8Fa5KtyA1o+BIIMqdgECBsg7IBwHAIPHXoefQohAYFhdjNPddX6oIZnoSJDlZV5FkREgefbEBIQGOj9szCWZ9E3qRwWevV0t6SlzT+tYnmYpwHLAE8jhA4IeyG8DYFDC+G5A0KCoVbjDuYpePcUIsxTzJNdRp+xSmaeQMshEOYxZMD0h659zNZuo0qbR7sNliKlysg8guohEBRjxqM+CASq3QRom+hKytR1Af9TEtZ1y/oiI5RfD51eDx1ZD012whOraQUCLb++22Kn1d/bZTCpeD/rKogmI91GZ1E9UGEpwkwLswAFYUqXAUwHOBsgnepZzBykU/updBuMRR3QXiUUr2RsYKX4mCrGDlzkY2oYN/KoxRZ36ZPtLO7Kzi2CEVczTrWIgdEBU/oYkRG6inz+I4yiEn9Nt6Sh/VvTZbQVHWNWMgKyQqkOKOXwGY4xMsysrI5kSrekK9pYpWWmwDCnAFl80EcMVF6gVrSgCyqqMjGjmTRkh3c3wvJqA1jLpKtwF/MkqgX4eHcozdd3hHlIxXqQVgrNj0yy1shunb6or0pi6BXgGPMATMADauMbu0PDilBViMlGBQz9z6F+ZjnElqtMvw5i62DW1sFMrYOZWgedWkdtAmYtvKG/2M1n7kBtzBK0EcIOiFO2snUBQXvVSGZ2US/jYpxAGOMRICWGXHe3pKc9c3aZLWoxZ7dWX1R5jLkF+PwWqFNhbu12OIsWHmFy1aEM6XZ6KEJbF7DrMcaRnBpAtNMpOcakASEoYbxMepfNF6vyQZoysg8MvDfJCUok8i55n043/a+QKvx1Cr6Vgv+ShIk+ciIpFOS3FPZXpRHql80gn6AdECPkCHkFVIyPfER6aC/Ih6QXVQI8Cek5AHsBFgM83BX4la+H9HQDgL5v69LZ6WDJK12R/FTEl5WKODypiNleVJVFXiYvoTSo4ncAMwG+RPrA//GR4wCdAPvAifkVwAOgtUYA3J+Cr5KjlMXJIXIQdKWPdHfpaRdiXQIFe7t4Cl7sQslUfb7vKHmRPI/cUPTnXSE35O7uDmX6DEegPkyeJbd2eX3mKpk8iRvwWSjUiU5SiMzkqa4yWsnGrqN+Xy/ZSDYqzjIlS8lTdjIFWQV5BTsZf5Y/z1/m3+mvMpIHQIHsICC/ZD08y5CfAPdAUCBsJGu72LJY1SCMiY6LoA54dqqxZni2qTEET+Olt2fUWCVZiSZAIFDHMgjLIXRAuBtW/o3kDgg/g3AnhLvUnFshLIawBLRJG2C0AUYbYLSpGG2A0QYYbYDRpmK0qa0vhkAxmgGjGTCaAaNZxWgGjGbAaAaMZhWD9rcZMJpVjHrAqAeMesCoVzHqAaMeMOoBo17FqAeMesCoVzEUwFAAQwEMRcVQAEMBDAUwFBVDAQwFMBQVowAwCgCjADAKVIwCwCgAjALAKFAxCgCjADAKVAw/YPgBww8YfhXDDxh+wPADhl/F8AOGHzD8KoYRMIyAYQQMo4phBAwjYBgBw6hiGNX5WQyBYvQDRj9g9ANGv4rRDxj9gNEPGP0qRj9g9ANGP1myjzlR9UtAOQEoJwDlhIpyAlBOAMoJQDmhopwAlBOAciI19FtVYhBgm2UQlkPogEBx+wC3D3D7ALdPxe1T2WsxBIobA4wYYMQAI6ZixAAjBhgxwIipGDHAiAFGTMXoBIxOwOgEjE4VoxMwOgGjEzA6VYxOlXEXQ6AY/+dM+X88NeRu3CDCWks6cI4Kl6OvVbgMnVThXWifCu9EO1X4M3SPCu9AZSpcgkIqhPpUeCvyibjLV2aosoMKmABhBoSFEHZAoEbScQiCGnsbwqcQEqREyWANwgRhh7BXOC5we4V+gRj4CfwOfi9/nOf28v088Vd5iE7Vo6Ba0Ab1uRye3xC6a5QPz0o1Vkmi0G4U9GwJfKMkqpgG/N/k4rdz8fFcvDcXb8jFVRK5ErOqpvOjMgIdxw2KNjTSdxJCWSg8EjTTAwe/dvi6QqU+8MyTIEeJAPwawj4IOyHcA6EMQhGEPAhZEHxqXi6Ub1AyUlUehRCGEIDgp00gux2MR7NJVHqJDu/s/qUO0X2BrnA24B3pChcA6OkKTwBwqCs8y1cl4YMoTK0ifABm7nmAe7t8p+D1z5PghS7fEQC7u3xRAE1d4aEAru0Kv+Wr0uGp4DNT1CkpOBnGTeGkLt80KDaxy5fjo7tM4RAtnQsNZcHbHNyATgHMSmFlJlsKdvlGAMjo8pXT0iIK04nHPMpTu8dBoJDphg5904sbWKxofAO+h3xfA/pfgLDAHh/6e1gAb2fRYwHZdzTvCShc5euqkml5WB/2pWCMwgO+nVlrfdugLpx10Peob6jvgbweEbLvh36vVZvo8t3j7yHPKxZfh6/Ad2veKd8tvnG+mb5JvqYsyO/yXec7SruJGnEDef6grx4qHAujyOryXZnVo3ax1ne7T/GFfeX+o5S+aFiy3rK8o5QCqCjZ+hCgb25WD+XxqWU92KTkCmeEjcK1wihhhBAUMoR0wStYRbNoFPWiVpRFUeRFViQiEq10Wy9CfVcrT3/Oi3iWPlk1biT0SV1dcFUJFgkah2IWpo7UTR6F62J9s1HdLH/s3ORgD5YnTo9xwVE4Zq5DdVNGxYZF6nqExKRYWaQuJtRf27AP4wcaITdG1vRgNKWhBydo1koP/Tel+zBaeb+nF2HsWnl/YyNy2m+rdFaaR5rKa2v+g0dz6hn58eO8POqNba6b3BDb422MFdFIwttYF7ub/hPTXmIgutE1vURPQWNDL9tGDKMn0Xy2raYRip1SiwE366EYClMAxcRRyE+LgT4ZRYvBHCXLhQAdygUogHKyDoXUciFZp5ZjMS2376R/dM0+v18tk4XQSbXMySx0WRngGMCt2RcKqaWCftxAS+GGoF/tWI5akc8HRfJ8ahEMdp1akQ+rjcXyfyySlSpScqlIidoWg38s40uWsWZfLGPNhjKR/8tPy6gI7i5cvOwV+n9hm4OjWyA0x9bfNt8Z65jl9+9btjj1D2NDzbNmz6dwZktscbClJrYsWOPfV/jKf/D6Ffq6MFizD70yekrDvleUlpquQqVwdHBmTWN3ZUVD1U/aWnuprYaK/6CyClpZA22rsuo/eF1FX1fStqpoW1W0rUqlUm1rdCvl+/qGff9fG0ew0jAMTVtZ3aayXaRsDqmjF0MdDHSHgXRlO/W4i/U0j54UkrDb/IV+QncpO9YWRAeCf6bvJenmYa9NXvJe8l55L214NMkxCXF1lsSl2WzAGF503Tg8b73e44D+GrvOqrs9IsaGNGmcn/TD/BQSsvyJP0EWvGfIOsPDfzXLWY3d7tbYaFYLyO1+SCrTEmyERzpGuTt/fMChkgdPh33GECTbIbPnKdxQ5zLB9b8lYQeBHwIhBMNMUEZIlF/Po/wOD5i0bVC1mMZAu6loliVp7/X67PP3B5gUHsLgqA5L1MDdUUEDoi7bTGupbWKowMtOb/jyDTP4GySI48xlMZDhs7ksrzyMX3g5uFUYwlXERccd4v+HEXRF7CkctH0oJF7iJ6PUS/10VAPqRwbEywyn0mKQWYRTVhkCijwmatMW6FsXFz2pOMUCpTFlckXLzh17MDTeG5ZpqUyK51Q7RNGZFgKeUNpF1U3oTpIpZCclRNV22R64QFFoT/hK/wEPJMBRDQplbmRzdHJlYW0NZW5kb2JqDTM2IDAgb2JqDTw8L0FzY2VudCA3MjgvQXZnV2lkdGggMjc3L0NJRFNldCAzNCAwIFIvQ2FwSGVpZ2h0IDE0NjYvRGVzY2VudCAtMjEwL0ZsYWdzIDMyL0ZvbnRCQm94WzAuMCAtMjExLjAgMTAwMC4wIDkwNi4wXS9Gb250RmlsZTIgMzUgMCBSL0ZvbnROYW1lL1hITFZHTitBcmlhbC9JdGFsaWNBbmdsZSAwL0xlYWRpbmcgMTA4OC9NYXhXaWR0aCAyNzcvTWlzc2luZ1dpZHRoIDI3Ny9TdGVtSCAwL1N0ZW1WIDgwL1R5cGUvRm9udERlc2NyaXB0b3IvWEhlaWdodCAwPj4NZW5kb2JqDTM3IDAgb2JqDTw8L0Jhc2VGb250L1hITFZHTitBcmlhbC9DSURTeXN0ZW1JbmZvPDwvT3JkZXJpbmcoSWRlbnRpdHkpL1JlZ2lzdHJ5KEFkb2JlKS9TdXBwbGVtZW50IDA+Pi9DSURUb0dJRE1hcC9JZGVudGl0eS9EVyAxMDAwL0ZvbnREZXNjcmlwdG9yIDM2IDAgUi9TdWJ0eXBlL0NJREZvbnRUeXBlMi9UeXBlL0ZvbnQvV1sxWzY2Ni4wXTJbMzg5LjBdM1s1NTYuMF00WzU1Ni4wXTVbNTU2LjBdNlsyNzcuMF03WzYxMC4wXThbMzMzLjBdOVs2MTAuMF0xMFs2MTAuMF0xMVsyNzcuMF0xMls2MTAuMF0xM1s4ODkuMF0xNVs1NTYuMF0xNls1NTYuMF0xN1syNzcuMF0xOFs2MTAuMF0xOVszMzMuMF0yMFs1NTYuMF0yMVs3MjIuMF0yMls3MjIuMF0yM1s2MTAuMF0yNFszMzMuMF0yNVs3MjIuMF0yNls3NzcuMF0yN1syNzcuMF0yOFs2NjYuMF0yOVszMzMuMF0zMFszMzMuMF0zMVs3MjIuMF0zMls4MzMuMF0zM1s3NzcuMF0zNFs3MjIuMF0zNVs2NjYuMF0zNls2MTAuMF0zN1syNzcuMF0zOFs2MTAuMF0zOVs2MTAuMF00MFs2MTAuMF00MVsyMzcuMF00Mls1NTYuMF00M1s2MTAuMF00NFs2NjYuMF00NVs2MTAuMF00Nls1NTYuMF00N1syNzcuMF00OFs3MjIuMF00OVs3MjIuMF01MFs1NTYuMF01MVsyNzcuMF01Mls1NTYuMF01M1s1NTYuMF01NFs1NTYuMF01NVs1NTYuMF01N1s1NTYuMF01OFszMzMuMF01OVs1MDAuMF02MFs1NTYuMF02MVs2NjYuMF1dPj4NZW5kb2JqDTM4IDAgb2JqDTw8L0JpdHNQZXJDb21wb25lbnQgOC9Db2xvclNwYWNlL0RldmljZUdyYXkvRmlsdGVyL0ZsYXRlRGVjb2RlL0hlaWdodCAyMTcvTGVuZ3RoIDEyNDgvTmFtZS9JbTEvU3VidHlwZS9JbWFnZS9UeXBlL1hPYmplY3QvV2lkdGggMjQ1Pj5zdHJlYW0NCnic7dnbkeMgEEBRxUIcCoRICIVYCIZctNDdvGTv2vMxtaLq9s9YsrA4PBqkOY4Pce0UnzDfxv92/ChAgwYNGjToTQI0aNCgQYPeJECDBg0aNOhNAjRo0KBBg94kQIMGDRo06E0CNGjQoEGD3iRAgwYNGjToTQI0aNCgQYPeJECDBg0aNOhNAjRo0KBBg94kQIMGDRo06E0CNGjQoEGD3iRAgwYNGjToTQI0aNCgQYPeJECDBg0aNOhNAjRo0KBBg94kQIMGDRo06E0CNGjQoEGD3iRAgwYNGjToTQI0aNCgQYPeJECDBg0aNOhNAjRo0KBBg94kQIMGDRo06E0CNGjQoEGD3iRAgwb9uMjxf9fg+8ilnc92EHPQQ3eVD6H8sV4I84dQLkzpuspFo0S9wIXLHYcvn5JceurFj4sr11p6O4r1sFS2aov8vGI958qp8mXKeiDW2iL6wUpITwe5th7I2eW3nxPSNaW77DDKYU4FVgdrkvNFE5N+74RQmkAuVLSV6GgpWb8S/RNHfRKNl5ofTV9QToaljs1y0tsUGBfWrtfhbSUa+tSuLc2gDfpAdLbseUaZk9qjDe1GbpWP/h26lWhor83zaHRaDpUQO3rJQvk6/4aOrz0dn4uOlpJni87pcLQmSTbjy4TWOV3oA91KvJvTD0VL9j57j8a61rQMXb+ImprFXc9L3ipnJ7SVmLK3b9n7qWiZ1X1ViTnqemwjW6ZyrXpqH+qqHJdEZiUk2d3W6ceil+hr1y+WeFyA/qUSBEEQxBzB9lV9T6nbhLbZSrpJcOPtjD5D6PsBferw+jcd42Fjfu7wupVpv2i77PqmwLae2W4RDt/KuLP/entZcep1qd3KtrL1zHgC+nJLE3TLJGgvVfPyNkDrGPVn9Jk+yhdxbEBDe3KUP7VSVu4cd8+lSrWSrp1SdJIy9iQWGvowfn+eqb9pjVK3qE2ea51n9GG17S9zPqJzQ1/O2XNPgcg9re1sUyjPQPrrb9C+b76nitR6eNuJuoG2g9oSzl48DXTuiqT709jv1Zojpzdo//VLpjK85dqO1kciZ/t/Q6d7obfoYxoh7l4PP6Nbt3sZVNLsHT36K+hMSG2EjTkYwit6GiCf0U7uok865S6nDVatgtYuXmPGy33yG3St4a2n53q0Op5yj/EKrBSR2dCK+mn2W9OURsk6rOeN3B09Bsg36OPKUyP6N+gjLlnC3+f0lL3CfMFUj3Oe035FW7awqb1M6KPdQCs192VcX39/PaGPlsDCB/Qxv/Q9273XntZR2DP2Wg/XBe/Q1Wfo24RuPquN3Fiz+q2nv5/Qhq616+h3w3upuO/tvaI1K023nupxdrMN73GZFCnjQIu+TOhjusMY3v6O/sGEbujS0h09JbKGbveU/BVGO/wbPdXD2knaUxNZHyuuYb0uly8TekYvw3FB/2BC9985r5GqbMlyA926PebFfENXzYwe9WhjQ1ry1LSpiiuNYS3/Gnmd0DO6N9Yd/ZMJ3dFzfvZz5ZUYbMHwawes6HzNi+00PAelZv1kGyvdnPSl/azoMY1XRUefmrXSta7T57dbsRV9TIvSvA29btvQ1HaHC1piWWzHzvBKcWS33HKtFkrHvLSHvnO9xiY3Lmjb/mYt0NG3RE4QBEEQBEEQBEH8ZvwBGkO3Ow0KZW5kc3RyZWFtDWVuZG9iag0zOSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDI1OTQvTiAzPj5zdHJlYW0NCnhenZZnVFPZFsfPvTe9UJIQipTQa6gCAaT3JkWKIAohCRBKiCEBe0FEBUYUFWmKIIMCDjg6AjJWRLEwIKjYnSCDiDoOjmJD5SWy1uib1+bN/8O9v7XP3ueeXc5aFwBSQAhfkA0rAZAlEIsi/b0YC+PiGdh+AAM8wAAbANicHGHoAr8oIFOgrzcjR+YE/kmvhwEkf19jBoQzGOD/kzJHKBIDAIXL2I7Ly+HIuEDGmXliodw+KWNacoacYZScRbIDylhNzqmzbPHZZ5Y95MzNEnBlLD+zkJvFlXOPjDfnSngyRkJkXJjL5+XJ+LqMDTIlWXwZv5XHZvHYOQCgSHK7mMdJk7G1jEmiqEhvGc8DAEdK/YqTv2Ixb5lYnpR3tnC5iJ+aJmaYcEwZNk5OLEYALy+TJxYzw9mcDLaIy/DOzhKyBcsBmM35syjy2jJkRXawcXJwYNpa2nyp039f/IuS93aWXkZ87hlE7/ti+3d+2fUAsKZktdn2xZZcCUDHRgDU7nyxGewDQFHWt/aBr/Khy+clTSwWOltZ5eXlWfJ5HEt5Qf/Q/3T4C/rqe5by7f4oD8OHl8KWZIoZ8rpxsjOzJSJGjpDN4TGYfx7ivx34lb46h0UkL4Un4glkETGyKeMLUmXtFnD5Yn62gMEX/Kcm/s2wP2l2rmWiNnwCtERLoDRAA8ivfQBFJQIkYa9sBfqjbyH4GCC/ebE647Nz/1nQv+4Kl8ofOfzUz3HekVEMjkSUO7smv5YADQhAEdCAOtAG+sAEMIEtcAQuwAP4giAQBqJAHFgCOCANZAERyAOrwHpQCIrBNrALVIFa0ACaQCs4AjrACXAWXABXwFVwA9wFUjAGnoJJ8BpMQxCEhcgQFVKHdCBDyByyhViQG+QLhUCRUByUBKVCAkgCrYI2QMVQGVQF1UFN0PfQcegsdAkahG5DI9AE9Dv0HkZgEkyDtWAj2ApmwZ5wMBwFL4ZT4aXwCrgA3gpXwPXwIbgdPgtfgW/AUvgpPIUAhIjQEV2EibAQbyQMiUdSEBGyBilCypF6pBXpQnqRa4gUeYa8Q2FQVBQDxUS5oAJQ0SgOailqDaoEVYU6iGpH9aCuoUZQk6hPaDJaE22OdkYHoheiU9F56EJ0OboRfQx9Hn0DPYZ+jcFg6BhjjCMmABOHScesxJRg9mDaMGcwg5hRzBQWi1XHmmNdsWFYNlaMLcRWYg9hT2OHsGPYtzgiTgdni/PDxeMEuHxcOa4Zdwo3hBvHTeOV8IZ4Z3wYnotfji/FN+C78AP4Mfw0QZlgTHAlRBHSCesJFYRWwnnCPcJLIpGoR3QiRhD5xHXECuJh4kXiCPEdiUIyI3mTEkgS0lbSAdIZ0m3SSzKZbET2IMeTxeSt5CbyOfID8lsFqoKlQqACV2GtQrVCu8KQwnNFvKKhoqfiEsUViuWKRxUHFJ8p4ZWMlLyV2EprlKqVjivdVJpSpirbKIcpZymXKDcrX1J+TMFSjCi+FC6lgLKfco4ySkWo+lRvKoe6gdpAPU8do2FoxrRAWjqtmPYdrZ82qUJRmasSo7JMpVrlpIqUjtCN6IH0THop/Qh9mP5eVUvVU5WnukW1VXVI9Y3aHDUPNZ5akVqb2g219+oMdV/1DPXt6h3q9zVQGmYaERp5Gns1zms8m0Ob4zKHM6dozpE5dzRhTTPNSM2Vmvs1+zSntLS1/LWEWpVa57SeadO1PbTTtXdqn9Ke0KHquOnwdXbqnNZ5wlBheDIyGRWMHsakrqZugK5Et063X3daz1gvWi9fr03vvj5Bn6Wfor9Tv1t/0kDHINRglUGLwR1DvCHLMM1wt2Gv4RsjY6NYo01GHUaPjdWMA41XGLcY3zMhm7ibLDWpN7luijFlmWaY7jG9agab2ZulmVWbDZjD5g7mfPM95oMWaAsnC4FFvcVNJonpycxltjBHLOmWIZb5lh2Wz60MrOKttlv1Wn2ytrfOtG6wvmtDsQmyybfpsvnd1syWY1tte92ObOdnt9au0+7FXPO5vLl7596yp9qH2m+y77b/6ODoIHJodZhwNHBMcqxxvMmiscJZJayLTmgnL6e1Tiec3jk7OIudjzj/5sJ0yXBpdnk8z3geb17DvFFXPVe2a52r1I3hluS2z03qruvOdq93f+ih78H1aPQY9zT1TPc85Pncy9pL5HXM6423s/dq7zM+iI+/T5FPvy/FN9q3yveBn55fql+L36S/vf9K/zMB6IDggO0BNwO1AjmBTYGTQY5Bq4N6gknBC4Krgh+GmIWIQrpC4dCg0B2h9+YbzhfM7wgDYYFhO8LuhxuHLw3/MQITER5RHfEo0iZyVWTvAuqCxAXNC15HeUWVRt2NNomWRHfHKMYkxDTFvIn1iS2LlS60Wrh64ZU4jTh+XGc8Nj4mvjF+apHvol2LxhLsEwoThhcbL162+NISjSWZS04mKiayE48moZNik5qTPrDD2PXsqeTA5JrkSY43ZzfnKdeDu5M7wXPllfHGU1xTylIep7qm7kidSHNPK097xvfmV/FfpAek16a/yQjLOJAxkxmb2ZaFy0rKOi6gCDIEPdna2cuyB4XmwkKhdKnz0l1LJ0XBosYcKGdxTqeYJvuZ6pOYSDZKRnLdcqtz3+bF5B1dprxMsKxvudnyLcvHV/it+HYlaiVnZfcq3VXrV42s9lxdtwZak7yme63+2oK1Y+v81x1cT1ifsf6nfOv8svxXG2I3dBVoFawrGN3ov7GlUKFQVHhzk8um2s2ozfzN/VvstlRu+VTELbpcbF1cXvyhhFNy+Rubbyq+mdmasrW/1KF07zbMNsG24e3u2w+WKZetKBvdEbqjfSdjZ9HOV7sSd10qn1teu5uwW7JbWhFS0VlpULmt8kNVWtWNaq/qthrNmi01b/Zw9wzt9djbWqtVW1z7fh9/3606/7r2eqP68v2Y/bn7HzXENPR+y/q2qVGjsbjx4wHBAenByIM9TY5NTc2azaUtcIukZeJQwqGr3/l819nKbK1ro7cVHwaHJYeffJ/0/fCR4CPdR1lHW38w/KHmGPVYUTvUvrx9siOtQ9oZ1zl4POh4d5dL17EfLX88cEL3RPVJlZOlpwinCk7NnF5xeuqM8Myzs6lnR7sTu++eW3juek9ET//54PMXL/hdONfr2Xv6ouvFE5ecLx2/zLrcccXhSnuffd+xn+x/Otbv0N8+4DjQedXpatfgvMFTQ+5DZ6/5XLtwPfD6lRvzbwwORw/fuplwU3qLe+vx7czbL+7k3pm+u+4e+l7RfaX75Q80H9T/bPpzm9RBenLEZ6Tv4YKHd0c5o09/yfnlw1jBI/Kj8nGd8abHto9PTPhNXH2y6MnYU+HT6WeFvyr/WvPc5PkPv3n81je5cHLshejFzO8lL9VfHng191X3VPjUg9dZr6ffFL1Vf3vwHetd7/vY9+PTeR+wHyo+mn7s+hT86d5M1szMPwD3hPP7DQplbmRzdHJlYW0NZW5kb2JqDTEgMCBvYmoNPDwvQmxlZWRCb3hbMCAwIDU5NC43MiA3OTJdL0NvbnRlbnRzIDIgMCBSL0Nyb3BCb3hbMCAwIDU5NC43MiA3OTJdL01lZGlhQm94WzAgMCA1OTQuNzIgNzkyXS9QYXJlbnQgNiAwIFIvUmVzb3VyY2VzIDEzIDAgUi9Sb3RhdGUgMC9UcmltQm94WzAgMCA1OTQuNzIgNzkyXS9UeXBlL1BhZ2U+Pg1lbmRvYmoNMiAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDU1ODc+PnN0cmVhbQ0KeF7tPWtz3La11FqWZ6RRrDp2UkeqvZUtJ3VsCCABkLwfkhn3kUzntjO9ycz9UPdDk1vP/aB4pmrudPrv7zl4kABJkFguV+Kma1krAovHwXnj4MG/Hx+yJYWf1/gnL9Pl9z8cH1a5bMk44dR8Nr4iDP9i5uVv/vbur/939eNX13/91/L7fxwf0uU/vn9/fPjmW/jud2wpl9++czrCioKwLFt+C5X//Fkik7fvk/2EJvfw4TxJk0v4fPtZ8ixZJHfgm0Xy9rvkAB7PoUiGiX347hJqLODpMrnAwnlVGMtRaAUyKTxiY0KV9VrJky9+9Zflt78/PvwtwPknb2xcpKTI5ETj+wghgb4XAOhCj/YA4LeZJ8nCAHL5u6zZGM9IXvjN7UGDHyc/h9/HySfJaXJW1W6BkkvCGPer287qQjl0kfqFHiQfJg+TR9DTI9XX42YlHCRLSVZXeaiAeQRAnSW/gOo/h+cn7YowIEaLRt0WTJyTPJeNUiGg2vRT0FVMuy799hRPHQDX7CPF3v6o+XWRHCVv3+HHdfIBcte75D4QE1LwtEh+hn/28OPtu0FGmw7YJwDZFwo64KvklwA2gHwO7Aa/vfhKGZEahG4Q6+/XBfEBSN+lkVT8fAZplFgKf58pLGvgj5LnWmgzRDgK8B5g+EVyv38cBSl6x1F9v+44HqpxKJV1D9TJSwU4sueTagAArOKA64QA8Efwi3+fQy7+LpKnpvzZsHwh159WOLtUCvMyWXZWzEkmgrKlkEQJK3izSI1QDzW//gZR882v/wiF/wJt/M/xIaEl/CuW/8RvREkoNAZtCSkIGBGTcXV8+I1q0CeE5nXp2hSkDIcv6yYo1jbPJTLelS3lp9Tjfx8fvu8gJ9PktAWFzAAsqRu4/tvx4TsFma32X1+9MUxAUvjlHjNky8JnBt2oJAWvsMiUZrjG/3eQK4BxT0D8gGJWQQf4DXmNpV3tA6pokXWRqUIaMEnOcgdzJqNGX5qTshA1yprpukIMHk1pi0wmSCoLB50OoVMiBI6McKiHlKaWxBmRoqJxRjJZAtJhoJBWf23ifzthQn5kDX7ECooZCeNMuL3ojIoXHfiElEDqzIeQaV/I+jYGZBhmxW3wjOOaHGDTxzC8oMEQ5wje64phGgDPBceaBxyIFbCzwnCUAmDdCoCVREhmBfRTpZa/MMbtJTqxxlf4vKmEjSgKcHOKoKY2hQoiUT30KAGD31oJmIxaCWQ5KXSGrtFM1xVilIApHdCovSozAxNaj+YMFOQLRBFatSMwjgdabT5IHo5WmhzMpmC9+OJUqcAaXyajxlchSe7ip5muK8Tgy5S2+OJAdmDOHqUJFXKaLmesND0Iu5UmlyTjpYYYnqmU0wNs+hiGt8gJBcRukdJ0IA4pzVlgOCOpKHBel3JuHTqqu0adC8PgrAbFpktS6AzqPtpSAaEiRZoLLVimbN2cp4Ic8F4D5BrZLuZeqwz9aaCSZd7OoDYhhFiqlhC3psV0FG51H4RSKiyCsCed0YVgp3vWK3CISGNCS5I7MK4HMK2B1T0Mg8oooanol7YNopiugl7NIA7EIWmjDnvo0lV685g3PTaGEeW7tCwxGDMOuM4JS3NrJ59i6OK7aq7SnluzEoyYyLZN0OntCDndCfhs0Bst4LeE3nFCnKMj3RBix512nOmLoExnOcwteLHlMl1kxW3INHZL1pfphieiOWTThqXhg+ykfrklUl/AhLJsSP0rlHEQ+QcdgVzfSRcZ1JMbl3MJsE0h53NhpWhZviVW+neRVHrTapJOIcOt0CEIIct9EVZLhRdqieiiXlYc9MV38kx28jw79EbLc7nlUitxD8c5WF466GHvJJVsVFJnZxp2Msz4NsgwgZ9F8p/JlwOuMy7d0GInwCvyUbQAl1slptsQgYgW4dlGICYT8pHu9U7mdzIflPlZriREy/wtoX4yiX6j9oy+xE2Xg773TozJRsV4huuiI0W8YQlvUswb9nCYPP82or6XfICLWu/UXnBf2Mf1YXZ0UZK1dok1y3B3e1+oUE6ysrXd2ttvVuitPD/U28t0xlW9x1kSqTPMLudGuq4Q0D/efjNTesz+vDJTCwxmNDQ5qA49LHA9EXfv39EulN6y9wLJ8iM87qsM9Tl66x6jjLCM9+KyLNVOvBqXJqPGJcsEkbKskdfKqKvEYNOUttiExkrK+nbvQQVeCFcG57KzzO6G8yDs1uqZJFwaVQfPeFxgcoBNH8PwIgVLkfZr77kg2ex7d0AOqeZZ4FjHNxhNwZLkbS9JSJACWgNm0yO9pOYegLq51bykhqlGqqRp6WfQorDMkJKSy4ksX8NU267Dptrpfvv3AtjBxPhTGyQC9QmAvUzgK83QlY3ycdrGPGeg4fPm9iC1Hwg+HrRcqbZCYAzsXLlxhdCcNo1VCHPhtWhhnyGvjRTzbdLF0apgtro4SiHETKwem9O25+ow/f50UyuWliRlQ/MmlmXgmaSDpcADLGWz1CpzCyA750QWee+8gvEcOnLmFSbjqs4QEuZGmGFqNNNVhZhZhSk9Zo7GBHenSXtapx/YY6f+6GqtnqFWB5hz3qHVGadEOrEwnWQ4TzCa3H0e0OrMD4RVbaV0DRcPm8nztJ1B3cSKckij5LBqfEitaBTFehi6tJvOuB2OQpaFn44fiavzdX+NQQQ4DfRoU188Mgeczez/CLntRAUI9pED3yd3+44P8IyUxQAD5jnzOBDTk7GgaSzEg7TFf7TJaqydQd3ExOSyrY5Q/zHkDN0j0qZdWnCSi7KHdiwlEtqvaGfS09Cubmwc7Uz9VgZ1ExPTzrY6VtY+0gFPE1ILu+plTjK8KCVIGVmQ3Akr2PQ0lKkbG0cZWRIqXcpAg2UqDWUs6NNSxvTZs2BggHAAj5qtG/UdUucZ35RxMm2PUBMsghP1LSyfJF+rS5dy596WP+iz7XjaPVeLcQvQJFRdroRn3/fxa6y5SF4kRF+Ek7xoenm6Rwbs6+6r01cJPVE32JxC6qPkP3qu+zGuTQ6eYsZqGaCOX1Pp6coRsaxvH2kM29NoZ0YXiPcE0lZyk35ASldSTd49J3gd0n3laSpv4BdA6Cdr+gRByrVM7Nq06/IC1pEVDzWtG6oAVZH3YlVywOvmntrJTpsuAsqxZnHoaan6OgWxqe976oBdMCKlaNRfDpsZn1BNjUl71eW8+D3g4TgD7NQxJSA+RsfYW4qo87QCl8rhbQOlvY4rQr+osn6KVk/TIls3OVa31FOMOzilPQJj4imbIxW5BP1yoXTM/Z7dH5VyCZKspVzWJFrVxAY0C5rEN6BB3oBsf2hMY/x9eJX8+rgYLb+3zE8B2XUG1yW7KRWE7mT3z5uSXXuDwHq+QJhK2ySuq19daEW0Mf6fhogaAWQchCNCAFNuL6ei3vMKxK1b6RFDUyJSEE3pZpo6z9Pi1TY6ViCfq5DwgzXlMUi0ljxOQDanmWmkEpcYwgsRugzwb30JG7rrr5WJPQWX/clgTCyAn64Q07r48ZsZXCvo4IiPgQ0uhlVQ95BMOEYPySTWHZLfTKeorqz5ZiWnMcbigbkKGq+RPTfXyJ60VroC3F81DNIj8MyC27I691DCD0HnuVSHnfYCM8+M0LaktIjX7NVUhhmWK0I4nh/XGAuuDPKy0SwM5hWM4YW5RNfcrtw9mhRcwe49mZ2GKSuheDlsmMxNoYpz3OdYdvda6QseuTeSDhomU7qZps7ztAxvGx1rmM5ADT2MsT1BurTjQutTxmnmenqPsPMm7igZ7FHUPn5Ga8yZMFCnaApGyiyLEE1hLzCl3vMKDFC30ieaYvAqWxezunQzTZ3niTFrGh0rmks9icO93nfBMF0ovxFDimfD0hokVVta1yeW08z1JuZv0Te3x17M3ifizULC3YMfoQd8zI/XA/Pg1k49IHMgZcTccQJDMGCi6yIi1zc6vK7o14NbqFWyzM/wdq/g7ptpsWu6DC91Vt6GHUlIpWmoXQOBNZpp6jzbAai/o0eje3Dthmp7rHY7BRHeG1ZkQV67MbejwW6mzKr8tk07VmK08p5+2QrOY16Bgn6uVbTWzqiR9xIOzxzLcCjFTTkOJTmU5XrWsFzP+aom/t1c0jXxX5dL/Ga6uaQusxKXsO3YG+Oxgb83xglvXZu8EyD6HeXDDO+cCZCxK9ixLhn9ZqYJdjD9Oo6QJt6I656zmO0zMZzYNCumaiuDuonNWBbbeL/qUoor43i8azmxS8mSVL1P6DzRLzfj6IdT+Mn09mzIEMnb9w5D2806QpagvQrCU9znRXPLWuvo3V5taGu2N1qnRUEE66z39+rlESVTbyX7odpYbXOuqpyMgiXRObpSK8Op0y96fvEx261TUBWlqOJQj0G36GXpfedFP/qv0kUP1Lp1/J5sHJvInYmT3byXCiAGr7dV2vQkm/ecxvp3MilBCQsttpMVZTuDuomNCG3V+JCDu4XbsqOEN2Yn6RJ+ngFHPoLPM/g5hecU2FKz7PseE5kKCVIiwvy52/Y7gWszatuvBKSkaQ9lSknKrD79bNPTUKZubBxlQJ8i9F4GLezUxII+LWVMnz1+iwHCAXwLt/3G7+ttrzqNWKcpSJaWa+wXdjYGJ4t6329ghuZtEo7fGJyllFAhmuGxygCmK02ZsJrI/LRn7pTFnpR5TZeDZm7L4zgB6+NTzwxkN88e5JoxxmiV3QLWBnXTx2hxT6WvSx+/mW76VKZkeyfQZggxLNayRbpqyLJWFm4DIm0bX8Ee3ewuCL1xQFsb963MTSszbuabcUYy2X8NVIYBZuneXWRzruoc1PXSfVNjK6OuEzPztcXHzHwzQUlRv62RmfdZqgnvXfxjD3+oWe4R5J0k+3oS/PZX+D4KFYhr7TRrW2gYI++6fCY0Ax5110T3/Hdory7Z+umvxlDk7FcXdpK5dWY3snO02ODM153xniHr3ks+VxGZI+BblaHemdK3yc/6ICH+DM2AJ+DPuilJd9PfbtcjSJbA9HcKslRNyd3cV2uHbmUx4lKUOLVnmh6hNGKmxV+r06s4Q1WnV3GyCnYuVc7Je3XprJrEQp4O0y/Ulq478El1qWf6tc+9F9Nqo4c31NUXLPk6m23jDsCA8vTHaaC/0Qnc5HOe7iFt0ZxnDuwSPzeYbEdxc17wyp0X7I2eFrRlOxegpVo7sqzPmZIyjw8ezDfiVI8jMuCkKzSStH7ciMEwTUfpKp9ufbpKz5AUxp3HWLH2GumNNK3GK9vi9nnnco6GFW43XboU7np08RqZRtvqm9e6eb6YXNXq3oZdvQi2asju/IJLf+oNyOD1+6DDegMyJcYupRuQMTlXTg64+jrHVmplVHWiAjKm+KiADPInrffD4S6nfRuVwdf+Nm7juGu++xDmvScxgRgYm2BOMHcXiIlgz10gpqXfNxWICfHnLhDjknOMRV4rEBMkyy4QQ30ztgvEzC4Qw2lJsrIKI/o6m/10AjGNcRrotzoQExjSLhCzErv8hAMxPGXgOLeuU9kFYmYeiGnQrU9XrTfh9xrZBWIGFW43XXaBmBYxdoEYMxQOKl/w/jMhHN9+xN0zITbnqs7hGAN0joC0M+o6MYEYW3xMIIbzVJ0VNYN6ikYRD8yrM2iDJz4Qckm79m1LfGWlcw2/SecpocLMktzn1WZMtjFG8nyNSIs+K5W3M6hN5IXYEP+ZnnrEqu6+fwal0Gh8LcBIyaaaJTk6wPQxDC0UZOXQq+E3h2W6CoY1jzgQR8yLTGk3fRPIxz5XMYbeBPRj8HHvVcGPRknwQjPnbF+gUOm+PvJUB2X1/rmDOiRbqYpG7RS0W337UaCLDJBXXxXxXIV7v6vjv8REiA9MHHg/0EoBf9KBrjgnPC1toVd+y91VBAWFIwfaxbeoyCpO375F8q46a2eO07mddZzgB5ojI4T1K7gVeVl48ShMT6NfbWOr6lfaNOVpO6N2rfj0omI76fNWbM/boFU1sFFKdR7ojdapt4ffyQJ7n4JWwssbwFWC/2egST5XZ39UOA9fHwAP50mqjkKrMJ49P5QqbfkZpPD40GVCq2+oOSR9EKOsQ5fueMq6vkziSMckuMnY07dL7Dm/kKEvl6hup8BE4JoJX6sHYPG1+nqwBODwVX4ADl/lB24O9JV8oCVfye8pyh2ot4/plwsr4i+00legfwApeFaK/1qvRvysHRvqnqhmcttNQJpmt2ACsFeytglozBaMNtm869eYKuysxPIWrES8GfgQZf5LpbjPlQJ39P295Lf65uwv1XXFVs2/hEz8UpWiiXrBzNd+TbANAfXuHR69g+Xv4dpSvXx0smokW+tzfJtly7YEZxhpSVhtZRhot9fo1eLWDff6iKfJY6XfD5SXvVB+cJp8AlbztOohdOOxINmggeGMiNrA7NlzuMQ1HIuQ4XmhPsvqq4CF4bl7dihkFzihtYU5Ut2emlPDf9AUvgRmAGq9VEsOSKj60DBJBg8NS0pSHv36yGZlfHd2ZbXe6IXHr9Xi48sxax/6rSt+q8qmEaBsad6td929+iHVyg1InWwRN7T4IVhOpOhalg+EmQoA0No993k1G1g3lq1kA+cS4IgOISkUGTULz2ITatb0MQwtFMzLrQohORCHDJnjFhlENNO3gPz4ENJH+nU1eneT2po3GLoIy2zAb51GZuvGVpTZcqvCE8UsJFYDGyWw5Ywczwh5vT38RoUnYmRWu16PzQunTrR3hr4YXjdyDrbfhjE7PDCQYYwheO0t9FaJsGNYABBZ5lfi2hW8j/t1EYzXxgcU4O6IysXtgADfKp2zRmvNuXSMh9wx2W6U7/Z8m4U8f/e5brR1i+eLWGczGFYZ4fV+mnylPK8/6mFeJE+Sh9CJDkc9VK73vrqLAOcVZ/D7Mfil+tWWAn4PVPj7WatsIMQumJq1mb6/girPNGtlZivNp6r/zwO1c8IHfWmZEblZX7okxWhfOpeETu9L+63G+tIaogItboQvbSJKO8ucbtAyz9LT2xlttlH8Tma0NxFIGbFqsJlAyoglgw0o/+4Fg0jl7y8kTKX8/VZXU/7dqxbBSEoJNoB23TQxyw07c5nnR0dSbi9g3QFtzIqAY670G+Xd12bcEPZ1t0MGIGK5YNYrNvFG4Ay0/AtULSf6hqoDo+8v1AzjpOc4QRV8CYr5LBcN2Xa5ePkshDx+1c+V8Zluy4kW8dvD/WQ+Xn9gJuzNgQJmXRGRobAMg4GUk4VlBOFF2R+WSRa9URe9ADTCK1VRly7H9FWybthlhGt6s2EXP+Szathlt4Q56RKmEerIJUwbdtnZ5GJzNpl6bt5M9miPM9cNL/YGTXbDj2U7s70LzQTt3wYMRHdoZvDKYlmAYcki3jPJONI9xwlnfdZ6kNNoif80szHoibn37JiMFrs1rZmFXvrACzC6KXAA0jir7FDrgIEQORFFo9QCfI4WpYRMoWSzwbfXPk7g//8DKmT11A0KZW5kc3RyZWFtDWVuZG9iag0zIDAgb2JqDTw8L0JsZWVkQm94WzAgMCA1OTQuNzIgNzkyXS9Db250ZW50cyA0IDAgUi9Dcm9wQm94WzAgMCA1OTQuNzIgNzkyXS9NZWRpYUJveFswIDAgNTk0LjcyIDc5Ml0vUGFyZW50IDYgMCBSL1Jlc291cmNlcyAxMyAwIFIvUm90YXRlIDAvVHJpbUJveFswIDAgNTk0LjcyIDc5Ml0vVHlwZS9QYWdlPj4NZW5kb2JqDTQgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCA0NjUzPj5zdHJlYW0NCnhe7V3rk9zEEdftne2quzpszGHwA7Px4wyGm5sZjV4Q+GBCnEoVpAiuyoccH4Dg4sPiqhykqPz36Z4ZaR5arUa70p3WEeZ2Na15trp7ft0zq/n34T6bU/h3gl9Zwec//nK4X1HZnAkiqP70bhGG30g8/dNPL7//z+K35+ff/3f+46+H+3T+64+vDvefvYB7f2bzdP7ipdUQFkwIi+P5Cyj8zw+iNDp7Fe1FNLqGFw8iHp3C59kH0cNoFu3CnVl09kN0FS4fQJYYE3tw7xRKzODqNHqMmbMqM+ajUAsQKVxiZYnM69SSRZ9/+N38xV8P97+Efn7jjE0knORx2tP4bmFPoO0ZdHSmRnsV+l8Sb0Qz3ZHTP8d+ZSImWe5WtwMVvhO9C3+3ozvR3eheVbrWlSwljAm3eNmYyZRBE9zNdDN6KzqK3oaW3pZt3fYL4SAZJ7EpciQ78zZ06l70HhR/F67v1wvCgBjNvbK1PglBsiz1cjV1qv78ZO8qod30+e1ImboKUrOHT+zsNyWvs+ggOnuJH+fRGyhdL6Pr8DAhBVez6E382sGPs5etgtZfZ+9Dzz6XvQO5iv4A3YYuPwBxg7+V/OKMpKoLy7to7m/axZugfadaU/HzIaRRYyl8P5RcVp0/iB4ppY2R4ajAO8Dh4+j66nHkJF85jur+puM4kuOQJusamJOnsuMonverAUBnpQScRwQ6fwB/+P0IqPg3i97X+e+16xdK/d2KZ6fSYJ5G86UFMxInjbolmUQJy4WfxTDUYc0X3yJrvv3ia8j8HdTxr8N9Qgv4L5//jneSglCoDOpK0oTAJKIJi8P9b2WF7oNQsp4um1Ni6Hc+PyFMsPIWnROex1g5S3MwVEKlFyZdkFwRqH1Z5vrH4f6rJY+aqUet85mqQMTPfzrcf+l3GvvE51XHkAhfqqfqU/eo4GmdQO2ErAnSZY0y8fPSni7jPPb397JpQilNSubIyiWh4rzNdj1GRgnliRzFiTX5U3tc1B4CPMw0WzEm+Uz0MOj6A6L2YFSbzYNRj8MaihyFuktXPSFVokqjwAg1lIJk1vPo9+GoVr3hrDY/8Tx3zU9MOMvmGWE8K/X2IViTAg3QLlqYXbwCa/kemIb7am6CqeoKmFvr5nV1u9GCsozLUTfpYJGBahsVVMk+NLCsqUkBaU35bCFVpf00ta57llBdabO2qQxdlW0c4+hDMo9A1KTs/YCYCGWvUeZiUHfOV8hcSoq4sIROpXuRurKqtcXOdLx6Rqx8YLrfvT8xbLNN9JjdcVaK3bbYxiXDCVElf0S6aNPzqfg0wLDKyvvWrDsA/o6VSl0FS35DObXSJ2lWMAmr8CE2wKpUxA6swjRMBDTRSmVfd1OwsjIG/tzGyCqrEywUkgz0JHVLbcgqaVc4yUatUsCRgvWlU5Z90G209xYn+qJFnwbkMu3CYSUjVo+b4J5lnHVuO30RzMc2G5T+78+faZ0nHP5EZ93f0e7fFfjGcIRRfQX3duHrGrrMv2HqpvL998y9vXIqdlxo5HNMSZwCR0lcGgWYZdJEExaGgCKgCLpIjVAVWW0g3OwxTJVUwGiFPQ+XjrjHmbKow5tZ9ATQ8DH41RiAOY/uRR9HH1lxtaXcZWAZReUGH7hMqbLk8IU8gd4JVhIWFYEzmXFRlvDTpsBqjji5wUnmvMaQtaYPVpAEuKUHeVfFrD7xR+uOTk7MOZQr7PFqihlgjQM1HrUIgZO9YPBA86Yxr9Seuozomp2xy4AcukbPoq+iNDqBq0+BE7fg6iT6Inoe/S06WSYDPCZCMSVPSAKqrQmLigASmdvP3E+bAiEyoHPnHExMHqgUumRBmBnv+zBcAYPEP4KjF5qAYSihSBV1p4olNUpSnJA4y1eqC2TJE4asShmYQVYSFhVBQEZFUCX8tCkQwiqdO8lkGKIPdRGMJEViWCgR1q4xojLMe6I8m5oWuYNGLRLQM26zoaSYcdcYU2Pdak642fMUqu9HicqOORzpFg3fcaPflZyIhAjFIZ6QNGclYVERMFxry4WfNgVC5ETn5pyIVHRSqYTJOV2PfklUv1GSQCgFoIxV6gJZ8lxCB1FIXmvCoiKkCRiBxAzbT5sCIWzQuYEbfalLGpOUF83q8haikFd1TXHHqzUlYbE1oJJihlzjSY1rq5ngZi9gOmM9qUrZM4cb5VJQHmXRg+ipXCE4NZpS+IqyfNWomfXgoYt0mXx5iD/jEqs2OYAFWIzCDuqpdD8OYFlZVwewFhXjdYIJs4j+sXzZyKrIRNnyNrh9qrNBXt842Bvs9F0ef4NsRYhn9350GwzCbTmbnoM1uKp8uh2A63eiB/4KXuUpdHBeOKCO1PFeNGUY94ULkohuE62L1R+hDTxWGFWtnQJjCrj8WC6bLgW2x/Kz0LcCAC1AjawF0PJUojJkYSbA3rKSsjCUGKy+A2G9tCkRwkKdm4Eop7wbC2OQfoNVnoBHg0j/azWhPAbX5wg4A34xsPBIboXZAxj3QO6zuQd/78A8FcMshftlHsD9mdxn4+fdW437E4BvWWyBV00YBvcDnkvSTjxy0exzuRVHqlusV/CfSD61xg4AnOQt6E7kEqeg7LBEgf68RC4lBbnj4DkvbUqEsEXnZoyDW9pNdhJBqIEuqFczsD6ZZMlXiPVfAXb5EnctGSBzXPmQmDvVO4DuL+NFksrgobT8MUkQ4CvKwqIUJGWFxQs/XZUI4YXOzQqMFok57v4Q7cxIiYBsKSXcQKtqf1YDQPZxGdSRVvs2ninZ+ovc5PLU2u1VsgfUPE2wxQzGilNNChNWRVgYQk6Y5oYuUiNURVr442QXgoieoi5lxQ4DJKAlYNALNOEHGhUvdwtxJVBxoZQJTbGkxGBRPZF6aVMiREp07rWkBFpOc19Ilq9vxul242/O40vA39gq2Rh/e2tJGsoNvzDgLSRNEH2+zRCdgek+UUhhF2McB2qN5UBj9x2JkWYyOHYQcZgKH0V3+wDuLCc5rsQY4K4pwwB3gCWpyDcA7jtLUXsgZj/oG7NrlGVhdk0ZBrOvgbtczN477ooFyTQv9PypKQuLksGXhTlr6apECC907rVm1BjwqwHVHXEXAhmDYANxF7SYKlyqYZYmLCqCSMEKKm6oIjWCKRKEu3T2/nGXy4AuuAucGeaic02xpCShhDpo3EubEiFSonOvJSXQclpH5037XnKAPkUcvvFF2lE5Lupcd8NdZWWUFHHaBXiNZc9F8K4W5JFGInBJs7z/3qom2vsK+XBjwBbtabF63ISdLCSu+OAlL57zQUYqBFOt3NCCYOtTndp1jVYGVjPJrO0qHCoX1t6TklDtTtEl/HTgZhUn9/LFswaDpUvWtqocAWi8Gd1Tkbnr6+9V8TPBlFUHR3W8RuuRKx9msW6LS41WtsG77cfKlpV1t7LFVi0h8RHYWNXVIBNbjMg7DbCwfAvtaEyyVmuQkmS5p+TBJB2fmlSYD6jC45vGJ+UWA3K3d+Vu8m8YjWE+77CzX25O1LpqX3fTW1NZEr/eDg7ySEsQXKZDSJBqor2vkK9oVdB0TA6O1eMAB0fxwUtePOc30d1wB+fsXP06/CrcvmH/SFNv2T/7EChHcHPXKem6Qkzgj9cKyxdyCAtDMDv1mwieN/SNHZCGx6jqFzBfZxVhYQh5WVqX8NNVgdX2xcktYtJxeZ/h9teK/zVH67jd0eIcprQ2aLU8Cu1nAhPZ6mjFjIgujlazuW+Aaf2Ye1NZ8lrDtHgExl51NcjWFyMCYwGmPt5Cgz6ApzXpMBlSh8cHKCbtFgNyt3ftbnS14hiaL8JdrX5CJNNaUo+9bQ2FTGtJjGzhWtId9Vsa5VzB//Knzlf0757Vu0hm8pUJ1/3VpLwgIostDypOCLcXh0pC5TDpEn46cDXJyd1pNUmXbFtNetTu5Ix8NanZ0E6x6HZssRVmdoo4H/bM3U1M6RBOzqTDfEAdHt9UPmm3GJC7vWt3o5OTJISKLNzJ6Sc4Ma0n9djb1iDEtJ5Eyeu2nnQczfQLnvDtAjfg9jX5GmJ8W8dj+HcDcniuj9wnV9tJ5/g+mmAWi5oIr/fq0Y7aRN3qWI199ajRuE+R53Y8sxWmfYovH/bM3U3M9xCO1aTDfEAdHh98mLRbDMjd3rW70bHKE/nDzWDHqp+AyLR61GNvWwMf0+oRI1u4euS8sN64VH+MynMUAP3jPj30pPzlI05yymwXKpc/n7VcKEUwy0WqhJ8OXT6yc3dbPlIl25aPinYvZ+zLR42Wdgo9t4OLrbCzU4D5sGfubmJLh/ByJh3mA+rw+ObySbvFgNztXbubvBxOkVfT+xa6ovDJy/l5UP4Ga+j4LOMmuhvi5eyqr5vyzUK7et+c5+SkoNzOHjlOWOzskVME49SoEn461Mmxc3dzclTJNieHbL2T02xoJ4DUji22wsxOMOiwZ+5uYkoHcHImHSZD6vD4pvJJu8WA3O1duxudHJ6TmLLJyXElKP1/dXIsQ6MOr7YP8b0g3qtme9Be1fOLtpyqgeH023EIbkVvwb9d8HP8NzLgAs9VdWoxHoDgv3iOyqdn3CCA//KQvMoN0oTK7dEl/HSgG+Tk7uQG6ZIr3CB8Oej17feCGi3xhKDawcdW2OFwnGSbYc2CGuGSGR9shS+L85vY2CE8pEm/+YD67XpIKJODT/SuAGKTpA/d91DLBeq/h1zYZAOa/Kia1nmvNUd0YNcIGpyA+pvX43vvcK+MhXLKUkrypOGHS4icbKcM0wXJFYHal90MRVVVSruYCV9apY+Q1gnUTpBBxLWsvMUREvirCspbDiapOULZijHJZ6KHQdcfkG0YdZttumcNJdAL0iWqNAqMPtAEz/XhAz0c1ao3nHA/Z0f+AEj6OFfkD4bKA+D3VgJraZ4atUnaN2velck+dKmsqUmVaE2NaoCvlqbWdc+ypitdMXnJDF3VZhzjqKMxzlcKBUyoceGgMUz3IhZlVWvLBec1IMDm1O5n/yzlLU6N6oTV8eUAbcRmaMlwQmR9KVBjjc+n4tMAwyorX9e83pEr5tKm4ptlbix/S6enSgqrYHwm7vAmqRRPutTqY193UyVTGcs2hitZnTBAjHMpXOklxizZqJUHruMhDiXTbbT3FjImrae+Dcdl2oXDSkasHjdhKMsM69x2+iKYj22urd4MVXmmf3J9rXy11MsSRJWR09XOktdA8+FvdRiGI2o2FA3xj34MhamMbXJsJB1hBC40NJKOwjyozgZZh3GwN9g4XB5/NwlvLDm2fbCjH6cz25e9YKHL+Y+cQwed8x9LyiDnP3L4jjc6/3GoM9uBsv5R5+6pjEtZbo5RrA7YrA5FrA4/N+cmyjJ+OvgYRTv3Okduuuck9nHkZiPr3KMKS9Y1xUGbD2dPSd75SPGEyfPBf6lOstSEhSHkJFGEskiNUBVpeSZO9v6PtnQZ0HK0ZePTSGOMdLRir2rtaaux12t0ZLeexod3Hjxnc4Jn822GZ9OR3WG4bQxHdieElcdU66V3RbGsqzmGWiMAL21KhHBP5y5PN/aiyx0g26D4YTn06owfpqOxuxyN3RHN+Zli7Hw7yJBx4Bj8DlZ02EjcD8RYNw48lgjk6xvjtUHcuHcSB2CIUcO4cBzh/GyyXEH3bfEm4d8me75y1n6ikM0noT1ZYhw5JQxY4tZ7oF8Zeg1nsh901BuntgP1YlEwlm9EM/UryhvadM6iN5VRDTKjzXjA0xsdA282kqP0w0aC9EN9rXQUJjLckfLc3DEuMQQbyMvjfRCaCjGOypd6BMbxivSn5A8p7kW3ojmYg1uAcj/rw6WaQuGd7Kjxq6pQODg7cm+GCWyXlEFC4UxkJKfdvNKmUDi66o/BY/pIek5fgtuipuBYRrdVvPsUrk7BB3sqnRo9Y+1Gn6EXlsjYuI6EtzG1W7A7yYkwlIWhDBPsThLU0i48dR2fHTm7l74qrg9Q+OaSnx9AOpNcpPreDK5i4NmpXFdY04OdIuD9eLCNEXAJuj7Gs23bHkXH8PcEu/iAsIs6ftBI9sash8g8N+8CUZnn6LEJmTmbvz9S27/P4UuBswGQ2fYHu6VXO5ui3UGo7BIQxBQD7wdBNMbAwxHExgFwb44R2PUMA45F9aOCVkNKC/xP2VJGockUn0+SJqTgJaFmTX0xKVmVusNMEkE4GD+0GbFBW+f+SJMkI/hKdyfbDLyUWS0nTjZ5Y42GL/8DHYkxQQ0KZW5kc3RyZWFtDWVuZG9iag01IDAgb2JqDTw8L051bXNbMDw8L1MvRD4+Mjw8L1MvRC9TdCAzPj5dPj4NZW5kb2JqDTYgMCBvYmoNPDwvQ291bnQgMy9LaWRzWzEyIDAgUiAxIDAgUiAzIDAgUl0vVHlwZS9QYWdlcz4+DWVuZG9iag03IDAgb2JqDTw8L0xlbmd0aCAzNzQ3L1N1YnR5cGUvWE1ML1R5cGUvTWV0YWRhdGE+PnN0cmVhbQ0KPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgOS4xLWMwMDEgNzkuNjc1ZDBmNywgMjAyMy8wNi8xMS0xOToyMToxNiAgICAgICAgIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIgogICAgICAgICAgICB4bWxuczpwZGZhaWQ9Imh0dHA6Ly93d3cuYWlpbS5vcmcvcGRmYS9ucy9pZC8iCiAgICAgICAgICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIKICAgICAgICAgICAgeG1sbnM6cGRmPSJodHRwOi8vbnMuYWRvYmUuY29tL3BkZi8xLjMvIgogICAgICAgICAgICB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyI+CiAgICAgICAgIDxkYzpmb3JtYXQ+YXBwbGljYXRpb24vcGRmPC9kYzpmb3JtYXQ+CiAgICAgICAgIDxkYzp0aXRsZT4KICAgICAgICAgICAgPHJkZjpBbHQ+CiAgICAgICAgICAgICAgIDxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCI+dGl0bGU8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6QWx0PgogICAgICAgICA8L2RjOnRpdGxlPgogICAgICAgICA8ZGM6Y3JlYXRvcj4KICAgICAgICAgICAgPHJkZjpTZXE+CiAgICAgICAgICAgICAgIDxyZGY6bGk+YXV0aG9yPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOlNlcT4KICAgICAgICAgPC9kYzpjcmVhdG9yPgogICAgICAgICA8ZGM6ZGVzY3JpcHRpb24+CiAgICAgICAgICAgIDxyZGY6QWx0PgogICAgICAgICAgICAgICA8cmRmOmxpIHhtbDpsYW5nPSJ4LWRlZmF1bHQiPnN1YmplY3Q8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6QWx0PgogICAgICAgICA8L2RjOmRlc2NyaXB0aW9uPgogICAgICAgICA8cGRmYWlkOnBhcnQ+MTwvcGRmYWlkOnBhcnQ+CiAgICAgICAgIDxwZGZhaWQ6Y29uZm9ybWFuY2U+QjwvcGRmYWlkOmNvbmZvcm1hbmNlPgogICAgICAgICA8eG1wOkNyZWF0b3JUb29sPkFwYWNoZSBGT1AgVmVyc2lvbiAyLjg8L3htcDpDcmVhdG9yVG9vbD4KICAgICAgICAgPHhtcDpDcmVhdGVEYXRlPjIwMjQtMTEtMTlUMTA6NDQ6MDNaPC94bXA6Q3JlYXRlRGF0ZT4KICAgICAgICAgPHhtcDpNb2RpZnlEYXRlPjIwMjQtMTEtMTlUMTE6NDQ6MTMrMDE6MDA8L3htcDpNb2RpZnlEYXRlPgogICAgICAgICA8eG1wOk1ldGFkYXRhRGF0ZT4yMDI0LTExLTE5VDExOjQ0OjEzKzAxOjAwPC94bXA6TWV0YWRhdGFEYXRlPgogICAgICAgICA8cGRmOlByb2R1Y2VyPkFwYWNoZSBGT1AgVmVyc2lvbiAyLjg8L3BkZjpQcm9kdWNlcj4KICAgICAgICAgPHhtcE1NOkRvY3VtZW50SUQ+dXVpZDo2ZDM5Nzc4NC04MDI0LTRiMDMtODhhMi1lNDZkNTk2N2U3MWE8L3htcE1NOkRvY3VtZW50SUQ+CiAgICAgICAgIDx4bXBNTTpJbnN0YW5jZUlEPnV1aWQ6MDJkYWNjODMtNjcxNC00MmRiLWFhZGUtMDA4Y2FlYzk3OGI4PC94bXBNTTpJbnN0YW5jZUlEPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgIAo8P3hwYWNrZXQgZW5kPSJ3Ij8+DQplbmRzdHJlYW0NZW5kb2JqDTggMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAyNTk0L04gMz4+c3RyZWFtDQp4Xp2WZ1RT2RbHz703vVCSEIqU0GuoAgGk9yZFiiAKIQkQSoghAXtBRAVGFBVpiiCDAg44OgIyVkSxMCCo2J0gg4g6Do5iQ+Ulstbom9fmzf/Dvb+1z97nnl3OWhcAUkAIX5ANKwGQJRCLIv29GAvj4hnYfgADPMAAGwDYnBxh6AK/KCBToK83I0fmBP5Jr4cBJH9fYwaEMxjg/5MyRygSAwCFy9iOy8vhyLhAxpl5YqHcPiljWnKGnGGUnEWyA8pYTc6ps2zx2WeWPeTMzRJwZSw/s5CbxZVzj4w350p4MkZCZFyYy+flyfi6jA0yJVl8Gb+Vx2bx2DkAoEhyu5jHSZOxtYxJoqhIbxnPAwBHSv2Kk79iMW+ZWJ6Ud7ZwuYifmiZmmHBMGTZOTixGAC8vkycWM8PZnAy2iMvwzs4SsgXLAZjN+bMo8toyZEV2sHFycGDaWtp8qdN/X/yLkvd2ll5GfO4ZRO/7Yvt3ftn1ALCmZLXZ9sWWXAlAx0YA1O58sRnsA0BR1rf2ga/yocvnJU0sFjpbWeXl5VnyeRxLeUH/0P90+Av66nuW8u3+KA/Dh5fClmSKGfK6cbIzsyUiRo6QzeExmH8e4r8d+JW+OodFJC+FJ+IJZBExsinjC1Jl7RZw+WJ+toDBF/ynJv7NsD9pdq5lojZ8ArRES6A0QAPIr30ARSUCJGGvbAX6o28h+Bggv3mxOuOzc/9Z0L/uCpfKHzn81M9x3pFRDI5ElDu7Jr+WAA0IQBHQgDrQBvrABDCBLXAELsAD+IIgEAaiQBxYAjggDWQBEcgDq8B6UAiKwTawC1SBWtAAmkArOAI6wAlwFlwAV8BVcAPcBVIwBp6CSfAaTEMQhIXIEBVSh3QgQ8gcsoVYkBvkC4VAkVAclASlQgJIAq2CNkDFUBlUBdVBTdD30HHoLHQJGoRuQyPQBPQ79B5GYBJMg7VgI9gKZsGecDAcBS+GU+Gl8Aq4AN4KV8D18CG4HT4LX4FvwFL4KTyFAISI0BFdhImwEG8kDIlHUhARsgYpQsqReqQV6UJ6kWuIFHmGvENhUFQUA8VEuaACUNEoDmopag2qBFWFOohqR/WgrqFGUJOoT2gyWhNtjnZGB6IXolPReehCdDm6EX0MfR59Az2Gfo3BYOgYY4wjJgATh0nHrMSUYPZg2jBnMIOYUcwUFotVx5pjXbFhWDZWjC3EVmIPYU9jh7Bj2Lc4Ik4HZ4vzw8XjBLh8XDmuGXcKN4Qbx03jlfCGeGd8GJ6LX44vxTfgu/AD+DH8NEGZYExwJUQR0gnrCRWEVsJ5wj3CSyKRqEd0IkYQ+cR1xAriYeJF4gjxHYlCMiN5kxJIEtJW0gHSGdJt0ksymWxE9iDHk8XkreQm8jnyA/JbBaqCpUKgAldhrUK1QrvCkMJzRbyioaKn4hLFFYrlikcVBxSfKeGVjJS8ldhKa5SqlY4r3VSaUqYq2yiHKWcplyg3K19SfkzBUowovhQupYCyn3KOMkpFqPpUbyqHuoHaQD1PHaNhaMa0QFo6rZj2Ha2fNqlCUZmrEqOyTKVa5aSKlI7QjeiB9Ex6Kf0IfZj+XlVL1VOVp7pFtVV1SPWN2hw1DzWeWpFam9oNtffqDHVf9Qz17eod6vc1UBpmGhEaeRp7Nc5rPJtDm+MyhzOnaM6ROXc0YU0zzUjNlZr7Nfs0p7S0tfy1hFqVWue0nmnTtT2007V3ap/SntCh6rjp8HV26pzWecJQYXgyMhkVjB7GpK6mboCuRLdOt193Ws9YL1ovX69N774+QZ+ln6K/U79bf9JAxyDUYJVBi8EdQ7whyzDNcLdhr+EbI2OjWKNNRh1Gj43VjAONVxi3GN8zIZu4myw1qTe5booxZZlmmO4xvWoGm9mbpZlVmw2Yw+YO5nzzPeaDFmgLJwuBRb3FTSaJ6cnMZbYwRyzpliGW+ZYdls+tDKzirbZb9Vp9sra3zrRusL5rQ7EJssm36bL53dbMlmNbbXvdjmznZ7fWrtPuxVzzuby5e+fesqfah9pvsu+2/+jg6CByaHWYcDRwTHKscbzJorHCWSWsi05oJy+ntU4nnN45OziLnY84/+bCdMlwaXZ5PM94Hm9ew7xRVz1Xtmudq9SN4Zbkts9N6q7rznavd3/ooe/B9Wj0GPc09Uz3POT53MvaS+R1zOuNt7P3au8zPoiPv0+RT78vxTfat8r3gZ+eX6pfi9+kv73/Sv8zAeiA4IDtATcDtQI5gU2Bk0GOQauDeoJJwQuCq4IfhpiFiEK6QuHQoNAdoffmG84XzO8IA2GBYTvC7ocbhy8N/zECExEeUR3xKNImclVk7wLqgsQFzQteR3lFlUbdjTaJlkR3xyjGJMQ0xbyJ9Ykti5UutFq4euGVOI04flxnPDY+Jr4xfmqR76Jdi8YS7BMKE4YXGy9etvjSEo0lmUtOJiomshOPJqGTYpOakz6ww9j17KnkwOSa5EmON2c35ynXg7uTO8Fz5ZXxxlNcU8pSHqe6pu5InUhzTytPe8b35lfxX6QHpNemv8kIyziQMZMZm9mWhctKyjouoAgyBD3Z2tnLsgeF5sJCoXSp89JdSydFwaLGHChncU6nmCb7meqTmEg2SkZy3XKrc9/mxeQdXaa8TLCsb7nZ8i3Lx1f4rfh2JWolZ2X3Kt1V61eNrPZcXbcGWpO8pnut/tqCtWPr/NcdXE9Yn7H+p3zr/LL8VxtiN3QVaBWsKxjd6L+xpVChUFR4c5PLptrNqM38zf1b7LZUbvlUxC26XGxdXF78oYRTcvkbm28qvpnZmrK1v9ShdO82zDbBtuHt7tsPlimXrSgb3RG6o30nY2fRzle7EnddKp9bXrubsFuyW1oRUtFZaVC5rfJDVVrVjWqv6rYazZotNW/2cPcM7fXY21qrVVtc+34ff9+tOv+69nqj+vL9mP25+x81xDT0fsv6tqlRo7G48eMBwQHpwciDPU2OTU3Nms2lLXCLpGXiUMKhq9/5fNfZymyta6O3FR8GhyWHn3yf9P3wkeAj3UdZR1t/MPyh5hj1WFE71L68fbIjrUPaGdc5eDzoeHeXS9exHy1/PHBC90T1SZWTpacIpwpOzZxecXrqjPDMs7OpZ0e7E7vvnlt47npPRE//+eDzFy/4XTjX69l7+qLrxROXnC8dv8y63HHF4Up7n33fsZ/sfzrW79DfPuA40HnV6WrX4LzBU0PuQ2ev+Vy7cD3w+pUb828MDkcP37qZcFN6i3vr8e3M2y/u5N6ZvrvuHvpe0X2l++UPNB/U/2z6c5vUQXpyxGek7+GCh3dHOaNPf8n55cNYwSPyo/JxnfGmx7aPT0z4TVx9sujJ2FPh0+lnhb8q/1rz3OT5D795/NY3uXBy7IXoxczvJS/VXx54NfdV91T41IPXWa+n3xS9VX978B3rXe/72Pfj03kfsB8qPpp+7PoU/OneTNbMzD8A94Tz+w0KZW5kc3RyZWFtDWVuZG9iag05IDAgb2JqDTw8L0F1dGhvcihhdXRob3IpL0NyZWF0aW9uRGF0ZShEOjIwMjQxMTE5MTA0NDAzWikvQ3JlYXRvcihBcGFjaGUgRk9QIFZlcnNpb24gMi44KS9Nb2REYXRlKEQ6MjAyNDExMTkxMTQ0MTMrMDEnMDAnKS9Qcm9kdWNlcihBcGFjaGUgRk9QIFZlcnNpb24gMi44KS9TdWJqZWN0KHN1YmplY3QpL1RpdGxlKHRpdGxlKT4+DWVuZG9iag14cmVmDQowIDEwDQowMDAwMDAwMDAwIDY1NTM1IGYNCjAwMDAwNzc4NjAgMDAwMDAgbg0KMDAwMDA3ODA0MiAwMDAwMCBuDQowMDAwMDgzNjk5IDAwMDAwIG4NCjAwMDAwODM4ODEgMDAwMDAgbg0KMDAwMDA4ODYwNCAwMDAwMCBuDQowMDAwMDg4NjU0IDAwMDAwIG4NCjAwMDAwODg3MTggMDAwMDAgbg0KMDAwMDA5MjU0MiAwMDAwMCBuDQowMDAwMDk1MjEwIDAwMDAwIG4NCnRyYWlsZXINCjw8L1NpemUgMTAvSURbPDQ0NDI1OTVBNDM0MjMzNTQzOTM1NEQzMDM2NTgzNDVBPjxFRERBNENGNEVBNkEyMTRDQjEyNjVDMTdBM0E0M0ZEQj5dPj4NCnN0YXJ0eHJlZg0KMTE2DQolJUVPRg0K
                  </value>
                </observationMedia>
              </component>
            </organizer>
          </entry>
        </section>
      </component>
      
    </structuredBody>
  </component>
</ClinicalDocument>
```

