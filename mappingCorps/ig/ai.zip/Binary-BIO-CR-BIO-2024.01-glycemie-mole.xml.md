# null - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* ****

## : null - XML Representation

[Raw xml](Binary-BIO-CR-BIO-2024.01-glycemie-mole.xml) | [Download](Binary-BIO-CR-BIO-2024.01-glycemie-mole.xml)

