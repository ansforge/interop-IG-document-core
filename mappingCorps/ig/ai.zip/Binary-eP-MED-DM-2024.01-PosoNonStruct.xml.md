# eP-MED-DM_2024.01_PosoNonStruct - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **eP-MED-DM_2024.01_PosoNonStruct**

## : eP-MED-DM_2024.01_PosoNonStruct - XML Representation

[Raw xml](Binary-eP-MED-DM-2024.01-PosoNonStruct.xml) | [Download](Binary-eP-MED-DM-2024.01-PosoNonStruct.xml)

