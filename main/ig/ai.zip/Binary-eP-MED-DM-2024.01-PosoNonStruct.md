# eP-MED-DM_2024.01_PosoNonStruct - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **eP-MED-DM_2024.01_PosoNonStruct**

## Example Binary: eP-MED-DM_2024.01_PosoNonStruct

```

<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="../FeuilleDeStyle/CDA-FO.xsl"?>
<?oxygen SCHSchema="../schematrons/profils/IHE.sch"?>
<?oxygen SCHSchema="../schematrons/profils/structurationMinimale/ASIP-STRUCT-MIN-StrucMin.sch"?>
<?oxygen SCHSchema="../schematrons/profils/CI-SIS_ModelesDeContenusCDA.sch"?>
<?oxygen SCHSchema="../schematrons/profils/CI-SIS_Modeles_ANS.sch"?>
<?oxygen SCHSchema="../schematrons/profils/terminologies/schematron/terminologie.sch"?>
<?oxygen SCHSchema="../schematrons/CI-SIS_EP-MED-DM_2024.01.sch"?>
<!-- 
    **********************************************************************************************************
    Document : ePrescription de médicaments et/ou de dispositifs médicaux (eP-MED-DM_2024.01)
    Auteur : ANS
    **********************************************************************************************************
    format HL7 - CDA Release 2 - selon schéma XML (CDA.xsd) du standard ANSI/HL7 CDA, R2-2005 4/21/2005
    **********************************************************************************************************
    Notes:
    - 02/12/2022 : Création exemple avec posologie non structurée
    - 15/09/2023 : Nouvelle version 2023.01 : Ajout de la Section FR-Document-PDF-copie [0..1]
    - 17/10/2023 : Modification du code de la Section FR-Document-PDF-copie
    - 19/11/2024 : Nouvelle version 2024.01
    - 20/08/2025 : Suppresssion des attributs author@typeCode, author@contextControlCode, assignedAuthor@classCode, serviceEvent@lassCode
                   Maj des codeSystemName en fonction de la nouvelle règle de nommage
                   Maj des références parties narratives / entrées
    **********************************************************************************************************
-->
<ClinicalDocument xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="urn:hl7-org:v3 ../infrastructure/cda/CDA_extended.xsd"
  xmlns="urn:hl7-org:v3" xmlns:pharm="urn:ihe:pharm:medication">
  <!-- 
    ********************************************************
    *              En-tête du document                     *
    ********************************************************
    -->
  <!-- Périmètre d'utilisation -->
  <realmCode code="FR"/>
  <!-- Référence au standard CDA R2 -->
  <typeId root="2.16.840.1.113883.1.3" extension="POCD_HD000040"/>
  <!-- Conformité spécifications HL7 France -->
  <templateId root="2.16.840.1.113883.2.8.2.1"/>
  <!-- Conformité spécifications au CI-SIS -->
  <templateId root="1.2.250.1.213.1.1.1.1"/>
  <!-- Conformité au Volet IHE Pharm suppl. PRE -->
  <templateId root="1.3.6.1.4.1.19376.1.9.1.1.1"/>
  <!-- Conformité au volet IHE PCC -->
  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.1.1"/>
  <!-- Conformité au modèle de document eP-MED-DM_2024.01 -->
  <templateId root="1.2.250.1.213.1.1.1.39" extension="2024.01"/>  
  <!-- Identifiant du document CDA -->
  <id root="1.2.250.1.213.1.1.1.39.2024.1.1"/>
  <!-- Type de document -->
  <code code="57833-6" displayName="Prescription de produits de santé" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
  <!-- Titre du document -->
  <title>Prescription de médicaments et/ou de dispositifs médicaux </title>
  <!-- Date de création du document = Date de rédaction de la prescription -->
  <effectiveTime value="20231201093000+0100"/>
  <!-- Niveau de confidentialité du document -->
  <confidentialityCode code="N" displayName="Normal" codeSystem="2.16.840.1.113883.5.25"/>
  <!-- Langue du document -->
  <languageCode code="fr-FR"/>
  <!-- Identifiant commun à toutes les versions successives du document -->
  <setId root="1.2.250.1.213.1.1.1.39.2024.1"/>
  <!-- Numéro de la version du présent document (entier positif) -->
  <versionNumber value="1"/>

  <!-- Patient -->
  <recordTarget>
    <patientRole>
      <!-- INS-NIR de test : 1.2.250.1.213.1.4.10 -->
      <id extension="279035121518989" root="1.2.250.1.213.1.4.10"/>
      <!-- IPP du patient dans l'établissement avec root = l'OID de l'ES -->
      <id extension="1234567890121" root="1.2.3.4.567.8.9.10"/>
      <!-- Adresse du patient -->
      <addr>
        <houseNumber>28</houseNumber>
        <streetName>Avenue de Breteuil</streetName>
        <unitID>Escalier A</unitID>
        <postalCode>75007</postalCode>
        <city>PARIS</city>
        <country>FRANCE</country>
      </addr>
      <!-- Coordonnées télécom du patient -->
      <telecom value="tel:0144534551" use="H"/>
      <telecom value="tel:0647151010" use="MC"/>
      <telecom value="mailto:279035121518989@patient.mssante.fr"/>
      <!-- Identité du patient -->
      <patient classCode="PSN">
        <name>
          <!-- Nom et prénom(s) de naissance -->
          <!-- Nom de l’acte de naissance -->
          <family qualifier="BR">PAT-TROIS</family> 
          <!-- Prénoms de l’acte de naissance -->
          <given>DOMINIQUE MARIE-LOUISE</given>
          <!-- Premier prénom de l’acte de naissance -->
          <given qualifier="BR">DOMINIQUE</given>
          <!-- Nom et prénom utilisés -->
          <family qualifier="CL">PAT-TROIS</family>
          <given qualifier="CL">DOMINIQUE</given>        
        </name>
        <administrativeGenderCode code="F" displayName="Féminin" codeSystem="2.16.840.1.113883.5.1"/>
        <birthTime value="19790328"/>
        <!-- Représentant du patient -->
        <guardian>
          <addr use="H">
            <houseNumber>28</houseNumber>
            <streetName>Avenue de Breteuil</streetName>
            <postalCode>75007</postalCode>
            <city>PARIS</city>
            <country>FRANCE</country>
          </addr>
          <telecom value="tel:0147150000" use="H"/>
          <guardianPerson>
            <name>
              <prefix>MME</prefix>
              <family>NESSI</family>
              <given>Jeanne</given>
            </name>
          </guardianPerson>
        </guardian>
        <!-- Lieu de naissance du patient -->
        <birthplace>
          <place>
            <addr>
              <county>51215</county>
              <city>DOMPREMY</city>
            </addr>
          </place>
        </birthplace>
      </patient>
    </patientRole>
  </recordTarget>

  <!-- Auteur du document -->
  <author>
    <!-- [1..1] Horodatage de la validation par l'auteur -->
    <time value="20231201093000+0100"/>
    <!-- [1..1] Identification de l'auteur -->
    <assignedAuthor>
      <!-- [1..1] Identifiant de l'auteur (Id RPPS du PS obligatoire pour les PS) -->
      <id root="1.2.250.1.71.4.2.1" extension="801234567897"/>
      <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
      <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
        codeSystem="1.2.250.1.213.1.1.4.5"/>
      <!-- [0..*] Adresse du PS -->
      <addr>
        <houseNumber>25</houseNumber>
        <streetName>Rue Berthollet</streetName>
        <postalCode>75005</postalCode>
        <city>PARIS</city>
      </addr>
      <!-- [0..*] Télécom du PS -->
      <telecom value="tel:0158432300" use="WP"/>
      <!-- [0..1] Identité du PS -->
      <assignedPerson>
        <name>
          <prefix>M</prefix>
          <given>Romain</given>
          <family>PIOU</family>
          <suffix>DR</suffix>
        </name>
      </assignedPerson>
      <!-- [1..1] Organisation de rattachement du PS -->
      <representedOrganization>
        <!-- [1..1] Identifiant de l'organisation de rattachement du PS (FINESS) -->
        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
        <!-- [1..1] Nom de l'organisation de rattachement du PS -->
        <name>Cabinet du DR Pierre JOLI</name>        
        <!-- [0..*] Télécom du PS -->
        <telecom value="tel:0158432300" use="WP"/>
        <!-- [0..*] Adresse du PS -->
        <addr>
          <houseNumber>25</houseNumber>
          <streetName>Rue Berthollet</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
      </representedOrganization>
    </assignedAuthor>
  </author>

  <!-- Personne à prévenir en cas d'urgence -->
  <informant>
    <relatedEntity classCode="ECON">
      <code code="SIS" displayName="Soeur" codeSystem="2.16.840.1.113883.5.111"/>
      <addr nullFlavor="NAV"/>
      <telecom value="tel:0647150100" use="MC"/>
      <relatedPerson>
        <name>
          <family>NESSI</family>
          <given>Sophie</given>
        </name>
      </relatedPerson>
    </relatedEntity>
  </informant>

  <!-- Personne de confiance -->
  <informant>
    <relatedEntity classCode="NOK">
      <code code="SIS" displayName="Soeur" codeSystem="2.16.840.1.113883.5.111"/>
      <addr nullFlavor="NAV"/>
      <telecom value="tel:0647150100" use="MC"/>
      <relatedPerson>
        <name>
          <family>NESSI</family>
          <given>Sophie</given>
        </name>
      </relatedPerson>
    </relatedEntity>
  </informant>

  <!-- Organisation chargée de la conservation du document -->
  <custodian>
    <assignedCustodian>
      <representedCustodianOrganization>
        <!-- Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
        <!-- Nom de l'organisation -->
        <name>Cabinet du DR Pierre JOLI</name>
        <!-- Coordonnées télécom de l'organisation -->
        <telecom value="tel:0158432300" use="WP"/>
        <!-- Adresse de l'organisation -->
        <addr>
          <houseNumber>25</houseNumber>
          <streetName>Rue Berthollet</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
      </representedCustodianOrganization>
    </assignedCustodian>
  </custodian>

  <!-- Responsable du document -->
  <legalAuthenticator>
    <!-- Date et heure de la prise de responsabilité -->
    <time value="20231201093000+0100"/>
    <signatureCode code="S"/>
    <assignedEntity>
      <!-- PS identifié par son N°RPPS -->
      <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
      <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
      <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
        codeSystem="1.2.250.1.213.1.1.4.5"/>
      <!-- Adresse du PS-->
      <addr>
        <houseNumber>25</houseNumber>
        <streetName>Rue Berthollet</streetName>
        <postalCode>75005</postalCode>
        <city>PARIS</city>
      </addr>
      <!-- Coordonnées télécom du PS-->
      <telecom value="tel:0158432300" use="WP"/>
      <!-- Identité du PS -->
      <assignedPerson>
        <name>
          <prefix>M</prefix>
          <given>Romain</given>
          <family>PIOU</family>
          <suffix>DR</suffix>
        </name>
      </assignedPerson>
      <!-- Etablissement de rattachement du PS -->
      <representedOrganization>
        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
        <name>Cabinet du DR Pierre JOLI</name>
        <addr>
          <houseNumber>25</houseNumber>
          <streetName>Rue Berthollet</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
        <standardIndustryClassCode code="AMBULATOIRE" displayName="Ambulatoire"
          codeSystem="1.2.250.1.213.1.1.4.9" codeSystemName="TRE_A01_CadreExercice"/>
      </representedOrganization>
    </assignedEntity>
  </legalAuthenticator>

  <!-- Participant : PS remplacé (obligatoire si prescription faite par un PS remplaçant) -->
  <participant typeCode="CON">
    <functionCode code="CORRE" displayName="Correspondant" codeSystem="1.2.250.1.213.1.1.4.2.280"/>
    <time nullFlavor="UNK"/>      
    <associatedEntity classCode="PROV">
      <!-- [1..1] PS identifié par son N°RPPS -->
      <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
      <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
      <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
        codeSystem="1.2.250.1.213.1.1.4.5"/>
      <!-- [0..*] Adresse du PS -->
      <addr>
        <houseNumber>25</houseNumber>
        <streetName>Rue Berthollet</streetName>
        <postalCode>75005</postalCode>
        <city>PARIS</city>
      </addr>
      <!-- [0..*] Télécom du PS -->
      <telecom value="tel:0158432300" use="WP"/>
      <!-- [0..1] Identité du PS -->
      <associatedPerson>
        <name>
          <prefix>M</prefix>          
          <given>Pierre</given>
          <family>JOLI</family>
          <suffix>DR</suffix>
        </name>
      </associatedPerson>
      <!-- [1..1] Organisation de rattachement du PS -->
      <scopingOrganization>
        <!-- [1..1] Identifiant de l'organisation de rattachement du PS (FINESS) -->
        <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
        <!-- [1..1] Nom de l'organisation de rattachement du PS -->
        <name>Cabinet du DR Pierre JOLI</name>        
        <!-- [0..*] Télécom du PS -->
        <telecom value="tel:0158432300" use="WP"/>
        <!-- [0..*] Adresse du PS -->
        <addr>
          <houseNumber>25</houseNumber>
          <streetName>Rue Berthollet</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
      </scopingOrganization>
    </associatedEntity>    
  </participant>

  <!-- Participant : Exécutant et/ou Date d'exécution souhaitée -->
  <participant typeCode="PRF">
    <!-- Date d'exécution souhaitée -->
    <time xsi:type="IVL_TS">
      <high value="20231202093000+0100"/>
    </time>
    <!-- Exécutant (obligatoire si prescription de TSO sur ordonnance sécurisée, nullFlavor possible dans les autres cas) -->
    <associatedEntity classCode="PROV">
      <!-- [1..1] PS identifié par son N°RPPS -->
      <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
      <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
      <code code="G15_21/A" displayName="Pharmacien titulaire d'officine" codeSystem="1.2.250.1.213.1.1.4.5"/>
      <!-- [0..*] Adresse du PS-->
      <addr>
        <houseNumber>12</houseNumber>
        <streetName>Rue des produits de santé</streetName>
        <postalCode>75005</postalCode>
        <city>PARIS</city>
      </addr>
      <!-- [0..*] Coordonnées télécom du PS-->
      <telecom value="tel:0158410697" use="WP"/>
      <!-- [0..1] Identité du PS -->
      <associatedPerson>
        <name>
          <prefix>M</prefix>
          <given>Lucien</given>
          <family>SAMPAIX</family>
          <suffix>DR</suffix>
        </name>
      </associatedPerson>
      <!-- [0..1] Etablissement -->
      <scopingOrganization>
        <!-- [0..1] Identifiant de l'organisation -->
        <id root="1.2.250.1.71.4.2.2" extension="1750512302"/>
        <!-- [0..1] Nom de l'organisation -->
        <name>Pharmacie SAMPAIX</name>
        <!-- [0..*] Coordonnées télécom de l'organisation -->
        <telecom value="tel:0158410697" use="WP"/>
        <!-- [0..*] Adresse de l'organisation -->
        <addr>
          <houseNumber>12</houseNumber>
          <streetName>Rue des produits de santé</streetName>
          <postalCode>75005</postalCode>
          <city>PARIS</city>
        </addr>
      </scopingOrganization>
    </associatedEntity>    
  </participant>

  <!-- [1..1] Acte documenté : prescription -->
  <documentationOf>
    <serviceEvent>      
      <!-- Identifiant de la prescription EPU : root="1.2.250.1.215.500.1.1" + extension calculé selon la règle fournie dans les spécifications de la Cnam -->
      <id root="1.2.250.1.215.500.1.1" extension="01S2TBPZ2JCNZZYGHZ"/>
      <code code="57833-6" displayName="Prescription de produits de santé" 
        codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"></code>
      <!-- Période de validité de la prescription -->
      <effectiveTime>
        <low value="20231201091000+0100"/>        
        <high value="20240730091000+0100"/>
        <!--  <high nullFlavor="UNK"/> -->
      </effectiveTime>      
      <!-- La personne ayant exécuté l'acte -->
      <performer typeCode="PRF">
        <assignedEntity>
          <!-- PS identifié par son N°RPPS -->
          <id root="1.2.250.1.71.4.2.1" extension="807505123456"/>
          <!-- [1..1] Profession / spécialité du PS (obligatoire pour les PS) -->
          <code code="G15_10/SM26" displayName="Médecin - Qualifié en Médecine Générale (SM)"
            codeSystem="1.2.250.1.213.1.1.4.5"/>
          <!-- Adresse du PS -->
          <addr>
            <houseNumber>25</houseNumber>
            <streetName>Rue Berthollet</streetName>
            <postalCode>75005</postalCode>
            <city>PARIS</city>
          </addr>
          <!-- Coordonnées Télécom du PS -->
          <telecom value="tel:0158432300" use="WP"/>
          <!-- Identité du PS -->
          <assignedPerson>
            <name>
              <prefix>M</prefix>
              <given>Romain</given>
              <family>PIOU</family>
              <suffix>DR</suffix>
            </name>
          </assignedPerson>
          <!-- Organisme représenté -->
          <representedOrganization>
            <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
            <name>Cabinet du DR Pierre JOLI</name>
            <!-- [0..*] Télécom du PS -->
            <telecom value="tel:0158432300" use="WP"/>
            <!-- [0..*] Adresse du PS -->
            <addr>
              <houseNumber>25</houseNumber>
              <streetName>Rue Berthollet</streetName>
              <postalCode>75005</postalCode>
              <city>PARIS</city>
            </addr>
            <!-- Cadre d'exercice du PS -->
            <standardIndustryClassCode code="AMBULATOIRE" displayName="Ambulatoire"
              codeSystem="1.2.250.1.213.1.1.4.9" codeSystemName="TRE_A01_CadreExercice"/>
          </representedOrganization>
        </assignedEntity>
      </performer>
    </serviceEvent>
  </documentationOf>
  
  <!-- [0..1] Prescription bizone 
  <documentationOf>
    <serviceEvent>
      <code code="MED-1096" displayName="Prescription bizone" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> -->
  
  <!-- [0..1] Prescription médicaments d'exception 
  <documentationOf>
    <serviceEvent>
      <code code="MED-1097" displayName="Prescription médicaments d'exception" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> -->
  
  <!-- [0..1] Ordonnance sécurisée 
  <documentationOf>
    <serviceEvent>
      <code code="MED-1098" displayName="Ordonnance sécurisée" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> -->
  
  <!-- [0..1] Prescription grand appareillage 
  <documentationOf>
    <serviceEvent>
      <code code="MED-1132" displayName="Prescription grand appareillage" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> -->
  
  <!-- [0..1] Exécution à domicile -->
  <documentationOf>
    <serviceEvent>
      <code code="MED-1094" displayName="Exécution à domicile" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> 
  
  <!-- [0..1] Prescription en urgence -->
  <documentationOf>
    <serviceEvent>
      <code code="MED-1095" displayName="Exécution en urgence" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf> 
  
  <!-- [0..1] Affection militaire  -->
  <documentationOf>
    <serviceEvent>
      <code code="MED-1159" displayName="Affection militaire" 
        codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"></code>
    </serviceEvent>
  </documentationOf>
  
  <!-- [1..1] Contexte de la prise en charge -->
  <componentOf>
    <encompassingEncounter>
      <code code="AMB" displayName="Ambulatoire (hors établissement)" codeSystem="2.16.840.1.113883.5.4"/>
      <effectiveTime>
        <high value="20231201093000+0100"/>
      </effectiveTime>
      <location>
        <healthCareFacility>
          <id root="1.2.250.1.71.4.2.2" extension="1750512345"/>
          <code code="SA07" displayName="Cabinet individuel" codeSystem="1.2.250.1.71.4.2.4"/>
        </healthCareFacility>
      </location>
    </encompassingEncounter>
  </componentOf>

  <!--*********************************-->
  <!--   Corps structuré du document   -->
  <!--*********************************-->
  <component>
    <structuredBody>
      
      <!-- [0..1] Section FR-Code-a-barres -->
      <component>
        <section classCode="DOCSECT" moodCode="EVN">
          <!-- Conformité FR-Code-a-barres (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.223"/>
          <id root="F28128CA-1D38-11EC-9621-0242AC130002"/>
          <code code="57723-9" displayName="Numéro de code à barres unique"
            codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
          <title>Code 2D de la prescription</title>
          <text>
            <renderMultiMedia referencedObject="Code2dPDF"/></text>
          <entry>
            <observationMedia classCode="OBS" moodCode="EVN" ID="Code2dPDF">
              <!-- Conformité CDAObservationMedia (CCD) -->
              <templateId root="2.16.840.1.113883.10.12.304"/>
              <!-- Conformité FR-Image-illustrative (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.103"/>
              <value mediaType="image/jpeg" representation="B64">iVBORw0KGgoAAAANSUhEUgAAAPUAAADZCAMAAAG4BraMAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAI6UExURQAAAOzs7CwsLFNTU6CgoO3t7cfHxwcHB1RUVO7u7i4uLsjIyFVVVQAAAKKiou/v7y8vL8nJyVZWVqOjozAwMMrKyldXV/Hx8TExMcvLywsLC1hYWKWlpfLy8jIyMn9/f8zMzAwMDFlZWaampvPz8zMzM83NzQ0NDVpaWjQ0NM7OzltbW6ioqPX19TU1Nc/Pz6mpqfb29jY2NtDQ0BAQEPf39zc3N9HR0REREaurqzg4OIWFhdLS0hISEl9fX6ysrPn5+Tk5OdPT062trTo6OoeHh9TU1GFhYa6urjs7O4iIiNXV1RUVFfz8/Dw8PNbW1hYWFgAAALCwsP39/QAAAD09PWRkZLGxsf7+/j4+PouLi9jY2BgYGLKysv///z8/P9nZ2QAAABkZGWZmZrOzs0BAQI2NjRoaGrS0tNvb2xsbG2hoaLW1tUJCQo+Pj9zc3BwcHGlpaba2tkNDQ5CQkN3d3R0dHWpqare3twAAAERERN7e3h4eHri4uEVFRZKSkh8fH7m5uUZGRuDg4G1tbbq6ukdHR+Hh4SEhIW5ubru7u0hISOLi4iIiIm9vb7y8vElJSZaWluPj4yMjI3BwcL29vQAAAEpKSpeXl+Tk5HFxcb6+vktLSyUlJb+/v0xMTObm5gAAAMDAwAAAAE1NTefn5ycnJ3R0dMHBwQEBAU5OTpubm+jo6CgoKMLCwk9PT5ycnOnp6cPDw1BQUJ2dnerq6ioqKsTExJ6enuvr6ysrK3h4eMXFxVJSUg9nUzYAAACidFJOUwD///////////////+4/////////////////////////////////////////////////////////////////////////////////////////3b//yL///////////////9Y//////////////////////////////+W/////////////////////////////////////9z/////////////PJ60fsMAAAAJcEhZcwAAFxEAABcRAcom8z8AABfLSURBVHhe7Z2PgyTFVcdHOZGIk2SVU+QMRu5AQmQBjYTEH6fHSSQgOLmJdozb3hBWQ8SQH65kOE1yCdGDaEgCLpIThrE2QSAGJODpGf433/u+b3VX9fSPme3e251jP3AzVa/ej3r9o7q6p7u3B5IyrAlQEsM2hZIYtilJ4jJS+yq2nzhzJnEb7oxLXKLFmXYxwX+p/NNCWbtI04r2VDC5FQvtK8CtulUWi/YuzXO4ApHYpkg7RNKGougW2mmty8W5q0v6N3HJZOImSbI1mfxNKt9xu2Eh6IdtSib2H7P+ZcFIAxZ+eq+Ui+1cvlxOFe3svzLj31oYRmtsU7yRoKrvnl0+JbBNoSSGbZ5hrzfWL9frDTZNVEpJ28C5kZj3nDroq2Sz51RguN5InKKgH31VmfadVbuACRVgo0BBATYKFBRgo5AkB2zZ64ftf8V22edOueTUfW4jPXrmjOyFxXbnTsrKPSf2R0vt0a5rt7zd9jl3XLaP+233i9rfsH3O/fLqiu1/RXvx+Kz1X53P2B+QwCd1K5M9TeJjc2SjoLuf2qoYW7fqxfZbE/cJ2f/uStYmkzXZCQrtRD1YDwQ2CuifSrFs30Sx2D/L/x6JfT96X2y35cvdb9a/tau8Yv0J0n5OPiS+1qL2V81IW9JfRRpxexlsFCgowEbPuNeX/cLpTjE1yZwMdUeSPW+EPXPUc4Oh7qTwZOhuKS3Y46a9wQDVoL0TmNU80CKCTfNAiwiV20oybDMTsDl4as0PWLNg5rItwPxoLlVoEaFyMZcxXjYzKPqtTM2tuIi5RH1NzRBdpfOY6y6Co4f+/2taR/RMWm+eo7rHbV+iRKk1jwgNYmgRofIDTg7aa2tr751MJmYuhcmWe8/E/fNakk4aomO0gRk6r+mqVKtXy6fmo9AiQuVY776/9i25W8W+AS0iVM5FJ8OrcU6FKCU36CKkB1pEqNxGbiNZXZVP5+T/1dvgwsloXmt+QNMFoivdvUdsNPOPpOm90mTLpjb3mY02o7nzs+ZQF1SaVWgRoXJd8nKwPHNKzZ3b+A2RbSTpmavUWBvOqFaNeU4eEDusLPlsndIiAg3zQYsINs0DLSLYNA+0qEBH8j5mazLs+xF9MKybvrVGDk4Syh9SBg6d0PJIQk+1It1AT2SFLHgo22m4UOeBFiFsmQdahLBlHmgRwpZ5oEUIW+aBFiGQY/8y8uNCKH21lTUmYLQIMetH8ZUkR806kWm0WlOaNlrbWCLWyYYMLPe5UxtqvQZpszU6CGsr2tDyRS2eWNA66/ni1pJ48ppWtmOdHdAWscZhxVu7a/VYItYmbbL+DtTkZIXWeuIi1pQ2Wed4a/Q8o9bajqVAurm6KidFB3lWZLxRZx3CLRWLLoYWIZBD376l5xEifbFpO5d5z5bMg2TyY9a36TxIpHe7tbVka6txjaHHWob1cUhtfTfuJTpR8PnKMhdU6utNW0vBmiJfF+vXVUSLEBWz5zegTGtLw3pOaBECuS61p8XazxlFhEU4+daaWG9pXaBFCOToo1jbt4VDJqe1Dy8yPC1CrCEAPT+n+XpOsIUWIZBze1SSVDbSlZfdwYO6xdK6fks1LSCBWZKifTfu3/Eeqp3mh3zq2sRqoEWIWcejQ2xN21pr0RVFjooRjct8xvpOdCVN/0GlC8fGXiLYqMgKLUIgD625pao0p2kPzY5EqXtwQ0QbGyKCpTbgVJMWISpWawPW0gcNjA+rGLQIgRxaBqyz0cE+FhqRhStNyo+0/ug/H7QIYcs80CKELfNAixC2zAMtQthSymf5TWhRik2nh73eZl++cXl17MZDTrmbGOPakFj39bLuotbKjp5JxGTnL6PedKyXqvTUQU82+lqcuqElIkinrF/BFSy36cQwO/swZyNcB+tN5cxkOMZlMmuTT1scHhOKf9cTP/LpT1ukQYtiq+tAPe5TDjfmjqHzBqjcMXTeAJU7hs4boHLH0HkDVNaJQiklLbXKBp03QOX4ClAATpZiSkQGDnuAzhugMmJfz+57Pin+skDXpentVjLRJ6nkEVGb2DoZoCcsP/3VKIv9ozT9kZVMpPMKqqpyB7Fx2Q+c9LEFhleyusTG1Aqc2NnYjxw69Ih8HT58+MLHPqeTf5At852PrV65ToVMdOFiW2BbAllsXQdGJ7EjotjH8+m7jx3SNnYZhdhW0c8SljJ2JXEg6cUc0HkDVE6S5896rH65r8SxnzOx56Apm/R5qwh03gCVw2VuqfH3nMoFbFwB3fRFVNqs7++gwFiyjxl57OJ2zv0bfVXRtmO/7txfocBYX9Ud2u/SxrVoF1S0xhNtid36WJKRx1Ky7TwkV5FlrpWWY0uU912WtGD1LDYr1hbmzXGP0HkDVC6sb7vuZZTFNsL1HUPnDVC5MLZIbP+7pQe/Xyoa3jitP6hpbN3Oox7QeQNUDvdv4V3Z/n327HPiXvbfdyTJsfV1OT/OY//U+vp75Gt9fV3U6Mag8waoXEO+mPX4Xb6/++tCHjpvgMo147kwE06kuAXG0/4YWoZEkQ2YlQwRvcQiEKW7+dMOoPMGqIzYTcdvJVvmdvy2bW0GOm+Ayj52Pm/5eDZfK8k7omT4ofMGqDwbuzhXrMb6tsOxs2MJCeeKMXTeAJVrYqeHDl0js3Lha1RVkfJnpilY/T/Y3GFsfEZUrIM2+5jE5lFCkHIeW7AxlR2R9nz/Nn0BGoDOG6AyYl9/LObT6tjH/tljxzYk6Pnz5yWGNH5ISufPPwkV5Y1jx96GgkLnDVAZscvIYgsl8/Ns/1bRtpc5l1uRqMU0haySS/OSQOcNULlj6LwBKncMnTdA5Y6h8wao3DF0vjibuB4sX643HNhV5oF+6AXlvnxog3NDveW53xtM3QLX2psQ124qvvUu0eFAokiooYaTtrFeqtYGKbmRdLFvN4F2xqbDpW/LW9Md9jRd5K1htaEn3bO8u419UYPlJutxOOrJ//rrg190/DFD16atZP+vpzfbT0f4BWM6HGxijViLfPSnw7GuAXUQWc0i607WmDiRELpSIdS7x1CSjzy2lLEpozwd4T4vjatb4lh3iQG2DzVA/32PdWstxZqFEfYRVGVZyEale5hUR1o1Fd3y3Vj+jbC45KOPnMey63kstrax/zCA+T57B46/XUPvtVC1a+i9Fqp2Db3XQtWuofdaqNo19F4LVbuG3muhatfQey1U7Rp6r4WqXUPvtVBV0Cl9CSUNNboeeq+FquINx6AZLk2Sx1n0PJ4kl7JYYLGzEapWhl5JkrMses4myQqLBZYzNFdZhojy0FYXGNpUMjZURF/bCc0yKYT2C8aHphY5FonovRaqZqGZgzATuph1oCz2rUOnH8UNbIplKaFv2dh4WUoiks+XNzZu8aFTUxS+1EVou01OyUILayYS1lBnaBMJ0s+LNPQ1h66RzxcOH/7+BQ+dhco2s4s6tOw8D2Z14QKGfsK5b9q+K58vXdDQMqTw3mlhsnOhvwxXSjG0Jf5vpaG/3EHoioFUQgftPnSk3D50SFlog6FD2oYuUBJaxQwd80C70CUUQz+CCZKGLmFnQ+dbeAnLFzp8uCDgCEK/bxUPGcjn6ysrP58kR9hagJ4Eeq+FqnVI6Bw7aDZC77VQtY6dD22/ZAt3hHVZulHo3zRxhuneElYUeq+FquFmdiis22ZWjW1ZOhPOKgq910LVXQ/9MX3OZ/KNNbCFyskwtIkEfS56a7Iln6L4TJJ8dzL5c6m0CG2mh6UU+slDZyIbw7lgDkPUyeFjD4Q2qkP7s5GbodUiNKcCAkMbcn4toV/STvh2IR9IRfozzv1lq6lCThQ6G8MjgtBJcqjtBKk26zy0JZ9fVbCsP5Umv6UVKrVa1xrBKIT+inNPWAcEje3XtdapI9B7LVSdCY2SEYW2g6bB0LaFx9B7LVQNQ38gKxmvOfcKizsXGqPZlt5LKDsthi3lJ6Uu45j15vK1tU9QjkdFLbSMZg+j2UPvtVA1S4GEk2ySLYh1CryWhJYx/DxbDXqvhaq7Gjo/Xith/YPO/Z58Se/W19ffFYaWunz+9/r6D587G8yOBHqvhap1ZFu4piizlDx0hgwpMfReC1Xr2PnQnFUWkBnpL6yufgjlgxLkL1ZWrnXuKpuhZkjoG0WBngR6r4Wqxc0sw9zll3GM1YJ++5PcEnY3tAzOX2DNc2s2gBufT5NT8tUitB4CQkQkoR937utWEU6n6eetlKncLl/qoIPDRwZD2xbO0PkWDmWVdnX4QCogC92UtYTWEv0Y9F4LVX3o9G/hVrFR0tb150xUjoR+yLkn6ceg91qomoWuvmRXSSeHj+2F/kCa/pNzz0LRQ++1UHW+0LpKQ0wqfEYqUPTQey1UnTM0Khl56HZj+J4MfcehQ9+wm0upmiQP4F5SvT5uXHUNBHkH6L0WqtaFjmakRn4KELGsoZMv8Tec4BcfCf1Hpzb09QXCd/GLz69LO4Ipd5u+0C50PpKayEIr5pfzcGk3qXDY9AVoAHqvhap56ICa0NZodHL4uMPu4PXcIaI8tDSK2sPnz4voRmnEnbznpcFCp2KAAqD3WqgaZhGRhxaypYJTey2olYV+f9h+YUN3P0GKfrXPXOv5dRb67RC1yDqYJESEDdQ0UaGUixR6r4WqXUPvtVC1a+i9Fqp2Db3XQtWuofdaqNo19F4LVbuG3muhatfQey1U7Rp6r4WqCxPP+Geg94WxW27HAzeV4kDvT4do4Aa9vhsOsgZIZfyEUSeIK731eKw3n1t5rHdID/W1MHrXOho2e9In1ZWP8A0w7ZA89HZjcYhQWhXZyF6KrqG1gaHRuQ5D4391CMd9Wwh6O/lIoiH0TmWNVahLGa7xLIKIhrKux1KX0NowytZ1p6GNSoedR9pnZxnI5jEYjlxvNMWd/bICsc24nj5qMLBHAnSjQsE29qGuZYjlf32KAC380K/N3hQPA6genkPAkwpFBoOB7h54P5QTG9H2Dy2IhKFHCC1DSPAchAWxZxK0lD0HgQaVDLLQ5c9B6F6JRzW8B/nfdiqNgtA6lPis0TK1rFHGt5TMu+74I316wmL55x9Ms4julYXQVhmpNbMe+peFwYcuTC2iIp/6mi6reAn7gC6KGxPPIGH1dV5QVhXR1mXb07EqCz0dWWjE1D7JiCYLC43SvMluMIR+6T8funRFC5oxQvuxKxu29JMLnA/UQKjPo9hLwfSBFJGpHAM8nj0Re5XYM2AWWsWQ7bPPPrsMZ7PLAfvcHvpbDtjn9tDfcsA+t4f+lgP2uT30txywz+2hv+WAfW4P/S0H7HN76G85YJ/bQ3/LAfvcHvoLeeDAAuA98cnzrFVhr8Z7g7W5eAAmMexze+gvIK14oUw5K/oLSJr/SlTOWWhV/DRazoHgpxUP+9we+gt4a2d9/WOP1vDY06ZVkvVlavjYb7MGoqyfrnf8XtPanayfKokaYH8DsjTrcxBdzhqIsj5a6znVX0uF3cn60dq+NWfN9+say5b1iVkgL2T9IjDRa2qEP/ojWENJ1qk5CzH57mednshvSMv4OFrCrPmbtz5jWeRBa4JSmHX6MauE3Kd574ms81thMk6iJcoapGW3qa0F7VHW+Zv6Ms5cNFmfrlrXF1vW1yHP66xiPA6Tizrrucbw/aw9S5Z1evAK5XduukE5ol6SIyjfZEP1xZm1zVL4cE6I/tVaYT/rvZ91kpw6OcPvQqsy6/TnnlVuN/tnYHIjGsKsk2+jIeIUtPZC1lXUZG0vbD4+Yx9nXcV+1kXY5/bQXwCzfvpoPS9AqzHrc1D+LzQw6xcgqkRfQizsTtZz0pB12Wg2H/tZe9jn9tBfQPo6487FpUHWfGJcXwrg3D1W+SYqT0Cr4g1t5bx+YbMObhCfB1hY1mUE59fbcFyAfW4P/bWjJuvg/Lo97HN76C+EyzqCTYAiAkl11n9PtSrgkVBEKAxhn9tDfwHpq+xwwJtBH4KnHIVwv94G/xk6fohC8GpJ2uxze+gvoGwMDx5YS9LoD7WEY/g2uCJ0vMHLjWAPHLl+mlsd+DsKQct1fTV9InC0rncn61f+kB1SboaI/COFBkxKsv4o2wP0lR/C/ah83SrG280NYO67k3U4D0+jF5vgTDOiLOuGeXh8pnk4V947Zx9vgayT759T+IwoiLO++s7jOXchBcv6ThiS95tpgM/6e2p/5/tQftaUH4bLy3bxqkIJcdYRs/PwSsrm4TaGp4dQ2c1rKSW8FbKu3sLfGW7bRriFl2V9F5y9Q4vpXbRRyrbwm6G1gfbjn7uwWdeMZjeU9ESpzjo804yoHM3qYJ/bQ38Bb+mso1nKL0HErCkL+Vc033rEanBjpPZHYV+zhpDoRUOWNVtgWAr73B76C2DWZSDr+OyjhB9EaYM72RTwL2i41yrImrOyJ6vTZp/bQ38BjVkX/0xkEfzOFRGvWOM0fOkfABMsazv70D9OVgH73B76Cyg70yTvRufmW9dYlQLKJVn/O1q5ro+i8gzKu7Ouy/ZbT1X7D9DfV1iDkoncn2itLOsSPpWbl8M+t4f+2lEyhvtfcnEFac6sMUupg31uD/2F2BKfF1g8gV7ra8cz9MVswhdQ+WurNGBZw0BQxwXY5/bQX8A2rgyzp2X3IIXoa9KEy1idwWakPAu/wFeGa8bwEjAPN0rvxglZtSUU/VnakN2ch+9e1p9B1voSGGF3sl7o171jbwqXPGot37MW4/8g0jcJOXfbJVD7NETGn6LBPYXK/1r8Y6h8FZUY9rk99BfArNv+kktKxvDgl9xoltIM+9we+gvYzzpJ1r44w7eRSJh18hOnha99y9rtzJlcAdFtrIF3QmR80EQ2I33+Kyr64+olwD63h/4Cwqy3db/ZNtgD8/D9rLef9VW48a6aX6Ee+H29P++m01dqwyXLnPXs9fCIyvvN6mCf20N/AftZz5u1TbCj1xNfOZuBaZHody7jSTYZNAphn9tDfwHbyDq1Fw7qO4Jz1FfEYvel7M7v1wtlXXmNNKTsV4BqdmcezqzvQyVi9mkXZh1eS/EEovgRryb+J3JjsM/tob+AMGup8amjAJOXZM3nmMKrhekWRLwebuYl51y/OPsEFQwKsM/tob+AOOsqyrMGUdazvwKUnWnumXn4U9w2q/gItMqyXjEFc2ZDNe6y81v7DyGKiLKmGmsh7HN76C+AWc9JSdbGrUw7T8Hv139AmcLLRUHW6fM/DtHu7NdzUpl1w70KRsmZ5vJcQboIsu7oDQMPoiGCbxgIrw39mInCH8vfZqIL/IaBPQz73B76Ww7Y5/bQ33LAPreH/pYD9rk99LccsM/tob/lgH1uD/0tB+xze+hvOWCf20N/O8hD7sMsKYc/myQfdg+xtiDs8/KxiffsLgduU1+8O2JtrFV9gzxe2juc6vt3x3jjuDT2pU0rQzeQ70FvaAVaIOsBdLUCaeR7D9HHC5xH9qJiSUr6qd1FZrJI8HJiEY6cphIq6mJA1t7CZz21NDf7WtHCHtwEpHMhY1QlJWRtqWdsumlJ1t6imPV4D2eNLXyaZTd2koTfirUBmUyxcUOu/3oizbP2Fj5r+Sdp2xa+Z7OOse11ERa32Hu8NbPeZznQv9hi3xxn8Qb8bKDq26iCV+HrUCSDkiADD96LD2SIBjosmx7MfRGjlHx5jxytp9qkzoc6MuJ7gMhAxnQiBXvJ/9T08Kb+7Aig9PVIAF1zOA/Se3jTrJ3MIDh8juDS++GIKl+YePiAmFmobnZU9kct7QkYS5sduPxiRdasDMW9Lh2196aaAgv6B3TUr0a3WJavqOAQYOUs1ijz0IjE156hH7IERtIr5EAPlvVY/7ZLAA5Jvic+a82mkPXQ91LwndSsub6BmOBQ503zvkOsyHrRY5oka3GNYtb5wmpGs9VAflVkOYRZK7oRoUV6w1zirPvy5TdrSwqL0/DbsWUdTjiRrbQy68KKNnQmq1hgRJgWsl5gRQuWrdvMsh6iR/bJrJmW6OIjWxBx1ra55rGDFT2yIjYjrOd8uWFarnmh2yUrWsk7EKyaKOtFVrRAR8E2rCsi673Ftkx1+hR1Js5aAwdZY7IF8vR1z7C9QzcMXWvZUCCjFv4QlpaFYDMRfNaqpV999RhkHfVqn3322WeffZabXu//AS3VCdC2i9MjAAAAAElFTkSuQmCC</value>
            </observationMedia>
          </entry>
        </section>
      </component>

      <!-- [0..1] Section FR-Prescription-medicaments : Prescriptions de médicaments -->
      <component>
        <section>
          <!-- Conformité Prescription Section (IHE PHARM PRE) -->
          <templateId root="1.3.6.1.4.1.19376.1.9.1.2.1"/>
          <!-- Conformité FR-Prescription-medicaments (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.171"/>
          <id root="4A402640-1CF6-4153-B5BA-D56B623004C8"/>
          <code code="57828-6" displayName="Prescriptions" codeSystem="2.16.840.1.113883.6.1"
            codeSystemName="LOINC"/>
          <title>Prescription de médicaments</title>
          <!-- Bloc narratif de la section (Prescription sous forme textuelle) -->
          <text>
            <!-- Médicament 1 -->
            <table border="0">
              <thead>
                <tr>
                  <th>Durée du traitement</th>
                  <th>Médicament</th>
                  <th>Posologie</th>
                  <th>Substitution</th>
                  <th>Nombre de renouvellements</th>
                  <th>En rapport avec une ALD</th>
                  <th>En rapport AT/MP</th>
                  <th>En rapport Prévention</th>
                  <th>Non remboursable</th>
                  <th>Hors AMM</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>du 01/12/2023 au 06/12/2023</td>
                  <td>
                    <content ID="med-001">PARACETAMOL MYLAN 500 mg, comprimé</content>
                  </td>
                  <td>
                    <content ID="med-001-posologie">
                      1 à 2 comprimés 3 fois/j à partir du 01/12/2023 pendant 2 jours puis 1 à 2 comprimés 2 fois/j à partir du 03/12/2023 pendant 4 jours
                    </content>                    
                  </td>                  
                  <td><content ID="med-001-substitution">Non (Marge thérapeutique étroite)</content></td>                                
                  <td>3</td>
                  <td><content ID="med-001-ALD">Non</content></td>
                  <td><content ID="med-001-ATMP">Non</content></td>
                  <td><content ID="med-001-prev">Non</content></td>
                  <td><content ID="med-001-non-remb">Non</content></td>
                  <td><content ID="med-001-horsamm">Non</content></td>
                </tr>                
                <tr>
                  <td colspan="4">Précondition</td>                  
                  <td colspan="9"><content ID="med-001-precondition">-</content></td>
                </tr>
                <tr>
                  <td colspan="4">Instruction au patient</td>                  
                  <td colspan="9"><content ID="med-001-instrPatient">A prendre au cours d'un repas</content></td>
                </tr>
                <tr>
                  <td colspan="4">Instruction au dispensateur</td>                  
                  <td colspan="9"><content ID="med-001-instrDisp">-</content></td>
                </tr>
                             
              </tbody>
            </table>
            <br/>
            <!-- Médicament 2 : préparation magistrale -->
            <table border="0">
              <thead>
                <tr>
                  <th>Durée du traitement</th>
                  <th>Médicament</th>
                  <th>Posologie</th>
                  <th>Substitution</th>
                  <th>Nombre de renouvellements</th>
                  <th>En rapport avec une ALD</th>
                  <th>En rapport AT/MP</th>
                  <th>En rapport Prévention</th>
                  <th>Non remboursable</th>
                  <th>Hors AMM</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>du 01/12/2023 au 06/12/2023</td>
                  <td>
                    <content ID="med-002">Préparation magistrale :<br/>- 30g de diprosone<br/>- 70g de Cérat Frais de Galien</content>
                  </td>
                  <td><content ID="med-002-posologie">2 applications par jour</content></td>                  
                  <td><content ID="med-002-substitution">Non (Marge thérapeutique étroite)</content></td>                                
                  <td>0</td>
                  <td><content ID="med-002-ALD">Non</content></td>
                  <td><content ID="med-002-ATMP">Non</content></td>
                  <td><content ID="med-002-prev">Non</content></td>
                  <td><content ID="med-002-non-remb">Non</content></td>
                  <td><content ID="med-002-horsamm">Non</content></td>
                </tr>                
                <tr>
                  <td colspan="4">Précondition</td>                  
                  <td colspan="9"><content ID="med-002-precondition">-</content></td>
                </tr>
                <tr>
                  <td colspan="4">Instruction au patient</td>                  
                  <td colspan="9"><content ID="med-002-instrPatient">Diminuer la posologie progressivement une fois la poussée traitée. Par exemple en appliquant la préparation une fois par jour pendant 5 jours, puis 1 jour sur 2 pendant 5 jours environ avant d’arrêter.</content></td>
                </tr>
                <tr>
                  <td colspan="4">Instruction au dispensateur</td>                  
                  <td colspan="9"><content ID="med-002-instrDisp">-</content></td>
                </tr>                           
              </tbody>
            </table>
          </text>
          <!-- [1..*] Entrée FR-Traitement-prescrit : paracétamol -->
          <entry>
            <substanceAdministration classCode="SBADM" moodCode="INT">              
              <!-- Conformité Medication activity (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.24"/>
              <!-- Conformité Medications Entry (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7"/>
              <!-- Conformité Prescription Item (IHE PHARM PRE) -->
              <templateId root="1.3.6.1.4.1.19376.1.9.1.3.2"/>          
              <!-- Conformité FR-Traitement-prescrit (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.83"/>   
              <!-- [0..1] Déclaration de conformité Mode d'administration : Normal (posologie non structurée) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.1"/>
              <id root="AADC9C14-F1CA-4177-B2C8-A5178D5B3CA0"/>
              <code code="DRUG" displayName="Médicament" 
                codeSystem="2.16.840.1.113883.5.4"  codeSystemName="HL7_ActCode"/>
              <text><reference value="#med-001"/></text>
              <statusCode code="completed"/>
              <!-- [0..1] Durée du traitement -->
              <effectiveTime xsi:type="IVL_TS">
                <low value="20231201"/>
                <high value="20231206"/>
              </effectiveTime>
              
              <!-- [0..1] Fréquence d'administration : uniquement si posologie structurée -->
              <!-- <effectiveTime xsi:type="PIVL_TS" operator="A"> -->
              
              <!-- Nombre de renouvellement(s) possible(s) -->
              <repeatNumber value="3"/>
              
              <!-- [0..1] Voie d'administration : uniquement si posologie structurée -->
              <!-- <routeCode> </routeCode>-->
               
              <!-- [0..1] Région anatomique d'administration : uniquement si posologie structurée -->
              <!-- <approachSiteCode> </approachSiteCode> -->
              
              <!-- [0..1] Dose à administrer : uniquement si posologie structurée -->
              <!-- <doseQuantity>  </doseQuantity> -->
              
              <!-- [0..1] Rythme d'administration : uniquement si posologie structurée -->
              <!-- <rateQuantity>  </rateQuantity> -->
              
              <!-- [0..*] Dose maximale d'administration : uniquement si posologie structurée -->
              <!-- <maxDoseQuantity> </maxDoseQuantity> -->
              
              <!-- [1..1] Entrée FR-Produit-de-sante -->
              <consumable>
                <manufacturedProduct classCode="MANU">
                  <!-- Conformité Product (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.53"/>
                  <!-- Conformité Product Entry (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.2"/>
                  <!-- Conformité FR-Produit-de-sante (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.43"/>
                  <manufacturedMaterial classCode="MMAT" determinerCode="KIND">
                    <!-- Conformité Medicine Entry (IHE PHARM PRE) -->
                    <templateId root="1.3.6.1.4.1.19376.1.9.1.3.1"/>                  
                    <!-- Code CIS du médicament -->
                    <code code="63107752" displayName="PARACETAMOL MYLAN 500 mg, comprimé"
                          codeSystem="1.2.250.1.213.2.3.1" codeSystemName="CIS">
                      <originalText><reference value="#med-001"/></originalText>
                      <!-- Code MV Médicabase du médicament -->
                      <translation code="MV00002306" displayName="Paracétamol 500 mg comprimé" 
                        codeSystem="1.2.250.1.213.2.59" codeSystemName="MEDICABASE"></translation>                      
                      <!-- Code CIP du médicament -->
                      <translation code="3400933516390" 
                        displayName="PARACETAMOL MYLAN 500 mg, comprimé, plaquette(s) thermoformée(s) PVC-aluminium de 16 comprimé(s)"
                        codeSystem="1.2.250.1.213.2.3.2" codeSystemName="CIP"></translation>
                    </code>
                    <!-- Nom de la marque -->
                    <name>PARACETAMOL MYLAN 500 mg, comprimé</name>
                    <!-- Forme galénique : EDQM Standard Terms (0.4.0.127.0.16.1.1.2.1) : Pharmaceutical Dose Forms -->
                    <pharm:formCode code="10219000" displayName="Comprimé" codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="StandardTermsEDQM"/>                    
                    <!-- [0..1] Équivalent générique -->
                    <pharm:asSpecializedKind classCode="GRIC">
                      <pharm:generalizedMedicineClass classCode="MMAT">
                        <pharm:code code="N02BE01" displayName="paracetamol" codeSystem="2.16.840.1.113883.6.73" codeSystemName="ATC"/>
                        <pharm:name>paracetamol</pharm:name>
                      </pharm:generalizedMedicineClass>
                    </pharm:asSpecializedKind>
                    <!-- [0..*] Substances actives -->
                    <pharm:ingredient classCode="ACTI">
                      <pharm:quantity>
                        <numerator xsi:type="PQ" value="500" unit="mg"/>
                        <denominator xsi:type="PQ" value="1"/>
                      </pharm:quantity>                    
                      <pharm:ingredient classCode="MMAT" determinerCode="KIND">
                        <pharm:code code="100000090270" displayName="Paracetamol" codeSystem="2.16.840.1.113883.3.6905.2" codeSystemName="SMS"/>
                        <pharm:name>Paracetamol</pharm:name>
                      </pharm:ingredient>
                    </pharm:ingredient>
                  </manufacturedMaterial>
                </manufacturedProduct>
              </consumable>               

              <!-- [0..1] Entrée FR-Instructions-au-patient -->
              <entryRelationship typeCode="SUBJ" inversionInd="true">
                <act classCode="ACT" moodCode="INT">
                  <!-- Conformité Patient instructions (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.49"/>
                  <!-- Conformité Patient Medication Instruction (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3"/>
                  <!-- Conformité FR-Instructions-au-patient (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.33"/>
                  <code code="PINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                    codeSystemName="IHEActCode"/>
                  <text><reference value="#med-001-instrPatient"/></text>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Instructions-au-dispensateur -->
              <entryRelationship typeCode="SUBJ" inversionInd="true">
                <act classCode="ACT" moodCode="INT">
                  <!-- Conformité Fulfillment instructions (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.43"/>
                  <!-- Conformité Medication fulfillment instruction (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3.1"/>
                  <!-- Conformité FR-Instructions-au-dispensateur (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.34"/>
                  <code code="FINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                    codeSystemName="IHEActCode"/>
                  <text><reference value="#med-001-instrDisp"/></text>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Quantite-de-produit -->
              <entryRelationship typeCode="COMP">
                <supply classCode="SPLY" moodCode="RQO">
                  <!-- Conformité Amount of units of the consumable (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.9.1.3.8"/>
                  <!-- Conformité FR-Quantite-de-produit (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.86"/>
                  <independentInd value="false"/>
                  <!-- Unité issue de EDQM Packaging (30009000 "Boite")-->
                  <quantity value="2" unit="30009000"/>
                </supply>
              </entryRelationship>
              
              <!-- [1..1] Entrée FR-Autorisation-Substitution -->
              <entryRelationship typeCode="COMP">
                <act classCode="ACT" moodCode="DEF">
                  <!-- Conformité Substitution-Permission (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.9.1.3.9.1"/>
                  <!-- Conformité FR-Autorisation-Substitution (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.87"/>
                  <!-- Valeur issue du jdv-hl7-v3-ActSubstanceAdminSubstitutionCode-cisis (2.16.840.1.113883.5.1070) -->
                  <code code="N" displayName="Aucune substitution permise" 
                    codeSystem="2.16.840.1.113883.5.1070" codeSystemName="HL7_SubstanceAdminSubstitution">
                    <!-- Motif de non substitution obligatoire si substitution non autorisée -->
                    <originalText><reference value="med-001-substitution"/></originalText>
                  </code>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-ALD -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-ALD (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.13"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130003"/>
                  <code code="MED-574" displayName="En rapport avec une ALD"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-ALD"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20191227093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas liée à une ALD -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-accident-travail -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-accident-travail (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.14"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130034"/>
                  <code code="GEN-180" displayName="En rapport avec un accident du travail ou une maladie professionnelle"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-ATMP"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas liée à un AT ou une MP -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-la-prevention -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-la-prevention (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.34"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130035"/>
                  <code code="GEN-295" displayName="En rapport avec la prévention"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-prev"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas en rapport avec la prévention -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Non-remboursable -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Non-remboursable (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.15"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130026"/>
                  <code code="GEN-181" displayName="Non remboursable"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-non-remb"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le médicament est non remboursable -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Hors-AMM -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Hors-AMM (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.12"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130017"/>
                  <code code="GEN-179" displayName="Hors Autorisation de Mise sur le Marché (AMM)"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-001-horsamm"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le médicament est Hors AMM -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
             <!-- Précondition -->
              <precondition>
                <criterion>
                  <text><reference value="#med-001-precondition"/></text>
                </criterion>
              </precondition>
            
            </substanceAdministration>
          </entry>
          
          <!-- [1..*] Entrée FR-Traitement-prescrit : préparation magistrale -->
          <entry>
            <substanceAdministration classCode="SBADM" moodCode="INT">              
              <!-- Conformité Medication activity (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.24"/>
              <!-- Conformité Medications Entry (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7"/>
              <!-- Conformité Prescription Item (IHE PHARM PRE) -->
              <templateId root="1.3.6.1.4.1.19376.1.9.1.3.2"/>          
              <!-- Conformité FR-Traitement-prescrit (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.83"/>              
              <!-- [0..1] Déclaration de conformité Mode d'administration : Normal (posologie non structurée) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.1"/>
              <id root="AADC9C14-F1CA-4177-B2C8-A5178D5B3CA0"/>
              <code code="DRUG" codeSystem="2.16.840.1.113883.5.4" displayName="Médicament"
                codeSystemName="HL7_ActCode"/>
              <text><reference value="#med-002"/></text>
              <statusCode code="completed"/>
              <!-- [0..1] Durée du traitement -->
              <effectiveTime xsi:type="IVL_TS">
                <low value="20231201"/>
                <high value="20231206"/>
              </effectiveTime>
              
              <!-- [0..1] Fréquence d'administration : uniquement si posologie structurée -->
              <!-- <effectiveTime xsi:type="PIVL_TS" operator="A"> </effectiveTime> -->
              
              <!-- Nombre de renouvellement(s) possible(s) -->
              <repeatNumber value="0"/>
              
              <!-- [0..1] Voie d'administration : uniquement si posologie structurée -->
              <!-- <routeCode> </routeCode> -->
              
              <!-- [0..1] Région anatomique d'administration : uniquement si posologie structurée -->
              <!-- <approachSiteCode> </approachSiteCode> -->
              
              <!-- [0..1] Dose à administrer : uniquement si posologie structurée -->
              <!-- <doseQuantity> </doseQuantity> -->
              
              <!-- [0..1] Rythme d'administration : uniquement si posologie structurée -->
              <!-- <rateQuantity>  </rateQuantity> -->
              
              <!-- [0..*] Dose maximale d'administration : uniquement si posologie structurée -->
              <!-- <maxDoseQuantity> </maxDoseQuantity> -->
              
              <!-- [1..1] Entrée FR-Produit-de-sante -->
              <consumable>
                <manufacturedProduct classCode="MANU">
                  <!-- Conformité Product (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.53"/>
                  <!-- Conformité Product Entry (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.7.2"/>
                  <!-- Conformité FR-Produit-de-sante (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.43"/>
                  <manufacturedMaterial classCode="MMAT" determinerCode="KIND">
                    <templateId root="1.3.6.1.4.1.19376.1.9.1.3.1"/>
                    <!-- Code CIS du médicament -->
                    <code nullFlavor="NA">
                      <originalText><reference value="#med-002"/></originalText>
                    </code>
                    <!-- Nom de la marque -->
                    <name nullFlavor="NA"/>
                    <!-- Forme galénique : EDQM Standard Terms (0.4.0.127.0.16.1.1.2.1) : Pharmaceutical Dose Forms -->
                    <pharm:formCode code="50015000" displayName="pommade pour application cutanée et nasale" 
                      codeSystem="0.4.0.127.0.16.1.1.2.1" codeSystemName="StandardTermsEDQM"/>                    
                  </manufacturedMaterial>                  
                </manufacturedProduct>
              </consumable>
              
              <!-- [0..1] Entrée FR-Instructions-au-patient -->
              <entryRelationship typeCode="SUBJ" inversionInd="true">
                <act classCode="ACT" moodCode="INT">
                  <!-- Conformité Patient instructions (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.49"/>
                  <!-- Conformité Patient Medication Instruction (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3"/>
                  <!-- Conformité FR-Instructions-au-patient (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.33"/>
                  <code code="PINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                    codeSystemName="IHEActCode"/>
                  <text><reference value="#med-002-instrPatient"/></text>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Instructions-au-dispensateur -->
              <entryRelationship typeCode="SUBJ" inversionInd="true">
                <act classCode="ACT" moodCode="INT">
                  <!-- Conformité Fulfillment instructions (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.43"/>
                  <!-- Conformité Medication fulfillment instruction (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.3.1"/>
                  <!-- Conformité FR-Instructions-au-dispensateur (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.34"/>
                  <code code="FINSTRUCT" codeSystem="1.3.6.1.4.1.19376.1.5.3.2"
                    codeSystemName="IHEActCode"/>
                  <text><reference value="#med-002-instrDisp"/></text>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Quantite-de-produit -->
              <entryRelationship typeCode="COMP">
                <supply classCode="SPLY" moodCode="RQO">
                  <!-- Conformité Amount of units of the consumable (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.9.1.3.8"/>
                  <!-- Conformité FR-Quantite-de-produit (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.86"/>
                  <independentInd value="false"/>
                  <!-- unité issue de EDQM (30067000 "Tube") -->
                  <quantity value="1" unit="30067000"/>
                </supply>
              </entryRelationship>
              
              <!-- [1..1] Entrée FR-Autorisation-Substitution -->
              <entryRelationship typeCode="COMP">
                <act classCode="ACT" moodCode="DEF">
                  <!-- Conformité Substitution-Permission (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.9.1.3.9.1"/>
                  <!-- Conformité FR-Autorisation-Substitution (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.87"/>
                  <!-- Valeur issue du jdv-hl7-v3-ActSubstanceAdminSubstitutionCode-cisis (2.16.840.1.113883.5.1070) -->
                  <code code="N" displayName="Aucune substitution permise" 
                    codeSystem="2.16.840.1.113883.5.1070" codeSystemName="HL7_SubstanceAdminSubstitution">
                    <!-- Motif de non substitution obligatoire si substitution non autorisée -->
                    <originalText><reference value="med-002-substitution"/></originalText>
                  </code>
                  <statusCode code="completed"/>
                </act>
              </entryRelationship>
              
              <!-- [1..1] Entrée FR-En-rapport-avec-ALD -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-ALD (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.13"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130003"/>
                  <code code="MED-574" displayName="En rapport avec une ALD"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-ALD"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20191227093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas liée à une ALD -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-accident-travail -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-accident-travail (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.14"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130034"/>
                  <code code="GEN-180" displayName="En rapport avec un accident du travail ou une maladie professionnelle"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-ATMP"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas liée à un AT ou une MP -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-la-prevention -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-la-prevention (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.34"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130035"/>
                  <code code="GEN-295" displayName="En rapport avec la prévention"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-prev"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du médicament n'est pas en rapport avec la prévention -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Non-remboursable -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Non-remboursable (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.15"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130026"/>
                  <code code="GEN-181" displayName="Non remboursable"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-non-remb"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le médicament est non remboursable -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Hors-AMM -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Hors-AMM (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.12"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130017"/>
                  <code code="GEN-179" displayName="Hors Autorisation de Mise sur le Marché (AMM)"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#med-002-horsamm"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le médicament est Hors AMM -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- Précondition -->
              <precondition>
                <criterion>
                  <text><reference value="#med-002-precondition"/></text>
                </criterion>
              </precondition>
              
            </substanceAdministration>
          </entry>
          
        </section>
      </component>

      <!-- [0..1] Section FR-Prescription-dispositifs-medicaux : Prescription de dispositifs médicaux -->
      <component>
        <section>
          <templateId root="1.2.250.1.213.1.1.2.222"/>
          <id root="5D743612-F997-4BCA-B990-B06A33B27B19"/>
          <code code="46264-8" displayName="Dispositifs médicaux" codeSystem="2.16.840.1.113883.6.1"
            codeSystemName="LOINC"/>
          <title>Prescription de dispositifs médicaux</title>
          <text>
            <table border="0">
              <thead>
                <tr>
                  <th>Dispositif médical</th>
                  <th>Durée de location LPP</th>
                  <th>Nombre de conditionnements</th>
                  <th>Nombre de renouvellements</th>
                  <th>En rapport ALD</th>
                  <th>En rapport AT/MP</th>
                  <th>En rapport Prévention</th>
                  <th>Non remboursable</th>
                </tr>
              </thead>
              <tbody>
                <!-- Dispositif 1 -->
                <tr>
                  <td ID="DM-001"><content ID="DM-001-LPP">Lit médical, lit + 135 kg, forfait de livraison du lit et accessoires [LPP 1215702]</content></td>
                  <td>60 jours</td>
                  <td>1</td>
                  <td>0</td>
                  <td><content ID="DM-001-ALD">Non</content></td>
                  <td><content ID="DM-001-ATMP">Non</content></td>
                  <td><content ID="DM-001-prev">Non</content></td>
                  <td><content ID="DM-001-non-remb">Non</content></td>
                </tr>
              </tbody>
            </table>            
          </text>
          <!-- [1..*] Entrée FR-Dispositif-medical  -->
          <entry>
            <supply classCode="SPLY" moodCode="INT">
              <!-- Conformité Supply Activity (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.34"/>
              <!-- Conformité FR-Dispositif-medical (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.20"/>
              <!-- Identifiant de la fourniture du DM -->
              <id nullFlavor="UNK"/>
              <!-- Référence vers la partie narrative de la section DM -->
              <text><reference value="#DM-001"/></text>
              <!-- Date d'utilisation du DM -->
              <effectiveTime xsi:type="IVL_TS">
                <low value="20231201"/>
                <high value="20240131"/>
              </effectiveTime>
              <!-- Nombre de renouvellement(s) possible(s) -->
              <repeatNumber value="0"/>              
              <!-- Nombre de conditionnements -->
              <quantity value="1"/>
              <!-- Durée de la location en jours -->
              <expectedUseTime>
                <width value="60" unit="d"/>
              </expectedUseTime>
              <!-- Description du dispositif médical -->
              <participant typeCode="DEV">
                <participantRole classCode="MANU">
                  <!-- Type de DM -->
                  <playingDevice classCode="DEV" determinerCode="INSTANCE">
                    <!-- Code EMDN du DM -->
                    <code code="V0806" displayName="LITS MÉDICAUX" codeSystem="1.2.250.1.213.2.68" codeSystemName="EMDN">
                      <!-- Autre Code du DM -->                      
                      <translation code="1215702"
                        displayName="lit médical, lit + 135 kg, forfait de livraison du lit et accessoires"
                        codeSystem="1.2.250.1.215.300.4" codeSystemName="LPP">
                        <originalText><reference value="#DM-001-LPP"/></originalText>
                      </translation>
                    </code>
                  </playingDevice>
                </participantRole>
              </participant>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-ALD -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-ALD (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.13"/>
                  <id root="7FA00C4C-3721-11EC-8D3D-0242AC130003"/>
                  <code code="MED-574" displayName="En rapport avec une ALD"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#DM-001-ALD"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20191227093000+0100"/>
                  <!-- false : la prescription du DM n'est pas liée à une ALD -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-accident-travail -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-accident-travail (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.14"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130034"/>
                  <code code="GEN-180" displayName="En rapport avec un accident du travail ou une maladie professionnelle"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#DM-001-ATMP"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du DM n'est pas liée à un AT ou une MP -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-En-rapport-avec-la-prevention -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-En-rapport-avec-la-prevention (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.34"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130035"/>
                  <code code="GEN-295" displayName="En rapport avec la prévention"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#DM-001-prev"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : la prescription du DM n'est pas en rapport avec la prévention -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>
              
              <!-- [0..1] Entrée FR-Non-remboursable -->
              <entryRelationship typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Non-remboursable (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.15"/>
                  <id root="40C12236-3721-11EC-8D3D-0242AC130026"/>
                  <code code="GEN-181" displayName="Non remboursable"
                    codeSystem="1.2.250.1.213.1.1.4.322" codeSystemName="TerminologieCISIS"/>
                  <text><reference value="#DM-001-non-remb"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201093000+0100"/>
                  <!-- false : le DM est non remboursable -->
                  <value xsi:type="BL" value="false"/>
                </observation>
              </entryRelationship>            
              
            </supply>
          </entry>
        </section>
      </component>

      <!-- [0..1] Section FR-Commentaire-non-code -->
      <component>
        <section>
          <!-- Conformité CDA Section (CDA) -->
          <templateId root="2.16.840.1.113883.10.12.201"/>
          <!-- Conformité Document Summary (IHE CARD) -->
          <templateId root="1.3.6.1.4.1.19376.1.4.1.2.16"/>
          <!-- Conformité FR-Commentaire-non-code (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.73"/>
          <id root="E9BCD936-DDBA-41C9-AB5B-D9B190A8DE81" />
          <code code="55112-7" displayName="Commentaire" codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC" />
          <title>Commentaire</title>
          <!-- Bloc narratif de la section -->
          <text>(texte libre)</text>
        </section>
      </component>

      <!-- [0..1] Section FR-Signes-vitaux -->
      <component>
        <section>
          <!-- Conformité Vital Signs Section (CCD) -->
          <templateId root="2.16.840.1.113883.10.20.1.16"/>
          <!-- Conformité Vital Signs Section (IHE PCC) -->
          <templateId root="1.3.6.1.4.1.19376.1.5.3.1.3.25"/>
          <!-- Conformité Coded Vital Signs Section (IHE PCC) -->
          <templateId root="1.3.6.1.4.1.19376.1.5.3.1.1.5.3.2"/>
          <!-- Conformité FR-Signes-vitaux (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.75"/>
          <id root="362B214A-8414-4547-8B56-EABDCAB587AA"/>
          <code code="8716-3" displayName="Signes vitaux" codeSystem="2.16.840.1.113883.6.1"
            codeSystemName="LOINC"/>
          <title>Signes vitaux</title>
          <text>
            <table border="0">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Signe vital</th>
                  <th>Valeur</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>01/12/2023</td>
                  <td>Poids</td>
                  <td>
                    <content ID="poids">55 kg</content>
                  </td>
                </tr>
                <tr>
                  <td>01/12/2023</td>
                  <td>Taille</td>
                  <td>
                    <content ID="taille">1,70 m</content>
                  </td>
                </tr>
              </tbody>
            </table>
          </text>
          <!-- [1..1] Entrée FR-Signes-vitaux -->
          <entry>
            <organizer classCode="CLUSTER" moodCode="EVN">
              <!-- Conformité Result organizer (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.32"/>
              <!-- Conformité Vital signs organizer (CCD) -->
              <templateId root="2.16.840.1.113883.10.20.1.35"/>
              <!-- Conformité Vital Signs Organizer (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13.1"/>
              <!-- Conformité FR-Signes-vitaux (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.49"/>
              <id root="0B9FE5D6-8A5E-46D6-87BF-D9E19F73B956"/>
              <code code="85353-1" displayName="Signes vitaux" codeSystem="2.16.840.1.113883.6.1"
                codeSystemName="LOINC"/>
              <statusCode code="completed"/>
              <effectiveTime value="20231201"/>
              <!-- [1..*] Entrée FR-Signe-vital-observe : Poids(kg) -->
              <component typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Result observation (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.31"/>
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité Vital Signs Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13.2"/>
                  <!-- Conformité FR-Signe-vital-observé (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.50"/>
                  <id root="C4815527-3DBA-4907-B3B1-EC6F9F8D1224"/>
                  <code code="29463-7" displayName="Poids (mesuré)" 
                        codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                  <text><reference value="#poids"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201"/>
                  <value xsi:type="PQ" value="55" unit="kg"/>
                </observation>
              </component>
              <!-- [1..*] Entrée FR-Signe-vital-observe : Taille(cm) -->
              <component typeCode="COMP">
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Result observation (CCD) -->
                  <templateId root="2.16.840.1.113883.10.20.1.31"/>
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité Vital Signs Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13.2"/>
                  <!-- Conformité FR-Signe-vital-observé (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.50"/>
                  <id root="80E7B7B1-353A-4870-B8F4-F1176A23F1DB"/>
                  <code code="8302-2" displayName="Taille"
                    codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                  <text><reference value="#taille"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime value="20231201"/>
                  <value xsi:type="PQ" value="170" unit="cm"/>
                </observation>
              </component>
            </organizer>
          </entry>
        </section>
      </component>
      
      <!-- [0..1] Section FR-Historique-des-grossesses -->
      <component>
        <section>
          <!-- Conformité Pregnancy History Section (IHE PCC) -->
          <templateId root="1.3.6.1.4.1.19376.1.5.3.1.1.5.3.4"/>
          <!-- Conformité FR-Historique-des-grossesses (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.77"/>
          <id root="573B13F5-2C78-47E0-BE1F-55C02B6F40B2"/>
          <code code="10162-6" displayName="Historique des grossesses"
            codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
          <title>Historique des grossesses</title>
          <text>
            <table border="0">
              <thead>
                <tr>
                  <th>Statut</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <content ID="grossesse-001">Enceinte</content>
                  </td>
                </tr>
              </tbody>
            </table>
          </text>
          <!-- [1..*] Entrée FR-Observation-sur-la-grossesse : Patiente enceinte -->
          <entry>
            <observation classCode="OBS" moodCode="EVN">
              <!-- Conformité Simple Observation (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
              <!-- Conformité Pregnancy Observation (IHE PCC) -->
              <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13.5"/>
              <!-- Conformité FR-Observation-sur-la-grossesse (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.53"/>
              <id root="889E8A7C-ABE9-426B-873C-BDF23B505006"/>
              <code code="11449-6" displayName="Statut de grossesse"
                codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
              <text><reference value="#grossesse-001"/></text>
              <statusCode code="completed"/>
              <effectiveTime value="20231201"/>
              <value xsi:type="CE" code="77386006" displayName="patiente actuellement enceinte" 
                codeSystem="2.16.840.1.113883.6.96" codeSystemName="SNOMED_CT"/>
            </observation>
          </entry>
        </section>
      </component>

      <!-- [0..1] Section FR-Document-PDF-copie -->
      <component>
        <section>
          <!-- Conformité FR-Document-PDF-copie (CI-SIS) -->
          <templateId root="1.2.250.1.213.1.1.2.243"/>
          <id root="770B0DC2-A6B8-468E-8432-632B18D35F68"/>
          <code code="55108-5" displayName="Copie du document"
            codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
          <title>Copie du document</title>
          <text>
            <table border="0">							
              <tbody>
                <tr>
                  <td><content ID="titre-copie-pdf">Copie PDF du document</content></td>
                </tr>
                <tr>
                  <td><renderMultiMedia referencedObject="copie-pdf"/></td>
                </tr>
              </tbody>
            </table>
          </text>
          
          <!-- [1..1] Entrée FR-Document-attache : Copie PDF du document -->
          <entry>
            <organizer classCode="CLUSTER" moodCode="EVN">
              <!-- Conformité FR-Document-attache (CI-SIS) -->
              <templateId root="1.2.250.1.213.1.1.3.18"/>
              <id root="88BEB395-3B4C-37F5-9A31-03BEA73A8D8B"/>
              <code code="55107-7" displayName="Document attaché"
                codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
              <statusCode code="completed"/>
              <!-- [1..1] Entrée FR-Type-document-attache -->
              <component>
                <observation classCode="OBS" moodCode="EVN">
                  <!-- Conformité Simple Observation (IHE PCC) -->
                  <templateId root="1.3.6.1.4.1.19376.1.5.3.1.4.13"/>
                  <!-- Conformité FR-Simple-Observation (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48"/>
                  <!-- Conformité FR-Type-document-attache (CI-SIS) -->
                  <templateId root="1.2.250.1.213.1.1.3.48.18"/>
                  <id root="0D1629B3-CC69-4632-81F3-2301FD4C318B"/>
                  <code code="69764-9" displayName="Type de document"
                    codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                  <text><reference value="#titre-copie-pdf"/></text>
                  <statusCode code="completed"/>
                  <effectiveTime nullFlavor="NA"/>
                  <value xsi:type="CD" code="55108-5" displayName="Copie du document"
                    codeSystem="2.16.840.1.113883.6.1" codeSystemName="LOINC"/>
                </observation>
              </component>
              <!-- [1..1] Entrée ObservationMedia -->
              <component>
                <observationMedia classCode="OBS" moodCode="EVN" ID="copie-pdf">
                  <value mediaType="application/pdf" representation="B64">
                    JVBERi0xLjQNJeLjz9MNCjEwIDAgb2JqDTw8L0xpbmVhcml6ZWQgMS9MIDkzMzYyL08gMTIvRSA3NjI3My9OIDMvVCA5MzA0Mi9IIFsgOTE2IDI2OV0+Pg1lbmRvYmoNICAgICAgICAgICAgICAgICAgDQp4cmVmDQoxMCAzMQ0KMDAwMDAwMDAxNiAwMDAwMCBuDQowMDAwMDAxMTg1IDAwMDAwIG4NCjAwMDAwMDE0MTMgMDAwMDAgbg0KMDAwMDAwMTY0NyAwMDAwMCBuDQowMDAwMDAxODI3IDAwMDAwIG4NCjAwMDAwMDE5NTUgMDAwMDAgbg0KMDAwMDAwMjA4MyAwMDAwMCBuDQowMDAwMDAyMTE4IDAwMDAwIG4NCjAwMDAwMDI3NDYgMDAwMDAgbg0KMDAwMDAwMzMwMSAwMDAwMCBuDQowMDAwMDA0OTE3IDAwMDAwIG4NCjAwMDAwMDY5NjUgMDAwMDAgbg0KMDAwMDAwODE2MCAwMDAwMCBuDQowMDAwMDA5Mzc1IDAwMDAwIG4NCjAwMDAwMTA2NjggMDAwMDAgbg0KMDAwMDAxMTc4OCAwMDAwMCBuDQowMDAwMDEzNTAxIDAwMDAwIG4NCjAwMDAwMTkzOTYgMDAwMDAgbg0KMDAwMDAyMDU4MCAwMDAwMCBuDQowMDAwMDIxMjg1IDAwMDAwIG4NCjAwMDAwMjM4MzIgMDAwMDAgbg0KMDAwMDAyMzkxMiAwMDAwMCBuDQowMDAwMDUxODEyIDAwMDAwIG4NCjAwMDAwNTIwODUgMDAwMDAgbg0KMDAwMDA1MjkzOSAwMDAwMCBuDQowMDAwMDUzMDE5IDAwMDAwIG4NCjAwMDAwNzEyMTUgMDAwMDAgbg0KMDAwMDA3MTQ4OCAwMDAwMCBuDQowMDAwMDcyMTg3IDAwMDAwIG4NCjAwMDAwNzM2MDQgMDAwMDAgbg0KMDAwMDAwMDkxNiAwMDAwMCBuDQp0cmFpbGVyDQo8PC9TaXplIDQxL1Jvb3QgMTEgMCBSL0luZm8gOSAwIFIvSURbPDQzNTQ0MzUzMzIzOTM4MzU1MjQyNDU1MTQ2NDEzOTRDPjxCNTgxRDFDNjVFQTBDNjQ1OTdDMDYyNjdCMEVCMDIxNT5dL1ByZXYgOTMwMzE+Pg0Kc3RhcnR4cmVmDQowDQolJUVPRg0KICAgICAgICAgICAgICANCjQwIDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9JIDIxNi9MIDIwMC9MZW5ndGggMTgxL1MgMTE5Pj5zdHJlYW0NCmjeYmBgYGJgYKlgYGVgEJBiEGRAAEGgGCsDCwPHBYYuTcY1DgwMc54hSTMIibjJKGte2rbPeO0OFY0eC7fgpbk16dEFQKmKDhBoYGDgADM6gEIQRgPUJCQgA8UMDMoM/Ix9TC5ML1gvMDBMcWRh0+XfJaSg8sBvQfvCxd1FLLWsNuoOjHlnJ8geOHNA7NhHxjtcCdoGSxZADWJlYPQ/CaQZgdgIiDkZGDOnQ/mHAQIMAIMLMQoNCmVuZHN0cmVhbQ1lbmRvYmoNMTEgMCBvYmoNPDwvTGFuZyh4LXVua25vd24pL01ldGFkYXRhIDcgMCBSL091dHB1dEludGVudHNbPDwvRGVzdE91dHB1dFByb2ZpbGUgOCAwIFIvSW5mbyhHZW5lcmljIFJHQiBQcm9maWxlKS9PdXRwdXRDb25kaXRpb25JZGVudGlmaWVyKEN1c3RvbSkvUy9HVFNfUERGQTEvVHlwZS9PdXRwdXRJbnRlbnQ+Pl0vUGFnZUxhYmVscyA1IDAgUi9QYWdlcyA2IDAgUi9UeXBlL0NhdGFsb2c+Pg1lbmRvYmoNMTIgMCBvYmoNPDwvQmxlZWRCb3hbMCAwIDU5NC43MiA3OTJdL0NvbnRlbnRzWzE5IDAgUiAyMCAwIFIgMjEgMCBSIDIyIDAgUiAyMyAwIFIgMjQgMCBSIDI1IDAgUiAyNyAwIFJdL0Nyb3BCb3hbMCAwIDU5NC43MiA3OTJdL01lZGlhQm94WzAgMCA1OTQuNzIgNzkyXS9QYXJlbnQgNiAwIFIvUmVzb3VyY2VzIDEzIDAgUi9Sb3RhdGUgMC9UcmltQm94WzAgMCA1OTQuNzIgNzkyXS9UeXBlL1BhZ2U+Pg1lbmRvYmoNMTMgMCBvYmoNPDwvQ29sb3JTcGFjZTw8L0RlZmF1bHRHcmF5Wy9JQ0NCYXNlZCAyOCAwIFJdL0RlZmF1bHRSR0IgMTYgMCBSPj4vRm9udDw8L0YxIDE0IDAgUi9GMyAxNSAwIFI+Pi9Qcm9jU2V0Wy9QREYvSW1hZ2VCL0ltYWdlQy9UZXh0XS9YT2JqZWN0PDwvSW0xIDM4IDAgUi9JbTIgMjYgMCBSPj4+Pg1lbmRvYmoNMTQgMCBvYmoNPDwvQmFzZUZvbnQvRFNWVVBBK0FyaWFsL0Rlc2NlbmRhbnRGb250c1szMyAwIFJdL0VuY29kaW5nL0lkZW50aXR5LUgvU3VidHlwZS9UeXBlMC9Ub1VuaWNvZGUgMTcgMCBSL1R5cGUvRm9udD4+DWVuZG9iag0xNSAwIG9iag08PC9CYXNlRm9udC9aWlFOV1UrQXJpYWwvRGVzY2VuZGFudEZvbnRzWzM3IDAgUl0vRW5jb2RpbmcvSWRlbnRpdHktSC9TdWJ0eXBlL1R5cGUwL1RvVW5pY29kZSAxOCAwIFIvVHlwZS9Gb250Pj4NZW5kb2JqDTE2IDAgb2JqDVsvSUNDQmFzZWQgMjkgMCBSXQ1lbmRvYmoNMTcgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCA1NTg+PnN0cmVhbQ0KeF5dlMtu2zAQRfcG/A9cpovA5ktMAEOA4wfgRdMibj9AlmhXQC0Jsrzw34e8vAyKamHjSEPOHA4xi81he+jaSSx+jn199JM4t10z+lt/H2svTv7SdvOZlKJp60kQ8Vdfq2E+i+uPj9vkr4fu3M9nq5VYfITPt2l8iKd105/8txD1Y2z82HYX8fR7c4wvjvdh+OuvvpvEcj4rS9H4c9ztezW8V1cvFlj6fGhCRDs9nsOyf0J+PQYvVHohU1V13/jbUNV+rLqLD4Usw1Ou9uEp5zPfNf8HOJMWns71n2pMC2QZfrUsE6lIaknSkQpDKiLtXkkO3zTJgCzpBbQlvYIUaR3JZXpD9kwbUM6+BeUMO1S2Ie3xjbXIJWhNgpF6I8HI0EHCyOxJqNqwTmlBeU/Ymh0JtpanJOFnaSvhZzLBz+RI+Fn6SfipnA9+hkYSfpa2En6WDgp+lusU/ExBgl/BqlXqGKtW8NMvJPgpuiv4aUeCn8qRqX85En6OdSr4FZngp3L21L9cGfwsu6Lgp3lKCn6OXdHwc3TXyY+3QMPPZUp+PF0NP0VbDb+C2TX8bF4HP8fsOvmxMg0/nWtJ/cu1wM/kSPg5npKG0S5ngFHB8zSpY9zTwMjylEzqGHcxMHI0Msko75JuZCYYOfqFtysV714iOOxYp0k94u0xyYF30MDBsrcm3cFYSxgXeSzEyYFJ9zWa6vs4hqmEgYhpFOdQ2/mvoTn0A9bx5xNF7zFhDQplbmRzdHJlYW0NZW5kb2JqDTE4IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggNDg1Pj5zdHJlYW0NCnheXZTNrpswEIX3SLyDl7eLq8Q/wL1ShJQmRMqiP2raByDgpEgNIIcs8va1j4+vqrIg+vCMZz6cYbU77o/jsIjVdzd1J7uIyzD2zt6nh+usONvrMOaZlKIfukUQ8dPd2jnPQv7peV/s7ThepjzbbMTqh1++L+4pXrb9dLaffNQ311s3jFfx8mt3Cg9Oj3n+Y292XMQ6z+pa9PYSdvvSzl/bmxUrpL4eex8xLM9Xn/ZPyM/nbIWKD2Tsqpt6e5/bzrp2vFrfyNpf9ebgrzrP7Nj/H1BUMfF86X63LibI2t+LdR1JBaoUSQcqC5LBmiYVWEtUgt5JFSLTnm8gQ3pH5IG0BTWkz4FUytthLeXtQXvSIVDDenKNNUmCkWIFGY3oIKNRSYpGbyQYGfYiYWTSnjAq2IuEkWIvEkYF35mEkUnVYWRSnzAq+M4kjFSq3oBSJPwM6yn4GdZT8cTYmYJfQT8FP5MIfmZHiieWKJ5YRYJfSQcVT4xvScHPsE8V/eig4FekSPhVqTP4mS0p+qV68Cu5p4ZfRXcdz499avhp7qnhp9mnhp/m/0XDT7MzDaMmVYCRZi8aRk3Ki0Z00NEo5PkBSoMSZgmz/zGs3cM5P6f4RGA+w2QOo/34jMzTjDze/gKb9AQGDQplbmRzdHJlYW0NZW5kb2JqDTE5IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMTU0NT4+c3RyZWFtDQpIiexXXW/bNhS9cdwUiJGly0e3NGnDbl3XbgtDUpQovbZdi+1hwNYAe5j70HYN9pB6aJph2L/foUjZkmxF8mIn7ioYlkiJurwfPDyH79ZWJRP4HdibSRR7/XZt9V32VDKpuRb+al8dPnlz/PKvk7Nfnj1ir9+vrQrGFf54+/71YG310RGGPA1YzI6Oc6alEVwEEZMRj7VmRzD02wNaog4tU5eu4b5C16n/Crf+GfUH1KP+Md7hdkrrtr2CUTdsb9m+xsguXi7bxqf2k43cF3Zw15o7w23FWd1MxxeNbdDWwxfs6MecnyqWcDBmKuAikpmfPT/s8KksB6aU4SqMmEq4MnExMBtS107vQuriYepd6scn6KG97oJCq2MDOcanuPSPsxl9tp+dvvzHpztNs/VEqqIrggURD6XJnOh4G98fFQqqeGJCFmhulMmKbYsYBwwdmUTcJLHrn4z6CY/dA5FvZqN+XVsdjC8NHkeYgicankrnt/9kZDUS7PTN2iri+Lng5QGXWjFcZOqjfYjbQfrAXVPnDBexGn8gMtcTzVJD6GYG084fZZ/TBD9+bmd6/vgn5O8FjPyOr6y7f2czcyFE6NLkJnIPYPB5OYDR7FkE0hXJ/nIh2Wxq53DCTc7Fi/krRr66GWo9lUCoClPXDnJrquDs/PIrpsmtWxw5h90eM55ckVsabvSwP/+8+xlLYVRskIrHgWaGSzXE73a6b5zmNrYBNgu7tXXtpjHAHracg3gxRUpg9rAa53ajU9jhMgRn/WlwPtyUiuAemZoO3LliWROhDscfiKyjRTD7imWzVK+83NSLDuvM1Sa4XpT0Ngb2FaX3v4mfCdheopv0GX2O/w7dol3aqwZyStdaA0zJh0bXC0IXLRUvFhW7LFwiE09M+zRg7dhjw8Dz8W3w752LsXIVnBeQlReFGlrmbZm3jnllAzBv0CZtQVvfxN8y8A7AvZVy8Dbae0D3Jp5uA+E7HsZDa1LEPFJR0V6H9v24CZuJlAEXpuTBPmZj6Xy7dJe+oC+H34/5L8OEKxBv4XtWoxVCzXUiW63QaoUFy+3HoBX2oAm2GiiAKpC2CqBVAK0CmKsCuAu13n9liTdHvlVkGmkemKAl05ZMFyy3HwOZ7tMNi9Rl6lH/2N0GeLRCXfxu2M61BlRbBeGWaluqbal2rlTbo3v0lcVu/xT3JVqn+7Rew7hGcxWGLeO2jLtguf1wGRdBOHBKHjgwmQBYi33/ZNiPufFcmA4vdYejG4Mq/52RiM/uDzoPrOZi4B54f5k2ztUC1MttLu9KYdoih4qHwSgQ3x/GWU5DOU2NAy98aGIehmpy5GO7qP+yEPrXdJ36DxBelzq0TTfpDu3g16H+Q1xu4xjTP8O7b/BboW9rBVHVDtsKolYQtYJoroLoO6uEem4P8/Ddolt0QJvA9S4wfadGHcWay8A0V0fKpIefFLH59kX1EWyJ5H8skNJc+ZWGtgrmsNT8HLXOYlwoPySNlHO4gUbyaSj3ryD1zcUIs5LjFdC7AtmxgbONFSS7wPBeLftWIbiKfadDcA3/Tg3bRWGIxgS8EMDNvG2C3EXJcGPoXl2GZ0bDPbpP65aDwcacltBfSu/38NT+O7TvdfYerpaZO159H+IqcGUe56VZZMADHHL8NJ2KQRGXkPilQeM7hrY1A9cGmhs13DHOx2tuX8VGEyF7+b6OfN3QDtQc6ubnrF5lo4nPh7Hzeui7O3eUumLUnE0gzn5BCgbNVKuuVa1Dd42dwnsoZiZZx/ycvJQ0llJYXkm+JuLcgohi9lW5K0bN2UdXLzncqLoiXLabk4sQAiSBaqtwtVWINJhOt1W42ioY5DuJ2ipcbRWQbwVFcsEqpKJNjfVFrj3bCDOj9ZrWDqvVtJfvaoXeCzEsyaoRO2cPjOBxaFjAQ2GYUenNDjn84a1iT/6cYE/xBGQvJayOzI0OnDKJuMF02UEy60vFjTQu9Hx78oEz0+I8jqBReaIlJFHh7Jmzq6F+pzh8ygTH1Qwi1kyiZy9Zs0mqV9Fo5vM1a5qs2HuLAplo5t6yfwUYAJH5myQNCmVuZHN0cmVhbQ1lbmRvYmoNMjAgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxOTc3Pj5zdHJlYW0NCkiJ7FdbbxNHFJ7YJpEcuUnTgtoCZRWupc0wl53d2bZqJWiL1IdKlEh9IDwAJeoDIAGpqv77fmdm1nvxrtcOjp1KliG7MzuXM+ec7zvfDKXiqbQRF0KY6NVo+Hg0fDQavh0NZSTwk5HMEp7FEcZZk0UvXo+GB/5TeFAPPd3jgMtY0jIyS7lSutohrMJA13Br4puipnvmjb9Gwz9Gwzej4b2fXh4/+/vVycN3z/6NHjym5R8/+G00fPIUi/yJWcrq6B/q9sa/LnZtP82B26Z0GHcO/7VyFm94Yb53U70twrtJkwWdxu9QnKgxPPcPseAvOrLR4XF+NhwDp9JxlHKp0ugQk5/cYZfY0THrsT4b4Ndn29R0j3ehb5fdwluPbbL+V0+jw18nlpOa6zjO19sOg34+rHtWCcGFMZGUkhvhnfvWRYdOhoaykqtE+varou2OmFKPqLzn4xr89+I97fv+xZvxuNJiMYx+93I0PG6OvfNvKdA008TGh5IasdCLz8x8l/bMLG2d2ydzjFUy88xST3SlXYO1c9JC7oaJjlV7f2ZeWJ3384V+f3jfAYAyH/9j4YHgOUHOwAnbgPwOEQFIgLMNtDfc8wZ66b9kiml2j+2DHq7jGbOj50zgp11zgA7Djt7MQhe9VrqIKSSZdXSRmJwt8q825lrJseebgSAqdGxNnZ7TUpTMODBiUSGiDdsTKpwgGDIVH7VSg5lxoifaIrzTqmdSasI+M2AkP9FUjBTep/ezwUhat/ZRgQOpqkDACbThmTZNuVlmNp4hW+AZrrSarGIkXVLkbV6d8jZ5z4bKVX7vqGLcKuxWrmSlBZWYq5LVJUtQXEuQYHXREjbqFJWdtc550ha5H58B24Y9Oo3FuER1lLqlqdzp7vX5UTK4DamiQjM0ukI7S3A97fkB6vYC1aY+u4qq9GW3NG0DtU4MT+neEMCat08J6qo0LS02J6BL0dFJgldb7RAikCxtYROz+ADl27anWmnr6VBuqHLWLiHdGqrcVLTnB5oF7ssLAu2yALyvjk8Xpl4TSE+gXbAtetmHViWlenQH2tTfc3vowhf09FmKT/cwNv+Sa9hNvN+G6L0FwQsVjH9X2Dfs63kk7QTqw0nqkzNucC8Nk8mi+gItHhmvg+0zU19owx1pE04YEAMenXiv9CDmIey36UQfoYX3HbaL0XjpsY/p4d6Pjmc9hVSG60TVtu/Bj6c5ieWpSGprkf/JOuuidRe/ASI0Pkk220FqbofVaWrrMasN0pJn2VgP7rHLWPoyJQ48qmELZVTCLrJP2GcuX75FLzxNH7yJLpxhYuLuS5R4PhDfYdpVTG5JKrhCkURt1KKdqJMAl1AEPL9aDCynWbmUhZ5aUW0BmIm5AHMEYz5n37vMSsvI+sEd1/tmHx/3XZzIK59iwh7ws+GDlLWdOBFcgW+mhwRUR5eQaZYM3N+U/Pyja2w1G8LbDEkVT7pSI7XcZmPO+QIXXoNdtsp2OEfcdQRDyRLCXjZjAzbstFlhDZdyglUaxIu7jyhKaGlnv48oxbUMcqX8fur7CBYRei75ck7E8Kx3DeelUBvxLtMzqI1hj05jMS42HeJDVG92CqBfwlWv5nratUuXlA7Tpktq4jC4qd5efGhq4rA5PPPcR/b8fWQPTDDbnaQV2G13klMCu/lOMj+oz4vknfneISppRIl49mlVRTzt2X2QWSBfg0nupWVcCmtImfVOMgP2V8e7C7uTLFc6Nt9Hpt475rsu5Iq8QWYHIstdQwp20jfKQGGZdokF4jKGx1mb/M1X0dzGjgsNUhmj855XRU+ieex7wqSJjmLOdGasDjdYR9gkyngiSvQ4U8a0VAoFAZzYtBqSAbuAJwUGYdkMgXFB6fuw7ND7Jka5sPRdljxng47r25TYJCkcNyHDq54HuE1SdrzvKPyO6HKTldw80VFMmcntfnTudZ1RXdLNdUlxY6SbodK0TCQ0OzFB9FBDJ9m4LLpn3minEtlKJaA/U97FdzQxnyHThK6Z2Fyd6KQmywJjZ0RTyeJtznfptpniaMHAU8vQeXG0z4SyyW015ry4WXMFXlQJLJbZpOaLkf5ajW0JTW3BG9qrvPL73Fe5Yr1YzKP5arIDy5D76m0R3mU6912jxbU1zRH2aZccxebTJaFzYhySAbxVsvHDDC4rWL9Hp7EYZ5WZjrczc7CYw7k+NUrmtmGtJLjD6HJ7GY6nPU8j9SYKtwGc06rUu+budju+PB+zvbq20W6KTHC9Gs9Bwe6hfm/6u2FRxlsvhzGqYar+dzwhVsAR86Twmh/OAz+szrunIwEcDOtXSCBqluWteLYZt5C1azyv8bzG86rxrIHBWlHfYEcnbEB/btKfW0B2vxXMUmvaZg3mNZjXYF41mA+4zrIqmK9Aod8mND/3insvvJ2gSLeDOoXklvEa1WtUr1G9clSnOJGsovqiA/A7ILs3rs3j8dJylZhIJjwtZkCgTww8gK+MAcq5Lgb2gn4/Iaq4g8ZN/PolXc8GrbyhJKS9smveWPPGmjdWzhuygTiuF2V/PM7yTOsaXfTYLtvCDzTQA+YnKCYG0NIac+x6vrhQH5zw2GaRNjwrxu4Rl/TZNrvEbrBr7YSSaOfVNaGsCaVAaPSfAAMA55CH+Q0KZW5kc3RyZWFtDWVuZG9iag0yMSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDExMjQ+PnN0cmVhbQ0KSInsV11v3EQUvZtEqbTR8lmCAFUaNaqSCjI7nx6bBwoJUIkHJOhKPNR9aEMjHkKkbosQ/54z9n6MvbbsRt1kU402Xs9s7vW9c+aeM9fDY8kEPrPb2d+job/jZjTXMsH4ohhLZxiXRvlpcZ9P/hoN/xgNL0fD8Y8vz5//c/Hm8fT5f+z0yWgo2ZPTX0fDp8/wkD/hpVLN/vXP50IIG8Qo53gWnH4bDV95V5+FZMdFFJ3yVNlZcsi0/G8lW5gkqSmzxdgGCb6zbGcxatnOH/T74xN29rpwULiMYK/PEOdkApOfNUvZ5Hy+Lr8EhyVJ5rhUjk3w8KdHdED55cNnbPJLYJfyTGsmE+6Wdlv0Ed3BJ3+DYf6i7iIFN2nGVML10mefPqePidFgZv3TpA61Fgk3NoEf0JZZAe6rcjlAotwsoVU5vVhMC1CKH0RlPDdrQNujhNU7WyI0s10+D9BNX46G583FgC8Z7rwofpezlHw51ec3W8LLwPO05ZxtG1LBq8kGhIv68L7pg+IqkTV5GMDyQ8qPaBsx4EO73nsRrkEtTMadi2IRxSKKxc2LheXSuqpYfFYh8ML0WHMLvtYFA7Sf0qF3+QSzHQjIIT2g7Xb6ZyAg0o/8j/yP/L9p/utV+ucPy+N/h/bQ+zNirVQ2Gp1Altap/HY8sitzEYzXs9W2qzR1udemR2naoDT1IkVxPckGdWm661IHdSnXVJe6nm0NXZdx62RbyYjOcjErcxGM1wB/h4x5g961cv3JVvO1SvE0tVdF39j6obfm4vcBO9C33SdemfIi8VmZ1ufvnhplhA56rK7nCspzjUpZa+a4sinTwnErZN9WTmqz7N8qk85mLsEx1dDM+Ye8XTe3EV1F35atxGgmHn6ylrZiHqUzX294m9q2MN+28zEQujkOKz/cCPy92jrZ0NbJWlu3Ta7+RldaVV/o8nMa4P1tgObvAS5M8TVt9lRo/5aeui2AtjyrBPimNUBDj5mgX1BRYqLE3HaJeT9kJKEv6Stc39IX9D3ud+lTutdHWO7SD3QPDvt9tIR7XcDfFuUv6BF90EdY7lB+5M0V5Zd03492W1UlzdAHJ1FVoqpEVdkEVRmA6d/h2uujJA1EJ9FHVfIpQljvfZ8Euo/UR+0jLQrNDWKNfbRLOLX2UsZye7VeytoQD0U7dIAwGt/jZofEhJjsIavUr8z5DFvQcCZEQ8HW47DVhX6qO2S2LV6mQzT2eoMvha6C0RN9KVWtlcWO98RfKlUFJ9gAxMxavLQMsVndgdWjR2rtSRKPnnj0xKNnA46efc/Zgz7nziF62EKJHtFOn+NmTCfQRtjrQk5coWCnuLd4V8+cXZjDt9DLMdy/blcUl3ArTZSUKClRUjZBUhY9xipXlcSbp0ojVyNXI1c3gauV47+Br4kuVhH5Gvka+br5fNUi4cYmka+Rr5Gvt4GvJuPORbpGuka63ga6ZqALwke+Rr5Gvm4+X41OuM7SkK/sfwEGAB3xu3oNCmVuZHN0cmVhbQ1lbmRvYmoNMjIgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMTQ0Pj5zdHJlYW0NCkiJ7FdNbxs3ECVsowYW2GMuRQ6EfVEOpvhN7tX5MJBDgSYL9GD5ELgWekgFxElR9N93SIrW7koreG1T0iKEIC2HIrnDx+G8N8W3smCYwofhC8Ikx/DD8O3fZeE64SEFEUxB++tD248DM473xl9l8UdZLMpi+u5u/uWfrz+u7r/8h99+dut/fvtbWVzfwCJ/wixuBf7XrU8oparxjmDDWjDp97JouAYDmBGYCUksl969i/Df8tHvsJsXfaS78TYA2XTW+xn+bvnqxmh4gXfWGQrAf3F441s6HncgNhVRhmFBDVE0hEDjb7o5MGQjMGQKnOX2qHADHh8Vu/e27bDinFirBmK811heXfnoGIvotvClPupZjGMXbmsde4ny9b08JYvsMO21fRaEK4ul5ITB/E7AjCBjU0K5GknCXvnal68bUV7BTZZdk4amaaD8YpCHN2zP4ZpIwfqi5ZBT+GPDZN8Z3LrDVRnhdAgzIQhV1UCIR8GRe8oRGxhweFY+AAKUWsVoiPLZcFKZJaTRqIim4fBXLf/Y4Obtd/DLam7w99tFGNha5v6uLObeozjt09WlnwW74PCVNMy8rGHIB8gPuJ5H3y+c84wZrImVEtfg8PUEaTRboF/QKZpN0Dk6RmdoCl9nvLnB9ceyeF+vXQmjiYJ7k1XAYaiAg+B6ziBCrclUlI6KuAYqollPJYRYUO1vZYY4HcQSEgUfKqgyxEMgrkAzSJEhTgexFBqEYKa7lBCbiiiT6S4hxIpzUHZD6W4UxS31+pkFUezUa8fMZe+gsrdZ860XvsLCVZVLUKPxzMK3tUyCwvd1b30rILNbLBUndLXTdlWWq9udVbcHd5E7oGsiBeuLlkxSzycp6w5XZYTTIcyEIFRVAyEehQzIZP8Esl8RoJCmQ/XMQG1plpBG45lU31omAdW/QueIoimaLZBBp9A4Q7MJ9B0hAR1HiMPTdZ5A37RXFjxIoCwMDkIYHAT9cwZBa01mp3TsxDWwE80SKyHEgmp/KzPE6SCWkCj4UI2VIR4CcQUyQooMcTqIpdCgDTPdpYTYVESZTHcJIVacg7IbSnejqHep188siGKnXjvmzuXy+h6eUIbssGzqr/mENDFSll4KC1dVLkGNhi9ifWCsWv6xwVFX1RKruQkVrRvYWub+rizm3qc47dPVpZ8F++DwlTTMvIRqdfqBYYvrefQeUIVQZQZrYmHBGhy+nqBffb07W/hi9zg0jpBABn5P0WwCDeijYB2jd2CcQ8sP4jCIvrnB9ceyeF+vcS/QgsVSM2Bg071QF/HMtl2qHZ5xOybdbX5MTDauFsySSrfs5PnBvbB/HwHixjb8DjYkiODzjpNEWH97ouiciyZSsL6AGjkJ0k7kyDV7v/xo3dmrDP5ewGdCEKqqgeiPQpyMSoJ040T1pvu9qZNIupxwXnW0CTOcVGaJdjSeqU1ayyTQJq9AbVA0dXrDgBiZojMnSM4f9MkxdFAQIid+nIABJ16u9KqSB/n28+iSbYH64qkB/y/AANsKtKQNCmVuZHN0cmVhbQ1lbmRvYmoNMjMgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMjIyPj5zdHJlYW0NCkiJ7Fddb9s2FGXsNAMUCM0MtHspUAJblvbBHL8/XtttBfYwYIuBPdR9aLMae8gCzM0w7N/vipRkiY4sJ4vsBiCMSGR0SR4d3nN4lUlBBFOYUEoVvsyz8zz7Jc/+yjOGKfwYnhImOWaUUK7wxZ95RvGU4fCUlv+gGG6OWCuheVk0DYzxA6Hn71Xnjzz7Lc+u8uy77z8u3v99ef1m+f5f/Pq8WPD89c959vYdzPE7jOJW4H+K2QO2eoUIahstZ45oa7DUjDhpPL7GY1rgYE3U/v1L2GW7gkrvBXQ1aSfBZUCD4Wl4VN4aYKnfDdbAGvd3/R4R+1rAc5bY3wv7gmqv5cT+XtiX4DzcJfb3w77jwLpI7O+FfSk04Sqdunti3ziiTDp198O+4hzK0tueuqpGzYwYAvWmkr4KWAFjFfFd1Jc7VfeHL/bLFXvfYpscCrDbeaPW+rTRvp/XCSv0bEz7rZjRREHOSc0Jh3KiTKfyRYQFqcuS+KoDdQcN2bNq+dsNYC8+ATqrucGfLq5CYGua5cc8W3hM1bBf37zyo2BrOPxJGka+mkHIjwxbPFtU6IF4yGdmsCYWJpwB4Lcv0LOX7/Dspzz7YfY/5gWNCemdjktXzTwqZ46jrCSO2TiqWL9ZMcCJZSHWEKfNima/dWGvqOChe1l3hYWvSxEobrarsE7GuVEV4z52NZ9skt7AN61Sj/Vlsl7rr7xFDpjJerM4y8U3W4wnsc5nyMMBnKRcoxcsxNk+JxmM4Ni/N5EbUqMB1yPdbOBldLO/C+LtuoUHhYtY4YooZ7AhDLypVO5zNEEj9BiN0TGaL9AklrvwQ5gmZjVm/gGGnKCjojFG82VxuYJO24Samw9+a/iDM4K4LNqFCdwmR5MBfA4GsD92O1QOyGGClsoxKBzUfYQegW63EKwtak+dBJsEmwQ7vGAFsSw6lg/Q/BodFpfT4vItSHfcqVYmRFHfJ7UmtSa17uB4Fc611foMiuizQq4fQlE8KVvXcMx2q9ZAVcxkkm2SbZLt8LI1AJm1ZfvEK3QJ0h3Vp2sdzyzhWsVfvov1wCmQoRTmmohV4Kgssa8LL3gBnVP4jRulNzrsNAbOoPrmNhlDMoZkDMMbA7vBGb5eHdx1nCVOiMgPRugEfQE/0PkIRL3mIRKUZCJrOAmG8CgO1kRah4UibhU7KcxijI7RU/QNet7tGFp42pJjJMdIjvGgHYN6F2g7xlP0FfoSYXTQaQCCgnsonQwgGUAygAdtABy+Olik/wOIfByqhvDtcOQ/XK667UA6Ykxyg+QGyQ124AaKMGXabvCkpdA6dCqIYm7NEUDXS3RWDJlA7xAc4gydonG3vh0oDPAlgSeBJ4EPLnCxru/5y3CAH6JjKM8xwp1alQLOcmdjrd5OKGqtTxvtYfZS9eWeCJspt8g91cg9UUOkuwHbSDzZn3iikXhsoMQTMdqIXeOIMqwrZWhvusi1Pm20B6C/x6eKgK1zZfdg23gV58RadVf2pYpPtYGTv1iwh33Vf6QFyDXwMk3j/v1LI6zQI4/197mD8+zQKaNqjXBlIa000dJtW6sZ6z8xfaI02721moZD6oZaDeZQwt6mWPssioZtKzJPEQ9gTZFDd8OK/xNgAMwHtAANCmVuZHN0cmVhbQ1lbmRvYmoNMjQgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMDQ5Pj5zdHJlYW0NCkiJ7FdNb9MwGDbrNKRMkTggThzMEDC+PH9/cJm08SFxQEKrxIFygLKKw6hEB0L8e944yZK0SdshsmatD61ft37jN4+f57EdffyEKf4aR4RbgX/HEcWEUqrw9zgylljOs/5ZHJ3E0fs4+hFHDFIoZlgKwozEMM5pgYeQ8jz9K2uSX5IWGhgqmIb4zMdJGmGSJ13f5p1vcfQhjsZxdPDydPT519nPN5PPf/DxSTLpyfG7OJpTbzZHc73P/Sylcn2l6b+VaqkfypKHZCBM92kWa/v/36Me96M+POw1wxb3R/krQfWAJTPYEMYN7kPyx33UQ+bxJ9x/OzOKaWKKYYMRuoEewGcXvneTLnxN6jO5JqLIFE0TCEVcZYJnjRO86s+wSRNlOFYwl5bOL8cPj0uCULq8VPC0e3bR9WD5laGVOB9WswrDc4Ddaij0fDi+GFs8TwmLJ6dxNKrnj2dC16hdTJzXxnIVVpi9Mvpugm1cA2/QaDBGO4iDhiEQ6ADtocE+ur+UYXyBhENIoJDms5+gbbSFbk0na8KFxFwSoXmevNXgGIw4p/NBd+Fpg0niFIcQ9dB2fZJkRBVJPaiIJ/XAe1D/MrN5aUXSQcMWVKQ0eIMqV/RwYUFaE1nkvACAM3C30L00BNDqU40mtEjteUBfeWj3IL7f6JbWEWt1cMvglh3Ddp3ccncZWxTgPtzr9WbJUJv0Xj1JZT68hWySZCBuFDwTgnAaBB8E3zFs10nwd5Y+DD1Ct1PtHjYdCqpKP0BH+bGAw8ZuvFEcQ9uQXb1K7aQnLihuD6Jt9LTZJuBAoZgMPhF8omPYrpNPDEaNAuQMTubcBgEGAXYM23USYGWjrhGhFr7KIMIgwm5hu0EiFFQTqXQQYRBhx7DdJBFKR4wJGgwa7Bi2m6RBByqwMogwiLBj2G6QCKXQRDg7LcIlBKAuFimJ21kktYhUIl0lvgSpVIlU4qJEejXFlhjFFzOKFYwyriVKselqp9A1jijDmnhB6zkhS5yQbWAs5xMiGbA0Ia6+2Gq9inNirbokxCulcSH2+ZsO9YRnGYkTsk33V0Dw2ff4B++4Qq+bOi0RrizWVBGpr6FNM0ooV9fDpku1Ntl0ieAORCynuzQNTQnl/wZ5OsN899ZECtbElg6b99I0WbV522RxVUC4PYSZgPuZcpeE+FpsjyvyiNlK/8GVO7ABGsVyNmQ1MsOJMxmkeccRTdPFLyLf1JQ5PIe6rIZr0/lwnA6sPGZyGkejxTcvTayU+c1Lo8EY7aCb/gKGemgPHcBn7m2MGU0UCCNs893Y5juxmXMGFLQm7DXt7TVcw15Dw4GpRYgF1V6VAeL2IJZgFPyyJ6YA8WUgdnAokCJA3B7EUmg46YXtrk2IjSPKrNt2h/8KMAAZFq2rDQplbmRzdHJlYW0NZW5kb2JqDTI1IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMTY0Mj4+c3RyZWFtDQpIiexXW2sjNxTWJt4NeHFbtt23hQ4JhWQhsu7SQKGQNAnNQ6FdQx/iPGzShD5kDU22lP77Ht3mYs/YmdSTSeiA8Uiac6RP3xyd82lIEpJ8Gg0Fx5wKaN9kbUwFs12Stf4YDX8bDWej4fjHq+uPf918Prn9+E9y+GE0pMmHw59Hw7NzmOH30RAzw5O/nSshRBYW8H2YC5x+cb8/rbdFQRPJGDZGJopILFSaXH4qvXZAqBstopYZaqp5G6jlPOoCpmiQA6PJvn9JikhJsu9sYI4U9ijmu8Q3NUCOuN1zHZvwK6zcAyWYMOlAhx2ERz3hYevrhVvNeRky1QpLCCcbKVrSGCkBJTcpliKQGjspVsQHRt5yjwqgl3eAzCimk7vLmTcsTXN7NRpeO0wHE3A9polJJtcRHtAGsUh1orABjwkgOttF7/bOk8npaHg0md8Mx0yaRFGJeb6V+HI/8ros8B/xO5Tjxp44CpQ0jJsODqrnsYDVwVx+UsFaFI9q6JPQ5m0c1rDG0ugXCgtO6yKmJk0+fnKfTzHi/qHSdSUyNhXLnuH2GKacYyLThhQ/i1rfXZqoKOrNk3NnRT2vg4rzuZJONcOpjqSGDmyOhUpeaDYo6uWJHlLV36IdRNAYTWdIoy1obKPpLoxtIA4DG4jB0w4OYGxcqwAyOdNrgCehAZ5KoWcWq9F9HWqvDjEFdYj0YqpFijlR7mD2FLdHsbBIm6qpnuImFKegFQTvKW6PYsEVSMC+3LVJsU6x1H25a5FiyRg2pmm5exY3W+IkNA2y2MrX+X5/6W146S1e/RavvdzAcRWB1tj5z9fe8kQPufa+sffcC/jbgVvuAE1ncNV9j7i78E53EbF/7+3fD2Az8MMz34fnAAwIvDi2rhfwt4PGYKPhaW2lNdwGi9Kc2jm9chZjOwsHm7EbEDCkoO9gDND3floG3gM3sAP/HPp2ZBsdwlQ8LJnNP4OJmJ+Cw5ttu+LO3nkyOV0ggiosciYqQLMIxXjcrs0cjs1sZVx6T9AXzkaHKV7MeZPYeH2PqfyWj+0mHOd++8eZ/SY68Qjh9xOMuO8nwmaPJgvCB2qySRQX2OTxGV/ux8OyLKM94uEqJwObSinBZFUyKOQ18BJSlfqtJ2e7YP0+PMWFbbgdVGRnjzlDnkIVEvNd4pt6benZz5/txq+yXILA+eG0LqCesgJpHEnWa77frTgx9tvLnvxOyKecYyLThuw/C2XYUnYhKzJLhfZ7QJzI2nTfmSyMRVeC5JBzopBqhlMdtXbogOQNQjBvNZCEpWkeogjfgrggXphptJVJKCc9tBMdVtl46UKcxho4vVIrOzJh/P8RHssisYOzf2/h0dHhL6Nl9tZndF/aOiltTEFpI72q64Z9TpQ7yz37nbAvIPOwprKuZ39N7KegXATv2e+EfcEVKNW+6nbEvk6x1H3V7YZ9yRjI0qZVt1NJn9+JIjAaia+jPnyprN++2A8rrtzFfWLIw77vJWt990W/wooPU3fhlZhSGcMpbIQbOOoiEB87oDuIj5685R4VYC/vAJ1RTCd3lzNvWJrm9mo0vHaYDibgekwTk0yuIzxgFgKWQqLHBjwmgOhsF73bO08mp6Ph0WSZI5wSDtuSDFMuo+tGcF2wAiVr1EqrFDM2b2RRAGHRxGCjlaVOKolTlo3c5CPKYOFHgtPCQO5TQyn1dJbNpb0NwS4qieU1/AAmne3pBdpAm2iAXsLzFdpC0wt4TD+j6Qy9RtNreOcer8Bky44P7Gtr8zU04dUt+tK/f4m+Qm/QN4GiBfjEw7dfjbJKWBrklUyXc60plikvch1Gcq61lFikIqd2YaDgcy+ug3nk2nCcwgU0Z7t4O8VSUufBSwnZ+kJc+jNjO1yliTvCN+Eox85D8hlkAFlcxQ9UJTSpQEURXkZYnZmNwEJpjxjaFHLx2gGHNVbjtd9Qa708BT8Vkn0QFCE7tE+VYw662kBEcGxgW1kxcFNBRxNMSQ4ldGmKhR8gpXY0q60LTMtYF5xtPh8j1WdqPxZIuqTewjTc6IU+CW0mWqq3YZ16CZEvvvy4ORJD1YU2b0Xv+DVWggU7tUrvtEYwaUCuD40C3LqDVpSZ3rrYfwzi1aLQjBP9enIQSqQ9A1iEUllTxKkBsqGqYQoKKxTLb6vq84KigTIGdZ8qqP6ZZ7l+fwc+yb8CDAC4CocrDQplbmRzdHJlYW0NZW5kb2JqDTI2IDAgb2JqDTw8L0JpdHNQZXJDb21wb25lbnQgOC9Db2xvclNwYWNlWy9JQ0NCYXNlZCAzOSAwIFJdL0ZpbHRlci9GbGF0ZURlY29kZS9IZWlnaHQgMjE3L0xlbmd0aCA1NzI4L1N1YnR5cGUvSW1hZ2UvVHlwZS9YT2JqZWN0L1dpZHRoIDI0NT4+c3RyZWFtDQp4Xu2dX2wVxffA9/vkQzUBE4wIarAhGDHy9ycKgsY//Kn8C6Dy58GQGGNJFEx48M0no8QYDA/4ABqCESWAQbAgUEEthraiiKCBlDYopGBVjBIwJnrOb8Kkm7lzZnfnnrvbbsfzeWi2986cmZ357O7cnf2DxQOCAICBAoIgegtBg4ECgiB6C0GDgQKCIHoLQYOBAoIgegtBg4ECgiB6C0GDgQKCIHoLQYOBAoIgegtBg4ECgiB6C0GDgQKCIHoTsDT0fcX6vkRPgAsGCnDp6OjYVAJ6enqsinV3d28qEhXfKlHVYVMJUD0CXDBQgIXKuHHjxqgEHDlyxFwLtXzgwIGoSFR8q0RVh6gEqB6ppUODBFiojGp3EZWAtrY2rJTt4MGDUZGo+FaJqg5RCVA9gqJ3JcACRW+jRNG7tAALFL2NEkXv0gIsUPQ2ShS9SwuwwAS9ly5d+sILLzxfACpsQ0MDLZGt96JFi8yqquUbb7wx8sBTb1Xb4ppi2bJltETRmwIs0KW3chuL5OOPP6Z9ytb766+/tuLv2LEj8sBTb1VbLIzOzk5aouhNARbo0nvVqlXsgJmoyNu3b6d9ytb78OHDVsbW1tbIA0+9VW0Lag0V9sSJE7RE0ZsCLNCltzpuIg5gvdUnkQei9wACWKDobWQUvUsLsEBvvZELjZOv3l9++aVVovok8qAWvZEFDSJ6ewIs0Fvvf7nQEv31/h+BZmxpaTGrp5bVJzQZDcXWW/37LwsaR/T2BFigh954rTenTp06gkVXV5cVzUdvxdWrVzsNVJwNGzbQjEOHDrVKVJ/QZCqvimAGVPHN4tBPb7W8a9euESzWrVtnlSh6ewIs0FvvW2+9NWJx6tQpZOlN17GpqSniovLSgFZxnnpPmzYtYqG2O3MfjqK3N8ACvfVWO5+IxenTp5GltwVe221GXFTezPieej/22GMRC9WGojcPYIGitxFf9C4twAJFbyO+6F1agAX+Z/Tet29feqOh6F1igAUOfL0fffTRJUuWLO5FLatPaLLVq1dvqeTixYtWfNG7tAALHPh600uq1CeRB/RmNNG7tAALHPh69/GkPIre/QGwQNHbyCh6lxZggaK3kVH0Li3AAkVvI6PoXVqABZZYb7qOzkn5lpYWK77zkiqK6D2AABZYVr3Vcnt7+9hKnn766WPHjn1TyeXLl6ES9YmVRuWiF4qI3gMIYIEl1ru5udlKM2vWLJ91d6aZO3euFU30HkAACyyx3vR2htmzZ/PWVOVSea1oovcAAlig6G2kEb1LC7BA0dtII3qXFmCB3nrffvvtEYui9fZpDfXJ448/bkVj6+28psUH1YaiNw9ggR56a7q6uk6z+Pvvv60Sc9Rb/fvUU0+NrGTHjh20/ufPn7cqduXKFSuUj96Kc+fOnWah2tAqUfT2BFigt95YA1acfPW+9957rWQTJkxAv/pbCTz1xhqw4ojengAL9NY7LzBvvSdPnmwlU58w6o/eeucFit7eAAsUvXtB0bvEAAsUvXtB0bvEAAt06f3iiy9ikezevZv2adF6O2tiJXDqrWqLhdHR0UFLFL0pwAJdejc0NGwvktWrV9M+LVrvw4cPW9X4+eefrVBOvVVttxfG2rVraYmiNwVYoEvvfqFQvdF1strzZrS+R/SmAAv8z+jNnrXse0RvCrBA0dtII3qXFmCBoreRRvQuLcACRW8jjehdWoCFyvj2229HJYC+dJvqPXfuXLriDzzwgJVMfUKTzZo1y0rW3NyMlSWW5KXbqkcQRe8KgEtPT09bCbDuKUOX3oMGDfo/wvXXX28lU5/QZMqZ9vZ2s8Q//vjDagpVh7YSoHoEuGCgABcsDVatqN61kPl879I2RVVgoEBYYN56Zz4hNgwwUCAsUPRmgYECYYGiNwsMFOCCNQAeoDdWrnz1/uSTT7BIwAP0BrhgoACX7u7ugyxOnjwJHrS2th70wDqPgXnr/corrxw6dOhgMbS3t4MHV69e9amD6hHggoECLFTGjRs3RiwWLFiQWa5K4PlKNZ/z3qXlzjvv9GmKM2fORB6oHsEaOjRIgAXWMGu5ePFi9OjTkSNHRh60ecxalpaxY8f6NEVnZ6fzzbMWMmtJARYoeueB6F00wAJF7zwQvYsGWGANej/xxBPowW233RZ5MKDH3uPHj3euu9XUnmNv0ZsCLDBB72nTps2ZM2d2MurblStX7vJg2bJl6aE0p8nDrNh6Dx482KdEC5WFXp2lmDhxohlNLQ8ZMsRKc8cdd9AVP3/+vNXUFy5csEI9+OCDtETRmwIs0KX3vHnz/vnnn6wCcevWrZEHP/74I/phVYyt99SpU5HFd999R6PRW4lnzpwZebB582YkK2Xh3J+L3hRggcl3ymdm3LJlS+SBtVv2BGvQu9AHQaD3IzRV+6RXA+VBEN4AC+Q+5wRF7yxE7xwBFih694Kid4kBFih694Kid4kBFui6Ge25557D/PQ+e/Ys+mHFZ+vtfEJsJpig965rlxqazJgxI/JA/fTOXEfR2xPgcvHixcOVdHZ2ZmWqQu/x48dPmTJlchbff/+9uRbo0lvFOezB8ePHoXowQe9Ro0aZ9VfLgwYNstKMHDmSVmPFihXWii9atEgeX88DuPCiobfenhzh3krsBKoHa7hT3jmt8+STT1rJbrnlFtGbB/QtmLfebawHQeQI1qA3nZRX/y5evNhKJu/WYQN9C4reBqJ30UDfgqK3gehdNMCFFw2xH8beteiduZpYw2N8PMfew4YNs/R2XgYgj/GhAJd8z5yMGTPG5zwJxefMSS16q/jWav7+++9mAhVZpcmqZk1nTrZu3WqVqJqaFrFnzx4UvSsBFpj3eW9tKQ8rfo56q1zTp0+3olkPYQNvN/I6751SInDBQAEWmPes5TfffIPI750YzFvv2VmP0PQE85u1LAIMFGCBoneVoOjdHwALFL2rBEXv/gBYYA3Xe2/bto32aY56t7S0WMHnzZuHoncqGCjAAmu4W+fll1+mfUr1Ri5vvfWWFXzSpEmXL1+mKSELdL06Sm0+yOKhhx6KPKB6O6NBrmCgAAtk3WupvmpoaHDe9G3prZafffbZ2dWjirjuuutofOvOR4V1RjGJ1tZW615IVTHeLZnr16+3Qr355pu0qpbeSO61VKxYsQIxT8MxUIAF1nCnvBOqt+dTqth88cUXPqtPW2zKlCkRi08//dQK9cMPP9BkVG96Z2V9fT2i6J0NsMDi9fZ8zgmbw4cPM1YfvccYlH379lnrqNaaJqN60+ecjB49GlH0zgZYoOhdPaJ33wMsUPSuHtG77wEWWMMTYp0cPXoUK/u078fePk2ENej92WefWZGdY299k6bJ+fPnrTQy9vYEuLCf7+3kzz//tOJ7Pt/b4tChQ/fdd58lw/3330+fj02vjDpx4sRDlTQ2NloVwxr0vueee6z4EydOpMnuuusuK9n8+fP1qsWVb2trg1zBQAEumDd5xVe7ZUsYPa1DsYqjGRUfffQRVh5W2HqzGTZsWHrlawcDBcICuZPyKoEajVO1dlW+Wwf7Q2/rdoYiwECBsEDRmwUGCoQFit4sMFCAC5YGq1bNzc2WHrNmzUIP2tvbqVp79+61kj388MNR30L1xgSACwYKcCntO+W/+uor673wy5cvt94LT1EJNmzYQNV64403zLxqecKECVaauro6+jL6wYMHRzlB9b5y5QpdBXmnPAVYoOtmtH7BupUYXD3V1NQUFcmkSZNooYsWLYpygt4pL7cSewIsMO9ZSzZtlQ+CcFZVjZ+jIlH7aiSb2IIFC6KckAdBsAEWKHobiN6lBVig6G0gepcWYIGit0HReg8fPtzS+/jx4zSZ6E0BFlhivek67t27NyoS50/LuXPnRjnxyCOP6PWKV7Crq4u+Z01euk0BFujSu6GhYXuRrF69OiK0kWcMqgP3AoOFCxc+//zzNNqoUaMiD1566SUr4+jRo600gwcPVqVYha5du3Z7Fq+//jotcdWqVVayX375hba/Wk0r2dmzZ4ELBgqwwOQ75Ytj9+7dVAaq94EDB6w0M2fOpNGcL6Ok6Iu0TdS+NPJg586dmIXzgtgdO3bQlM4u8EnmCQYKsEDuc07YqMhqB0VlaGM9IVb9O3ny5MgD9qT89sp361DQ73aGvgEDBVig6J2F6F0GgAWK3lmI3mUAWKC33lgDVhxPvUsy9qYv3ab4PAgiqQ0hVzBQgAV66632fo+xOHfuHFZ666O34rfffttnsH///vXr19P49GnbTsaOHWtl9LxWasyYMY9lQe+bi1y3End3d0+fPt3M+Mwzz2CuhmOgAAv00Fst//vvv+w7gk+dOoUsvek67tmzJxo4yGN8cgRYoLfeI0aMiFhYbyVGb70tsPhZy3yRB0HkCLBA0bswRO8cARYoeheG6J0jwAJF78LYtm2b1Uc//fSTlWbkyJEoensALDBEvevq6sYWyQ033BB58Oqrrx47duybXtTyvn37xo0bZ4ZauHAhit4eAAsMUe8pU6ZgkXi+GY0yfPhwGg1yBQMFWGCIek+ePBnz1iYGvV8+QpEHQbABFih6VwmK3v0BsEDRu0pQ9O4PgAWK3lWCond/ACywxHrTdfS8GW3cuHG8BkE/Zs6cGbHQU/A+ABcMFGCBZdVbLZ88eXKxwZIlS1auXLnFg/3790P1qBI7OjoWZ6GqcfPNN0cs6urqdIT0Ij7//PNaOjRIgAWWWG/PC2KdQPWoXEeOHIlKgNxKTAEWWGK9Dx7M7aXbPqjIqg5RCZAHQVCABYrevaDoXWKABYrevaDoXWKABXrrPXTo0IgF73YGdOnt826dJDIzqn9bW1ujEvDOO+8git4VAAv00Fuzbt26ESy6urowJ71vuummpqYmFbDT4K+//gIPLly40FnJ1atXzQSqxG+//ZbWv66uLmIxZMiQESwyb15OAQMFWKC33nhtH86AxmHrrflfJT6vbVUJ5syZY2VU8WlGWnn2Mwbfe+89GtAHqAEMFGCB3noDt+lokBr1tvDUW43brYxOvWn92XpvuXY7AwOoAQwUYIHV6J0LWG69acYa9Ya+BQMFWKDonZVR9C4DwAJdeq9atQqLZOfOnVQGtt46owVdTXqhSHNzs5USXcyfPz9i4am3s1DggoECLNCl99KlS0+ePHmiGFTktWvXUhnYer/77rtWbTs7O+lqrlixYnQl9CKuK1eu0NouX758dBb19fW0Yj56qwQ9PT1WoZcuXQIuGCjAAl169wtsvSn6KfR0TdMbDRPOe3/44YeYhfMFZ5l647XnVt19991WRjnvTQEWGKLevOu9MWHWcnthj9BEefmIN8ACRe9esD/0PiGvjvIDWKDo3QuK3iUGWKDo3QuK3iUGWKiMGzdujEqA9dJtdN3O4AnvZjRMuJ3hgw8+wCxLjx49SjNu3rw5M6Nz7C23M1CAS0dHx6YS0NPTY1Wsu7t7E4umpiZgoepAo/m8p+zXX3+lGen5ScqlS5doRtUjwAUDBbhgacixYsCCHa3vMyaBgQKCIHoLQYOBAoIgegtBg4ECgiB6C0GDgQKCIHoLQYOBAoIgegtBg4ECgiB6C0GDgQKCIHoLQYOBAoIgegtBg4ECggdnzpyJoui1117LSghbtmxpbGzUyyq9yqXyQunBQAEhV+rr62O9BxAoCB5ovVH4D2M+W6+lpSUpmfJEpVyzZg1N3NnZqf6Nv1IL8YcxZigzSMpXOo4uesY19Odxcem1MotQWXQataC/ff/99+NvVWSrAipI/G1cDWHAERmv2dU9rv46UyqRzMSxBmiYrL9S/2o94j2nzqvV0hnjsEqtOKaZzHI4MrYa+pWzVli59zb1psmsCJ5tIpQZa4eGvTtDZ2LTPY1Kqfd72jdzGGBKGyfWCfSuGAk6iClSvCFYRVO9nbXCZL2t2poBLfNRRjgDFn3ENz/ROyvTlhhqfqyfqYcmIsf0OHs8KrAGQulFmzt8OjgxE5tHB6fe+shi7ZDjjYJu8qL3AMX5RGstnjYqRnU33esm6W2Nuk2cCbRpbL2TaoUJeuuCrI1L9A4P8zieCRUpts6pt+cvMr2JKdny0ttMXNXeW6cUvYPB0gZdnZuS2Bp7mz7TDYeOxjXxkJuOvWPh0/VOqhXWMPYWvcMgMs4S6N1a0l5XixSbY/6mo3pbZ07M32uW52YccxkNCTP1dtYKs86cxJtS/TVoMhpEGHCYI/CUM2CN137ENRpj8vgr52jEGmCbwsRnsOlXa4wz2LFU6Xon1Qorf8Za3qaf9xa9/2s0Jp8z7EfKWSthwNEoegvh0ih6C4IgCIIgCIIgCIKQK3qOgM4Dpsx9a8xJh6RpxBkzZtDpBmsyJaqc5sDKi/zjSRxzMoUSXxBiYc6G0HI11oUoTszZQ5rRwnnFiHn3QeSacKdnV8y5IefaaeJrVJzEX9HbQPRXVrnWfFbK1TI0l16uT7gKrl8mnmJtLJNNveO2jTvUvKTNOSGIvU1hrRS99l4nM0PFWZKm4M0J9BjnVXaR0X3OelpT8xTdWXo5MrrbqqoJ1Vv3vlk33Z56Od6snJOqSRuR/jblejNz3SPX5mNO9GOC7Xr1Yzd89KaYXdzHxHpb62XqrRd0e+pvrVlgrZaZPerFEsA5fRx/uMa4UlTjbE9/vc1r/JJsSekas1/o5YJJBzhLb2cyc+swjxpm/dP1Nrc7il4pa37fbHnahlHCxlJvXADG0FsXnbQWRRMPTqw6pOjdSS6csz6JdwuRS2//C1zRJTxWr7deTj/KUEsz+4UKr7H0jhJ28iqBdfiLKncyKXqn7w/XVF6OpTGPIPTQk7Sp6q/iOlSrd+Yhpmji9bJazFzfeA+vW0x3Hx0G0I6gPdvYe2WRsyUpzotU/fU2e7mqvbdPvyT1tak3HahQ4opZI6WkCqdvdynDrah387GGJc5PnFSrd/ohpg+w9tLxOqZszkki+eiNhuGalHFvUj+m6E2JszttSSois19SLDKVpr81KGbF6C8Rq26Z213kGmZrzCai3eezj7X6zsKZuF+G3DGmxmZfF6d3TH3q4x20JM4299970yMyhbqX2S+dCec6NLXojYafTr2rGnJT9Ko5e8pqaquVdGv4770zh3Z9g6Vx3LMpetcyOKE4VdGNk7Q/8dfbHGSmDGVNMvulxXWGgSYwByfphVoVi48LtMKMIbeFs5UwdXBiZvHUO/MQ02dQjXXfpejdmfXTMsbSO6lt11T+ftT/pmwXxemd2S/O7c7a3k29Mfm4H7dwksbWhsYecpukd0HmwdpT7/r+HnLH0PVqMeYIkg5z9a4TgzQxbXBnBzUal4xmuo3V6G2a5qN3er8kHVOsrduy3VlbNLRPGYTEn2dud1HqASUmSW9M3gyr1TtzaNeXODfb+BdEkt7mkDJFGyoqtdc8pHrugvz1NnXN1Dv94J4umHmGh57tMX8CaMzmdVYs3snoz9MH1f5Gpegdl2h+qMuN1zpTb88e7DOSjkpm+zt53/gZnuSMc007yU+8+KsZlTPCMVZ3pOhtYWqWqbf5U9dixrWrC5xfxZuDmZ0Gt6pnbiZJFYt/BtIWM1nTe9rWidX+KXprrGjWdpqpd1IraVAQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBCGL/wc0jQzmDQplbmRzdHJlYW0NZW5kb2JqDTI3IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMTExMz4+c3RyZWFtDQpIieyX32/bNhDHz7KbAgq0rgWaPg0hmmXpipXhb0pPA9qtBfIwYIuBPdR9aLMae+gC1E1R9L/vkZRsmbZgb3MTG2BsxzqZPB5P/H54HJ4V+a/DIv+9yN8XOScMX5xYSY2SxOB3qQW5+Mf/yggVpSRoWEY5k8F8NzV5RVW4weaum2Z/FvllkZ/+8nb8+uO7qxeT15/JxYcip6Wwmny4uJy2nfkTjEzeFvk4DvAJ5UoQ/Md9cO6m/3rib4WQZGkXbFZfC6WJd4Fm48obfy8N89m5G/r82W9F/vIVOvkLe7lAP/mQGWO6zoobI9jo63whrdOBm7BxJuFH1p6HT54KweK1bMW3sWDrMVYGi+2M0D66OtT6qxXvViQ3LIlWuD7Srcpu4+iPF0/9ynfLHT+KhdX/FHV4+lySkgzHzbzcFDBGFKGlXFgyROcvH8Eh3IMM7kAf9mE0hv6Pr8jwrN1H4FMg3FA763MMoyu4Bd/C6A3suevRJfb+HnrQq7svgoArRZkoEwkSCRIJbp4Emmpr5klw3yt5AifIgy4aCNQwj2hwqyYAtt9rEwHffeev7403MOhkg+CKKp6qhMSGxIbdZYOipozQkNXiv8IiY/QIjWN8rQuFUlFbpYIhQSFB4eahYGjFo5PDUSj7MzwH3MYXijxzit6HAzwKHHbqWmpNeZk2+6TrpOub1zXu10KpdYS9cBRQeBZQ0YZ/AA/gLhDodcpfCSwvTNrWk/yT/HdZ/nhKsJWJ5N/DpndCpR/K+z1/brjspkGlaaV3vRjQorx2Grgx/z8NQtTT2OulFdubX85hhASMnQOGKKmpooPA/TmRzwjBKOMxITKHhgmcuC730BogZU7gGPrd5wUqNJYLlaRSqnUBocrmBpu7XgkIg6EuAYQq/w0dtmIJrosAn556BeI1/xorsB5jZbDYTq3S97ajNyyJ1ky6pB+xt85RbG/+uUTsXf5s1qIDj+kgKed2Hg7fwUM49RUEFgN9NG6DhMfwDd56XP90NyZHcBOXFogNiq3P4GffW7s6A6sMjf6Cnz4MlnsShsqZJzfsc9fT9WPOy5HvbFshDeB0uSuJ9crMlfQV0gC9eD8PnVdnZXCIEzdgljtReARqz2wfPxR+gNEYL0knCbFGMkomFCYU7siZdG0U3lziN8a5n5x6MygdB6zjAOvUMVeKMpFqmiTkJOTtE3KvU7eCK6p42oCTbpNut0+3o3G3cEtFbZU23CTcJNztE+6BK5mPOsUrtaa8TLtuEm8S786JFzNAtUk7bxJvEu/uibfStNJp5/164m2JoV5xbfs6lpcbcyO6DoFfv7bDCEnf6+r7vzkXtEQAWFVRJk3jPqs9x620xFnZla0MhsrjVosU4soFZw0OXdmGQQu5ZlGuWeX+Qro5rjduXL61QaKJ5sZCwqcsipJh5pOhtcIFrAivqJaymUEvnqfWluoyapXB8WJGtBHYMnY4msznBN/kiwADAJG5uicNCmVuZHN0cmVhbQ1lbmRvYmoNMjggMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCA2MzEvTiAxPj5zdHJlYW0NCnhelVNLaxNRFD4TK25CFdFQurrLIkkYHwvrLiZpmrTEmKZoRNBxctNMMy/vzEQTuurGjWhX4sKN4A/o0kUXLgrdKAql+gtc1AeIQpfiNw+TsVXUC/eeb875zjnfPZchGltXbFtPMCLDdEWpnmtebV5jR95QgsYpSViK6ti5Wm3ex6Zlcjqw9t6S5NvtjF+L/m8dbnFHhX2Bbd1xbZdIkoFPdBv1PHABeFy1he9vAM+2HNUAfkJ06HiU66+TJW5yoamsJJQ+qwmrrelxrX+L/9PyZxOib5eDO0upl6onelFYkl4Rufyu63/kLbsvtKWOy05PT59nGXZGls+yHCbEWd4ybM/lgpVNNZtmiq6zgOowwR0ueryVJUP3ft7tKHaSm4sLsFNEiQ/cKUZYsltKYQ74HPypFi8UgS/Av9nWZsrAWezNtphZhD0FP9PcciP0JzZMvTof+hMV06peAk6D89h2L9aB8Q6J+05voRjV+bqsVGqwKXAqXWvO50yA4w46jSvAx+C/Oejkq6Ff+k5N0omTRiZOkxjNkkKCDJwKZcgGtqiNuAaeRqWAxeHVyKEu+CXg9wFWgkqjDJ1qMewzd5G7G+TeJg/cMBuVqrSaltflT/Iz+Z38Wd6RnwJ9XJv0pmz70YNVcUNTXz/8gnp+51G9UAWLVIWVVXT8k0oXMXOfxhy2TkvwGsM5OFGGApUOsjxw/YqZ+I3a5trkkNcn5ivk96p7se58qHPU+1ZQvxto6wUMB2cupiF8h/B2y4iO1IK9tbIxEe+6M/b8+nZya2XfbFrBdPPBfQZgHpxR/G2sYb8lbGvI5r+dqBrv/0sd/K0/AJ+x8FENCmVuZHN0cmVhbQ1lbmRvYmoNMjkgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAyNDcyL04gMz4+c3RyZWFtDQp4nO2ZZ1BUWRaA73udEw3dTZOhyUmihAYk5yQ5igp0N5kWmgwqigyOwAgiIkkRRBRwwNEhyCgqohgQBQVU1GlkEFDGwVFERWVp/DG7NT+2tmpr/2yfH+99de6pd859daveV/UAkCEmsBJTYH0AErmpPF9nO0ZwSCgD8wBgAQkQAQWgI1gpSZ5+Tv5gNQS14G/xfgxAgvt9HcF67jlSTNEHHcNjMy6P3040b/57/b8EkZ3IZQMA0VY5js1JYa3yrlWOYSeyBflZAWekJqUCAHuvMo23OuAqswUc+Y0zBRz9jYvXavx97Vf5GABYYvQa408LOHKNKd0CZsXwEgGQ7l+tV2El8VafLy3opfhthrUQFeyHEc3hcngRqRw2499s5T+Pf+qFSll9+f/1Bv/jPoKz843eWq6dCYhe+VduWzkAzNcAIEr/yqkcAYC8B4DO3r9ykScA6CoFQPIZK42X/i2HXJsd4AEZ0IAUkAfKQAPoAENgCiyADXAEbsAL+IMQsAWwQAxIBDyQAbaD3aAAFIFScAhUgzrQCJpBGzgLusAFcAVcB7fBPTAKJgAfTINXYAG8B8sQBGEgEkSFpCAFSBXShgwhJmQFOUIekC8UAoVD0RAXSoO2Q3ugIqgMqobqoWboJ+g8dAW6CQ1Dj6BJaA76E/oEI2AiTIPlYDVYD2bCtrA77A9vhqPhZDgbzof3w5VwA3wa7oSvwLfhUZgPv4IXEQBBQNARiggdBBNhj/BChCKiEDzETkQhogLRgGhD9CAGEPcRfMQ84iMSjaQiGUgdpAXSBRmAZCGTkTuRxchq5ClkJ7IfeR85iVxAfkWRULIobZQ5yhUVjIpGZaAKUBWoJlQH6hpqFDWNeo9Go+lodbQp2gUdgo5D56CL0UfQ7ejL6GH0FHoRg8FIYbQxlhgvTAQmFVOAqcKcxlzCjGCmMR+wBKwC1hDrhA3FcrF52ApsC7YXO4KdwS7jRHGqOHOcF46Ny8KV4BpxPbi7uGncMl4Mr463xPvj4/C78ZX4Nvw1/BP8WwKBoEQwI/gQYgm7CJWEM4QbhEnCRyKFqEW0J4YR04j7iSeJl4mPiG9JJJIayYYUSkol7Sc1k66SnpE+iFBFdEVcRdgiuSI1Ip0iIyKvyTiyKtmWvIWcTa4gnyPfJc+L4kTVRO1FI0R3itaInhcdF10Uo4oZiHmJJYoVi7WI3RSbpWAoahRHCpuSTzlOuUqZoiKoylR7Kou6h9pIvUadpqFp6jRXWhytiPYjbYi2IE4RNxIPFM8UrxG/KM6nI+hqdFd6Ar2EfpY+Rv8kISdhK8GR2CfRJjEisSQpI2kjyZEslGyXHJX8JMWQcpSKlzog1SX1VBoprSXtI50hfVT6mvS8DE3GQoYlUyhzVuaxLCyrJesrmyN7XHZQdlFOXs5ZLkmuSu6q3Lw8Xd5GPk6+XL5Xfk6BqmClEKtQrnBJ4SVDnGHLSGBUMvoZC4qyii6KaYr1ikOKy0rqSgFKeUrtSk+V8cpM5SjlcuU+5QUVBRVPle0qrSqPVXGqTNUY1cOqA6pLaupqQWp71brUZtUl1V3Vs9Vb1Z9okDSsNZI1GjQeaKI1mZrxmkc072nBWsZaMVo1Wne1YW0T7VjtI9rD61DrzNZx1zWsG9ch6tjqpOu06kzq0nU9dPN0u3Rf66noheod0BvQ+6pvrJ+g36g/YUAxcDPIM+gx+NNQy5BlWGP4YD1pvdP63PXd698YaRtxjI4aPTSmGnsa7zXuM/5iYmrCM2kzmTNVMQ03rTUdZ9KY3sxi5g0zlJmdWa7ZBbOP5ibmqeZnzf+w0LGIt2ixmN2gvoGzoXHDlKWSZYRlvSXfimEVbnXMim+taB1h3WD93EbZhm3TZDNjq2kbZ3va9rWdvh3PrsNuyd7cfof9ZQeEg7NDocOQI8UxwLHa8ZmTklO0U6vTgrOxc47zZReUi7vLAZdxVzlXlmuz64KbqdsOt353orufe7X7cw8tD55Hjyfs6eZ50PPJRtWN3I1dXsDL1eug11Nvde9k71980D7ePjU+L3wNfLf7DvhR/bb6tfi997fzL/GfCNAISAvoCyQHhgU2By4FOQSVBfGD9YJ3BN8OkQ6JDekOxYQGhjaFLm5y3HRo03SYcVhB2Nhm9c2Zm29ukd6SsOXiVvLWiK3nwlHhQeEt4Z8jvCIaIhYjXSNrIxdY9qzDrFdsG3Y5e45jySnjzERZRpVFzUZbRh+MnouxjqmImY+1j62OfRPnElcXtxTvFX8yfiUhKKE9EZsYnnieS+HGc/u3yW/L3DacpJ1UkMRPNk8+lLzAc+c1pUApm1O6U2mrH+nBNI2079Im063Sa9I/ZARmnMsUy+RmDmZpZe3Lmsl2yj6Rg8xh5fRtV9y+e/vkDtsd9TuhnZE7+3KVc/Nzp3c57zq1G787fvedPP28srx3e4L29OTL5e/Kn/rO+bvWApECXsH4Xou9dd8jv4/9fmjf+n1V+74WsgtvFekXVRR9LmYV3/rB4IfKH1b2R+0fKjEpOVqKLuWWjh2wPnCqTKwsu2zqoOfBznJGeWH5u0NbD92sMKqoO4w/nHaYX+lR2V2lUlVa9bk6pnq0xq6mvVa2dl/t0hH2kZGjNkfb6uTqiuo+HYs99rDeub6zQa2h4jj6ePrxF42BjQMnmCeam6Sbipq+nOSe5J/yPdXfbNrc3CLbUtIKt6a1zp0OO33vR4cfu9t02urb6e1FZ8CZtDMvfwr/aeys+9m+c8xzbT+r/lzbQe0o7IQ6szoXumK6+N0h3cPn3c739Vj0dPyi+8vJC4oXai6KXyzpxffm965cyr60eDnp8vyV6CtTfVv7Jq4GX33Q79M/dM392o3rTtevDtgOXLpheePCTfOb528xb3XdNrndOWg82HHH+E7HkMlQ513Tu933zO71DG8Y7h2xHrly3+H+9QeuD26PbhwdHgsYezgeNs5/yH44+yjh0ZvH6Y+XJ3Y9QT0pfCr6tOKZ7LOGXzV/beeb8C9OOkwOPvd7PjHFmnr1W8pvn6fzX5BeVMwozDTPGs5emHOau/dy08vpV0mvlucLfhf7vfa1xuuf/7D5Y3AheGH6De/Nyp/Fb6Xennxn9K5v0Xvx2fvE98tLhR+kPpz6yPw48Cno08xyxmfM58ovml96vrp/fbKSuLIidAGhCwhdQOgCQhcQuoDQBYQuIHQBoQsIXUDoAkIXELqA0AX+j11g7T/OaiAEl+PjAPjnAOBxB4CqagDUogAgh6VyMlMFq9xtDNa2pCxebHRM6jpGWgqHEcXjcBKyBGv/ADUmExsNCmVuZHN0cmVhbQ1lbmRvYmoNMzAgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMT4+c3RyZWFtDQp4XvsPA38ANtAJ9A0KZW5kc3RyZWFtDWVuZG9iag0zMSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDI3ODE0L0xlbmd0aDEgNDYwMzY+PnN0cmVhbQ0KeF7sfXl8E8f598zsJa2k1eo+LUuWLRsLMPgADA4W4Qr3bWxAxdx3wEBoDhIgCUcMSUjakKO5yEkOEmEMmCMNzY8mzUFIm6NN2gTakoSkdcKvpTQJWHqfmdXacpq+7+/9vJ/P+/n98ZOs3WdnZ3dmZ57j+8w8s0YYIWRBGxGHJk6YUlbuHJ28FVL+AL/GeSvmrArP+eokQrgGIaN73rq14b0vn74DIXkqQuLVC1ctWjHgSXccIfUEQqbUouXXLXx6c/l0hIJrEdr82OIFc+b3eu/xiwg95oX79VsMCdIL6QFwPBGOCxevWHtt7S/ytsAx5McDlq+cNwc5W+D48edpmSvmXLtKTLnXIPTEOcgfvnrOigUbN49MIPSkASGyftXKNWuh3vB5mtY5vGr1glW7W859CcdPIGQuQxy3De9EAjIIDwgVcMeAtud+jRYSu0EgJpEn9MOfQb0zx9G1M+EuRnq/qeOGhlEChTOXhXfTk3CFNBi3JBDOZDII8THhKC0NuWDLZX9B1o6I88MRUKIX8SQNCbugZUXkhtzFqAT1QHHUE/VCvVEZ6oP6onJUgSpRFeqH+qMBqBoNhDKHoCvRUDQMDUcj0Eh0FRqFRqOxaBwajyagiWgSmoymoKloGmpAM9BMlESz0Rw0F81D89ECtBAtQovRErQULUPL0Qp0NVqJVqEmtBqtQWvRNWgduhatR2fQF+jLsI8+y3/bev13/Oz6b/kl0CfF0H82pAAXVqIiZAYONIFMV0N/9kQxVIisSIVe9aMx0JN25EMR6MVxwL+DUB5yAnc6oKc9KIBC0M9e6OleKB84YyxwgRFJwNE88EIt9H8BcMNoVIoMKApcUw78IAO/lAGXjEA1wEWDgddHAXeg/+F+9D/c///j+z/cP/d/uP//w2fXf8vvf0/uR8IR5IOfX3ga+fgY3BVlPoffObpPL8mco+fpngBSQ23ZH0J70F68BO1FL6NX8Hm46kV0GLWiX0HthqEHgUd+irZCGTMg5TbguMmA64ahn2JfphVqsRtquhudhLzT0U3oCHJjb+YLtAFt5t6FqzZDixTAs00E3rsdj81cg2ah0/wtUPexwI+r8MZMfeaOzN2ZJ9CT6DD3q0wHtKEf+HceOpn5Svhd5g/QKrPQPeh+dBrfbTwALTUdZPsw9xBw8QNckseZRZnvoAYR9GOoAw/texIfJ3G4+wL0Ofbi9dxQuMvjmVTmBOQKgoQsRg+gI7gKjyQRYVZmXOYk9EQvkISNUEYLOgjfNvQS+gibhfOZJzLnod96QutugPZ4Gx/n0h2b0rW0oaGVekBfj4Ln+jl6Db2Do/gXZKVgFsqFhHB95j3o4b4gl9PR03DlZ/if5Cb4buBe5UdkrgSe2Yzuoq2Nfon+iP24DE/AdaQHWUke5lZDP/eEa/uCDC+B9r4P7v4JjuODxExOcY/zz/GXxLz0mYwCPRJDP0MPoV9gCzxpGK/BN+MP8J/JUDKb/Iz8ifsp/wz/G2kOPPWPQPpvR8+hf2I7HoAn4Zl4MV6Pt+K78P34JH4HnyNDyFSyjHzNLeaauJf4K+E7hV/D3yJsEbaL59L16RPpX6f/mSnPbAGdsx5tgtrfgx6GJzuMTqEP4Xsa/QkL2IQV+IZxBE/DN8D3Jnw7fgzvwc/gVijlHfwn/AX+G/4HvkRAgIhIAiRCCuAbJavJj8lPyYPkFHzfIX8l33IeroCLc1VcDdfArYRabeV2wvcA90fez5/iM9DO5cIu4RFhj/Cc8IpwXjRLNxuQ4a3Lj3eUdnySRult6V3plnRr5o8gcT7gqSBIVw3Ufg58l0J/7wKOexG9i83Qdn5cigfjsdAys/FS3ISvhZa8FT+An2R1fwEfg1b6Lf4a6mwhQVbn3qSKXEkmwPdHZAFpIjvJ3aSVfEC+4yTOxFk5F1fKjeSS3AJuLXcdt4tLcW9xH3N/4i5yl+Gb4WU+ny/gY3ycH8nP5q/hH+Y/5z8XZglvCp+KsrhC3CK2if8p9ZMGSxOlSVJSulM6KL1naATu/A90AB3KVZD4DLeJG84dQHeQCt5H3iZvAz/PRvO5cQQ4lezB28iNuJUUCteKg8ggPB6d52PQ1q+SR8hFMogbh8fgKWgp6avdTXTyz8Kuhv8P1M4fg2d7G+58rWjGN5GvRTNqwYhUQ5m/5Prwce5N9BF3Gkv8bvR7XsYe3E6e5iYCF7zEDxbqUYR7EL3ANeEb0QEyHDzXS4YdwMfj8bOgF6bicvwNl0EcGQ9c1J/7M7oFLSO/Q+0gx9vQvXg+vwjdgSrwevQ5egqkoodwtVgquvDrZAnfTBy4FRH+GXi6alyIOcGJbsVJ7gHxa/Ih2LVTvIw+4Z6H2p8iL3Dj+PPCZLwYJOBGtAU1ZTah64R6/jd4EeJwHSoCB/SnaD1XzkdgvwG0yizQaQdBuo+AHhjCjYMUL3DOWOCLaaAhHoDvfaAneOCgJSDj00GLvY1axamkDS0SFAxaB0DIm+nJaEbmKXR/ZhG6OnM36gX6YGtmPdxxD/oU3Yn24M3pG8AWh0ByPsFjhRHklDAi04s0kw/JFLKre/9CaxdhL/oSvi/AwWDwgZv534Ldr83syLwP3F0CGvZ+sPqj0Vl4yq+ghKu446giPZ7sy4zgVsHznkaTMk9n8rGMFmeWA3I4hp6UBDRHikMfp/Bv4HlvQAvI5MxabkF6CbTDndAKCWita0D/3MY38bfw36IdIPO7QN88CnLzLEgOlX2UmLl57ZrVTatWXr1i+bKlSxYvWrhgbrJ+et20qRPGD0nUDr6iZtDA6gH9qyoryvv2Kevdq2e8tEdJcayoMFoQCeeH8oIBv8/rcbucDrtNtSoWs0k2GiRR4DmCUc/h0RGN4VSsMcXHoldd1YseR+dAwpychMZUGJJGdM+TCjeybOHuOROQc+H3cia0nInOnFgN16CaXj3Dw6Ph1Mlh0XAbnjGpHujbh0Ubwql2Ro9j9E5GW4COROCC8HDv4mHhFG4MD0+NWLe4eXjjMLjdPpM8NDp0gdyrJ9onm4A0AZXyRFftw57BmBHEM3zgPoIMFqhUyh8dNjzliw6jNUhxRcPnzE9NnFQ/fFggEmno1TOFh86Lzk2h6JUpa5xlQUNZMSlxaEpixYSX0KdB28P7eh5v3tGmormNcfP86Pw5s+pT3JwGWoYtDuUOS3muP+vtOoSb24fWb809G+Cah3uXhOlhc/PWcOrRSfW5ZyN029AA94BrSdGIxuYRUPQOaMQxU8JQGtncUJ/Cm6HIMH0S+lTa8y2IDqcpjUvDKWP0yuji5qWN0DX+5hSafF2kxe9PHM6cQf7h4eap9dFIqjYQbZgzLLjPiZonX7fflwj7up/p1XOfatMadp9izRJmSy6xoPMco1h2So2Z3NmymNYoOgoYIhWeF4aa1EfhmQbQzYIBqHneAMgGnwYMV6XmQ48sSRmHNjarA2k6vT4lFKnRcPM/EHBAtP2v3VPmZFPEIvUfiJKUTzpZDc7rdCoeT5WWUhaRhkKfQh0Hs+OqXj3XtZFodJUahh00H5oIbTunYWAZNH8kQjt4e1sCzYWD1MZJ9dpxGM0NtKBEWbwhRRrpmeP6Gdc0emajfqbz8sYocHIrG1JzpQyxzj+r6nYMXzwwhd3/m9MLtPNjpkTHTJpRHx7e3Jht2zFTux1p5wd0nstSKcfQei5AshQJcOwsMOWszsz0oN6c4ovgT2RMPb9NMgBXshQcHpFSG6/Stg1yJPJfvKgtc55exXZdl2WrmRoY7348qNtxt+qZmzmoMJjXMVNnNDfL3c4Bq2kFjsrugOPR1PpIeGgKTQPJLIK/tszxAfTXEEgloMmG0gzAf1pS9rBbxkCWboAP5c5ePUeAomtuHhENj2hubJ7Tltk4NxpWo82HySvkleZVwxt1xmnLHNkeSI3Y0QBttRgP7NUzSs80N8/fh7giKCYR2IcZ0X/o9obUhHhDNDU3Ho1E6xfAs+wbiMyRqY1DgSLoyn1RvG3SvgTeNmVG/WEVvNttU+tbCCZDG69s2FcI5+oPh8FUsFRCU2kiPQjTAzQGQ9O0EAPLHzicQGgjO8uzBHY8rw0jlmbQ0zCa10a0NFUrKMYKSgCwnNfGa2cSem4e0gxa2kYtd0k2twHOqPTMEQQWB7GT2mcfHEytT8j9EwMTgxKDSS2BFqFJLZByBPIOwmj/YFyLA/vgnpNZchveuG9QInCY3WlyNudGyEnTNnamQc1ptpwbQXnag0/reoJpM+r3D0Zwf7aFHFfSD9W0UIlcGWKKifL59Hi9mTSPmQIcSE/KAwJyzukwvTCFo6nZ0Wsj9OlSddHrIpAYTYVBW0OmfWhksKG5OQzfKLTKvLp6bUtP4Z5BuFNDauNcPW8gCDzRdWiGSxlf7Q9SHdJZ2g16aauhNEo068Wl5v1gaVD7FJ5Jt+yPVX9fPxTVygcrrRXaPKt5BvBjJJVHC87WAw6VYAO7A9TkPlYTzIzTPMAEC6kshamSAzUZHb2PjI+zPWb75tHR4fMhB/2B0a2CzoqE5zfQXFEqNJTx/20mnJOJGhJ282Z1kH6Es0ea+DanFnU/XNx5OIL+AKMU9dbUBDwLE9lIamkgtbwh3pllDn3mZpDtgVTAB7KLR9JfI5idkamN8+ZAFcHejJoXhYTRkBCun6u1IDXUzRQ5zZsDl9FWzpaUujre7ZagEzCoKLgRfZzUxonhxoZwI+gQPAkaOxBOCbAPLwT4FJ1D9cZE7XkmgvKH3ZzmKXAtot0WSEmgzxbOWRClyjVF+V1rfVpHHmqHptSnUKC5OQo8BFUsGgGZ4faxlBgbRXfwtyoenbOAIruFFNgt0CAHVJe1Dr1bYHg00gBZSBFrS2g4ELS5dDOvmeLGZGMcWsLWbG8OVzeDwCdVOqU0r64R9FpYDY8Is66eE4AjaIRR9KgBbqRlNBbRjHA9+4ulVsT3JaWirhT2tzKuZTawuzIQkZqoZ5HYHxBN8RTxDICT9OHx5BnMLkBH0cYTikZB8yaAqwL0apCiqVmzoV0/il4a0DtMuwxSGnQDAPy+rwhvm5irCWel7GMmzwxAw/YCvXkadNMl4TiSsZLaHK/fL5vN5jacaK1DOiErJpOWohOywWLRUjQiEanjEhZb5TJ+A7mT3G/gn+exEYkC4YwCNhP8hozAKiXkSLSyD8JhKLUtc6ZVVck0IL5M2KxWoIJmM2wVi4Wlnk/4rFZxGlLNZrq1WGDrNwsJi7VSoPdS6L0EHBYSAhF8piO4Bm9G3vh49WyyKR5XL8a1DxzUjOuoQbW1nmpsq+7bBydRMo61k4EE1M0oJgTBiM1GAXlra+3VZf6TNnt1n74NkahNFKWqfv36V5BLrUPenXrvn8rW8jcMXp//wsg3ZkNrjsic404LR5AN5REHbbvEepnwliJLpWWYRahyVgWnk6nyZOeU4CIyX1hgnOdsDB7Pf0943/Gx71PHp86vPX/xfZp3Jj+T787Pj/tr3DX+Mf5V+Tvzpd6k0NLbPZBUWcaQ4ZYRzlHB6XKdZZHlU/Fz93f4gqJiF6eYVCvoXJNkQ7IryJm8Q+TMN8iCLDiB6pAXaDMy0z7yVmB0NPM3ZEIm1mVFNusQNSerNXNBy8robL5EYZ21SFXfsWHVlrA12jba+PyEyUSm5SdoB9nstPNsbZkLWufZREWBrZeda8v8DbKaxGk2RVVFevxVK+1FIL5ppR1pO6rX7mCdba1dZya7znB2jc8O1tkLJTWbJqkapw2qe1k6JZ2WMhKfL9VKEyROCtF6SV7KPlKI1kAy09IlMy1L8tOiJV+ociLljgudbBEf1w5ER7zrk2yqUWma2hGvORuPo9r22hr6s1UDQ/Ttg5K4KYmaAvs4VxtXlpCXcyasKEg2BeCwdblJsiLKQfHaCnt1bZwyUJUYLYjFqirt/SrK3R5bhQ073RXl/aoqY9ECkRuw4MSG969Z+t4tjbvK9neEn79m3ZN7brh295aHd1x6/BHMNU8aQpTvRhD7W2/84tWP3joBDDcmc44P8YPBxc8jbsZwnnwUdJFpXFJIGqeZFnDLhJXGBSaDqy1zVmtpIBKTKZUXpNti+4fCd86Lfr6vfaCvb3CIfZx/SHCSfZZvcnCOfYV/TvBa8VrXRXLRqyI3tlo8nonuRvcqN+cOWneqj6pEVflAUJbQEfIswpnjTIQxE0fa0yrG+B5HkDd5gMHOdzKVR2cqRmcZb3+dJ2Fpy/yhlXaYhbIIrR8QXzJesdCbGotLK1MWbPHnw9H+olgl3R8KgeDn43z30cxl7VYH69wVqiHLJ6quo9SsanLUqYVSorC0UmcXncsof9AM8TopnMNBQcZBCuOgIOMdN+Mj4KD+ORwE7BIfR7nnLKQBN11sommMp4BxOpJworYdtEmypqOpBgMDVdt17ROP46bVgUQeQhPRKrQR7URCnyxxHL2DRLBCqpuymGW5itQ+KnFwqsw7GJfxJpmyW8ty6AQv8FrcXj37R8myuK2iLNkEPIc9IjAdsqmoohzZnFLETTkOR2LFjOd+dKTnV4e/SH+NnX94Hyv48jm5ZfO8HR0fkUnmAXW3rX8G13keb8X5mMNmXJL+JP2tGn7xyGJ8z5ahi58Crf0J/yyZILyCOLSOst9h4IFf7ff4KgntH9hztNdiQGzAG8lpzK3kNqANHLcSrcRkAp5ICEKcyhFuK+ZxG2lsIVu4NjLlAPLxHz7N2nZcx4UOVNuRrKFNBR+qpMEtxcgLahkez+Go4D7Z/Nc/8M9ib/pcJqOJBNToccD08EkgbYtvQQL6e9cxCiQUciZyPkIiMroqTnDkMCmgE244nqyCB5sIqrwdJMtP5tAHOwZ8el7Xn7LOWkadsHYym07YgDhMGXwfYV5CpbLBiq2U5WkXc4i3g6L2gmRgxSUZqK6k3Ee3jOdUxn9llINOvvcqVTzt6olkOf317RNIjDSacX5wqGOoZ4pjiqfR0ej5GfkZ94DlCfUJv9lg8clLyRJuqXCNeZVlo+Up8wHjQfmA2ew2bzH/mXBKwWzrSusGK2eFJn82EeuDaKUaoVo70aPoDDqPjMhqNaGuOgah6mBMfsgqWOushYqByoNSEIB265YNZb7qzIYKTfF8jBFohIQSZ22EE1k9jxPZVsP9mKwmwpBE5Q0nqBbBV1Gpw35aCh4VdOnmwaULrksTcQAdrsJTEqZyTbICK9MbSHYmtubsdVmBP1gn9Q1UnvDq2CDZxHS9DhTiydVZH4pyNXjQcHb1hTjdsv4AUbZVl6nJs/BHbUETTjY1dOIIGdw2u2K12nlvVkxNdiampqyYwrUV9JcjolmzIMWoZLqYZeBq9uV9/cJH6X+u/uK2vX/If9G3Yca2Z5+4dekdeLPn0Cmch+XnMdn04u7AsuX/8e4Hr9wMPbAVITEGnBvlVlLOHXI3cuSoWzWHtufQthw6T9ejQAdz6EAO7c+haX69y4M5dCCH9ufQ5ky6k7bk0EoObc2haf11Ws2h7Tm0LYd25GCZXFxjz6FtObQlc4HZGkNbljC2ZX6XGGeyVBbxZ/mzxj96Pg0L7wsXw8RjCEeN3kDYyHHRUFB0BYHHJCxG/T5VfqcI7yx6tIgUeTx+pWinDdt4Bom8DA61Zf6aMDFI5KQCDsfnEh4q5DbCgJGZASORIlw499334FEbTu736qrFqxs0L6/ZK0udt2hnAAdYSYHOkgKsJDj+KmGjJQV4WlKASQSkphMmeu+AmZYJx5dZmQEo6iAiFVG9kKgubVFNahLOumgRfgdhqixIPqpFE0Cd0dvl0UIpMCcMpMPWTItFblosogXQkhGFiE6G5GWG5BWG5H2FRW342v2RkQDK4uM7TSoI5eoazaqqOYlUULsO48mO8cMXDPusCQSzpqamtrZmnNquttsowLczKzv0uoRidjpiTrMtgO0WVwBTRR/fpFvf+L/5gByrsl8GV0g0AcbrcxDE18iJISBblotMksvLQZrhA3JcYatw9WMiTDcuW9RWqYkyo4AAauvu8qeWrrs3/6Y3Hn52f3TW4FU/ba2fP3bTQD52z/jZc+uPvHiwo5g8tHz2wHue6LiXtFx77cQH7ur4EKDeFrBr+eBbqAD17Azq3YAFs7VQqBKGC0Jtfiqf5OcXBCuCVwapxyAOdFD3Yax7rD9pSFrqrUn3j/xLDcsti61Xu6/2H8//0PyR5yPfnxx/9fzV92fmc/jCQpm1zNlHqLUmhLHWicJC4aO8f/DfqWbVpfAiAd8CmB1cCwVci1y58uaofG+nZSio8xa+Y8KqKWFqNG008ZqfYDJTJjUxv8DUlrnYShkFiPOtlEtMVAIpb5ioO0jZg6ZojGpai20ky4s2Q1aD2yqQXfdFeR3eIZ5xH88Yq4LTrQSXxX++Oq6IkOMY78SP4hQ+j/l8XIsnAMQBLtYB7GWNnTEzypixM7ZTdsbMlcBUNJltolndtMrYy6yUk1kpX2hkd2yY5WTwJDTGPcu8is5TWZRYC39dzgVcAd5FK5ZVhToYB5YrJl7UfAtRIppvAY5Fea3mm1bYgO1CxKWiaEEx5/R0eRa419Otq/fNfbEpkf7bS8eWkcppd617/slr1j0vHOn4x50T7nxjTfrr9AcP4V0vT9t+8s13Xj0JZmQzQuRVMCM2LDFuG1TmwCqPo3wlP5Sfwi/k1/Ki0WYwGowWh81oQZwBmyh/iEg2luw0YENB2IEdpMCmKxKbrkhseofYijAbBVAr+lWep1MGYQC7ZwC3aY3LvP5vEjamVrQuFZlC6aZKWNsjkakShkPQePvILqMe1zx+TYMkL6w+C45/bbutuhr+GAhH6utblRtP0AZfjZOBQ1TWQcRNbVy/HBHPFW8w0NCmEgjz5scGL6md+aPBV1456EfOEB/b3XTVwKeLR9Y2ru54D56nBiCUJBxHIVJMm3CfyJCg0aZavA4H82gutNpsjPgqYaRPZAk5hRAzDTRDKETPhoIKnAkx3zXURo4mzET2eML5qo2QcD48Qtl7dHyi7CQqo1wUr6XbExQmZqEnLdBstzOn6kLCaLURvZwzCZPdQaaFnDSN3rsFbg3Ft9Jm9lBDwgZffqg0wKWsPFraCQ2TDhIGiUeFl8Wj0muG14PSKHODeaqyzDxfud5+veM2+zH7p/5PA+f95pdNhxwkJKsGUXwj6HcGg35D0M9hYvAHOUtIbSNP7J8A1rMNew/QeiJasf2YmGVQOl2KRs4BLJ3jHGAK5TWedxHCiUi0Eh8lm4CnVDwgYbYdqCWzyUqygfDkCClE+fjOfdsplyQvtAOr1KgXNBGs6aihztpZm51ZD0/1VqV3XLlRPYGZVKbI0FRiIrRpQA2qeWpIFX8OfoGUOYMMsDfCbwB8MN00UAle3dAQoF1rCUiShYDdqGhdTsxOC4OCTkGHgrYKaFJgsSJXJNa/Xz/40wRXKmb2xOUUgd9EiZcu9yeeoscf+HrP/Tfc/CA+7Pjm1+9evOrpVx6bFdq7d0jNvOM3nfh04bKfPNjsOPXhl3vrnz32xLY5fcF4TMt8ztuAE8F44DTjRY01ZH+IF5whi8VjpN1OVTMlEj7a7UYbYsoauTVjzgw7dUlOst6nGJgymfivd9J0OBCf6XDqq4SPqk24pTZwlx3EY8hAv2XXPRPjeXEr2WbaZn1dEYySyUuGO8a6RvuGBqY6Zrlm+SYHlknLTPMcy13LfI2B68iPxXWm661bxfukXerr3o/IB+IHpt9b/Z1V6sY4Pzj4kLDVedYYKdP0MWJkVI3EyDwZPaMxc07LeKjOuDO/S4N9T7ntr7OtYSrNDHeiqxRI55gpMuh2Sst6sA7tDL22PauoknHd9wBtpRuDdurzNqFklulaxbBPDYKpbCFh08+B5dzws8PPCr8BOt81AMftsziZlbBYeD/jND7LadRhVpmX4ba7VAJeR3HMoVJDYVOB3yRx2rJ3H13XsvbKpe/ufu+6uw4/s379M8/ctH50krwLDvoVz8/en858lE6n/2PvfYfwQ+l7vz6PF+OlXy3ZAtquLvMZ7wYei+OLORxm8nmZ3fcGERsWipupPe0RlS1WszUkyz1coSAf6hEUeliiFrPXh5E9zKxtWIpRlqTZY2WUP06W0S+yV9fWUnQHAtP+qvqqvVo9ES+nP8o3fQSL2zLcssXCD7dNt60LcJPdy9WlzvnuayzXObdYmp23BZ60yCazReElDOVhqmzoXOFRTKP1LLgKQIeL9x4hTyAfWZwwQu0EqJ7F3o2Fch0new4L2dfMDq8Mk7CX8nh4o9TtIinnIinnImlNjPFdDKOYGiPw1BcO0etjO3t52/CAFt+7+AgeAL708YSpk6t29mzDd2cVWLydqbAs41zQ0DHjn46zVFW3q0yfaeqsU4W1CGEOLACwTANFwbiJKirwzvmo2WKVGdywWoM9eKAOLe9h8Xm9QRfjpSDjpfKyCubDxivKq7NurKO/uxNySP270EdWiVEtJtEtwJNYXWv+Pcs2vPjYjRVjnXbTmrYtS5fscLZGvnzh2jeWLZx/8870uQ9+kcG3eO/fmrp5/W7nw+TaG+fdfOut4QOvLWqZP/vB3qGX7jie/sdn0HPPpj/Bt6CTSEbzKdsdkDkkPSe24YmJGOZqCMEyrkEy4eAAiQOkgRPQbLQSbQDnRUCPmnbfB014IXnhrNpeo9ZAo8EWuKujXVP3gQOSiOkcsLfWD9xHQUBVBX0OeKT+B09OnF5e3Y87ebJpe2ycb87MrKL1UZOPSsmMLqN/yJTvxajI5qWIl+pGr+5qeunERgnVhl4bM/E2phptXlvPuKkkZFXylQkKpyhONBFjJkEWFUAB5kNBSwG1jrSfT8ST5XRksb2cQRrQpVSdqiffO6l+/MtOIJBTiS+ZqqdEopRJp40NO/2bUruX9b2iynILSowcCC5HIjrTPT26kFvuXuFfFL3ef2Noh3976AH3M/5j/i/dn4Uvhh1XuB9273VzA3vMF0lJaIIyWyGKEqSF4Hcn0tkgsriVFps/pDhHhPJzRCg/xwHJx9XIlJPPlLnYmc+Uk88ESMDmZdIGLeFVvcS7sycGITuADhTpirpI1+lFuk4vWmPTJ5jCtoSN2HbGX9NFj0ocSF9W+DoHe7NDve2d4nYUFYOWjmbO7I+ExbAOEJpwEtT1AWhik1KiQXzFGeSZ8g5anAXfgwll8XINJ2iiNphUVRbToSPYI5Awu42p9Biu7BpAWrXXvX7OlBsn9sP9jq44eBlLr97ZfsP1//nY8x+RN59ce23LM+tv3I2nqNdfPXbD71aZvXXLsOF3p7H6QPrP6b+lP0/vf+FlrvJnB088uOPFF4G9DwOy2sLHwOGX0HjmFoTBtIiSkYg1PFeDRV4mNWWoFhE6pbfbkBWvpnZA3aCzs6PeTLAE3oAS2jBuLRvIBcHi4Hf45MmTXMPJk5efPkndkNWonR/IH4TubGDl5aOrjeRbA3e1IInGq2Ve/lbAV9eSCYQQn3n6DOZzJcddqAFBPltTg8ouAKC7AOUdAnEXZIkjAMH2LeegXNBc5RVlDHXZIlURcJ8iroiN4HQTvvNZfGe6qR3fvYfu96Svhkd/GCFhBvjfVoBQ2qPbw/l4qCGYFyKY2NSQFRko0Ej/G6BxEdKpws+v88TCRqx5w8YwdXOMMgNezCem6ClhpirA6M/P65q7kLPOk5odhVHq1DCbNw1nHaWLTKQZkZ0w/Y751kD8k3nSzJmSGfpKhgbN6vKQksw7qtFHQbtwMPzY0Ek/LiAZRINg4A286PP6vUQ0yWbZInOiy+10O9ycGOA8EWxXYOM1BCPYLdsiiI2rlMJnE/hV+5DKwC8y4DwgWpZj0glJoOXLPW4PQBInUUi0KFKeRcDFsWjkYfztczNuali7Zvz1d53cnN6Hq+96su/wcfcuH783/ZZwxJU3dm761Imn0+ln5pTv7dd3+BdPffbP0hCd2s58LnwsvIcUFMBTWYeN8VuxU3U6A55AgOdV3mnymAL8M56DyqsK5/F4AyScl7BNcEzwJPz1Qr1xujrNNtsxwzPbW+efHtjuuZ+ovhDH2UMmo6tbT7tyetql9/TBOlcsLGHp5zkwUgJEQ/tL0qa3GHGedZNElTIbsdYtAxDfJRQ2cO3fmIfzrESfbNCZwiqb2YCGXGeNUVboRJhmsz4SIjKErXnHvuC8WZ1jEkk2MTVeTXbOi4/7PuxMJpsC++iodXnrcpOR8wHRspzjcpAkipTztNP4aEEh6a/NMFUSUD5oHt6G+72JRzzXmj748qn0kT2/wnm//T0OXPfFXW+nf0vewCvwQ6+kn/zD6fSjB36FZ/w8/c/0KVyJA/ux6SfpT+FZ7kNItNLhLm4iC0IwlJo0ASBA5EysHAbH62LCRJvQoFjAjSWsaYEQqNdRQimznZ4WrGYOAA4xGE0KMhiJbBJpV5jU7FDUdwfZUJSKqNuijz7oQnW5tZv3Q12V2uPH1XfeOU5BVTwOTUZbT/eG8ukEojhNZFuObXm2FdjWQCfEo5QibDSJYx1EWGcbmfDLbCvpA8AGKrv5DBUK2ByW7ZVWthHMHMKKCRkMmMj0wendZH16XT5KAJ8ildQlLMicwwn6bRGmz3Kh7AKT+NqaGu1hktrTsA9i20BiAyJWg5MEDPw68xbzr6ApzaPMo6xcD77I0lOp52by6yzXKlstBhMRDNWWfsoEMoYbJiUM4yxXKvJ95H5ul7TLsId7WhLtxKoofQTiFARiAMzTRzAAaTBPtk7GCUyIwWCUTSaLRVFU2k+N9o12Yj9C9oBQ9QXUamjDfQ+YjbKsh57ImkY01snhhHmDCZuOwGMr2AR5SRvsrGxWqgsRICahZurLobB1lYrVNlJ3KCw0ChsFTmgje/bbBjV44z6KC5M13g6qG9v9PrUdjvw5h2eTdASuhiLGzq9fbW/fKvSOb73xxNbeXrrr2weNSZmmjEmFJs2ofwmZM5eAYz9AJPMBhQB4TMoM50omzdBwAp1ssmS+2afI9OTQWezwvYORaqVnpNrSBmT/aqW8PyMP9ILUXtVaPzWspqEISYonEO0vi8mADIJiMBuIlanaCvbVxrFAQXv69ccRW9SGo9h2Hy7EM/u4fVV4NhaOputeTNcLRy797a6rJv6Mu/zdCP7NS1X8mUtUw7wM9n8TSCWHNakkuk7idIJI2W7hgBiiwS6c+Tan8b/V406IYNZEmgOiM+slTXuyrJd0TQpPYCA0ymf/gCtYtM/+ikpt36uPti/poe2jRdo+L6TtvX4tOqjUolaGhZ3CiwLHhTFCd4IDkEJ8GZv7PI3OI8EehsSdiGPZTUzcvVk18FddDXyl29aLCW2Gg4kzeoz/oCHHnkK3tWwEVyrZ0LS6hk78ax8ac5QjWdBL+8Ea0r7Jji7aXn5FOPLdCGjnBwFs0MF+IyGsnTmv2fxz1iiGzDmNeVvq7CYWQuVwVRq8ZjeZxjF/WSMuJKI225XTDGa2JfDMksEpSQYicZzByBNilAw8B0bsUqcR43KMGKenH6jjwqIo6E0gsEge2gaCplMBXCT8TLElwyYcNk00NZpWmTaaBJPBqJspo6xPl4e18V4LVPn/AF00jY747NTRvyIYeVBOi8eTbIS3Rk02MeNWw4bWa5hOs9Nx3urqrTwTSk0/H4YHPHPIbKs0hGED8tJANTjFK9B1rYbEiGoat3BwRLUhUa6R5dVSga8abMsnB31AlmskTY0yMmGKVkuKE34OenzhoAPIPI3MA9JFyW/2ubLSqs84Me2qCayZMyAsgdDyROOJ2lqKljXOwMAcIKgPvsaRI69dToN0buI3gGRuvLQRkE595g7hK0A6LlRCOIZ07pkdeyRGfN7+LmIK8vl8NBB05jujYqnQyxOPDRJqPANjY4WxnlGxpDAtWh9bKdzAXS/s4HYI96AHuCfQc9z76H33p+hTz6def1CIo1JhkMAnhbu9u2Lvx/gid2ms0l0dG+UdFRyePzw6JlZnqLdNc80Izsiry58enl6wRFjoWha7IXZH8I7Y771/iPlMXuwCndUSqIZefC/RJ1DNe53eUmGgwBPOXcJJJTGvG1yJCOfwC4QeIKEwFLJyxFAYkoz+bnjLn8Oq/k5kLdf5Yw42B+rQJdXBRMLMCG2GyaHDK0okWFyAYzTxh0s3lpLSiK7FIjrvRjohViQGDG7qRFYmL5uvYvbU5OvRhay6gNW47ORP19yOzVNt1+YkPdXIVqG+rr6u2dpkEq1uYhM+gYRLQEiyemOxwlCJ211oJQmOkwoZCpOM1hBDYdYsCqvQYhPL6AZYhG6oP0NjCIpFCsqqKu2FFRpIg9R+WXTGgoH6x4r5f2xdXf3wQ4//8rX0sRdTePjrFLFd3fHZnhXPAVD7MP0nHPjD4lkzFzyUjG+tvmHmcTzrow/x/CO/SD/50YH06dvLkg/i6hYs/yT92zRkTr9dPMhH3T4A3gWgvJx4EGNGOWat5+sNrxt4N5V+N0h/JT/IMIIfbVhnfUo4Z5XMiNjo7INodHbrZ2dOPzv1ft5f54wRXSGRToVEmEImdFKDKSSSDLtx2D3RTWi82kY357bovWvRe9ei9e7BOkssLGNZV6cyU0yyrphkXTHJnYpJ5rNAS1NMcqdikpMuqphyg8Jo949TAUwzZdWJsllAUxyBZyTawCE6uFw0ImLSJJ+ia1xhywLrKuhZJxtas/GNr8xPX3rv7fR3q14ZuffGDw4KRy7v+zh9+fE7sOULbsLllpcPzH0FO6ETHkOIp4u5TaiddYJLFEIGgyQhjqf+qmwMAWqU6BM7VXulNJUbHZbDFiL7LbxRb6dcDW7RnE7jf9np/K7VaOxMEbUA3qzuNg+amdtESW2Cv2a8ehE897NdzicwNmjyGjqAJRigjQ4sFwSMjLofyXfzI+noiAZuwIvXfo/xhZcf5uKX3+duFY7sTdc+n7bsBeDVAca1AZpGQgppZiEyeYA7vsmZWeoKVTHmpAs5NN8VTWvQ4zJEXo8jNOjWWsh8p6MdA7hiP89ee6ETApn1RNyVKOrIVnJ3OnRZguqbXNDbWid0GldFr4aeImkph+qwYlU1UWnNEhr8p9Yp0dDldAhsW6b2URcZFhsb1W3cTvV14VXxuHpeNRmEBlxHJqqLTSn17+a/W/6uGHkzb+EVziQbBZ43WxSDKElmoA2iWQKIRYXCqqEkyQzgwwwwhKa5aBoX5s1OuMoYAugfEjmxjaxKGJHB/EUC2JMcwSYAUCZQ0GG0QOImT+RP8ad5bicPvY5xwjTRfFw6beZ2mrGZHqtW6ZRENkgbJSL9xPrBb7VRJx/84M/bruH1dmCUGn977dkaOtjLYHr8RpXh9Hh2go/OCm9VT5xQTpzYKmh7ENNO/K5j9FbeyhmkI5nzgFG/YUN5GNR3/H/zCewziG1c34R5uQHMPA9m3pxF5bVsNhU4N4orcJQD+xfhQHlLHKn4Nan/+LmOn+3+EP/n/SMKghUUHOJj6WFkBt51+Me3bwfTvxt4eS/wshcVkA1M0CN2k4Lt/YIz8hcaVuTzRjbfZmBbiW0LQeiZkLL5Z0qYdcKkE/a2zJ/22/2VsD+/v6C40kaP84or1ezemt3D+d/tz4tp5yG/mt3T84lRQBQpo4Ojw1NMs4IrgquN1yrXWTfL26z3Wp6xtlnPKZ9bVeDRsM3qtNmsNqvZaA+QiN8ti3Y6ZS14jUa3x+8LeX6eOZ4zknY84aLa1+NBkYIQA0tg9BVDqJvpCOWYjpBuOg7UhWLKg6I+1SnqekukVsNHH1wUaROJyXDhqsKNhVxhgVdXhl1RV53K0Pt/VIZZGCv+WxgbHbTnh1RhdljGd9abHY2jvmVWJcbjHXBQXcYmqLX5aQHYl5mT3A/FltQVSciGhLXaqg602QdCUgNuYm6lAqDV76u2Aay1w09JBKvVAif88uHXiVMbAi1GnwcwR8K03AfG3QqciwsYBskqXo1/q7PDeNlZHo/b44hyvUlxLAp+SKRcm8+O7CbNJ966/o13x5VMG5u58Mq0q6f3ioz5I969edf4ex9P9xGOTPjVdQ9+kFdUOP6adBPue+uOASap4xquov91IxfTKcYhuI0sJSsQh65gvO5bRVZxZBweRwiOIuIXVkEmH7/qdm3Zh/oZKhvXDg54E07SVa5dQcNVEdcQ0gO3HTgAF+wCU1kKMiSgJ9hdQTJ5LiQgQ5hqG/L0AYl0ureczgVcJxdw4f+qSbz4L90v/tA47GdJzQJSu4c43doxZBDPOooR165XyG9AH/x9LxQ9K/M5/xfhXdSHG8LMmQ0V50x6xHLoIp0GNtbXUfh0wg/EkHyWzwJepi495hzalEMHc+iATkPDeLMtRHQCa0SipG4eN49fw63l+aLiKq46OJQbJY3NG54/rHBE8RSuQZqVN73kNocSpYaKtmahThTpREwninUiyhpay6wRRToR04li6q+PoFSJJVZICrnion7WyuiwouFlM8J10WlFy01LLcuUhc4F3utM11uut96oXlO4pmgL12y6zdJsvV3dXHhL0d2WXdZdrlB2gK9XJGYPxPzGWA8cQ6iH386X942hBaCRLb2uC9wWIIEit6VXqLgIFwluoXNMXwj1MoZCbo4Ns8ZBcpIUs2u7JJufLWvXvoFEr6JCxWISIsG8UMAgiTxHRFxUWABpAOUCvfwJylV3+rG/3Y16sZlB5pKrOIwn4ka8Cu/EIm7DqYS5VyjscFw5jRYsUE1noUe0KvAEo43dJqmNOWrTqDPLwTpjDPXAPegQNQ3G6sFi8mhhPfzlEX3erMtn0gMcoI1wzE6hOr3KrouEvRMY2KdSyfH1nTczO29zFgSgXdUcqIu6L3WhHZqLBhqpHcn4Wbq5QFsKdB+12BjIBhZ/3aX6cO4BU4SBQziAewXcvQQmT71M7hBDj25OR4+gxbSZtRCpKM/OPhQW08U62ux1Z1i2x817mJqjDlZs1iHL7F/duPLZKRNnDUovn7Rk0U1/++nj324Rjlj3PpPaXT0Af1i/8fotlx56Lf33+/Fv1atvn37lmmHDF0U9c+L9H1+w8hfzl7y1Sdl+x6aZEyoqlpUMOrDumlNr1n4BrbI9vYR4GUpdxLRSnOfimKiCGEeSnSNEEl/ghSJMR3RBuRgo2KaN+bzhocXa1GScznzVsFntzskcUCgCm1xECoXPZaDFUdd4PqiVqK3CtR3f/uGH6SXSpHu+/fAeuGVxegluZTVp1JYY8UJcElWOxBG2iwDJyQs8VyTRcbKEzGrzvPFnMygE++EqYMKqgBVRYFUQu6qAI1UVtmhVBLem13z4Ib49veQesZjWYQ/o6M10QAy9y+pQwNyZOyXc6dGAN/NgmIRNhPhN/48uTNZqm7NWO/0vDow8aNa/dWBogKFmqJPdnJdDzHn5ntdi/77Tsof7+PKnJNUxkTosA/d2LASNsg0hXEMHXZFEZG3YVe60Qlmiy2cAYogv61Jczhl27aKFHJrXadDXJt3G6YSoExIQnTft6FQWKIcWcmhep+GmfHbektMJUSckIHJqqpsolEMLOTSv04n+dcZ+NEBxgnGn8VFjynjceNp43ighY75xlXGj8ZFs0hljxijnGzHCEk84o8gdBRSp3aG0jrsJJEcQeVmUigTEP8I/yqf44/wZXjzOn+cJ4sP8O3DE83ooKk/5wkP1GM9CUXmZVoF3sqkdqhhp+CZPmYWyCE+jgll4Oz/eQEPac6NRV9ew5ac1oNE0n4PNiOPk6lyl1f0TOMTLgkgRDItEYQPGbMIcsMC21tZW/i+nTl1y8bFLHyG2AIT7jB+M3PgzJisOgRMdZI/apv6Z+9xxnrvoEHnKzAUmS+V1Kr5Pfcd7xpvx8mGDU3G67UFBwqLbIlsUs9ItzFvJsQ2KbjMSwTql0JugTeRly0FNJWxWzUmbykRVgo3Nr7FGMxWwHMx8sOEzJ201OP42G+ItZ2O/L2ojc6ZERb/KjAnDn2m8l5o4f2W/ypT3vJes8j7qTXmPe3kvOEoutx5b7Nbl3a2bJTcLMr7YarNlwVhW7rO9mQ0sZr3ZOdz8HV3DChRhgq/FkTMD+/1A5fEeFvrR+dEQ3AU6EB3vdiKuDQNqqpAFIOPsugS3aDPKBlmSOVGN2UQlgK2yPbs+gc6cNyFgmUDCaJHdMhY5wc7WHghaYHLOugNmo7otOtj62DUfN+6eqMqtpcuuWvM0H7v3xeGrxpXf2LGGbLl6xZC73+o4BjplSjZiyYOiqA95tSt0r9WMAqHe9LE9DgeZ1ru3PRIShZKQ3RIysmghGqpwkMUsxK10eJXqUasePUwJdtLq5ehJ2uqcnotNULAYU67QxRaJuNgdXSzG1NU1y9o92pRqy3YWPZKNqgpp4xbZiohaRc6yACtKsLRs+TSNo1JZQBNpsfRKFwu5crEn7Xo+vTAoi06Qnsz90SCncVVu3MM9yj0q9pn5iz6CsQ++Ed2I1/NrDU2m1eZrLNd7tqNmvIPfYthkutW8xXK75y3bqw67GYW8yAwlPdob5zRmN/zV3W3txF+hNS8bsXGInSxC8Zzc8Zzc8ZyQwvgaayIcrexjxciqWom1Dd/VWu7VJaLLk9WBmndNisNcG1m0v1DPVKhnKtSjoArXuDqjoFwJF3Ht7NstCooNdNJhl5zDbEsmWVNqei4bD3UYFWTOtATDfgCkLeFwGd31CgNkP7OvhxYepY2rgFZETQ0Ngf3Qcr1ZhFQgINpLGIKwW8SIhiByIqTYlAlmuE2LnNZjDhGkOHKXWzu7whVFvHTV8s9ePv7lshVbb09fBPhz8a65W5Yt3nzbwkXbBo7aOWXTnr03b3iaC/S4b+mjH51+dOG9PXqe2HYsgzA+fucv8NTFt94ye97WWy9nxu2c8NTGm5/dQ5VE5nNSDV4ZpwUm0jmnT1qc2mxR2Fl9L4cJ9wj3Ike4dQg7wcYTDHll7hwi5wC3P3MAIM/+66GBaWy62s4ms+iYVbLT2YdGMWKcnT904QqMn9mZrvcJf/2OjgDPgevdwtPAFNuZGVBOWDAPf8TAGzkLoisJ+hDMG82WNRxHaFDcBBYhzxG/1bDG+Bc0Ac/GswlXC7uVeAPmsU/JBp1SrN5UM+5COyAe+joFWjsKeqpt1VrcJG5KBlqNZg5UL0M7PO2fitqs6y0iTpSi/ez2/nO4AzvS7WP6WQ9zN//9Nv67vTvuSdvTl9p+vxd/iV97EJ5ifXoSaYRWVLPxZnIxMLVqlwyq2oYr9qNHFAPsEzbpEeVHdClxmOO4520P7WCM2XGxXb2otRxtMWgvq6S3F44RW2X/fv0rRImu5VAxPn3P2+NmHNt0XfEVUVC+6UnH8DdY+eqjjkvvNDTvOvpSOj8dpm91zZzji8G6WpAPZ2iVDrq82fmkc8z2U82XWEApHzthl2SfeaR4laFObDAsEpcYDJXqQPtAd5V3uDrGPsY93DtLmGWcrCbtSfdk7wphhXG+usK+wj3f+2PsMoqCZSY3VZgqzzQv5xYIC+TlZtkT5CVb0GSikyW5EyRdisHZqQzUOmdhgMWaBZh5ljpfryGxeLPsSmN9eowR2egjTWlmI5QYAdJfWFTZB9pQUqWwxElHocysipL6ng7gAJs7p+vxgVZ0o6zoSkXJrtMdApgBmRWKu+0MdDPtj4LMCLN1u9lVgWxVJF1/ANsEFE2XGxKkr+Ptiq3XxscP1qG+fromPxtSn2t51aZ48mI8mTNElhvuRGMn6FCZcYowxThXmGvkcbKBTc4G9pls2tscTLxHi6WXciKg+oOSQZoviHKVy7Anbvvl77H7hr9sP51uP9yydUvL/s1bW4gDF9+xLv3HjpN/uRmHsOWtN9/69S/ffAPY/Fh6Em5gymJoVlngmxJejITdhOhKAoUxxrt5GlNJBZAuJgMX4ytUS8e4KG936gIHwMJjD6UnSTd/cxPc/BZQLv1Z1Mamf3UfOgMvfsBZ+J5T0Jn1B1yA70H9nLv+C7A/VCcw/M7iM/oP0OI0Kqu0fZ++2r5Ai+NIFLk8lVYhX3hEOC3wE2BzXuDyhVXCRiEj8KBkZcJpq8jonRhIc1VUVT6C8HF0Hljlh5aUfZddqZqL/BiOR4bsqjINxAOR0V2/LJpH4/nuaJ7CeeZpa7Ed7Oj7H+gamQF3PczjltZsmEeXclunjTyWkBKVGGUVI7uRqjf5EQ5MQUUreoT7kaLDKEWPS1O0l3ow4q8JqywD2lLyFaI8b88qQFr8vyhBbDV2MkoU2SqLY/CtoOBRJR2bAHYWXFF8/aZjM8adAqY8g/947PCu5hm/udTx0Vfpv6UN0KjjADK6ADLmoVL8Rc5aj3wrzgdjweFASShhwRaLUwgFhIKQ0yKHMCpSO1GfGvKo9AE8bM7Ww1CfJ4v1aCz5L3UElqRvPaCQq9cyHx4mJVzDfMPCM+xTw8u4+dJ8w1L7/PBawzXBzYYtwQ8M77ltUph2XDFdPEqJKB3tClAqwk7Qak20EKhYAL87G7Ew84RRryQNBG9BB4q6AbKiHA1blAOxitaoLI4cukqFToFnO3+Icoi6s6cM99kf0nVTSAdSIVCHRzVgh6sTllrPbM9KzwYP71GzGaA1skMUHqbxPOw1I542Urg/3rlQSJtPzl3v0a4t9WBLPHIjzg/TZWmtxeFoOKKt8wA4RW9AV3uwmHNBtmgx5xZLgIWaty53WgLamEzgX2POscReGULXodERMXtW69mYDnTjXDTFXdrv7TlqWd2QaXPJkGOLWjt+/M6tf0yffei2c3s/7ug/4Y7xq5947Ibrn+WnKEv7jOsz+Ks/zGtM//M3ze034TF4PX7mF3teufxx8tmGtofve/FF6KUegGRSoL/MeArltmPIoHdKzgBP9p1ULXV2hWoBq8VWeRUeabjKyMkGk5Fkx20VM1gWbAqZDQYhJBJU21FT26FN/QUS8ed4zBEMmEjmDbIcy4tUlsj4WxnLYcw7IV0uMQUrMd0Y6MQX7Hn6pgAHTYVLhJAkEpMcMiODfBTTqQUeH0gEkNTHkDAQw2hzLfixfgW0ujgJ+SwH79fecALuIhs6AkDVVKOeVS93jpbVAJ6iXcZgXxONX1LUE1vhdwKvbmBmK86sFimIVGNvpBocoU8O+KpJgY/N3zTQsc9AC0YymzxHBgMdcQM8JhLNe4yXU41Uhfv1jwAsw1LE1YN8PfGqy2/z/suvN3B7Wrnn5o/eu/eytIhOM9C1LRHhKRQibEXwfkfn25l0wqHPU9t1wqHbajsQ3cJ2MQ0Eo4KPg4occrmCdopITVaeLvuANpK6LVNhas7LnLCTZbp26DihnohT7VBpZ36clW3H+K/La87b5Xja8R/mD8y/DxiMDq9S6uccssvucLyhWJ2Kw6lYLW3kiYSDFp1QHqWrT6wJF85W45CVx+/SZWFt2Juw0QrZZqsr1Q3qnSqv/peXdXVfaKIv6/LuDNuP4Sqw1vdAzgEtyoEfWt6V3315V7cFXsma3CUmIKFJtV09u9WgzQMiW8461VZjH6GP6UjmDA1401QAZZp4Q9YyJcwIBS0OBdAW79IWfblc1s4FKFY7Yxcr36UM2GtLaKRR1zKUzmVejogrwmmASKLrUKa95Lp/+c2te3dM31HyzB3kw45DE2696zg2rL39wq868Ea1efuJxx5omVDrJv/5fHrdrPTFX792V8sZaPbCzN9IqXA/8uCr2YRWuNsrQ0w5tCGHlnJoMYeWaVhorNJI1UIhEBt9GGGzRcYccqvGuFUW3UHOZFULUAG2dL17TFcs9mx8cUGdvciMM5JhuHF4o7RK2ijtlHgEMPhRKSUdl94BN4KGnWXD+y8w1pXoNBV7uY8Wc5ElqNWTtLEoDWAD31OoLWZxtuZISEfIUuTF/fYt/B7iYKvVtLnCsxdqWDBRRw2dwbBVVKiv50wEB/ZxbhY4xpmoJ1aeMC7HssViU2RjG9erZbksMr+svLwsC2iLPCJ7QZktWlVh62+rcEW1yCOi+sfWzF3e89Zb9x844IiXhHY/og5e8BiZtwNLy9O37+j4ybiefui42sw5bh84R334EFMRns6hBp3wATGkP+uXkhwpyl3lFetmfrvowhw6mkMX5NCRHDrcOUa5vo4vcBYMNI42DiusK1hQsN54h/HWwqccz/V8hbMYPX6vp8+Ynh94hACZRohajmXvLMMs4yx5lmmWeZZlqWGpcam81LTUvNTSGmstttKJocIe/QpnyA2m+bH5JWujaws3Fv5EftB8d8m9Pe/p84T8jPnx4idK9sd+GXOX6AGHBToR1YlCnSjR4i6yeSgR1YlCncij4wb2UPUMQ3GRWeb94ZiLN/XO89NXOBX4erI38flqfRN8s30v+k75RKsv37fSd9rH5/vu9BHfSwByXQhpb2lLOGl2lUbbq/gdTBBWMaFTiPud7ko2lagqtkqMe8/KW55H8oIuiafVYCPe2uoINsT9WcJB2ZYP9jbl+7G/0JdweCvL6eXllPl9Xm1L2d7H1pD7wvRKX5he5WPrHH0M49CzQ4ys03xkZpdK3V8nFZbC/Q4Eq98pxaW0aHqbUj2Ao1QL7xQp8SVrydKjeqfvryv1s7pEiksrG8uPl5Pa8o3lpJy+kq4QsUpl16KHtW4g0xhBa0iJQ7SS4azD6q4LF1qZp2xlD2INs6FN6ks42bAnW7qh2R+rFqMFJsBacBph+n4cgnx9s++KSzbpYaFMmcdV2K8ez8aLWWITjRDMeWtIO33ZVJy+Z6GJxX5QD4POgdKdNnecXdY79LpEorhXKCo4e8Zsql11qJxYYAkHkLFECmChF2xCTjiMKNEAKohazIYecgCXFBtlMc4HUL6aRwed6WhTjbZhyKM0vmnTJtRZG7pgkS406EygmQIJGWGcZ4rF8npry4V7m3x+vyuPIUmXNlKtLRe26a+86rQc4Hr0JlWVdMHX92ZZ4RsiGsiM1bZYb7th/bVVRT959f4JQwaU3jXlxpdm2FLmNUvWL3W7ywK3vnxv3ZJXbzz1Ib4iuGz1gmFXRL1F5aM2jR95XUl+/KobFnknz5rcPxrMc8iFFUPWz5rxyPTnoVNWgof8vvA+Gomm4yrmgE3nI2rYHYkUVVkqlOHKKO+wyIjCEaNG1k1Vru+huIt64JixNC/Wo8rfr3poUZ23IW9mpK5H3aiGugXeBUULe6zzX5+3unCz91b/jrztka0xn6JOVBA3hUIb2VrcxzTRREyS+yi5Cg1FY8jR1qEDOTmfIo6BOBxfFSfxI3gcKiZHD5ZdVWiVsNRGbklY1YmDUaH9UWthH3UVuBpH8DMoQB5urR1QWgj5jShKHk4Yw1W4ylc/fUd2Jr29g8KGZPuFDsot7aisvT0JhuJsu9pemzzbbq/OjtTRl1QEEoHS0rKB1uIyq2KdMsVkcg8cwxmQ2z3UkD8Qsyg1sPm1zOpX2KvLayvKsgCgSBRzX2jZv4LTlp3272evqiSF0QIeetDOV4QL+1eIIo1mLSyG3P3tdOUYdTgZTiiOsddg0uWs0PkK4W8bsntSw54lj/9t9fSHqwv27wz1yKuqW735ufTek1+mb3z/ffyTf2ARz60/UPFN+tn//CR9W/qboVPnX49/gRPf4O2r57x18HfDpzktaffNUwesb7pq65xE09LE42NmLv7dpkdw7aMzkz/rmLPDGii+YiK23Pk0Lnjh9+lFX/4j/fAzqZuWfLRh9af3vPT7Cx9jKw6/+freN9Of/PGN0mIfHnvbfUNvfXPhtl1Ddr4NzLM1vYSPgKmzgzv3PmOetWa1l3qFOkbla8OpMMkP9zBH88pd5XlX5q0K7wwbBnoGBkZ7RgcaDDPNszyzAksNy8xL1BWeZYHj4XedH3s/9r8bOus8GzoTzoTdUR5Ug6uKH6iO4EerM9RPTX/JS6smm8K5g+w1O+6gYkKKr9sQoC/H+vk6sWiwzlf4joxVOSE3yhtlPswGAsOJbEjzZxR8AOXVQ5yZjs1dTaa9zkOm45pWFu68FjsqSMUPQKXs4lQfQCWEfvgNS/qLldiyu+yLldRuL1a6+P0XK7GpGmynyhX78kf29+Jub1bqfLFSHIDRv7xTSQu8r+7+SiWk2BQ3U1WKCYucGGRwSNQn1eLV2VE0l/7mArauutjG5QzxbX1i4N2Lt72z9JrTN8y4s7ftqXXXPvf02jX70kuEl5onTdqRue/x9KXtYwd2XOKeOHnizffffOO3wDWjM+f4IHBNCerPFTCu6Wm0GEt9Fn9pD0tpabWln6t/YGDpqNKkJVm61LKktLFPs2VLjwfcP/M/Y3GVaLNrbITjnPZGlad8z5Yc9B0tOeE7VfIb18clhmFuHKIDLTbaaHZ7V1xvFR0MmUCpfE++N96ztLKar+45ir+qZ52hIb7QsCS+zrzV/Lr5W8u3cVv/SgXzallhpac84vTO7rGyB+kRLFNqlTuVR5SMIjyivKh8rXDKUT3A+VCdYs6OSX2pj1JdSLD5XYWZRYW9206J6WPCXsYqB+oUJch5AMTs9/bUbK1S5+0py1dO897jDAZpVEn2WdDwYrkcgHqPOeocBGyfu6CvKzC7c5QxYQIvgFn5okghjUHKRpT9VVsuUMhG/wrpCBplvkIN3zC89YeEiVa7kFW4UH8xXmEbmZlQihP0JR3hWJ/YizGhmkbSUmaOtWU+0IjOAfH9dbG+1WyxEx0Nrz5eTR6txtUeCizozT1a0HjCWOcp8haU6ZJUpnvSZVngYasrK3xZPCWSfLFWJKJTD/dw6tEU2fv0rhMVFtLKxtJE9uJakc2sikysRDaeLjLMJfYdkONOZAWFvv5IRyFgNfSTzM2If/opdTLOAgiBQzbOlHNxkwZDdBzCXqgXZ14mSNohxMXjZrPSAwQMhE0JFstcOaM5k9fjCTq1V4p0YYRaNofHPMxO+0JDsPqzL8ULzNUcTLLz3WBuPNEYJ0oK0V54AJm4mvmHl754bOSaq6qWfbQIVwzftuG6vJT36ndu2/bsRNXoKTgW9Mw9sXJW+Yolix+L5d0ybcRzm8dvGu9ULP7CIvnqXlc0NHmbto9JzBnd+9rzlzZfMQB/XBJUS8aVXdU4c8IVPwY/5whCeCs6iTjUnwmxl9B3jNRobxZ5EfGPQp5H2Ug9OPBJOkJHR+ix/iaRPtp7RI6cZK84cAAs3yi8C97uj9jNQk4jtvrKfH18Cd8q38/MD1qesRj8lhJLynfcx/soU+X78yvzDBbObA3K2EXiTgfPiUh+xImdGYfGOofqHAm+0//y6BzmyapoEzAejzhyN9ZGz/tmR8/jwfzKnQj7Egy7Jyx0oNzJBs5LWJxUARs675kNlfpbNlTKmQ2c+FJ/L9tnzGTQwXY2Kooe9/qO4SMogi5iGXnj8Rz+oxM1NSodBGPzNO3x9iSdTaxhb+KqtmnQ1qnaRKMkGkAGVKM9gGyiNYABfZZu2oTjAEhXBw4g2e2gr3foBe6uKFtZjLKMtZGLinJt7B3cWkAfXS9xc7moi9vyyCMO/y3rxs4KDCifPOzUKe6BHU3LKkdMtz8kj2icu+PyQu31D3yHcASE24t7a920wLbMScaoY5wz1ZlO3mQOWRUFebxaMJq9WzT6D74waH+dPWY4CnpM01dKnUGmzWpQs0vEs8vTDP6wH8Of3/tvFzDBtZb/26i2f12W48sNRtajkcerTcnchUv6upyOGu3d1YF9iplFtykKjW7z/nB0WzmD8iQSYcHg+psdSI+7xy2/u+Gr9OvpbfiGYw8nx/a9NX2bcESxLzi44mi6o+N5Du/YMOsWl4VOYmXOcWfof6zEh7QZMj9wq9HlqSRhh5suODif8NmdlXEHLjQ43GbscJtAImxgMFCFu1sckzunM9w5cUzu/9XalwdGUWSNV1Xf3TPpmclkZpJM5kgyE5IJBHIQhkQy4RSjchoTliMQQECUIyDqKo6KgusB6i6rfq4gq36sx5JLCOgnCK5+oq66Hrs/XF1UVsWfirqu65XJ71V192SC7k//2Ele1evq11d1ddWrV++I+LxU4SiPaTN5mR6T10Xbuzc9bHjZsOFNazB52QjnpRqtTIPJy7ypeqkGk53W74AXH/Ji77l5zPKNKi/lfZpHVuftzOvMG8jjqbNm47u0Wa/UZnygPc22CJNYMeeI1CdZSHlJOa7wirWSpaSdIyrspqjRPNOF+dJgmxSmvaQQelvKublD1q1MUeL31ZQMR4nMWrHemiLA55fHO7Lsup2Ihh8QTnTwtnxkl535iCoqlZVdDbwVHAmclYo5J/OUymkekQmYGiwXlYb3e5gAUIM2L5sAjqY413DFa/N/O82h9WrOi2fMuKWu9+7eMy+aVtNBbuvvuXnUlBmztm4h8W+PITKwKzUDj2W6kC58vbGYmdbIT9dg+uuwkPQCNLGQtFNQm4XY0zTWK+HS78ZC7KYH0UgzL0SEOr5KuF4QvLIgSDxPeCEbYbtGOLeNdwqalKFvWMT0DTVR8jv1bdBHe715Nps9oqrbNBzUGrRpGkcdUCRqmdKc4ZCCccYaG8K1AFOWY4vhmswU4xhLpeVmux853WMuVcxw9MN3yzzi0sXhBkPV3LA8ZUO1s6pqs0M2nLtkyQ49KjvUfKxkScbrpH5xY5m//C6nBO80oax06lqmGiJbBIeRDBvuvuh7pTO663tTywpHB2tH91Y1/noqf/Lll7/++Z1ZU2/j536786lzFkN3mkdd2sN7VJGd+I1FHRuwkuZSst0ycxOslyJaiGIh6agkgvWWxbSu72lrQoZFHkPSxnqS5SxFltM05luWLUSwENFCFAsx450kaptdLbZltrtsvwPOWTibO9v+S55zYSIjm8hJgqpxEvXGYj/K8W6O4zk7IjY7D22DPAa8AME7EyrieSBBR1W+jyzdJwhqoiBYrVrhUFTDiaI5IaNvXe3DtQm7lCgsqpaS4Rppm06Y1oXdXY2Ig4QIR4z1T2bpZyjBkUez+vBNbEHhIzrg0o7AtJR/z8EWr2EA/rLe8om6eUSMv9LxlK7r0MmbTije6nYxrxMJrSrOFQ6Pc3xBQT09RSuMAnQVym1LaHFbcnrclojGbYV+yE3nFJZX9CE/FMvfa+MVkbPDmF25j/oqRDbeCrkSq6qqNGKuOMM1uIpJojknJtv7N5Hf3P70072pGrzgfm7vd2fdn7qX8ORX/RfCGLF04H3hEuCkCnAFbVOPtpMVBVSuaUyaEJ00LaBYCFXa29FqtK4giTYVbEN3CQ9x99v3c732Z+wvoRMF/yhwZrkKnAUFXJk4zFnmDwWn2Jvd5+c05y4TLiz4uetG113cnVl3+Xfj+8hu52tZ2ciN8hxuRx5Ptbu6h8WZDDU0LO7QEebzswM2Lj/AK46ofhaKUi2OvKDXGssHWbS0qbk3GpKxbJqa25tlNmTLuYG0kbllY/4lIOb6r5Py3sySfA3lwPFawwU9rzscNj6fLQLwii2bcUU20+jBNcQFPZ9hL26K4ajwhn7YfO/hM1JH/v5x6s//tQdPOPxXXF53sOrw7b97d+5F713/23cIGXXq2yfxxX/6Oz6v6/hzw3fetit16tbHUid/8Ti8lNqB97mFNCgOzmV8k2MJuUBcR9aLW+xbgKljcudejc7w+3BeLx/QFWUI7zTUJCVtyadEVVUeQihnEMqD1uJyVLPmpJq1kqgZWv0M+cDyPJ1KsGV3bV4oG4eyE9nTs9uy+WwcRZYTAWTFIkF0kmhwTU2uvZYjio8dpo23qeprKhh9HGugsyJgUDFWdJ7Zn8AzGvZcQ8WhRg/K5jx1e6TV7VNXDDvc+uQ1T76Ad/p2XzGhYyP3+Xe5fUdXvAXVqiPEfQb8kIPEjP7TPrgoTt2GPTG08ozxMTMiRY6ONZEnCrDUdhWpOpPW6xWUx2toYM0pf5/uwnphblykaw/Tc+Nz9O38dhlavn5IOCQekp7TFT3hiedx2UqOPc9Rg8dqV+NbNLnCdT7fKrVqLVm/xneod2j7SJ/tf7WjWc87jnGvKS/b33D8XXW5zCV5zYZcTt1nh8GNWmYmsiimi4jYkaoSkSmu0E4pFjOX6ZeK0LXKioJFURF4jtN0HbgTO9Z1u0MDRonYNc7mUEWd6KrjafS0QhwRpLgRUjhif9qO7REbjNE2TlUUjoP5hB2GfqROc2HXVPtGW6GqLxSVjQnoZvP3JcTpYpIZJ09IZIW4jaRwGlT9VOcVT5mug/Ny++f15/k+dvzd8cXHzHDPsNSkKVu1Nx0BzTNXZuO6vllmS/hGCpmU5aivl+tbja62N8tXENeYR5EC6EW90Nd62XZ3OO6gvYqaE8eF4biS8Fs2mtADUyVxqtnB1nXzEzZWffBS6ctFQ3yJYFzlpc5/agEr4kqwjjel7nz7tyP85ZGeP6duxTe+eWxs6iQZhlNfTxk5vurblK3/j/is1tQ8eO5W/kH8skCDvaxhX7LGjaGhXhK6k80d0/Fe8jy51dPxdI4kuOkIhiNkrC9tBqSPzOrGNMZLWw/J5dfsxxXIUIJg/RjVZzMCvbDn6MZJYplsws1W4Zdvff8zGuhlYMAQpAk0zEvVaWFezkDfnBbmZUf8VJzE/SoN8xLPDPNC0PjUDO5Dfhzz11nKHqpN0wR3uRZxn61NcotKQW5BuRZ1lxfFtdHus7TJ7mapRVumfaP+MydrRFF5ybiicSVnl2wr31kujQ6PLm0on6xNDk8qnR2eXbpcag+3l7aVJ8uPlXwQ/qToVInT6xFz+khX7zB/tsSCrzhCaCRqY7F+aKQfCSroyoRD8Pt1dVKh36Z6cqoiVeoQIS91fD24tG0JeYub1YjP95IXO7wJb5s36eXL4csi55UzMa+XRedi0xam++ll0bmoghEr/dCczLjMyYzhPsxruD0DpFG1eDNEDbC/Ma9pa/au03EEFQatMSxo8UdBU8zgbQ4WH9Rf1P+mD+h8UG/Qp+mcbnFuuhnBa0SzzuIt6Xlsba2Qra3R0BrWihqL2KXnxsrXhatP53ZNE8FBwa9RbLgAOvElXR4/YapLnDA04GCAXEPXrBD2cAhl+wWm9wA1bitkImGodTEnexiTTGVniITpeLlg/jxojF66OsVkTdTLCjGWP7w1Vt+dqQi6dI9WOWHdlVt8WfiSzjc+vfjlmx+//IElb+x84sM7H7jyit2PXH7p7pa8GZHKxXNqO2/E9W/egfFNdyS/W/HVi5c+xJW9fOjg80eePgLf3kgYyw9QIzzsZdMe0eIfJAsRLc9b0o963hItz1vSj3jeSmQ1CyTAc9S6ThRg7kk6ekKGD4Z9YgiTCmo2gPGjGBsh/D6golMYKGVT+vC5NW6+Y4khvrMGUEvHEs4oU02oQStoqtvq6D8x7z0HM5cxzAYz3Wb1Illkjjy7V3KmJpPJKTIPntmpAv4XqXzB/sgj3/wDbktESJhM1ccIs1/s0QRrXifYM5/envH0ppF02t+GTcxQfx38FtDgnIXnodazWamUoUsrWwLy0wZj3XxZmvXWbD/y1vY1y8pYjq+DCf77PS4v1UB7P5EFCJ8LCUcTGramxxdmymmJOkD4YZC4onypXKZWZPHL8DJxmfaWyNNRU5QlBQZQkVNUG5UmhFTNraoaDHYKx2QItJQLEewmBIs2TcRQ11jrI7kJRVVhKIU2kdVHfAnFpsxMqEmVwIj5aMKuabYQ4mZOI1sJIbSEmii4LbGUsdZk+pKnzcJoH8S31551ONy22xIN0kYA37SRvWfIA2GKwrzyu+j8JCbDiCow3x0U20w9djggaer0zmrq9Gf46pBtio0/MPAF4ga+MFSgjJUgpjmnAHcjA/AwwnYxrbnWdDv7/qwFRiRNpHo06kror6hzQmI47GEzFtYGcZXhW68KO0ld/3Mf4fD0SePnY/87/fvIRdw5qclXXNGxDe/5rqf/dmSY6n3AXCU9awi1PDCM5njpMHo8wUT2Eb6Gm8QdsPOsKAeGWK/stDndnAAsoF+Q3JpqGyLdsmUMFba0dKuEipOYNZ2CDynYw5YAPUzQpTBBl8IM9pS0wZ4pU8qjdEymxEYIhYm7lLS4S1FNR/9f7mXCpnOZhycvlXN5PvWQ1Z6dnk7PgIf3ELc1Mrit3t9tDRrufx8G5N9Y68mnWet5Mqz1mLwLnZtzutWlaZtHRV4Z6hVpURhikR2d8UHDvCwxS4pkibZ8bJd1K2AQ5bMwzFw1YK44Qe/jRvauFCRsxWKxNLyNVcPMsD+9Gw9d8vum3vUXTr+5XjjQ//lt8+67u38BuXfzz2fdcmX/Y8CKnJlazh0HVsSB/PgJxoqs1EiMlPnqSBO5zCY25DTkNuVuC+wMCNXZ1fkNgYnZE/NnZc/Kb89uz28LJAOviq+53hNP2j70OUpJoS2WEyc1tqlksm0OWU7+j+0N37uek7nv5X9HdMzb3Xl+TcoS3X5eQ1nerCo0hMdAGQvJKIPHQDQCqI4dekJv05M6H2A8RoDxGDrjMfQ0j6EzHkP3mJoyKUP+rHtoC9ItxR1GzmZS+rofCBBjroJ5m53F3wvyeVo0t8SwZqmY2bIwLkJiXITEZnQSixwn5RYETucfTPYhg3ewOAeqV3f60rGxcox5N2MTeC1LtGt5bOVYG7pyjJ1mQLfRJl8wJMxnedmvz/uf1KlVr2z8w5pd/eGHL+14YM8l63+bWk7kunPxCCztTF37wC3fTOAeeeGFI8+8+voz8E3M4XpwCfNRUs+aRg4SOCx8QhB3dQhvA+Z6hbjmv9mchIoDTFO7/Ed5jBLEENYx9j+betjmtox4YSScz/XPf6Y+gXNfNPC+sF94BUXwf7Nz5+W783NIWwmeL2djF1dcjMIuL4mgAJuqU/dNMFfHojeQxYUDInTv0ZJI8ZCZeHFGUypO++ezNxeHOBhRQiVtTEZ1Iu3BzRJWHWPDAXNLxRSqyNpkCS4psDicAqvHKEiLSgqY47a0qERlC5xqbrT9Z0NEJeeYDnXmmYoCdEKZViOm5htOS5XKChc2kfpMzPPn+jnRFnVEcqLBqBzho0URn70gjDx6dhiI3dkhCbYKhUgY+zVvGLudkASUcBgVc5AwPSlsKlVZvzIWdSx/H5coLg5nMQu5R1dinEVtGSv3rRQVV3Z2lpcJarK4DN2pCirENSdDNRHnEHmNxyuNILSnkUSmbwOsqZM7m1y0NfXSzr+kdvT24Olv7MD4tuie8KK9q647vCE8ZjMmt278dBxpeBj3H1/bsR/P/8vruKP3gr5fjlydPGfGpmlbdjyV+iq5sBY7oY3k0YGKjyKVtH9PBZ9K4Bst1unD9EAkWzhQeNKMVmbPIg+G1KTe+zKFE15BRqosYlFFgiILmAjFtLEIFbE3X3C8+YKzqgqxYZcKKWpgKCx0xlU6abY744rH5a+WaQIN6cMeyLGZq5QvUgLhajQMEqbPohRGqpEHEtg6ltg4bEQ1CkGi20rRMCWqxlGNeiaaojbjZtIqtyhL8VKyXF6uXIo24A3kMvlSZYO6GSa213M3SFvkXyi/QXcot6oPo13q/6B9Upf6LPqDegy9pn6E3lW/RV+o5fA4qg951GEoqtaq01BCVYSEy1MtwHhabQWIon4iRBpIi34IOpP5IjYRonXB1gXpBq0VVkoEwabRtvFmDOoG4IXYCzFUweb8VDu+VpVkOaKobkVREfBtMNy6gScTVCogkGXK3knA0CEsVNiwrVBOJBJKUiFKH85/NCEkBSIAllBCJIELtQ//RHsZQ+4xL8/38Qnquob69E+LPpzxoQ6QKbtlKgQM/tC8QaFw/l7BeNeMlWJsFK7KplxUdhXGv0+tfOJEJOiLfbQ/dTEf7d90warZl5AtzNPBSu4kPkN4FhriDaznir4ivSuRLumIRD6X8e3yvTLpkK+RyXnyEnhMGcsah+SHJBocJIC5r+HJNVSPEeHqkTRGLkHMwi7X9pvL0hZ2VKOonlqJZIQFQc/CE61dAz+8BkYEGUlJ5lnqeaOLpQFCJCNCyBVPBmM/Kx9dw/FfvXz/9XUzSqd4FsxC1EXVg+Q24TDMTJaz+3YLIqaye0I2o8U8h4R68Qye9rVOxVbNL0aLuatwPcmVfrfMF8uFO/Od05/7pa+/PwYpteyC6S3wx/Rd2wgSkzp3FUfc1FM7na+a94Wlouyq7CLcsuaPfzn09vPC7B8PmHsmDQWflqSUJHwklKirCSWGV1broR0hgkJFqtpIcHFaprI2FqPBc7dAb/EVdT7JsUiFPVT0aM6NMqW5mQJbfrA/ScdjTi/6mMtACX+zaITwFpvFOQqn2/8hfAkTGBtlPMQ+03edaiGKhVDHyAmm63set0ElLjGUzSZJn/a4Suik6dNeyF0CKwizgsQmKBF5mCiJtcoUXoiIw9UWdQO3Xj3GvStKD4i4SIxKETkujlEa7NPsrXyr2CK1Klfylwl3Kk+Lf+JfF0+IJ6V/iV/LOS5VFTiOJ9A7K4oMG/DRRSTRLUkix/MRQXUL8C3CTIynXr54QZTomhRSYZatQ2fAMxWuQplu5YRYaFuHwdVss2O7Zo2JmsU9aUZl7WvWIii9OJpe1DRXQGFiD/0A3mbpJ1P+bNT34ncatpEuxmczXQQzwl6uzf52eMrSoZwUNQOPMQUOujSx5ks69H4R+zjdL0DP4GVdA11agtzHwqpJDrlerudYavZ/9iYFB5VNHFF8duqded4aUzYKnWV5QVyRCwrqqUS6u4AKpl/tDrGsK2wuNjE36Gugy2ELV+LAoe4w8+Hc7aHZW90OJs6GjG3ZWNalWW7Uaa9EL+V6k8ey2wNXc7vrWUK9BXb76MEfdeUb5NRIeJ6JmavozJezrnKKyCNehh6WF43ZAe2OvaY7ZzpLxEVYcm7pxQ+eTK3AB99K3XuVcOC7x3Fn6pL+xSR4eepniGOe6U7SpRNmavmWMUXkYQAoZW5n+MlFzUVLizqUTYq4PG+9sFrp0K4VrtXEEo/C+UrKAp4CupTyQcZSyqDLtnREs4SvWVGyXYGystJSZEQzCQYCTiT7hvB0voyP1Zfhc9kXFa3v771EhOmgMZtukTmmEmWmfcYUEKnSGqSzI0POO9TA0jqvozkStfnpeW1MKYa6qEywdTBbXjnco9kxDBpXphVhAj+qCGPJpL6vARP7AXd8zBGZof2Sqbh/upNaphLHQndipgbHIsvmdyuuMsbfuVwYBX44AIrz++4TIc0iRThcaYRBiRaFYV8t048GfDuJ7n6uY+kF1209P/nkTanb8RlXjzmrafI196TewBfNj06YM3b2r25KPSIcaN2/ZP4DVSWPJy/oahvFzXR6lp4zdVXptzsl25gLJ8+8bBTCA2+nlvO/SP1faGuG9NsG/QHJE2CEmtDInChaPhTzuxAd5OjozNWEc4L871LLr6Hhpu9DiHl71vBko33aBwwfzzwXUNSd6ksqUQVCNFkWfsJy3aPNcgj6RSqCNj10mu6dRdYjMUedzPuniFmTmpeEPpBoVnsY7A2N9gCdYMgUTRqunX+CgpRsihUynHV6jOZhC9lxyD7d3mZfbeepm+d5azIkDJZ8wSjJdEEfn2fqS1GDLGqLmbDTOCpYpiEaMr29V6T9O1J/75Ded5h8c/hwvygc6H+AzPlmMunpPwdGY4zSvwV6/T8Rkhn+7qLYlZm5bJSL6SMglcalzmW4OnA3WoxO/51LWqDP6UB/I3GWTwZoIg+it2gO/MF08UG0GfDroew6yOsBzgNoBvoHKQ75fv5htFZ4Bt0jxlE70N8BZQdh+27YboH8XqEZ7RKaB/opDudphOO2Q9lcoLsRoIR/F+3Gz6AtUE6vNcu8l4VAewXkE4kbPQ77rzW3zwH6UvPaxXCPDXIQrTKPPQvKDgBkw/nvge1r8TMDuyDPg2svBdpaAB3O00ppAcbDuUYCrWgefybejObAfV8EdHlwzZVAm2vWxRag2853DLwN57pvsArxWAO4h6DqywGegFoXEFIOImSHHt0B78M5FaHsVxDy1MLY8HuEcusR8ucD3IxQgQehwDPAi16HUDGURa4F3qsLobIEzCf/gFD5cYQqHkao8i6ATxGqgn211yM0xgHwS4Ti2xCqO4TQGZ8g1DgFAM41Hs47IYDQpHUALyM0ZQVCZ8L89KxbETrbB6/9Gni1dQjNPonQ+VGEWuciNK8IYDW0sByE2uC+F92N0GJoMUsPILRsGkLLH0BoZS7A/QAfIbTqVwitfgmhjgsRWr8BoQ1wLxvg/i53I3TFgwhduQjgFEIbxyN09S8QuhaO2TQCoet2sdZ5LrTVSwk8OnAjDuA34YkEr62CbSPoHLan23AxstozQRJsGTgHWMzEecCnmbgAnUyHiYtQvhEoMa9AyZlol4kTlIU+NHEOyr8ycR7ef8LEBeTBW0xchPJ7xiypHrWksr19+KIxSxYOr65ePGb4otrapcNrl8ZHLl1cE180sj0+c8kF61cuXPtTSH8KTfOStR3LV10cGjVi1E8hR2PQElSNRkFaidrhbzhaxMoWAlYNf4thi5bVwt9SwGgaRyMhXYxqAFsEeDvkM+GYC9B6tBKOXPsfO+t/6jzNcMxaeMfL0Sp0MQrBGUcA/KfOzqH/769r9nWNGldO/2ASVICCXIwrQ/WQl3WLBcE+blhP1Bd86XGuFB0HIFxpd6wguJ8r4Qq664KJPq6ox5VTqTcO5+gwVcHSEKSrAPYAHATg0QIuAOUOSK8CSALsATgI8BIAdCiQ0r0hgFUAOwCO0z1cAefvDgUdjSVcLhybC01d57zoFMAAAAf36YWretE0gAUAWwF2AIiMjpasArgK4CDAp2xPgvN231YF9+7tvpFlPStWVrLNhcbm3Hlss+f8ViM/Z4aRT5xqkI01yEZVG8Ujxht5SbmRuyKVSZqr9spDjR7OAw/pgRtfDSkmTzE/N0G0k8tBnQCEE82SBOfqKY5W7jjI8QhzhMPwJoMDhzjcbXdWNqpkgJxCLhQkn5CPjT3k454sZ+WOxrPIO2gPwEEAjrwDf2+Tt9FVhJqiOyBtANgBcBDgRYBTACI5Dn9/g7+3yFswhLyJKgAaABYA7AA4CHAKQCJvQuogf6WdEEsp3gBAyF8hdZA34LHegFQnxwA7Ro7Brb3SXRuv3M+QWIWJBCMm4s03EZenso/8qfvrUmhRUXjT0KIe4wrROFTFFXZHRkHz83XXLw/2kXd7QrHgzsaR5FXUCQBdKqQOgBDAdIA2gNUAImCvA/Y6SgJsA9gJ0AkArQxSB0CIHAV4HuB1NBIgATAdQCYvdcNl+siL3dHxwUYP+SN5Bnmhxl8g/8vy58nTLH+O/IHlz0IegPwoebo7EESNGuxHcIwDcgfkFbBfIE/2FLuCA41OchDqLghpBUADwDSABQBbAURykBR2Lw664CSPoaMwmARJNzrJ8gfQLhklVgQT0QnQAEM0iY49AzBIdoR2REkiuv1O2KRJ9JbbAKNJdNNNgNEkevnVgNEkuvISwGgSXbwCMJpE5ywAjCbRabMBg6SP3LOvuCRYO+1CHGrUyQaopQ1QSxugljYgnmygf+hrnt7bf3WXlUGN3ZWIlZYFkwdw8nGcnImTu3ByCU5uxMmrcbIeJ+fjZAwn/TgZwMkETj6Gx0BVJIHRHbIZT/hw8ihOPoKTHTgZxckIThbjZAjXJvpIuHtqFcsmsaynkX50kJ8xDnofnYShRsPQ5sPQJxyE9EWAAbaVAKJQoUGcG6B5YU9Zg7E9YmzlKvh8jsCBR+A1HAG+8Qh0VxWQtgG8CMBBsz4CJz8Cr+oIOgRwCmAAQATqQrjxrSzVIa0AaABYAHAVwCkAkd3OKQCCVpm3uIfdGL3pCvPGpwHw5Aj8FcJfmIQTBQ6/I+Y4k9vqx3oATwsMBEgt8gBvhVxO2dmH7Xv/Zf/qX3akNCrkFrKVdt1km5lv7f4aum58R3f0sWBjDv41CvCYBZmN4gjkY1AH265Bfpnm1chPHoK8stvfDIfp3dHy4AGcRY/aG/zafyJ40t9HAP3A/1jwz6E+HncHX4OSh/YGX/XfEHy2ok+GksejfRiyAyFGut8/JvjIUUZ6Ney4qzu4kWZ7g1f6pwQv9LMdS4wd8ztgK6EHZ0bnBM+E8030LwomOuCce4MN/vnBeoOqhh6zNzgSbiFmoGVws6V+dtGiAJT0BmvOO6+2Dy9LlEvbpRZpmjRaqpTKpbAUlAqkfMktu2SHTCPKqbIsizIvE5hguOmMLEYZMrfooJnI05RnuIOqfjH+jXZ9WCboLNSZzTWRplnjcVPnoXbUtCjU+eWsoj6szpjTKRSNx52uJtQ0e3znmFhTnzQws7M21tQpTf9ZSxfGt7RCaSfZ0ofR7JY+PECLrsvvdE2g3mSw87qb82k+7LqbW1uRz3NJg6/BNc4ZnzzxB5I2M40N/nxD8ILxndubZrV01zz4YMH41s5Khg8MAN7Uefus0NyW/fhz/OmkifvxZzRrbdnPjcOfT5pJy7lxE1tbm/pwM6NDIfwZ0EHT+YzRyTBKUzoUkgMG3V0GXQSOB7pimgGdoqAIo4soCqPjMaXr6iieNLGruJjReEOog9F0eEOZNEcjQBOJMBpPEh1lNEc9SUrTOY6R+P1AEvAzEpyH/IzEj/MYSfMgSYVJckOa5AZ2JQ4P0vgNGvtxi8Z+HGhiP/W3ZHwshnvqWtvnTlpSNKmtaNISgLbOGy9Z5utMLgqFutpb6Y5QJxdtW9S+jOYLl3S2Fi2Z2NleNDHUVTf3B3bPpbvriiZ2obmTZrd0zU0smdhdl6ibVLRwYmvPlOnVtUOudUP6WtXTf+Bk0+nJqum1ptT+wO5aunsKvVYtvVYtvdaUxBR2LcSa+vSWLhmNb50w18h7iKZCs23LD7eO9zhWj2NtuC7s25h/AFiX3UiLtXbaisZ32gHoruGNwxvpLvi06K4sKNbNXb6NdeH8A3i3ucsBxc6i8Si2bn3HeuSbtHyi8d8BPyhat55WuJHGOv7dD/ZN6kwsnNgBs8WmzrJZTZ0NM+a0dEkSlLbRR+oca5Vp2qS+gUNG4QgoHEsLOS5NSMvqaZmimITff//rzZzJa5PksR6cCOB1qKOV6ww0zSbQI8yeA886d07LAWCs6FjR0QoP2IFjuMM6h3nbVrzSGKLPbMG69SZm1sU6MzeOhEM6rCpJ/2hlxdI1to6dllVnbG5LYxY3mqtAjcA7j4R8OOTDIa+EvJKrSLiiQY7UBhW5NqipE4OSODFonbU1hv4f+EYBKA0KZW5kc3RyZWFtDWVuZG9iag0zMiAwIG9iag08PC9Bc2NlbnQgNzI4L0F2Z1dpZHRoIDI3Ny9DSURTZXQgMzAgMCBSL0NhcEhlaWdodCAxNDY3L0Rlc2NlbnQgLTIxMC9GbGFncyAzMi9Gb250QkJveFswLjAgLTIxMS4wIDEwMDAuMCA5MDYuMF0vRm9udEZpbGUyIDMxIDAgUi9Gb250TmFtZS9EU1ZVUEErQXJpYWwvSXRhbGljQW5nbGUgMC9MZWFkaW5nIDEwODgvTWF4V2lkdGggMjc3L01pc3NpbmdXaWR0aCAyNzcvU3RlbUggMC9TdGVtViA4MC9UeXBlL0ZvbnREZXNjcmlwdG9yL1hIZWlnaHQgMD4+DWVuZG9iag0zMyAwIG9iag08PC9CYXNlRm9udC9EU1ZVUEErQXJpYWwvQ0lEU3lzdGVtSW5mbzw8L09yZGVyaW5nKElkZW50aXR5KS9SZWdpc3RyeShBZG9iZSkvU3VwcGxlbWVudCAwPj4vQ0lEVG9HSURNYXAvSWRlbnRpdHkvRFcgMTAwMC9Gb250RGVzY3JpcHRvciAzMiAwIFIvU3VidHlwZS9DSURGb250VHlwZTIvVHlwZS9Gb250L1dbMVs1NTYuMF0yWzI3Ny4wXTNbNTU2LjBdNls1NTYuMF03WzUwMC4wXTRbNTU2LjBdOFs4MzMuMF05WzU1Ni4wXTEwWzMzMy4wXTExWzU1Ni4wXTEyWzU1Ni4wXTEzWzU1Ni4wXTE0WzI3Ny4wXTE1WzU1Ni4wXTE2WzI3Ny4wXTE3WzU4My4wXTE4WzcyMi4wXTE5Wzc3Ny4wXTIwWzgzMy4wXTIxWzI3Ny4wXTIyWzcyMi4wXTIzWzc3Ny4wXTI0WzcyMi4wXTI1WzY2Ni4wXTI2WzY2Ni4wXTI3WzcyMi4wXTI4WzMzMy4wXTI5WzU1Ni4wXTMwWzY2Ni4wXTMxWzI3Ny4wXTMyWzI3Ny4wXTMzWzYxMC4wXTM0WzIyMi4wXTM1WzU1Ni4wXTM2WzU1Ni4wXTM3WzI3Ny4wXTM4WzU1Ni4wXTM5WzMzMy4wXTQwWzU1Ni4wXTQxWzI1OS4wXTQyWzIyMi4wXTQzWzMzMy4wXTQ0WzU1Ni4wXTQ1WzYxMC4wXTQ2WzU1Ni4wXTQ3WzI3Ny4wXTQ4WzUwMC4wXTQ5WzEwMTUuMF01MFs1NTYuMF01MVs1NTYuMF01MlsyNzcuMF01M1syNzcuMF01NFs2NjYuMF01NVs1NTYuMF01NlsyMjIuMF01N1s1NTYuMF01OFs3MjIuMF01OVs1MDAuMF02MFs1MDAuMF02Mls1NTYuMF02M1s1NTYuMF02NFs2MTAuMF02NVs2NjYuMF02Nls1NTYuMF02N1s1NTYuMF02OFsxOTAuMF02OVs3NzcuMF03MFs1MDAuMF03MVsyMjIuMF03M1s1NTYuMF03NFs1MDAuMF03NVs2NjYuMF03Nls1NTYuMF03N1s3MjIuMF1dPj4NZW5kb2JqDTM0IDAgb2JqDTw8L0ZpbHRlci9GbGF0ZURlY29kZS9MZW5ndGggMTE+PnN0cmVhbQ0KeF77DwEfACPVB+oNCmVuZHN0cmVhbQ1lbmRvYmoNMzUgMCBvYmoNPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxODExMC9MZW5ndGgxIDI3MDA4Pj5zdHJlYW0NCnhe7bx5fJRFtjBcVc/+9L5v6XR3OulO0oRsnYRAJE9IiEBEwmoCRsISIC6QsAg6I0RFVhVwARSUuAGiI03CkrAMcRkdZ7niuAw6ixkHRR1z5c4gMkq6v1NPN4hz597ffb/3/t77z+1O1ant1HLq1KlzqqqDMEJIhzoQg+onTM4vsi27KYYQ+j245jm3zWpbaFr5MUK4AiHBOef2pf7Eqz+5FiFxCsSb57XNv+1o2LQbIcNBhPiR82+9Y97Qtd0fIGQ7j1DFtgUts+bmvfvMBYQm3Q/1lS6ABOGleAjir0E8c8FtS1ewJ2xPQvwziJ+7ddGcWUh4Ihehyachfv62WSvaxKfTshGa8iuI+xfOuq0l/t0vfwfxLxEiP25btGQp9Bs+Nyyg+W2LW9qYCaUvQXwdQqavEcO8S44jDonc41wxjMKThMzbaB4xixzRCCyhH7YfDU30oRUzoBaJ1jdlfLUfwTdxiXsnPhEXCyNxl4JwIpFAiA1xR2lryAY+k3JpKh0RaYMYhNjXEEuARmgpUqD9KJQOo2yUg4agPJSPClAhKkLFaDiqQtWoBo1GtWgMGovGoevQeHQ9moDq0UQ0CU1GU9BUNA01oFloNpqD5qIWNA/NRwtQK7oV3YYWokWoDbWjxWgJtLQM3Y5WoDtQP/oMfU57+j/U6v/7z9L/ga8GDUVelA40dSITzDClbAkahuwoF/lQEKicgzxA90yVU9zAFQHkAj5xoAwUQSOQEeaGQ1rgFwsKwezwKAvWoQz8J8B8EcQiEZlh9qwwb+WoDBlgnP/LU//vPkv/B77/y1N5/8tT/83f/wGegv0xTXV7UBobgrpQ4sxlF29NnKF5FJIvYE/2Jl3q04VeRL/F2diPuvG30IeL2IULYe5Z9A30YD8aRI9CS1PQVmyGHtth/sdiFspE0P14R+L2xOfoGvQQejpxBN+T2Af5m9Dr6CL04I8shr5dD+WnApd8znyCGhOPQ8/XAn1GoEnYDjz0Pny/hj48jB5BP8U/TlyEVq3oHqivAjixKvFy4hLQ7H52M3daOoS2oGOYT8xJtAJtM9AGEkm8n/gIKNSInkEvQp8iuI8dA7S8Bd2HtmMX8zqEHkXPojjWkiammjsJLY0F7l2IlqMNaB/6BTbjeu40dy7xo8RZoLIFaDoLOPlzXILHk+dYbWJk4kM0A/Win8N46bePncHu4WbEKxNPJF6BuTuCZXwcv8wVcQ8O3p14KvESzFoI5v0aGPc0WCH3opfRm+jf0F/JqsQqWFGToeWfYS/24xBQ/H3iIivJSuYd4Jcq1AS9XYZ2oRjMyFF0DJ0A2vwO1s4n2Io9eByejbfgvxItmUveYnYwB5l3Wcw+D/QOAnfkAtc9hw6jX6Ffo7cwB/UX4Hp8M16Et+EncD+JkS/JN6zI3st+xw5yoXh//LvE9YmvgT/dsMLvRKuAts+gbnQQ/Qt6D/0V/Q1dwEY8DC/AT+EY7sdfEolkkAmkjWwlz5GfMNczW5iX2RJ2FHsL+2v2Q24Nt1GYJcQv7Y4/HP9J/O3EkcTbwDt6qD8EkqQV3Q1c8Rw6id6B2j9Af0AfU/6B+kfg6fgmaGUJXocfwT/BP8Nv4y9glEj9ZpARpAZaXUQWA53uIQ+TR6D1t+B7inxI/kD+Qr5mOCaDKWXamaeYGNPDnGI+ZY1siB3KFrIT2OlsAmamiLuWm8zt5V7gXuHO8RX8XL6N/0y4R1gt/mowd/CPcRRfEI/Fu4F3ReCkO4EST6Knge8Pwhz8Aij6L9DjfnQeZsGNAzgM/S7HtbgOj8c34BtxC74Hr8UP4e14B34avwQjgDEQAfoeIVVkMplFWshqspY8QA7C9yh5k7xPTpMB6LmDCTIRppAZy0xnZjALYQxLmZXMaqDsFmYf8xbzDnOW+YwZgFlzsOnsMvZO9jF2D3uQfZu7jrsNvk9zJ7k+7m3uEneJJ7ybT+Pz+Zv5vfzHAi+UCvXCeuFd4W9iG07DudBz/9VCkbhgDaaTfcTKrsIDkODFLEiRLSgC8zAZVsXfUCUTh3nR03zom424WAvF5BUWbBWyFB9DJfhnaBVPGKp796Mu/HvSz75KrkHv4WbsYvcwC7lfkAB6AaTRZnKcHMOj0EFSQaaRnaCuf4L3ok+A31egR/AteAl6AQ/g4fguXIZXoXeJnZmMV6OKxNOExRIei88h6AG6m52LbkL/6QeXgxX1efxJVsf+GORTD9oKM/oi+gg/j77FXOJLkG4MSKNZIGXuB36/D1Gp1wTrbBWsRxdIkFv5t9BBzIOlVcaPZO9E59Df0efcUeCoUSBJz8Zb2SfZPyfKEnmwwmCVob2w7haga2HFfAJccgLiNHYjrHQZZEkRrOp6NB12ybtA6m1JxBI7E/cm7kgsQr8E3G/xEPwt7oQV0QMYFejn8N2EPsAbYR1ei/5/feJzUR/6AjtxFi6C9TDA3c5t5vZxB7mfcr/mC4Haq9EO4OiPgZtlGMEc9Db6An2DRZgbF+wsUejvMOh7A7qVNDInUDV2w27+DoykDI1KjWQJ1HIPUG8nrOcTsDbOgZy4Ef0UncYEO2BEc6B9EeqpAzrPhNK7YQbvxd2QMhekdi76C4xbj4eRpdCeAjVtBanVB336PfoUqJ1Q+zUE5EINngZ1fYNuQHOhhVJUjw/ADByG/e56VMP8CuidiY1oFM7AzwJeM6xQPey55dyfMUFD4tcnhpFW5gTsMQlI74Tdy4Ouwe3QCwOMYxDZ8ARUEp8EfXgHM2wM/0btxWOkJbGWWR6/Ff0SPQ9zorC3CzXsYvY+9jtl1NQpSuXIaypGDC8fVlYSLS4qLMgfmjckkpuTHQ5lZQYzAn5fujfN43Y5HXab1WI2GQ16nVYjS6LAcyxDMBoyOljb7I+FmmNsKDhmTB6NB2dBwqyrEppjfkiq/WGZmL9ZLeb/YUkFSs77h5JKsqRypSQ2+itQRd4Q/+igP/brmqC/B0+f2ADhB2qCjf7YgBoer4Y3q2EdhAMBQPCPdi6o8cdws390rPb2BRtGN9dAdQc0cnWwukXOG4IOyBoIaiAUcwTbDmDHSKwGiGP08AMEiTroVMwdrBkdcwVraA9iTNboWXNj9RMbRtd4AoHGvCExXD0nODuGgqNihohaBFWrzcT46pigNuNvpaNBG/0HhvRtuL/HiGY3R7Rzg3Nn3dgQY2Y10jZMEWi3Jua484zz+yhUbq5uWHt1rofZMNrZ6qfRDRvW+mN9Exuuzg1Qv7ER6gBcklXbvKEWmr4fiFg32Q+tkfsaG2L4PmjST0dCR5UcX0twNE1pvtkfk4Kjggs23NwMU+PeEEOT7gh0ud1Kb6IfuUf7N0xpCAZilZ5g46yatANWtGHSHd0uxe/6YU7ekANGU5KwB/SGVECruzrQciVPDanFaahu0hXKYtqj4FhgiJh/jh960hCEMQ2jXsswtGHOMCgGn0YMWLG5MCOtMam6eYNxOE2n+DEuyxj0b/gaAQcEB778YcqsVAqfZfwa0SDlkyusBvmXw7FIJJabS1lEqIY5hT6OVOMleUNu7yGlwTajHwCQD9UDbWc1Ds8H8gcCdII39ihoNkRiHRMbknE/mu3pQkp+pDFGmmlO3+Uc21Sa03E55wp6cxA4+aB6UmSLiaErfwaj3TJ6wfAYtv8n2S3J/LrJwbqJ0xv8ozc0p2hbN+UHsWT+sCt5qVDMUt3AeEgqRDyMmgtMeeOVwjTSoI2xWfDHq0w9N8YAU6oJ2F8bMzaPSfqNciDwH+L0COJVSD2JcxRLBd+jpXoZGx75YXzED+I/6J12AwP9ZUOkbsr0DRvkH+TVggDasKE26K/d0LxhVk+iY3bQbwxu6CV7yJ4NbaObL09oT+LoRk+s9v5GGMQCPByYlaBRB4J43cQDCl43eXpDrxGM0XVTGroIJtXNoxoPZEJeQ68fIUVNJTSVJtKIn0ZQHQY+7yKiWt7TqyDUoeayaoIan9ODkZomXk7DaE4PSaYZkw2F1IYU0DTn9LDJHOVyaRbSxGRaR7J0dqq0CDlGmnMUgUxHambyQ4VG9ZSGq9lBXWONecBeBCwRxF4EO8wAe9FyJYvneq29TuZaDs/n3ueI2ZSl0+uRx5gFdDAg0R7eL2ChJ9HXLWmiQg+5X7H7vAXeZm+bt8PLeY0GP/aD+UdQD9nYnVY42Rm53ni+qWL8YMV4Y/uFSPv4AVRZUVkxWGEuzwe/sAA1teOmYlPA77DD/sTzAh8MukhxUWlpSTQUDgUfxb/D+kkr983edv3Nb7789P7bq28aU9LJHbUH/rB/bU+ryTb4W/aVePPQ2VX1C3QykHMtQkwZOxKs1b1K9jYOS3o8mZvHLeOYfHODfoG+zczKkkHr05JN2oSWVGonaIm2hyxXcgQBI5khvJyNJKNUILVJrOReZd5lJjPNq8z7zafMrNmIQpjpwTmKhpAO3AnahctU2YvTkDrQdhjlgHGw4npjU/uFJtf4M8hJR1s50NS+uBy2ZtwEw0V1McfkulgJTMYBuWhYI2oKBEwBW2lpcZFDCAUzeN6EO+NnMVd9S01z4w3XXjNiUj4b2nZLTcnXQ6v2xf8NiFuV+IwNwxitKA0/04uMiYtKrab8Melx3VbjXm6PfEw6putxi6IVjyHX8rXyhPS9usP8Yfcb8s+178untReFb3S6NEOaTfF4ozZFb4oabCdtb9kYG51ZQ3qlCvUOgOQBRWvQm+v1zXqid5oxZBx2eaK42IxoGa8/qsKMnCSM5CWhM02FikFviHZSQWaEbs80m3vI0m5WY3YCVDI1AgrgfFtggh7r3fnpM9MXpe9KZ9MNAVHRGaKiy9tapZI1Mn4AKHqhafzAeWCfAZAzitWpZFsrnUq6ATyPEbw0U2UEPo2Vg5Dfi8zQCShhpp2BQiqEchR2XS56vqmdwoiKgCDDXE473eWgINYtySPVaFWgMoJo+TMRk7m8SW1erwCV9LRRPW1erwCxkFopsHUksjgSqcCmYjrj7agpgjmeD/rDoRIjKi5CTMBuBwa3hGCyBd5BvsXO0s/3x/9yXyu2vjOAzfygwtwza9T0MLNi2o0VFRhPyn/8qUNb/gAKcST+RvzEXRvH4FvvXFVdvQQIWwCsYARWyCWvKH28iQ+KYYfJEdxu3m7dFn40VxKstVZiPqbr1b8R+CR4UXchg8/RTdW16B7VbDPvyejVClVBJbMmND9jbmitea11Tca9mVJZaDRfqxmnm2CoDYzKEDIyw6EybUmgJKMkWJIp8DJnkgJOXVibkZERFDIzlCFLtCusd9huz1mWu862Ovdx26O5BzMOBnUdeJPjfudjuc/nxobwjoBdCQSjdiXNF/XZ8Ud2bC8WA/VZm7JIluL0RrPcQyjHOExyZf0QXDAE5w/BQ9IDBUZsLMYBlasMUqUKoYjKXZKkiyJXZEUPZZNLQH3gkHbKK+2LI6qwOQ+ByAA6wFMJqJTwGPPYjkMZpYHawBTc6JiLWx0XQLl3ENYdyCDZFp2WZLtnspitzdbUu7G71iJUDjbBn8nsKL/smto9vSgj8cvu7NxooCcJM3oS/d3pmTTe3+3LTMZdbjWueCBwiw6XZtRmbNc9kvFaxrsZfCBDq2NZNx3HIVhQqJgurW5HXiVO8Z4az8iKUqh43bCgcAFWcD1mm3EHPofBXjVCrBnsQ1rSYoeSGCvjEYtnsudYQodgV6Bqe7FDgXodClTqUErKog4lMhS8rBzwoF6Dw+eY6VjkYB1T3UpGZtTgxvXuhJukBt8eOd+kLpPImQiNno9Q8qrRJDGSmY3A7O1NqB0+TU3qispMvKlIGnOlIRs8oMOXh3XlWqu2nAa7tOVAoS8OaMrVVYMBH7U3WbLoyigD0R8OhYHpSqIgFO0OLrlSbFaHnaVWDB/MCBVgt3nhnNvKsqy2sfEXZ6z88JMP382Of2Oa2bCowJ8Wwi83Npz/6oNBnB+ZNDU7Ld9vs5rqRk57bMPxBzcWjhzlswfTbWnzxtWteeg3MVhFU2EVVcIqcqE/KRMbDI3mRvsCQ6u51X6X8w7XNrJN+7rxdedvje87P+c/Fz+3fG67yFuGWYbZxpnH2WudjdpWrTDcXGYvczLLueWGtdwaw3rXXvMee6/5sF3SqwLRE6XwkNka1RfraIorPapCgymqO4pZJININJs0SIGiSIFyqHgzxvgoxoiFLL9DwDQVlkK+jgZ0SbnpEQJWl7shKSmpoKRyMnJ+IIIqB883nYnAnJ2ncxVJ7rXtTVglJ1CTCqEyKpkykIkKJjtbGP+Lfs6E1rtW3VI/z4atkfO//jz+F2wfeOUT8mXR5Clb9p3YOWNR/k9fwSFgOgFn7QGh/jBC+EXQHxgkoOW9SAJmrYT1qUj1EumQYlKfdEr6SuJ8UrO0SuqEBI7hBQSmpwFhBZ0CC5lBTaCy8BwvsDIRoGp1aQcyo6xLrKxI7gBUg1A1B9AdmtorGM5YUQF/Ks8tjlhMARMG9zB2wcbpYg9jNn7pu3Fs6LsPoYcb47ey21SNIA09rgwdZhljIeYoU64rt0Q9NcxY3VhLjefvHmkaP01uNE+zT3M2pl0Q/u4RoVNu2Ki6OMFK9yu7RgPGsyMgutvScbopR683hIxGrGoDbagDWnJ5K5PzAKKnAvQA45nrQetJ6jwD8K1IqgC4ukHRzePnya3mefZ5ztY0vgm0AEtSB6BzAfwdNgWwOkOgBsFsbcR88Us392ISv9TbsGkCjNL+4LzZ96yZM38dG9pZPzf+x/hg/EL8g9qpg58zvd0vPNG95+ldwNi+xGdkC/cEMPavlRw/8uOgnGMYrh+nbzQILhtyMnYbcpgtVuwwEyt2MpIgC1onlSMG5Oh0xBxMM4A+B+PowWwX8ATdwJGNFyhB9FqNlC/nI5SPZ4ImBCWUbCcTcpin2iqtu6z7rUyztcO62XrKes7KIavR6rcWWFng1hWdSb2wfXFdrAx0oRGgC/Uia6JvWGPF+EugF4LKaDzvourTAFUWadEzsPeaig3woUTEtqDJqgoLB5UGoCmWmIIlxSVZJnJnnyacFh7nnP3j6+4s10h3343dbKg/PuWeSJrnw9ziiaMLH8Vv9b/zbHw9zNgkWPiPA2/ogELblDGf4bPiN5ZvbOwb5DNQfl2cSyKNxmmWafZG5zaynd8ubtP2SO+R33G/l97TnuXO8p/pjHvEX5Jf8a+Kr2u5ZeJ6frXImCjXyBoHJZKVFazlgrvZ0+YhHn0A/WCtJpkDWAMWJ6zMpnbgDKnVOA/4otXJYsoWuMkSNVO+sFmBLzJDWVdxxaQNgzv/DUfjb375UPybDdi/deHCRx9duHArybgf8xvib3z1b/FXVyf2Prl3b+fOvXuBHbaAst8Iw7WjXYpTsDgs08UFItvD4qgYNdaINYbPjRxPe+01CXodr9VoQCUmOGRHij8zuh/hBFTidtIFaoedYrOz00nanOec5CsndsqakFYPq6FLp9Oquh+gdGrxOS3WuhyphQw7x1U6MuzSaoK6tmE902VCxRQsatCJo6qc4m0mVT0uLkonNrYxfjZzYvnYpRGqIG98p+nxCT6S/mLLsPrVXXEfrISD1QtW/wjmdQrM6yzVqklDm5U8cyPfeGVtbxceky5KUlt6RzoZzkS1w21R1zimRjvOVuN6TJKs6pLXuFUO1wh6kFNIduTodSF1qRsMyL0J1r8xAApqQ8VVU1kxfmCw4tOklBq4MhC61lv51qvXeiBQkpK6ZtD56UJ3fD+n7Kz4d1UHph+Jfxd/pese7Bo059fcOWvd6vlz1+6c0YjDoAXqsesRYrzUtu+6hc89e+Qpus5XIsRvh4kN4xG9KAeI3wQyGGS71sbbtVEGptcZDdaQ0eJoZ01Q62fycyZLzTkdObtynuX3CLu1h/hD2ljOqZz+HD3Kyc+ph4yTOR/l8DlUQaiEeIeayQkBVnB77Sp/CwFKonRWMJpMYU9aWigsg8Q0GENmkzK9pNmEF4FQ7iG1isHtCXnTIG1RGm5Ow2mQdjAL1iylZxdC4ZRqR6FSCv0OQ9GwUgWuAlxmOBpWhl8TzQ+/Ff4ozBjCvnBHmEFhf7ggnAizYVf2nysui5OkKnKZxS6AbgLS40J7EwXqxACT0S+dHwwCBYEDcbI40k7FcsSi8pndUar6dsp5oIlcZsLv+XElZjb2zdtaUPv0jcuezvbGz3rDE0csGBo/m15ZWrUgL36WDW15fsrUqVNm3lizfbCRzHxyaMWYjVvjhNTumD6kdvVjg5dgzo6xe0kH9w7sf9WKBfvNtij2gwZZz2DEGBkCZmajIkH4E2QE47uHzDqCFyIX++mPkzx3fqDJSIVHUzuMIBKxWAL42AY8Ij7A7gU74b1EImkmQgPPJJ9GKSjp43uRHn32fRwVKibS7z/nJ37/BH8qROdCA4ahX5M9JkKwv5eUoBxEFbWm9vYSWGFjofKhwHFBVITblQWCW0zjvHb3OM+YtLFZvzN+ZJJKXbWuG0LzXPNDa0IPuR5273b3et5w/9yj5Xmdzc677GE+x9boWk7WkN38If51Xnsy+oGReDOLCk1DdJlUSc1UMrLBc3mjizIvZZLMWi/tVwEYldd4MfIavTHv372s1zsEFyMFUg3IB12bGqCGWYAaZgHFSXVwsvQQK2h1MrUwuiFvSMocVCGUGEI5WbFq0gtDYo6UrWv0aXdpiU+LEyC8FL09qnVPiOJoM8zagwWglBXnBGY68EcOPEHVnBmHqzhlqwITqkZIE7VYI8nYGcp8A8CXwIFgHFJ9+oy5PB+4M2mYdOV7cXvjQDJC9ea+I2CXT8mcm0maIo1U+QY2ZfSg7yQVHqrHhVUetdsYq90RgO0vTCUKVZhLy0rLkpIE09MUVc2DpNIS3JKI/Oat4z11jCcr/oXGKDBjnm169sS0HQ/97Lr6RXVT8E2lX2SWNdRcN7rYqCEfD338kcb1R+I99993XVqZS6yt7Vo3/YG6tCx/2sTRI+K/MRc5wxUjphWFyjJbYFsYTJwlI1ReHqZ4EcZjCWMlhF4vMEjGfyFujvkL8O7Dt36vpqaOgtZyQyN3GV8rLBBwMWbwLe/Et7i4L7+1AqkfABabzIZgt9qpOG4wzTdt5RiJd/EVpMJUR+pMZ4lgoBNnYjV2JNusVlniLdaQzYaooNbb1T3LjhNgaf4ne5YkXtmsRHxOxOIPN6urd6qkVvcPe1VTUpqHQAMJJHWS0lIaZK4ffqL1ln3XYZdvUuWYxbnYtWvq7Jv2bSWdcWd/y4gJy87gPtBPMXIiRD4F2tlRj1JUyuJc1m/0mxrZDicnsiedxGY3EavZbtJbDMiot2AQB1ZJNGjwTE1CQzSUAjKPTYbkSFWZbASl/BxUDeSQpeJKcYJYLzJitjHfNNNETFRR0+ktIWKdiTrtfXZiBwoclrRRu8uxope0Jg+zIu1JXexSE6hjruRRFqjeVP2mZmB5UUoXo/xoKaacd/kAy2YrBvUsYAo6d5Y/tmzFklD1yGtKfvOb+NmdbKh+zerJma8ZyyfW/eHSEWYs9FELOkkzzLIGb1c2Zgs/Z8l2oRf/Hr8nnNNxouBmnXw2X4aGiWNwI/4xXibIIRwRSvFwoRaPE7ZrLvIXBSmLDQm5cpQdLlez18uvsuJ18hS2UZ7L3iavwHfJj7BbhaPye+zv5UuyjmEFQZLtrJ/NlYvZSrmWlWysSx4uXy/fIu9hj7BvyhdYSehJnOs2O6NgjZzutjko7FdsWlMUs7LAIqICEUkiw0DO4Zy8aILBNKgY7JlRJkQkWAASx2s0qexzGkyDigOyNSHEWRHieI5jCC9KkgZxPeS2Lr5YAqBoxJYJul26fh2jY2gyKdbQZPO55EkaPWFlUYv2NVCjXarMcdKjMdd4EDlqCOUnORQ8urwi7ZG1d722dqgzFcLUbkfUS4qcQ7JfCqgD7AKIVFuemuUg6Rdj6hVjHKD7Cw4wjBavim/BNxx/HY+Lb8fr43tOf0iChIn/HmfGpcG38dj4EejldhhcEPQvCf+LopcYXnQxDpE1i4RSC3WbNZUMFb0zmqIUKrmTp0SZIkG0CgLwKSECI7FAPYiwCpRhFchni/i3OAxk2qi4FE29plnDtGk6NKRT06chfk0BLAVRSlVKoaKfPDkqFann0X0ghuiJtFy47MqJtKomNMHSvpCKqeKIagXlCNzaoVSTAGpdFssMzJ2kD0dFP3i010ckXVRU6BFU6vyjWi3VcVhTInZoStSBXeMeGhUng8cxdqaIURi2lrlP3Cx2il3iGYZ/jXlL/FBkQB8To8wIWKYPMbvETma/GGNOihpBNYRhaREFPIEyjy6/KEr81BOsJZCyDQzloVEyBTy1dG26H2LgiUQQnIRxCENIWBhBioXriSLcSKYJwJYeYTwZLTwuvCD8knxAPiNnhb8TTZhkC+OEFcI64UXCw6wvvqxMRSKoKaVagTlSDOoqVcixaTv2kwZsif928AB39FIe8863tczxSzWw/8KHOwmTL4Dor+pFQuK0IpWVR/ls8JJjyi6J8kq2OqbTSn0gDHng5aBcNpfLlvO1w1AZV6m9Gd1MWph53AJxvvwZYxjHYyJKmJEliRUkDBMrwBoSeIll/Rxv5ThelBW3d6Ss6i5ub1TOAnbjWakHH1f0vEA4lsVI1DocbmCGWYrGh9UXSR2w7fSQTEXySbhA6pCIdJRkIhZKSH5gOJfmpjlJphk/6AKVki63wetHt9R8enkjGD9gUq8zgIfockutNQACbNlrX0tx0EEpqvIKPSiri2nA7E1XzV4mEe8SWfloIg6UunSAZ4fRTyPI1ST1AwEGvrAAGYY7Gf9px+DhO+KvkxG4PPcXr+Px8W4g/gbiH+yHVTcERGmvSvjFSjBfKmALuHqpDYa0WRJ4zJEsliECEiWgALuKriWcB1uHAERAq+idDURNjL6etJEOspmwxCUOvpgcet3EhgNEoeY5rB3VPgcCnEnd5ahqSRMwRUnAFjDhj+Lj2Qfi17OvXLz43Ujo1RK8luwgnbAEi5QAPcIkuAxRFdfPFDAsU8MlJRoD+sFzqn5wpmm88dMmlD/QVFhAj3aWkGy8lh7tQB+3Am8dhyHaUABdVO4pN4w13CDcrLlZu0/ao+8MHtaflmRe5GWHaJdL9bX6WoMgGiWTVW81WI2l+lLDtYZl+juM78iaFdIK1+3eddI61xovL9mtktagn6xfpl+tf0T/jJ7T+3VaK1iyBq1N57BnWYxW3GzttBKrFfkD9DZMp9fbkKinzBVGOqOO6N71hDv5GN/Hn+JZfm1bEPuDBUESDNiuvhTLKJzz/aWYek80cL5p4DIrqRdjdJdNCiIQQk160I6wKWWqqCYlXYRF6nWZYLc7LAFmKAkGTabvL82CW8miv7zX8crLzXfd3B1/8v3FU26aV/G7926umDAm8+BZ7uiEX9zz3G/Thq15If4xrnyhMTC4k7k+s2HUuBlaDnrZmDjLnQV9hN4IPq1M3cZtE7drt+tZEQt60SA4w84V0nKzsNy0wraGXS+u167R32deb11nW+dY51zj1gpmkONum9ltdTttbsGSp5NceQJjD+8H+1A2yn6ZkenNob/Aq6RuDju9vN97zku8xnAnwlSLL1Al9v3daStfTenV4wfGq+Rqv3Jkgpvo7YolWkaV3mI/PTkL+BG2mq8Y043VRT+Zv74b1+D74ivjJ+K98ZW48NMDB/78hyNH+sm7/dvbuiLD4wvjj8efiC/Cm/CCv8cTicSli98B294POtRB9WBzUS/iYF8pikY5ur8Es1SoVFodUcQpXD3XwfVznI9r5tq4cxzbwQGHEwbBZvcB7NcxesTZh84hQpmAHniyaCFbuOuyuXDlaFO9LaJyFqbXdD/O5o5+Wwv9GJf4lP0rTMcQfEq5ptfU4z2c/foQVrAINofFYXNGWriW7KX8Ct3S7A+07we1jfJU/dSMxuAC7Tzz/EBr9vwhy71rvFsDWnNQvaLwRSlUWlzu6MSMicGXM14Osu0Z7cG7M+4O/injT0E+IufqMjMyg+W6aLBOrtPVZFQHb9a1BO/Q3ZmxXrchY7e8R7c3wyLJko7P4IMu2aWzZwgZQVnHYsc0p+LyRxc58SLnLidxHiUtyAOk0rrLfR7sybMyaIx6nzHW7Y8mbzOa8WbciWO4D4v4X1nFXW5kMZuXKzm/SjiwQ7E4oo46IRxyD/WFO40xIzHW4a9MyeXkyvtN6oK5bnLDAQTiaTxdS6ptcT6yGNhkUL28OJOEi8HqcpQn9zL1giID6OHxjgR6nErBP3dZ6L1EPwCIvdllprFTisFcrvOby2XVGWjaZ4peC2m6ctlJnaU8cvWnMXXhZBsuD9fRW7M6eayuOqM2uFt+PkNGTY2pe+/kfUdy0dKvqkT72R9ceKjrnA360Tjsd+9au2nLNddFe/+1ee2qr57HVuwQ4qctd91199j8IcNw7K1l9yfQyfgX8ffxH9K2rLtjYnSsxzx0xLQ7Xmp7dd5ff6Frn1OSUR7Nyp9324mNK39/C8bAXrfEJ5IFwF5GVKvosw17GLrHIsmIzOIJnIEkMOYywEB5RJGlv2l3+NkClrA9ZGu36blbnBEjSK/B8wP0HKKSnquoR7PBECkxWkrLigmxWc0OO2l5+bHOOdNW962ff01JMD7xLP7r5ziASf+J+NvxG/712fjeHfOgI9XQEUXtyFjFGSZheT6ZL28je8hevSCJRgR/ZiPtEgKtUu3SQfFv3A4t7Yz55mramYHBMz/si2UkA9oTU2w326wCYUZPrhmeNm/9yW17RtW9GJ/Y9dOLHy37V/w8zv9tPP3i21/Fz8e/A7Z6BLYYenZoBDG0SinOBo3kWkcL26Llch3ljjH2RvsCO1fuKPWs9TzGbdVwPlMWRsRizjIYRde/ex9h6Qhgf6AgQAImsx/5jQXAwnQf8P/wcUTTldcRg+o2cJlDAkUOu9p7nn6DoHeBOT+SAMtQQf8I8R5pvrunOa9s3vh7Zz87+A7O/sOPy8bMrKi4dfLIQ9zRtNAr8bP/cujezjl1uT72lUslevO0n+3bd3ieWZ88DeZdMFAtcSoaDRMSQxrYj6kR06FIacOjsn/4CKpK93enoPJs2lBIBY+XRPnP0pcyy0qybCFprFHyyUEyhPVL+TBxC9gW6WZ5OVnBPivtkw9JR+UL0reyfRe7Wdolvy69Kf+WnGbflz6Qz5LP2E+kL2TdcmmFfC+5n71Xul/eTIQGTQu5mZ0vLZBvJ3ewQg2pY2ukOvkG8QapQRaccr4+SoazUWmEXKkXGKJleUmSbcTNOiQhtfh8hAVVkdMKQhGv1xapGgcBO1gX1VBPHaVeQ1V40Oc1SlKp36kYaUAjMhixmAgyEunWXFlBraXk4m7C+QPGdwdogqcnMULJg1b8LNhwRQxrZRiWaGS5iCEQBIME7CUwZLQy6KyC6NNjUBd03fTl5VEyTN1UwFhRNxMHWDhckaAIq0QsnlgFs3BC49doSQ8ZpphhF6FmEKJmECryabGWVqOjxozxfPtAJGKs+FdjhdtlHGwfbK9wO42gikKC8Uw7dF4976yA3v5QN03poZbJIAjFRP8BjZ8qnU3qJ6nto0i7qu7jAL1eA87bgo9hGQv4eHwg/of4n+N/BNXTyXz2bS17z3crqVOVh9v4dFjFNpSNDcpda7xrA4+jx6077Tsd/ArjXY7l/jXyGv064zrreo/Ie6Ust8fqtQZcWbc47kTiUoQbhQVghdzhviP9Dv8GYb1pvXuN/zHhcc1W0/PCYfvr9vftpjJPg6lVaJXvRHcIPIOvQzeiWxGbac8IhzPtAmJ4EkrLMzDhHnLdodCEjDyJpO5ZSQ+erBiYdyUpFPK5wqRufy42pxarOamS5Cq5zbltuR25nbm8P/dcLsmFfUeL6YOhAi2jpSpJzj+qJLBwzwyayvNR5fmBiHEwnjxcVk3s8nL1ZkfV2pqy7A5BPaoLXtZVTLCus0pTyorNSI/qQuEyO1d4W8dt1Yr+yOb98Zfid4OFMhbX4pUl2fGj5eX9hw796U8vKuXTmyY/dPT6oW9bg8KPKvGDeAGejzfF2+OP/XTzQqX6pz+Kf3dpELQZ24jA80Ww2B8GrS4TFrsLbVCGCaIgCUbQkaVrxWsl4QZpmnGrcZtpu22HfY/xiP23tk/4C7xGp9WCYBOyLJJW49e9RbkXjO8MxVPvafYwbZ4OD/F7Cjydnj4P68Gg3vhdBa4+F+Oi8s19lamtyreknU1PQlVdV9V2LAET7HFXjsyMepK6zHsYZ2ssm368ssONswvuPv3Sbz5YafUCu316Ytj02+ZvfYmJXIrHL364tXHWjqkrL8Dw6DO2czA8DdqsXCNyrCBm8WYfhwu4/RzhOIlhqc4uS1kaJAp8HUPGyEiDNW6/rkCn6BgdK12tpGuvFs7q2yMwfCrOV1wRzyaqpatKBCziLm85rOGOLrcKDqjKQCMUUm+pCwtgDdkCKfcoW3npc9I/6GeKuaMX48e+ibd/A71/Anr/HPcS4tA1irteoPojy2RxSGQ5N+xbV3eNL+y9umtx2qfxgyn1sVi9K3sCZ5N+7qXvxtKqv7+fn6x2Vsmht/OgtJIOLsb1cae4r5K66yquExK45JEtYUIYXb6HB8Ps393Dp27ei5O37qqqStCU+ES2Wb0TyMfXK7OXe9d6iVmraytco+soZP0YjCGmABeTYkbB1aSamWFotDZmTcuZFmnMv8Vw0XTRYh6hK7aPyC4eAnqnvS67Zsg57aBDfhAknkar0+RqdWG93WHL02lBM3JmUlXykPoaTX0WpDepD7a6NdokzM5NPkYDhV2FhdHkozTJ5lGP8mdy9B7LZwhToJfz6NGpxiY4XXxujibkdtJTZMnlcrs3FeJC3IN7FBkVZwbMroIr937nUzd/9L7pzOVr/sHzqbOTy0dHSO2c2niXpI2qT8m+lxDUgZFacdUdsK7V0GptzZqfMy/Smq++DnBwdsflk/wSPpiRekzmKIEVBKvGD7qj5aqb4TtwlejNnrawLMuiW9n3/l2zMT75sw4sjGw7tin+148v3ds8/8F1C1rurQ0Ps6UH7IXBm3a8eGjTe1iD3T959NK1x4/eXNH7oJ7c+/wTTz35XOcTMLdrE5+xj6RuVJ+g7+suKoWa8jLPtR5ipi8nkner3wh8CTtCN8JS4hnN1unqLKM9jwiPSbJWDzyNrn5NYdFoDEi+/JrCmAMcZ6AE1+J/fEuRvFf9dy8pVGIBrTT0JUXybpWjlFJ5srS4yJx6SGGzXH29uha77ul6JR4f7J1xQDFHx97RdO/q+S1ruKOD5x6Jn43/PX4u/uGMxp0k97kJbbteOPzUE8AnGlid09UTao9i47Ld+VGBejz1ROox9IwYoPpyxe8eHn2cxTwoEaKs1diwjZgZt+SWM1Ce5g2NFrjgnGL3+qMy4jRW5NJkoVxNFA3XrEVS6qRIxjqtWpdGckRZ0MYxj2RQa0ELKY+oBwMexaxBMqsBvYIQzENYKqeviRRnWnZUo/OpUo3VORxuo1wpT1At7gJFw5JyDVvJTmAZUEAKEAYVyKAtQdgPphiDXd+fKEec4weagKebXOpJlxpX1z3VJszlGLqgPviKNNHnjclzKhywOOjtEz0oPhKfgsM/H+7g9cZf4EAcqDf48aHR9rw8kq7eedBjnFxVXD+jZEksJzNEkrNY835QfBjEUzFEBFEEYc2Jfv4tqlOrW4+uXtesY9p0HTpCJXenrg9GSTT+H5zyav/DrefKsTg9ZVHFN6OKb3pWC+Kbgn8Q35cl+JXvVhCuNTg7fnrwODDNSVL1bS25e3AVjGkW7LA3gerjRu8r16+R1lvX23eh7fwb0rvMu5qvGSlLytZm63KsOfZl3DJpDSeCDe8AG96RQ3JB2AvZ3GPcNulN5mcarhJPgPUyyYhwPz04SD56dCalmKwDiKcrDmceK+oVvTmqr5tpwBMMoG/ZnFFYRNlKhjlPZgxf6aehr5BalbsgDafZwp0CNgg+oUBgqG3S7Vk5+Yomc9UL20H6xO9M8uEYBJqS11ygxHCqIaqqLo7UszzeRLWWUrYS+0bFf/1l/PfxdfhOHMW6vXOL4r9zP3f7M7/8eeft+4hnxrnP8SY8HS/Ej+66KVa7ePUX8W/jX3y5lf4vDWCGKcAMPNZ3IwaLdC81l6sK+hRYTH3i+/h98gH7AcdRY2AFtw1vJY+x27ldosggDZ8vUoOjWVyOBRey8zkoxI9F1/I3IFAFCfFjZAVDl2eunBIzPWS2ouGBtVjQzTHhjpJZiKV3gGZYHXgV28F+xPazLNuDNYq8iulgPmL6wTCimw2UAA49ijWI0PNhehfsEq46H4aV03S+CZbLwBXNe+CHevf31wl93cbkRcIhSRedAgZH0+VXlE1N9KYdNcGSwtRS1gyex1V4CSh4wwf/xh397lX2GnW/nRG/lZ0N+60JedETSpm5gkR1UWtF2jhSo6uxjksT23zYK9oc0UauUb5BN83S6Gh0T/PulnenXZQu6L6xak1I76FCmdXYkkJZMBh5Z0B0pZtzgGohk0kVytImIza6fclt78JVr9vO/8Pjtkh76nlbK9cqz7O0Olpd87ywgWETr25ayYeGdNfC0e9fITJjy56deWjZBsz03byjAjPxc/fNnbd+9axZD8VvJfZrJ6/bhY0YYd/0GU98W8scfGbX07H9O16CJRdMnGV+DZxjRtOVzFZxj45MkeZJrbpWY6vpTuN6oyCP0dxtyBMk0GOR2U9fUWxUzG1WXGDFVs1XPhnLLstgSlpQbb6dbuZJFWfw/Jkk44P9A2o6veINZ9mTWwnZjcP+yMe9H3yBsYPzF8yeMwmU0+bDszt2/O0v/pXRCe1d0LsbmQP4Qegdh0Yq9jXcNxzhuXnc7RyDOAZj7jxBTA8WFQ29hCD4T/z46st8hCrHD5TjpPmAF7dbmJKAjdlSgouGQpWmixfjsKzRQ/QxF1RvR11KxIB9uJyqVsZReJTpj/jvWBI4O5dJGkwLTBzGxGI1mS2MlWD1ytzLCGC4W22yHSGNHBIl9a5cwgkJS//RXTmyhuz0hwHJu3IbPgdb2398V35FU1Sf24CW41CfMIiX30Caki+6fvCuxoRfWHdi1s4J3vhZ/8RrahcWx8+CjP1k15i2dZsGt5DCPdNLatavGfwSBo2RHpTNSbArW3D0oDmbwxZ6QOHUGqKiXWeICtTjqcfZIY1agIoPhAnH86xOo+eNBFl41gJqNkOlg6UZGLwH74dt1aDL12cjv63A1mxj6Bip0M0IRdWhm9PSozZ6fVLOKE5XlNrpPTisSESN0Wc6EDPjcqSklUZTp5TW11LPHSNJAUF31+QFUiTSvni88fwZ+oonPykvYGdNnvVTxbBc0KtqYWqHbaqLGSfXxYZPnN7QxRrR0cQ5EJ7nDjBGrN4YpcyRzxS9zlRpMVpc4JmdlRy9yIYIhV0QT9bVaFFvdAU9A8syrD4F1uNI/CIOxtdXZ1XfsKp+4vWuUSWzb3LB1q0nf71EeptmX5Nh+r1uSSMQf1m8Fz+H6e+1Kw9JooaXhR6crnj4nXiYRpYX45CQSU/xkzfVLu3821OcfWZwgPL2+UH1RoOytyWg/uwnXFpaFrwfu3KXTS+bOoasw64373ygzb80bfZUaO5phJgQ14ckNE2RbiE/IhsJQ0A+53TPVK+EbzoiShxGWgkdww1Ac0yaFB2HWB/rZ2MgyV3yUbwHd6LLasGFy+/BzjcNqLcqgYCJF0pKM8uKmVD87ONvL8Sk4Awb3Dw6kfnmGuhAMaw1LXTAiyuVmYech929nl+wbzhPOU+5TrnFak91WrV3mmsH+6hzH7s7TeTdfpTNl7nHsNXOale1W8x0Zroy3Yw9xE5j1zl3enam7fTuS9vnFc30FZPfW+i93bvau9n7vldUnzjZrbaolxi1Bi+9HFNvDhSq3QArmu2w/5OnugnWgmyepgR92nwt0SqQrt1t4aTTdjueAF12+wynjcuJK/2dVy4/GKOyu4IaK7DHR9rPgCEL+ztVKrGpOJLUh7ygCJnKaR+6DCpQ9MZyVjSWc6IJoKn8hyfcGsnj8hCPBdPf4dMXuuZyerqN6YXhCeRJ9KM0cN5Ef+pKE5QIU6DUrJox6gYgZJVmwo5A77J4lhdY7aWwsfPLn0aGtzQ2LBDjn7mw+PoHF68dXxy/cK0dc/HvHsHS7w5U3jD1ppabf5T22S++eGlO9+yq8/UhmPVpibOsHiZJDyR7WKlbIa+T9+B9Ar0ZPCL9XBKnmRrtsP/55psW2Be45/vEclLOl0qlurFkLD9aqtXtkX5J3uRfk17TfUB+x78rvaszGZ1+J1EFYhYQ2Llb1PkM+QZioOQ27Eac9/QEFrPuDOtpjStwmdIDyU2SPvpqpy4p8ppwkcNuMgrJp59lpQ4YPVWf1MVXajKGQqTovRWbNi9/7/34t+AX19u90QnFScD1bT8YnxlvPrwVj8W78ZOHt35eNeW2OHxeVqqm3EpPDF6uglkfDzTwAA1y0AdK0Vrbmzbyo7SNaWQ38zy3x3qYOcodtn7o/INLtFvxA/YHHCQg6xCLHRZ7wKczauUenKloJ+iwotukIzodtvdgohh8lnwLsdAhW3Z7OLCEpx0ywsoiqo1SBMns7rAupu0DNtTajadX+Tb5dvn2+076OF+/cHpCJs50R+ynHcvxaeTKvUKk8ykywRqkxykpnqSeerqiPtBMysIUYyV1I3TVtUkwQyizX+GkkQQMYmAlgd6Z0MfS47FRt3jiDcsXTyqt8y1e0TB2zDxNfNBz26t3vHXX/HdWbot/+ps34t/i+wILFq5uu/nHtk+Y1hvGNcxtHnLfrhmrb1338hLP8ftejp/7BOiay+7FX6kP3K5Vn4J0m21R9bWPlj7ZpDcpRvUJfKMig/j5BC000q2BzDpEXOwzLyRHPNh0/qoHmzgIqt1XB+Jf4hH0xeZ/+l6zFJ266r1mQTeoremXX2QmV2JP4tOD6ekajRLxKFpDui+9Mp1J18hjYItppM8130QIfwy7Jf2ZxlDFwwzDPD+MlaX9oCLzIeznCjjC7Rd//YJ6qUPf3FdcSF2zXv51xZvJX1cwOgov/Y360Gn1HajaaeO/6/SHV3XaBoTBURaNCQO48poUKLsNROtq+lQILVYqQSfnuSzBLxaIJ8WPRDZf3CwSUUTJ4zsJiUIlP4En/CQGQdydfPbzw7M7+Z+d3TVVfP+7U/V6/d+dzW1jBgZHkLmDO+m53HMXB7fQt1ZgmEymVioeoTxlYj3yRHa6zL7A7RZekJ7V/A6/K/D3abbjR5jHuW3C49Ijmr34WUZyY5uQDTtgI54m3Mds4DZIUhSPEIhL9rP5cg17nTxDXs3eL29hd8md7LvsH2VdGTtMfpjdIb/BvimfYgWZSLxGYERewzIiB7uZxKkPzfzfPyrzX/WAjKQekOHjR3jFYovydfTJS7fo1oGlchwRsDAgldRp6FsFTUor0VKrRbX16ZOxyAAELyRD//B67HvThT74u/JizBxWX4x1J+EvjkimqFwK3uXHUOr1VXt7O1pciJNmDP3DX8eHgxEIDIdviA+D2I74sfhRMkhOxHPwbweHDerxd3EOJWmf/Mw0VHyNkKiG/zw7ctfVUEym8+gyBvjCyPj1alhO7ERz0T9+KkgD0G0aepTxorXsElQFrgDcVFKOHmb/jDaSfcgHcBK4LZCGAE4RvGglpB9LlR9LyhODkP4ApDkhruXeQNvB0bJDIG0JhLfy5agR8O+HtsZB2i3gqiH9EX4f2kLzIPww7QfgPJFqewo42icNxQc3i5uWSEDaDEgL4rPoRgg/BGE9lF8G8GlwxeCmgRsP9efS/gF8k/YRym6D+q/+nKJPGkCVOglUAiKLCriPEZL+CMSKgyEwgJD2/aTTvY6Q4U5wv0PIOAwhcy24HQhZ7kHIejdCdqjZORkh168Qcs8Gtx+hNDNCXhe4pxDswODWIxSAtMB3CGVOQCjrM4RCQKXwfeD6Ecq+DqHcbIQiQYSG3I5Q3jiEht6LUP5xkHEnECqcAe4oQkW9CEVLwT2HUEkIodJfIlT2FkLlYXAbwZ1FaDiMZTj0a0Qa/X+jKjdUAG+sIAilA7sbUT6CHgt1pq/VOAwSbb3CM5noMv8QEI+ZqTADoUgqzEJ4QirMgda7JBXmIX0llMSsBCljQFFNhgkoIV+kwgykX0yFQf5hJRXmkB2vS4V5SH+yoLSsZM7sovK84tkFs/OiLbNm5w0rjJblFZYWF8xumTunpXxe8aSW+ctunbX4v1L0v1JmWsviJa2LFvoLhxb+V4qD6ChFZagEzUGzUREqR3mgGc+G1NkQiqIW9f/v5aFhqBBiZRAqhPLFan4LrMU54JejeZAyCULz0TJ0K2As/m+r9b+rnmkQov8rsBUtQguBlQvRUHD/XbUz6D/9VGnRFGY//cIm6UU+5iXmJ6gC4E+6ea+vo0rHvIj2gwOmBt8PrhMcgxTmxW5BV6T0ADRbVdhljxT1JvogMLxYTc97pKjjOPMCmomKIfmFrqk0+YVupaZIhcUjkjC/UIVdYjJbsBb5qtyAlg+OIEMqNAHcJnC7wJ0Ex0OHXkAfgUuAY5i9zNNdtT6o4TmoyFBlZZ6DJaKA/xa4BDgGev8cjOU59FUqhYVePdMtaWnzz6hYHuYZwDKAbwTXAW4/uLfAcWgR+LvAJRiqMe1inoa8pxFhnmae6jL6jFUy8yRaBY4wjyMDpj+G7GO2dxtV2jzWbbAUKVVG5lFUD46gGDMe9YEjUO0WQNtC902mriuvUCVhXbesLzJC+Y3Q6Y3QkY3QZCf4WI0r4Gj5jd0WO63+3i6DScX7UVdBNBnoNjqL6oEKKxBmWpiFKAhTuhJgOsA5AOlUz2bmIp3aT6XbYCzqgPYqoXglYwN1ycdUMXbgPB9Tw7iRRy22rEufbGdZV3ZuEYy4mnGqRQyMDtjQx4iM0FXk8x9jFJX467olDe3fui6jregEcx8jICuU6oBSDp/hBCPDzMrqSKZ0S7qizVVaZgoMcwqQxQd9xEDlhWpFC7ugoioTM5pJQ3bIuwW2UxvAWiZdhXuYp1AtwCe6Q2m+vmPMwyrWQ7RSaH5kkrVGduv0RX1VEkOficaYB2ECHlQb39wdGlaEqkJMNioAR4DGqyC0SmX6DRDaALO2AWZqA8zUBujUBqoDMOshh/6qM5+5E7Uxy9FmcLsgTNnK1gUE7VUDmdlFvYyLcQJhjMeAlBhS3d2SnvbM2WW2qMWc3Vp9UeUJZgnw+RKoU2GWdjucRYuOMbnqUIZ0Oz0Uoa0L2PUE40hODSDa6ZScYNKAEJQwXia9y+aLVfkgThnZB+rcL8gpSiTyDnmPTjf9z4Eq/GUK/joF/yUJE33kVHJRkN9Q2F+VRqhNMpP8Ae2CECHHyKsgaHzkQ9JDe0E+IL2oEuBpiM8F2AuwGODRrsDPfT2kpxsA9H1Hl85OB0te7YrkpwK+rFTA4UkFzPaiqizyCnkZpUEVvwWYCfBl0ocyAJ4E6ATYR5ainwM8BFJrBMCDKfgaOU5ZnBwhh0E2+kh3l552IdYlULC/i6fgpS6UjNXn+46Tl8gLyA1Ff9IVckPq3u5Qps9wDOrD5DmytMvrM1fJ5CncgM9DoU50mkJkJk93ldFKNncd9/t6yWayWXGWKVlKnrKbKcgqyCvYzfiz/Hn+Mv9uf5WRPAgCZBeB9Us2gl+G/AS4B5wCbjNZ38WWxaoGYUx0XAR1gN+phprBb1NDCHzjldxzaqiS3IcmgCNQx0pwq8B1gLsbdv7N5E5wPwL3Y3B3qSlLwS0DtxykSRtgtAFGG2C0qRhtgNEGGG2A0aZitKmtLwNHMZoBoxkwmgGjWcVoBoxmwGgGjGYVg/a3GTCaVYx6wKgHjHrAqFcx6gGjHjDqAaNexagHjHrAqFcxFMBQAEMBDEXFUABDAQwFMBQVQwEMBTAUFaMAMAoAowAwClSMAsAoAIwCwChQMQoAowAwClQMP2D4AcMPGH4Vww8YfsDwA4ZfxfADhh8w/CqGETCMgGEEDKOKYQQMI2AYAcOoYhjV+VkGjmL0A0Y/YPQDRr+K0Q8Y/YDRDxj9KkY/YPQDRj9ZfoA5VfUzQDkFKKcA5ZSKcgpQTgHKKUA5paKcApRTgHIqNfSlKjEIsM1KcKvAdYCjuH2A2we4fYDbp+L2qey1DBzFjQFGDDBigBFTMWKAEQOMGGDEVIwYYMQAI6ZidAJGJ2B0AkanitEJGJ2A0QkYnSpGp8q4y8BRjP9zpvw/nhpyN24QYa8lHThHhavQlypciU6r8C50QIU/RrtV+CN0jwrvRGUqXI5CKoT6VLgU+UTc5SszVNlBBEwANxPcInC7wFEl6SQ4QQ29Be4jcAlSomSwBmGCsEvYL5wUuP1Cv0AM/AR+F7+fP8lz+/l+nvirPESnylEQLWiT6q8C/ytCT0zywa9UQ5UkCu1GQc6WwDdKooppwP9VLn4rF5/Mxftz8aZcXCWRazGrSjo/KiPQcdygaEMjfafBlYXCI0EyPXj4S4evK1TqAzs8CXKUCMAvwR0AtxvcPeDKwBWBywOXBc6npuVC+QYlI1XlcXBhcAFwftoEsttBeTSbRKWX6PDu7p/pED0F6ApnA96xrnABgJ6u8AQAR7rCs31VEj6MwlQrwodg5l4AuL/Ldwayf5IEL3b5jgHY2+WLAmjqCg8FMKMr/GtflQ5PBRuZok5JwckwbgondfmmQbGJXb4cAJGucIiWzoWGsiA3BzegMwCzUliZyZaCXb4RADK6fOW0tIjCdOIxj/LU7nHgKGS6oUNf9eIGFisa34DvYd+XgP4XICywxwf+HhbAW1n0SFz2Hc97EgpX+bqqZFoe9ocDKRij8JBvd9Z63w6oC2cd9j3mG+p7MK9HhOQHoN/r1Sa6fPf4e8gLisXX4SvwLc0741viG+eb5Zvka8qC9C7fjb7jtJuoETeQFw776qHCsTCKrC7ftVk9ahdrfXf4FF/YV+4/TumLhiXrLcs7TimAipKtDwH65mb1UB6fWtaDTUqucE7YLMwQRgkjhKCQIaQLXsEqmkWjqBe1oiyKIi+yIhGRaKUHkBFqu1p5+pNPxLPUZ9WwkVCfmrpgqhIsEjQOxSxMHambPArXxfrmoLrZ/tiFycEeLE+cHuOCo3DMXIfqpoyKDYvU9QiJSbGySF1MqJ/RcADjBxshNUbW9WA0paEHJ2jSfR76rywPYHTfA55ehLHrvgcaG5HTfnuls9I80lReW/NPvOaUH/n+47w66I1trZvcENvnbYwV0UDC21gXu5v+o8teYiC60TW9RE9BY0Mv20YMoyfRdLatphGKnVGLATfroRgKUwDFxFHIT4uBPBlFi8EcJcuFAB3KBSiAcrIOhdRyIVmnlmMxLXfgtH90zQG/Xy2ThdBptczpLHRVGeAYwK05EAqppYJ+3EBL4YagX+1YjlqRzwdF8nxqEQx6nVqRD6uNxfK/L5KVKlJypUiJ2haDvy/jS5axZl8uY82GMpH/y0/LqAjuLly28lX6v0Obg6NbwDXHNt6+wBnrmO33H1i5LPVPRUPNs+csoHBWS2xZsKUmtjJY4z9Q+Oo/yX6VZhcGaw6gV0dPaTjwqtJS01WoFI4Ozqpp7K6saKj6QVvrr7TVUPFPKquglTXQtiqr/kl2Fc2upG1V0baqaFuVSqXa1uhWyvf1DQdENIrelaqwm2hk4OFmT6BxlN3YNpIydO+IgHOl5yiL8F6kiTTGtMFRMR04mpVXlVdFs2Cd0Sw9/QexqSznyhEBz1G8N5VlhGRTcBS6TFpEC9F/+1cXC0ye3kBZJabM+udztoR+1GwnGt1aA38QX6o6+F5dEi35p5+l/+yzbNmyJdRbFlmCUF0sd3JdrJT+E0JBgKaaaxohbejlNIZR0w5I0uieRB9kRqATeCltjoYimP6CRpHB6hJIJ98pEGoqLO12e4sWnYAdfBU4sOPI8q581Xwmy7szsqj9srQ7vyQJwVylsMsdKKK3mmWASmFWEiqmPAhsztqct7msM6szr7OMh9TDuyHRt5tupV35uxm0NLLkMiEguLQRJX/YA+091ZXmVRvupIFIpDGyRL33vjId339wCn5P2CWpWpeo1S+NpCYkmb4kVQnMRLL1ZZfRlqWQ1MxlKlKykmTsivf9Z+kyWhWlJ0jp/w+TzkaGDQplbmRzdHJlYW0NZW5kb2JqDTM2IDAgb2JqDTw8L0FzY2VudCA3MjgvQXZnV2lkdGggMjc3L0NJRFNldCAzNCAwIFIvQ2FwSGVpZ2h0IDE0NjYvRGVzY2VudCAtMjEwL0ZsYWdzIDMyL0ZvbnRCQm94WzAuMCAtMjExLjAgMTAwMC4wIDkwNi4wXS9Gb250RmlsZTIgMzUgMCBSL0ZvbnROYW1lL1paUU5XVStBcmlhbC9JdGFsaWNBbmdsZSAwL0xlYWRpbmcgMTA4OC9NYXhXaWR0aCAyNzcvTWlzc2luZ1dpZHRoIDI3Ny9TdGVtSCAwL1N0ZW1WIDgwL1R5cGUvRm9udERlc2NyaXB0b3IvWEhlaWdodCAwPj4NZW5kb2JqDTM3IDAgb2JqDTw8L0Jhc2VGb250L1paUU5XVStBcmlhbC9DSURTeXN0ZW1JbmZvPDwvT3JkZXJpbmcoSWRlbnRpdHkpL1JlZ2lzdHJ5KEFkb2JlKS9TdXBwbGVtZW50IDA+Pi9DSURUb0dJRE1hcC9JZGVudGl0eS9EVyAxMDAwL0ZvbnREZXNjcmlwdG9yIDM2IDAgUi9TdWJ0eXBlL0NJREZvbnRUeXBlMi9UeXBlL0ZvbnQvV1sxWzY2Ni4wXTJbMzg5LjBdM1s1NTYuMF00WzU1Ni4wXTVbNTU2LjBdNlsyNzcuMF03WzYxMC4wXThbMzMzLjBdOVs2MTAuMF0xMFs2MTAuMF0xMVsyNzcuMF0xMls2MTAuMF0xM1s4ODkuMF0xNVs1NTYuMF0xNls1NTYuMF0xN1syNzcuMF0xOFs2MTAuMF0xOVszMzMuMF0yMFs1NTYuMF0yMVs3MjIuMF0yMls3MjIuMF0yM1s2MTAuMF0yNFszMzMuMF0yNVs3MjIuMF0yNls3NzcuMF0yN1syNzcuMF0yOFs2NjYuMF0yOVszMzMuMF0zMFszMzMuMF0zMVs3MjIuMF0zMls4MzMuMF0zM1s3NzcuMF0zNFs3MjIuMF0zNVs2NjYuMF0zNls2MTAuMF0zN1syNzcuMF0zOFs2MTAuMF0zOVs2MTAuMF00MFs1NTYuMF00MVs3MjIuMF00Mls3MjIuMF00M1s2NjYuMF00NFs2MTAuMF00NVs1NTYuMF00NlsyMzcuMF00N1s2MTAuMF00OFs1NTYuMF00OVsyNzcuMF01MFs1NTYuMF01MVs1NTYuMF01Mls1NTYuMF01M1s1NTYuMF01NVs1NTYuMF01NlszMzMuMF01N1s1NTYuMF01OFs2MTAuMF01OVs2NjYuMF1dPj4NZW5kb2JqDTM4IDAgb2JqDTw8L0JpdHNQZXJDb21wb25lbnQgOC9Db2xvclNwYWNlL0RldmljZUdyYXkvRmlsdGVyL0ZsYXRlRGVjb2RlL0hlaWdodCAyMTcvTGVuZ3RoIDEyNDgvTmFtZS9JbTEvU3VidHlwZS9JbWFnZS9UeXBlL1hPYmplY3QvV2lkdGggMjQ1Pj5zdHJlYW0NCnic7dnbkeMgEEBRxUIcCoRICIVYCIZctNDdvGTv2vMxtaLq9s9YsrA4PBqkOY4Pce0UnzDfxv92/ChAgwYNGjToTQI0aNCgQYPeJECDBg0aNOhNAjRo0KBBg94kQIMGDRo06E0CNGjQoEGD3iRAgwYNGjToTQI0aNCgQYPeJECDBg0aNOhNAjRo0KBBg94kQIMGDRo06E0CNGjQoEGD3iRAgwYNGjToTQI0aNCgQYPeJECDBg0aNOhNAjRo0KBBg94kQIMGDRo06E0CNGjQoEGD3iRAgwYNGjToTQI0aNCgQYPeJECDBg0aNOhNAjRo0KBBg94kQIMGDRo06E0CNGjQoEGD3iRAgwb9uMjxf9fg+8ilnc92EHPQQ3eVD6H8sV4I84dQLkzpuspFo0S9wIXLHYcvn5JceurFj4sr11p6O4r1sFS2aov8vGI958qp8mXKeiDW2iL6wUpITwe5th7I2eW3nxPSNaW77DDKYU4FVgdrkvNFE5N+74RQmkAuVLSV6GgpWb8S/RNHfRKNl5ofTV9QToaljs1y0tsUGBfWrtfhbSUa+tSuLc2gDfpAdLbseUaZk9qjDe1GbpWP/h26lWhor83zaHRaDpUQO3rJQvk6/4aOrz0dn4uOlpJni87pcLQmSTbjy4TWOV3oA91KvJvTD0VL9j57j8a61rQMXb+ImprFXc9L3ipnJ7SVmLK3b9n7qWiZ1X1ViTnqemwjW6ZyrXpqH+qqHJdEZiUk2d3W6ceil+hr1y+WeFyA/qUSBEEQxBzB9lV9T6nbhLbZSrpJcOPtjD5D6PsBferw+jcd42Fjfu7wupVpv2i77PqmwLae2W4RDt/KuLP/entZcep1qd3KtrL1zHgC+nJLE3TLJGgvVfPyNkDrGPVn9Jk+yhdxbEBDe3KUP7VSVu4cd8+lSrWSrp1SdJIy9iQWGvowfn+eqb9pjVK3qE2ea51n9GG17S9zPqJzQ1/O2XNPgcg9re1sUyjPQPrrb9C+b76nitR6eNuJuoG2g9oSzl48DXTuiqT709jv1Zojpzdo//VLpjK85dqO1kciZ/t/Q6d7obfoYxoh7l4PP6Nbt3sZVNLsHT36K+hMSG2EjTkYwit6GiCf0U7uok865S6nDVatgtYuXmPGy33yG3St4a2n53q0Op5yj/EKrBSR2dCK+mn2W9OURsk6rOeN3B09Bsg36OPKUyP6N+gjLlnC3+f0lL3CfMFUj3Oe035FW7awqb1M6KPdQCs192VcX39/PaGPlsDCB/Qxv/Q9273XntZR2DP2Wg/XBe/Q1Wfo24RuPquN3Fiz+q2nv5/Qhq616+h3w3upuO/tvaI1K023nupxdrMN73GZFCnjQIu+TOhjusMY3v6O/sGEbujS0h09JbKGbveU/BVGO/wbPdXD2knaUxNZHyuuYb0uly8TekYvw3FB/2BC9985r5GqbMlyA926PebFfENXzYwe9WhjQ1ry1LSpiiuNYS3/Gnmd0DO6N9Yd/ZMJ3dFzfvZz5ZUYbMHwawes6HzNi+00PAelZv1kGyvdnPSl/azoMY1XRUefmrXSta7T57dbsRV9TIvSvA29btvQ1HaHC1piWWzHzvBKcWS33HKtFkrHvLSHvnO9xiY3Lmjb/mYt0NG3RE4QBEEQBEEQBEH8ZvwBGkO3Ow0KZW5kc3RyZWFtDWVuZG9iag0zOSAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDI1OTQvTiAzPj5zdHJlYW0NCnhenZZnVFPZFsfPvTe9UJIQipTQa6gCAaT3JkWKIAohCRBKiCEBe0FEBUYUFWmKIIMCDjg6AjJWRLEwIKjYnSCDiDoOjmJD5SWy1uib1+bN/8O9v7XP3ueeXc5aFwBSQAhfkA0rAZAlEIsi/b0YC+PiGdh+AAM8wAAbANicHGHoAr8oIFOgrzcjR+YE/kmvhwEkf19jBoQzGOD/kzJHKBIDAIXL2I7Ly+HIuEDGmXliodw+KWNacoacYZScRbIDylhNzqmzbPHZZ5Y95MzNEnBlLD+zkJvFlXOPjDfnSngyRkJkXJjL5+XJ+LqMDTIlWXwZv5XHZvHYOQCgSHK7mMdJk7G1jEmiqEhvGc8DAEdK/YqTv2Ixb5lYnpR3tnC5iJ+aJmaYcEwZNk5OLEYALy+TJxYzw9mcDLaIy/DOzhKyBcsBmM35syjy2jJkRXawcXJwYNpa2nyp039f/IuS93aWXkZ87hlE7/ti+3d+2fUAsKZktdn2xZZcCUDHRgDU7nyxGewDQFHWt/aBr/Khy+clTSwWOltZ5eXlWfJ5HEt5Qf/Q/3T4C/rqe5by7f4oD8OHl8KWZIoZ8rpxsjOzJSJGjpDN4TGYfx7ivx34lb46h0UkL4Un4glkETGyKeMLUmXtFnD5Yn62gMEX/Kcm/s2wP2l2rmWiNnwCtERLoDRAA8ivfQBFJQIkYa9sBfqjbyH4GCC/ebE647Nz/1nQv+4Kl8ofOfzUz3HekVEMjkSUO7smv5YADQhAEdCAOtAG+sAEMIEtcAQuwAP4giAQBqJAHFgCOCANZAERyAOrwHpQCIrBNrALVIFa0ACaQCs4AjrACXAWXABXwFVwA9wFUjAGnoJJ8BpMQxCEhcgQFVKHdCBDyByyhViQG+QLhUCRUByUBKVCAkgCrYI2QMVQGVQF1UFN0PfQcegsdAkahG5DI9AE9Dv0HkZgEkyDtWAj2ApmwZ5wMBwFL4ZT4aXwCrgA3gpXwPXwIbgdPgtfgW/AUvgpPIUAhIjQEV2EibAQbyQMiUdSEBGyBilCypF6pBXpQnqRa4gUeYa8Q2FQVBQDxUS5oAJQ0SgOailqDaoEVYU6iGpH9aCuoUZQk6hPaDJaE22OdkYHoheiU9F56EJ0OboRfQx9Hn0DPYZ+jcFg6BhjjCMmABOHScesxJRg9mDaMGcwg5hRzBQWi1XHmmNdsWFYNlaMLcRWYg9hT2OHsGPYtzgiTgdni/PDxeMEuHxcOa4Zdwo3hBvHTeOV8IZ4Z3wYnotfji/FN+C78AP4Mfw0QZlgTHAlRBHSCesJFYRWwnnCPcJLIpGoR3QiRhD5xHXECuJh4kXiCPEdiUIyI3mTEkgS0lbSAdIZ0m3SSzKZbET2IMeTxeSt5CbyOfID8lsFqoKlQqACV2GtQrVCu8KQwnNFvKKhoqfiEsUViuWKRxUHFJ8p4ZWMlLyV2EprlKqVjivdVJpSpirbKIcpZymXKDcrX1J+TMFSjCi+FC6lgLKfco4ySkWo+lRvKoe6gdpAPU8do2FoxrRAWjqtmPYdrZ82qUJRmasSo7JMpVrlpIqUjtCN6IH0THop/Qh9mP5eVUvVU5WnukW1VXVI9Y3aHDUPNZ5akVqb2g219+oMdV/1DPXt6h3q9zVQGmYaERp5Gns1zms8m0Ob4zKHM6dozpE5dzRhTTPNSM2Vmvs1+zSntLS1/LWEWpVa57SeadO1PbTTtXdqn9Ke0KHquOnwdXbqnNZ5wlBheDIyGRWMHsakrqZugK5Et063X3daz1gvWi9fr03vvj5Bn6Wfor9Tv1t/0kDHINRglUGLwR1DvCHLMM1wt2Gv4RsjY6NYo01GHUaPjdWMA41XGLcY3zMhm7ibLDWpN7luijFlmWaY7jG9agab2ZulmVWbDZjD5g7mfPM95oMWaAsnC4FFvcVNJonpycxltjBHLOmWIZb5lh2Wz60MrOKttlv1Wn2ytrfOtG6wvmtDsQmyybfpsvnd1syWY1tte92ObOdnt9au0+7FXPO5vLl7596yp9qH2m+y77b/6ODoIHJodZhwNHBMcqxxvMmiscJZJayLTmgnL6e1Tiec3jk7OIudjzj/5sJ0yXBpdnk8z3geb17DvFFXPVe2a52r1I3hluS2z03qruvOdq93f+ih78H1aPQY9zT1TPc85Pncy9pL5HXM6423s/dq7zM+iI+/T5FPvy/FN9q3yveBn55fql+L36S/vf9K/zMB6IDggO0BNwO1AjmBTYGTQY5Bq4N6gknBC4Krgh+GmIWIQrpC4dCg0B2h9+YbzhfM7wgDYYFhO8LuhxuHLw3/MQITER5RHfEo0iZyVWTvAuqCxAXNC15HeUWVRt2NNomWRHfHKMYkxDTFvIn1iS2LlS60Wrh64ZU4jTh+XGc8Nj4mvjF+apHvol2LxhLsEwoThhcbL162+NISjSWZS04mKiayE48moZNik5qTPrDD2PXsqeTA5JrkSY43ZzfnKdeDu5M7wXPllfHGU1xTylIep7qm7kidSHNPK097xvfmV/FfpAek16a/yQjLOJAxkxmb2ZaFy0rKOi6gCDIEPdna2cuyB4XmwkKhdKnz0l1LJ0XBosYcKGdxTqeYJvuZ6pOYSDZKRnLdcqtz3+bF5B1dprxMsKxvudnyLcvHV/it+HYlaiVnZfcq3VXrV42s9lxdtwZak7yme63+2oK1Y+v81x1cT1ifsf6nfOv8svxXG2I3dBVoFawrGN3ov7GlUKFQVHhzk8um2s2ozfzN/VvstlRu+VTELbpcbF1cXvyhhFNy+Rubbyq+mdmasrW/1KF07zbMNsG24e3u2w+WKZetKBvdEbqjfSdjZ9HOV7sSd10qn1teu5uwW7JbWhFS0VlpULmt8kNVWtWNaq/qthrNmi01b/Zw9wzt9djbWqtVW1z7fh9/3606/7r2eqP68v2Y/bn7HzXENPR+y/q2qVGjsbjx4wHBAenByIM9TY5NTc2azaUtcIukZeJQwqGr3/l819nKbK1ro7cVHwaHJYeffJ/0/fCR4CPdR1lHW38w/KHmGPVYUTvUvrx9siOtQ9oZ1zl4POh4d5dL17EfLX88cEL3RPVJlZOlpwinCk7NnF5xeuqM8Myzs6lnR7sTu++eW3juek9ET//54PMXL/hdONfr2Xv6ouvFE5ecLx2/zLrcccXhSnuffd+xn+x/Otbv0N8+4DjQedXpatfgvMFTQ+5DZ6/5XLtwPfD6lRvzbwwORw/fuplwU3qLe+vx7czbL+7k3pm+u+4e+l7RfaX75Q80H9T/bPpzm9RBenLEZ6Tv4YKHd0c5o09/yfnlw1jBI/Kj8nGd8abHto9PTPhNXH2y6MnYU+HT6WeFvyr/WvPc5PkPv3n81je5cHLshejFzO8lL9VfHng191X3VPjUg9dZr6ffFL1Vf3vwHetd7/vY9+PTeR+wHyo+mn7s+hT86d5M1szMPwD3hPP7DQplbmRzdHJlYW0NZW5kb2JqDTEgMCBvYmoNPDwvQmxlZWRCb3hbMCAwIDU5NC43MiA3OTJdL0NvbnRlbnRzIDIgMCBSL0Nyb3BCb3hbMCAwIDU5NC43MiA3OTJdL01lZGlhQm94WzAgMCA1OTQuNzIgNzkyXS9QYXJlbnQgNiAwIFIvUmVzb3VyY2VzIDEzIDAgUi9Sb3RhdGUgMC9UcmltQm94WzAgMCA1OTQuNzIgNzkyXS9UeXBlL1BhZ2U+Pg1lbmRvYmoNMiAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDU1ODM+PnN0cmVhbQ0KeF7tPWtv3TaW8o3jADbceNykndRuctd5dfKgSYmkpEWBFp1pBphZLDDbAvthMh+m3Qn2gxtgPF0s9t/vOXxIpCRKvLq6sW7nxvG1yMvH4Xnz8KG/Hx+yJYWf1/gnL9Pljz8dH1a5bMk44dR8Nr4iDP9i5uXv/vbur/9z9fPvr//6f8sf/3F8SJf/+PH98eE338N3b9hSLr9/53SEFQVhWbb8Hir/+YtEJm/fJ/sJTe7gw0WSJpfw+faL5HGySG7BN4vk7Q/JATxeQJEME/vw3SXUWMDTZfIUC+dVYSxHoRXIpPCIjQlV1mslT778zV+W3//h+PBbgPNP3ti4SEmRyYnG9wlCAn0vANCFHu0BwG8zT5KFAeTyTdZsjGckL/zm9qDBT5Nfw++D5LPkLDmvardAySVhjPvVbWd1oRy6SP1Cp8nHyb3kPvR0X/X1oFkJB8lSktVV7ilg7gNQ58nnUP3X8PywXREGxGjRqNuCiXOS57JRKgRUm34Kuopp16XfnuKpA+CafaTY2581vy6So+TtO/y4Tj5C7nqX3AViQgqeFsmv8M8efrx9N8ho0wH7ECD7UkEHfJX8C4ANIF8Au8FvL75SRqQGoRvE+vt1QTwF6bs0koqfjyGNEkvh72OFZQ38UfJEC22GCEcB3gMMP0vu9o+jIEXvOKrv1x3HPTUOpbLugDp5oQBH9nxYDQCAVRxwnRAA/gh+8e8TyMXfRfLIlD8fli/k+rMKZ5dKYV4my86KOclEULYUkihhBW8WqRHqoea33yFqvvvtv0Phv0Ab/3V8SGgJ/4rl/+I3oiQUGoO2hBQEjIjJuDo+/E416BNC87p0bQpShsOXdRMUa5vnEhnvypbyU+rxP48P33eQk2ly2oJCZgCW1A1c/+348J2CzFb7j99/Y5iApPDLPWbIloXPDLpRSQpeYfGF0gzX+P8WcgUw7gmIH1DMKugAvyGvsbSrfUAVLbIuMlVIAybJWe5gzmTU6EtzUhaiRlkzXVeIwaMpbZHJBEll4aDTIXRKhMCREQ71kNLUkjgjUlQ0zkgmS0A6DBTS6q9N/HcnTMiPrMGPWEExI2GcCbcXnVHxogOfkBJInfkQMu0LWd/GgAzDrLgNnnFckwNs+hiGFzQY4hzBe10xTAPgueBY84ADsQJ2VhiOUgCsWwGwkgjJrIA+V2r5S2PcXqATa3yFl00lbERRgJtTBDW1KVQQieqhRwkY/NZKwGTUSiDLSaEzdI1muq4QowRM6YBG7VWZGZjQejTnoCCfIYrQqh2hS3yg9eZpcm+01uRgNwXrRRinSgfWCDMZNcIKSXIXQc10XSEGYaa0RRgHugN39mhNqJDTdDljrelB2K01uSQZLzXE8EylnB5g08cwvEVOKCB2i7SmA3FIa84CwxlJRYETu5Rz69FR3TUqXRgGZzUoNl2SQmdQ99GWCggVKdJcaMEyZevmPB3kgPcaINfIdjH3WmXoTwOVLPN2BrUJIcRStYS4NS2mo3Cr+yCUUmERhD3pjC4EO92zXoFDRBobWpLcgXE9gGkNrO5hGFRGCU1Fv7RtEMV0FfRqBnEgDkkbddhDl67Sm8e86bExjCjnpWWKwZhxwHVOWJpbO/kIYxc/VJOV9uSalWDERLZtgk5vRsjpTsBng95oAb8h9I4T4hw96YYQO/60600/DQp1lsPsghdbLtRFVtyEUGO3ZH2hbrgimkU2bVkaTshO7JdbIvYFzCjLhti/RBkHmT/tCOX6XrrIoJ7cuJxLgG0KOZ8LK0XL8g2x0j+LpNIPrSbpFDLcCh6CELLcF2G1WPhULRI9rRcWB53xnTyTnTzPDr3R8lxuudRKdLIvwPLSQQ97J6lko5I6O9Owk2HGt0GGCfwskj8kXw24zrh2Q4udAK/IR9ECXG6VmG5DBCJahGcbgZhMyEe61zuZ38l8UOZnuZQQLfM3hPrJJPprtWv0BW67HPS9d2JMNirGM1wYHSniDUv4IcW8YQ+HyfNPI+p7yUe4qvVO7Qb3hX1cH2ZLFyVZa5tYswx3N/iFCuUkK1sbrr0NZ4Xey/NTvb9MZ1zVu5wlkTrD7HNupOsKAf3jbTgzpcfs0CsztcBgHaffJAfVuYcFPL9KTvXq4juzae8ZkuVneNxXGepz9N49RhlhGe/FZVmqrXg1Lk1GjUuWCSJlWSOvlVFXicGmKW2xCY2VlPVt34MKvBCuDM5la5ndDudB2K3VM0m4NKoOnvHAwOQAmz6G4UUKliLt195zQbLZ+e6AHFLNs8Cxjm8wmoIlydtekpAgBbQGzKZHeknNPQB1c6t5SQ1TjVRJ09LPoEVhmSElJZcTWb6GqbZdh0210/327wWwg4nxpzZIBOoTAHuZwFeaoSsb5eO0jXnOQMPnzf1Baj8QfJy2XKm2QmAM7Fy5cYXQnDaNVQhz4bVoYZ8hr40U823SxdGqYLa6OEohxEysHpjzthfqOP3+dFMrlpYkZUPzJpZl4Jmkg6XAAyxls9QqcwsgO+dEFnnvvILxHDpy5hUm46rOEBLmRphhajTTVYWYWYUpPWaOxgR3p0l7Wqcf2IOn/uhqrZ6hVgeYc96h1RmnRDqxMJ1kOE8wmtx9HtDqzA+EVW2ldA0XD5vJ87SdQd3EinJIo+SwanxIrWgUxXoYurSbzrgdjkKWhZ+OH4mr83V/jUEEOA30aFNf3DdHnM3s/wi57UTFB/aRA98nt/vOD/CMlMUAA+Y58zgQ05OxoGksxIO0xX+0yWqsnUHdxMTksq2OUP8x5AzdJNKmXVpwkouyh3YsJRLar2hn0tPQrm5sHO1M/VYGdRMT0862OlbWPtEBTxNSC7vqZU4yvColSBlZkNwJK9j0NJSpGxtHGVkSKl3KQINlKg1lLOjTUsb02bNgYIBwAI+arRv1HVLnGd+UcTJtj1ATLIIT9T0snyVv1LVLuXNzyx/16XY8756rxbgFaBKqrlfC0+/7+DXWXCTPEqKvwkmeNb083SMD9nX31enLhB6qO2zOIPVJ8q89F/4Y1yYHTzFjtQxQx6+p9HTliFjWt480hu1ptDOjC8R7AmkruUk/IKUrqSbvphO8EOmu8jSVN/A5EPrhmj5BkHItE7s27bq8gHVkxUNN644qQFXkzViVHPC6uUd2stOmi4ByrFkcelqqvs5AbOobnzpgF4xIKRr1l8NmxidUU2PSXnU5L34PeDjOADt1TAmIj9Ex9p4i6jytwKVyeNtAaS/kitAvqqyfotXTtMjWTY7VLfUU4xZOaY/AmHjK5khFLkG/PFU65m7P7o9KuQRJ1lIuaxKtamIDmgVN4tegQb4G2f7YmMb4G/Eq+fVxMVp+b5ifArLrDK5LdlMqCN3J7p83Jbv2CoH1fIEwlbZJXFe/vNCKaGP8vwwRNQLIOAhHhACm3F5PRb3nFYhbt9IjhqZEpCCa0s00dZ6nxattdKxAPlEh4dM15TFItJY8TkA2p5lppBKXGMILEboM8G99DRu666+ViT0Dl/3hYEwsgJ+uENO6+PGbGVwr6OCIT4ENng6roO4hmXCMHpJJrDskv5lOUV1Z881KTmOMxam5DBovkr0wF8metFa6AtxfNQzSI/DMgtuyOvdQwg9B57lUh532AjPPjNC2pLSI1+zVVIYZlitCOJ6f1xgLrgzystEsDOYVjOGZuUbX3K/cPZoUXMHuPZmdhikroXg5bJjMXaGKc9znWHb3WukLHrl3kg4aJlO6mabO87QMbxsda5jOQQ3di7E9Qbq040LrU8Zp5np6j7DzLu4oGexR1D5+RmvMmTBQp2gKRsosixBNYa8wpd7zCgxQt9InmmLwMlsXs7p0M02d54kxaxodK5pLPYnDrd63wTA9VX4jhhTPh6U1SKq2tK5PLKeZ603M36Lvbo+9mr1PxJuFhLsHP0IP+Jgfrwfmwa2dekDmQMqIueMEhmDARNdFRK5vdHhd0a8Ht1CrZJmf4e1ewd0302LXdBle6qy8DTuSkErTULsGAms009R5tgNQf0ePRvfg2g3V9ljtdgYivDesyIK89sHcjga7mTKr8ts27ViJ0cp7+nUrOI95BQr6iVbRWjujRt5LODxzLMOhFDflOJTkUJbrWcNyPeermvh3c0nXxH9dLvGb6eaSusxKXMK2Y2+Mxwb+3hgnvHVt8k6A6LeUDzO8cyZAxq5gx7pk9JuZJtjB9As5Qpp4I657zmK2z8RwYtOsmKqtDOomNmNZbOP9qksprozj8a7lxC4lS1L1RqGLRL/ejKMfTuEn09uzIUMkb987DG036whZgvYqCE9xnxfNLWuto3d7taGt2d5onRYFEayz3t+r10eUTL2X7KdqY7XNuapyMgqWROfoSq0Mp06/6PnFx2y3TkFVlKKKQz0A3aKXpfedV/3ov0oXnap16/g92Tg2kTsTJ7t5LxVADF5vq7TpSTbvOY3172RSghIWWmwnK8p2BnUTGxHaqvEhB3cLt2VHCW/MTtIl/DwGjrwPn+fwcwbPr4EtNcu+7zGRqZAgJSLMn7ttvxO4NqO2/UpASpr2UKaUpMzq0882PQ1l6sbGUQb0KULvZdDCTk0s6NNSxvTZ47cYIBzAt3Dbb/y+3vaq04h1moJkabnGfmFnY3CyqPf9BmZo3ibh+I3BWUoJFaIZHqsMYLrSlAmricxPe+ZOWexJmdd0OWjmtjyOE7A+PvXMQHbz7EGuGWOMVtktYG1QN32MFvdU+rr08Zvppk9lSrZ3Am2GEMNiLVukq4Ysa2XhNiDStvEV7NGH3QWhNw5oa+O+l7lpZcbNfDPOSCb7r4HKMMAs3buLbM5VnYO6Xrrvamxl1HViZr62+JiZbyYoKer3Nb4wb7RUE97b+Mce/lCz3CPIO0n29SSY4OsoVByutdGsbaBhiLzr7pnQBHjUVRPd09+hrbpk62e/GkORk19d2Enm1pfdyMbRYoMTX3fCe46cewdczwMVKf5cZ6hXpvTt8bMuSIg/QxPgCfizbkrS3ey32/MIkiUw+52CLFVTcjf11dqhW1mMuBMlTu2ZpkcojZhZ8Rt1eBUnqOrwKs5Vwcylyjd5r+6cVXNYyNNR+oXa0XULPqku9Vi/97n3Xlpt9PCCuvp+JV9ns23cABhQnv44DfQfdP42+ZSne0hbNOWZA7vETw0m21DcnBa8cqcFe6NnBW3ZzgVoqdaGLOtzpqTM42MH8w041eOIjDfpCo0krR83YjBM01G6yqdbn67SEySFcecxVqy9RnoDTavxyra4fd6xnKNhhdtNly6Fux5dvEam0bb64rVuni8mV7W6t2FXL4KtGrI7v9jSn3rjMXj7Puiw3nhMiaFL6cZjTM6VkwOuvs6xlVoZVZ2oeIwpPioeg/xJ6+1wuMlp3wZl8LW/jcs4bpvvPoZ570lMIAbGJpgTy90FYiLYcxeIaen3TQViQvy5C8S45BxjkdcKxATJsgvEUN+M7QIxswvEcFqSrKzCiL7OZr+cQExjnAb6rQ7EBIa0C8SsxC6/4EAMTxk4zq3bVHaBmJkHYhp069NV6034vUZ2gZhBhdtNl10gpkWMXSDGDIWDyhe8/0gIx5cfcfdIiM25qnM4xgCdEyDtjLpOTCDGFh8TiOE8VUdFzaAeoVHE8/LqCNrggQ+EXNKubdsS31jp3MJv0nlKqDCzJPd5tRmTbYyRPF8j0qKPSuXtDGoTeSE2xH+mpx6xqrvvn0EpNBpfCzBSsqlmSY4OMH0MQwsFWTn0ZvjNYZmugmHNIw7EEfMiU9pNfwjkY5+rGENvAvppgldZ3wp6oZlztC9QqHTfHnmmg7J6+9xBHZKtVEWjdgrarb78KNBFBsirb4p4osK9PzgnYr8wIeIDEwjeDzRTwJ90oC/OCU9LW+il33J3FUFB48iBdvEtKrIK1LdvkbytztqZ43RuZx0n+IHoyAlhBQt+RV4WXkAK09MoWNvYqgqWNm152s6ofSs+vazYTvrcFdvzNqhVDWyUVp0HeqOV6s3hd7LI3nOY5ePlDeArwf9zmPu/VGd/VDwPdS48XCSpOgqt4nj2/FCq1CWqNDw+dJnQ6htqDkkfxGjr0KU7nrauL5M40kEJbjL29O0Se84vZOjLJarbKTARuGbCV+sBWHy1vh4sATh8lR+Aw1f5gZsDfSUfaMlX8nuKcgfq7WP63cKK+Aut9BXoH0EKnpXiv9bLEb9qB4e6Z6qZ3HYTkKbZDZgA7JWsbQIa0wWjTTbv+zXmCjsrsbwBKxFvBj5Gmf9KKe4LpcAdfX8n+UbfnP2Vuq7YqvkXkIlfqlI0US+YeePXBNsQUO/e4dFbWP4OLi7V60cnq4aytT7Ht1m2bEtwipGWhNVW5gVot+fo1eLeDff6iEfJA6XfD5SXvVB+8OvkM7CaZ1UPoRuPBckGDQxnRNQGZs+ewyWu4ViEDM8z9VlWXwUsDM/ds0Mhu8AJrS3Mker2zJwa/qOm8CUww1vEFa45IKHqQ8MkGTw0LClJefTrI5uV8d3ZldX6Wq88vlGrjy/GLH7ot674rSqbRoCypXm33nX38odUSzcgdbJF3NDqh2A5kaJrXT4QZyoAQGv33OfVbGDdWLaSDZxLhCM6hqRQZNQsPItNqFnTxzC0UDAvtyqG5EAcMmSOW2QQ0UzfAPLjY0if6NfV6O1Nam/eYOgiLLMBv3Uama0bW1Fmy60KTxSzkFgNbJTAljNyPCPk9ebwGxWeiJFZ7Xo9MC+cOtHeGfpieN3IRcKqMGaHBwYyjDEEr72F3isRdgwLACLL/EqpdgXv4oZdBOO58QEzcLiyRIQhwLdK56zRWnMuHeMhd0y2G+W7Pd9mIc/ffaIbbd3i+SzW2QyGVUZ4vc+Tb5Xn9W96mE+Th8k96ESHo+4p13tf3UWA84pz+P0U/FL9aksBvwcq/P24VTYQYhdMzdpM399ClceatTKzl+a56v9loHZO+KAvLTMiN+tLl6QY7UvnktDpfWm/1VhfWkNUoMWN8KVNRGlnmdMNWuZZeno7o802it/JjPYmAikjVg02E0gZsWSwAeXfvWAQqfz9hYSplL/f6mrKv3vVIhhJKcEG0K6rJma5Y2cu8/zoSMrNBaw7oI1ZEXDMlX6jvPvajA+Efd3tkAGIWC6Y9YpNvBE4By3/DFXLib6h6sDo+6dqhnHSc56gCr4ExXyWi4Zsu1y8fBZCHr/q58r4TLflRIv4zeF+Mh+vPzAT9uZAAbOuiMhQWIbBQMrJwjKC8KLsD8ski96oi14AGuGVqqhLl2P6Klk37DLCNf2wYRc/5LNq2GW3hDnpEqYR6sglTBt22dnkYnM2mXpu3kw2aY8z1w0v9gOa7IYfy3ZmexeaCdq/DRiI7tDM4JXFsgDDkkW8Z5JxpHuOE876sPUgp9ES/2lmY9ATcy/aMRktdmtaMwu99IEXYHRT4ACkcVbZodYBAyFyIopGqQX4HC1KCZlCyWaDb699nMD//weg6vXJDQplbmRzdHJlYW0NZW5kb2JqDTMgMCBvYmoNPDwvQmxlZWRCb3hbMCAwIDU5NC43MiA3OTJdL0NvbnRlbnRzIDQgMCBSL0Nyb3BCb3hbMCAwIDU5NC43MiA3OTJdL01lZGlhQm94WzAgMCA1OTQuNzIgNzkyXS9QYXJlbnQgNiAwIFIvUmVzb3VyY2VzIDEzIDAgUi9Sb3RhdGUgMC9UcmltQm94WzAgMCA1OTQuNzIgNzkyXS9UeXBlL1BhZ2U+Pg1lbmRvYmoNNCAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDM4NzA+PnN0cmVhbQ0KeF7tXd1z3LYRh06yMiON6tRRnDhWnKtsy6kTQQBJgGSSh9T56EzTdqaNZ/pQ5SFJo+nD1TNV0sn0v+8uABIfJI/kHSndpbTndMQSn8vdxW+XAO7fRwd8zuD/OX6leTT//l9HByWVz3lCE2b+Brcox28kXnz+w9W3/1n89Pvrb/87//7HowM2//H7V0cHL17CvS/5XM5fXjkNYUFBeRzPX0Lhv79PJLl8RfYII6/hxSmJyAX8vXyfPCYzsgt3ZuTyO7IPl6eQJcbEHty7gBIzuLogTzFzWmbGfAxqASKDS6xMqLxeLSn55LffzF/+4ejgC+jnX7yxJSKiWSwHGt997Am0PYOOzvRo96H/BfF1MjMdufgyDitLYppmfnU7UOFb5G34PCDvkIfkpCxd6UoqKeeJX7xozGZKoYnIz3SPvEGOyZvQ0puqrQdhIRwkj2hsixyrzrwJnToh70Lxt+H6UbUgDIizLChb6VOS0DSVQa6mTlWfn+pdKbTrPr8dJVP7IDV7+MQuf9LyOiOH5PIK/1yTX6F0XZG78DAhBVcz8mv82sE/l1etgjZcZx9Bzz5RvQO5Ir+BbkOXT0Hc4LOUXxGnUnehvov2/rpdvAfad2E0Ff8+hjRqLIPvx4rLuvOH5IlW2hgZjgq8Axw+I3eXjyOj2dJxlPfXHcexGocyWa+BOXmuOo7i+agcAHRWScA1odD5Q/jg9xOg4mdG3jP5T9r1C6X+YcmzC2UwL8i8tmBKY9GoW4pJjPIsCbNYhnqs+exrZM3Xn/0ZMn8Ddfzj6ICyHP5l85/xjsgpg8qgLiEFhUnEEBZHB1+rCv0HoWVd1s0pMfQ7m59TnvDiFpvTKIuxci4zMFSJTi9sOqeZJjD3ssj1t6ODVzWPmutHbfLZqkDEr384OrgKO419iuZlx5AIX7qn+q/pUR7JKoG5CVUTpIsaVeKftT2t4zz29+eiacoYEwVzVOWKUHLeZbsZI2eURUKN4tyZ/Jk7LuYOAR6mTJeMST0TMwy2+oCYOxjdZvNg9ONwhqJGoe+yZU9IlyjTKDCJHkpOU+d5DPtwdKvBcJabn3ie+eYnphFP5ynlUVro7WONe8AC7aKJ2cUrMJfvgm14pCcnmKvugL11bt7VtxtNKE8jNewmJcxT0G2rgzo5hAoWNTVpIKtonyulunSYZs71wCJqKm1WN52hr7ZtxjiGEM1jEDUle98hKELZa5S5GPQ9ipbInKR5nDtCp9ODSF1R1cpiZztePiNePDDT78GfGLbZJnrc7TgvxG5bjGPNcLqoUjgiU7Tp+ZR8GmFYReVDa9Y7gP7OtErtgyV/XXu1yilpVjCFq/AhNuAqmcQersI0TARMGKVyr/spWFEZB4dubWiVVgkODBEjPUnTUhu0Eu0Kp9hoVAo4kvOhdMqxD6aN9t7iRJ+36NOIXGZ9OKxlxOlxE95zjLPJ7aZvgvnYZoPS//X3L4zO0wg+SW/d3zH+3x34xniEVX0N93bh6zX0mX/C1D3t/O/Ze3vFVOz50MjnmNFYAkdpXBgFmGWkMISFJaAIaIIpUiGURZYbCD97DFMlS2C0iTsPF554wJmiqMebGXkGzvUZONYYgbkmJ+RD8oETWKvlLgfLmJR+8KHPlDJLBl/IE+hdwgvCoiREXGVcFCXCtC2wnCNebvCSo6jCkJWmD55TAdwyg3yog1ZZOFp/dGpizqBc7o7XUOwAKxyo8KhFCLzsOYcHmjWNean2VGXE1OyNXUXk0DX6lHxFJDmHq4/JR+Q+XJ2T35EvyJ/IeZ0MRDFNNFMyQQWotiEsSgJIZOY+8zBtC3SRAZM7i8DEZB2VwpTMKbfjfQ+Gm8Ag8UNx9IkhYBwq0aSSulMGkxolKRY0TrOl6gJZMsGRVZKDGeQFYVESEsioCbpEmLYFurDK5BapikMMoS4JpyIXloUKYe1aI6rivM+0Z1PRIn/QqEUJ9Cxy2VBQ7LgrjKmwbjkn/OyZhOqHUaKiYx5H+oXDd/zwdykniaCJ5lAkqMx4QViUBIzXunIRpm2BLnJickcRTWTSS6UEV3O6GX1NWL9RkkAoE0AZy9QFsmSZgg5JrnhtCIuSIAUYAWGHHaZtgS5sMLmBG0Opi4ypjPJmdXkDUcirqqb44zWaInjsDKig2CFXeFLh2nIm+NlzmM74QKpS9MzjRvEuKCMpOSXP1SuCC6speago9a+NmlkPHnoi6+QrQPxppLBqkwOYg8XI3aCeTg/jABaV9XUAK1GxqEqwYZZkeCxfNLIsMlG0vA1un+5sJ69vM9jb2em7Pf52shVdPLv3yAMwCA/UbHoN1mBf+3Q7ANffIafhK7zSU+jhvESAOqTnvRjKOO5LlFCR9Jtofaz+BG3gmcao+uUpMCaHyw/Ve9NaYHum/ubmVgdAC1AjbQG0kVSoDFmYJmBveUFZWEoMVt+DsEHalujCQpObgyjLqB8LY5B+i1WegUeDSP+PekJ5Cq7PMXAG/GJg4bFaC7MHMO5ULbQ5gc9bME/FMEvhgplTuD9TC23CvHvLcb8A+JbGDng1hHFwP+A5IXvxyEezX6i1OErdYvMK/5niU2vsAMBJ1oLukkzhFJQdLjTozwrkUlCQOx6eC9K2RBe2mNycR+CW9pMdkVBmoQvq1QysT6pY8hVi/VeAXV7gK0cLZM5KHxJzS7ME6FEdL4RUwUNl+WMqEOBrysKh5FTy3OFFmC5LdOGFyc1zjBYlc1z+kbQzQ9IEsklGIwutygVaDQA5xGVQhywXbnyqZetLtcrlubPcq2APqLkU2GIKY8WpRsKEVRIWlpBRbrhhilQIZZEW/njZk4QmA0Vdioo9BihAS8Gg52jCDw0qrncL8U2g5kIhE4biSInFomYiDdK2RBcpMblXkhJoWWahkNS/34zlduPvKIpvAX9jq3Rt/B28SzJQbvwXA8GLpAmiz7cZoqPpfqaRwi7GOA71O5ZDg913FEaaqeDYITmHqfAJeTgEcOcZzfBNjAXuhjIOcAdYIpNsDeC+U4vaO2L2w6Exu0FZDmY3lHEw+wq4y8fsg+OuOKGp4YWZPw1l4VBS+HIwZyVdlujCC5N7pRk1BvxqQXVP3IVAxiLYjrgLWpQalxqYZQiLkpBIsIKaG7pIhWCLdMJdJvvwuMtnQB/cBc4M99G5oThSIhhlHhoP0rZEFykxuVeSEmhZVtF507qXDKBPHndf+KLsqBoX86774a6iMkbzWPYBXpuy5qLzqhbkkUEicMnSbPje6iba+wr5cGHAFq1pcXrchJ0cJK75ECRvnvOdjFQXTOUtE7VLWXJSrF4Gm7UP9/fJU7Lr260MLAZzV6xEmZq07IoVQygXqJgSYbrjehUvd/37swabZUpWVqscA268R050cO4uDLo15FQPHMNMMGtV8VEVsrFq8CpEWrzf+6VGQ9vg4A5jaIvK+hvafKveIkUbYGZ1VztZ2XyDHNQORjbaQlMa07TVGkgq6p2lACmZENWkwtGIKrx5M/mk3MmI3B1cuZtcHM5imM97LO4fRm8nH+doZAmq6WsnBZWTj3P97a3pbhcfZ1d/3VPRPJW4U3FxJCh37Lg4cUR5nDoujiFYl0aXCNNdXRw3dz8XR5dsc3Ho1rs4zYZ2Akjt2GIrzOwEg44G5u46pnQEH2fSYTqmDm/eVD5pdzIidwfX7kYnJ8I9cfnk5PgSJP9fnRzH0OgTY9yDM26I97rZAbQ3WKN0Q5YzWKE0uH57DsF98gb83wU/x9+3fK1e7+zrk0Jw0XHgBqVMr+Ms3SCA/2pjaukGGULp9pgSYbqjG+Tl7uUGmZJL3CB8IX93+72gRks8Iah28LEVdrg7TnLN8IZu1OpshW+L8+vY2DE8pEm/oxH12/eQUCZHn+h9AcQm6RC6H6CWG9T/ALnwyQY0+VEVrQuWEiI6cGsEZomExlHldF4Dx0pjoZ0ys8um1imbjutsEtei8hZHaDquc2NOpOvu5+yow3+Vj3NHnZNRHLq0txRYKxY1apOyb868q5JD6FJR08oHILLp3M2hxlFFY3jS4xKhkNPBmB5Lp4MxG2S9FqjxxudT8mmEYRWVr2peVz8Ak0tJJUxUtVilLoAscXe5UR/3up8q2cp4ujZc2fYjMBUbjfLAdTzGRkDTRntvIaNo3Wk5HpdZHw5rGXF63IShHDNscrvpm2C+yNdAT89RlfU2SjxwQkeJL6+CQ6RbnKWggeYNl1UYplW2yVA0xD+GMRS2Mr7OVm22gRG4rqERuRHmQXe2k3XYDPZ2Ng63x991whs1RyWNtt16Oidp3T3XUQQd9PZcF5RR9lxH8B2vted6rHOSgLL68UL+Tuhaltuty+Wm9nIjcnngkN2rrMqE6c5bl93cq2xz9/cmD7HNvfncTW97cMG6pjho84FIkma9j/HB00K9Y3wMYWEJeOqke2pPlVAWaXkmXvbht5P7DGjZTr7sgFDW593TVmOvX9AxOWYaH995CJzNCZ7NtxmeTcfkdMNtm3BMjqC8OBrGvHrXFMe62qNfDAII0rZEF+6Z3MWJIkF0uQdkGxU/1EOv3vhhOo6mz3E0PdFcmCnGzreDDBUHRncEEdOWxIE3JQL5y43xuiBus1cSd8AQGw3juuOIul8QrNjidcK/TfZ86az9UfhrBi09qTGO+Nu7TAT1HpI+P6qx5DemV8ADgd6YGHizkdxIP2xDkH5XX0tuhIns7kgFbu4mvmLobCBvj/ed0FQX46h9qSdgHO8of0ptpDgh98kczMF9QLkfD+FSTaHwXnbU+lX2+FHB1doM5/hRQxklFI4/mJOxfl5pUygcXfWn4DF9oDynF+C26Ck4VtFtHe++gKsL8MGeK6fGzFi75HP0woSKjfu/GNDT42oKdotM/TyaE+w2lHGC3UKglvbhqe/47KjZvfBV8f0Ag+9I8fN9SKeKi8zcm8FVDDy7UO8VVvRgpwj4MB5sYwRcga4PAYydtT2KnuHvCXZFI8Iu5vlBG7I2ZjVEFrh5N4jKAkePT8jMW/x9oZd/4684aXA2AjLb/mC38mpnU7S7Eyq7BQQxxcCHQRCNMfDuCGLtAHgwxyTY9RQDjnn5mr3VkLIc/2lbyhk0KfH5CCloHhWEijUNxaRglfSHKURCIzB+aDNii7auw5EKgb9LEGSbgZcyq+TEySZrrNHy5X+nbCp4DQplbmRzdHJlYW0NZW5kb2JqDTUgMCBvYmoNPDwvTnVtc1swPDwvUy9EPj4yPDwvUy9EL1N0IDM+Pl0+Pg1lbmRvYmoNNiAwIG9iag08PC9Db3VudCAzL0tpZHNbMTIgMCBSIDEgMCBSIDMgMCBSXS9UeXBlL1BhZ2VzPj4NZW5kb2JqDTcgMCBvYmoNPDwvTGVuZ3RoIDM3NDcvU3VidHlwZS9YTUwvVHlwZS9NZXRhZGF0YT4+c3RyZWFtDQo8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/Pgo8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA5LjEtYzAwMSA3OS42NzVkMGY3LCAyMDIzLzA2LzExLTE5OjIxOjE2ICAgICAgICAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgICAgICAgICAgIHhtbG5zOnBkZmFpZD0iaHR0cDovL3d3dy5haWltLm9yZy9wZGZhL25zL2lkLyIKICAgICAgICAgICAgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIgogICAgICAgICAgICB4bWxuczpwZGY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGRmLzEuMy8iCiAgICAgICAgICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIj4KICAgICAgICAgPGRjOmZvcm1hdD5hcHBsaWNhdGlvbi9wZGY8L2RjOmZvcm1hdD4KICAgICAgICAgPGRjOnRpdGxlPgogICAgICAgICAgICA8cmRmOkFsdD4KICAgICAgICAgICAgICAgPHJkZjpsaSB4bWw6bGFuZz0ieC1kZWZhdWx0Ij50aXRsZTwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpBbHQ+CiAgICAgICAgIDwvZGM6dGl0bGU+CiAgICAgICAgIDxkYzpjcmVhdG9yPgogICAgICAgICAgICA8cmRmOlNlcT4KICAgICAgICAgICAgICAgPHJkZjpsaT5hdXRob3I8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6U2VxPgogICAgICAgICA8L2RjOmNyZWF0b3I+CiAgICAgICAgIDxkYzpkZXNjcmlwdGlvbj4KICAgICAgICAgICAgPHJkZjpBbHQ+CiAgICAgICAgICAgICAgIDxyZGY6bGkgeG1sOmxhbmc9IngtZGVmYXVsdCI+c3ViamVjdDwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpBbHQ+CiAgICAgICAgIDwvZGM6ZGVzY3JpcHRpb24+CiAgICAgICAgIDxwZGZhaWQ6cGFydD4xPC9wZGZhaWQ6cGFydD4KICAgICAgICAgPHBkZmFpZDpjb25mb3JtYW5jZT5CPC9wZGZhaWQ6Y29uZm9ybWFuY2U+CiAgICAgICAgIDx4bXA6Q3JlYXRvclRvb2w+QXBhY2hlIEZPUCBWZXJzaW9uIDIuODwveG1wOkNyZWF0b3JUb29sPgogICAgICAgICA8eG1wOkNyZWF0ZURhdGU+MjAyNC0xMS0xOVQxMDo0ODoxM1o8L3htcDpDcmVhdGVEYXRlPgogICAgICAgICA8eG1wOk1vZGlmeURhdGU+MjAyNC0xMS0xOVQxMTo0ODoyNSswMTowMDwveG1wOk1vZGlmeURhdGU+CiAgICAgICAgIDx4bXA6TWV0YWRhdGFEYXRlPjIwMjQtMTEtMTlUMTE6NDg6MjUrMDE6MDA8L3htcDpNZXRhZGF0YURhdGU+CiAgICAgICAgIDxwZGY6UHJvZHVjZXI+QXBhY2hlIEZPUCBWZXJzaW9uIDIuODwvcGRmOlByb2R1Y2VyPgogICAgICAgICA8eG1wTU06RG9jdW1lbnRJRD51dWlkOjNiN2M5MTBlLWRjNTYtNDBjZS04NDkwLTA5NmNlMmI3NDI3YTwveG1wTU06RG9jdW1lbnRJRD4KICAgICAgICAgPHhtcE1NOkluc3RhbmNlSUQ+dXVpZDowNzllYzY5Yi0xMjk5LTRmZDYtOGE0YS04OGJiNzEyZjdhMGY8L3htcE1NOkluc3RhbmNlSUQ+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgCjw/eHBhY2tldCBlbmQ9InciPz4NCmVuZHN0cmVhbQ1lbmRvYmoNOCAwIG9iag08PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDI1OTQvTiAzPj5zdHJlYW0NCnhenZZnVFPZFsfPvTe9UJIQipTQa6gCAaT3JkWKIAohCRBKiCEBe0FEBUYUFWmKIIMCDjg6AjJWRLEwIKjYnSCDiDoOjmJD5SWy1uib1+bN/8O9v7XP3ueeXc5aFwBSQAhfkA0rAZAlEIsi/b0YC+PiGdh+AAM8wAAbANicHGHoAr8oIFOgrzcjR+YE/kmvhwEkf19jBoQzGOD/kzJHKBIDAIXL2I7Ly+HIuEDGmXliodw+KWNacoacYZScRbIDylhNzqmzbPHZZ5Y95MzNEnBlLD+zkJvFlXOPjDfnSngyRkJkXJjL5+XJ+LqMDTIlWXwZv5XHZvHYOQCgSHK7mMdJk7G1jEmiqEhvGc8DAEdK/YqTv2Ixb5lYnpR3tnC5iJ+aJmaYcEwZNk5OLEYALy+TJxYzw9mcDLaIy/DOzhKyBcsBmM35syjy2jJkRXawcXJwYNpa2nyp039f/IuS93aWXkZ87hlE7/ti+3d+2fUAsKZktdn2xZZcCUDHRgDU7nyxGewDQFHWt/aBr/Khy+clTSwWOltZ5eXlWfJ5HEt5Qf/Q/3T4C/rqe5by7f4oD8OHl8KWZIoZ8rpxsjOzJSJGjpDN4TGYfx7ivx34lb46h0UkL4Un4glkETGyKeMLUmXtFnD5Yn62gMEX/Kcm/s2wP2l2rmWiNnwCtERLoDRAA8ivfQBFJQIkYa9sBfqjbyH4GCC/ebE647Nz/1nQv+4Kl8ofOfzUz3HekVEMjkSUO7smv5YADQhAEdCAOtAG+sAEMIEtcAQuwAP4giAQBqJAHFgCOCANZAERyAOrwHpQCIrBNrALVIFa0ACaQCs4AjrACXAWXABXwFVwA9wFUjAGnoJJ8BpMQxCEhcgQFVKHdCBDyByyhViQG+QLhUCRUByUBKVCAkgCrYI2QMVQGVQF1UFN0PfQcegsdAkahG5DI9AE9Dv0HkZgEkyDtWAj2ApmwZ5wMBwFL4ZT4aXwCrgA3gpXwPXwIbgdPgtfgW/AUvgpPIUAhIjQEV2EibAQbyQMiUdSEBGyBilCypF6pBXpQnqRa4gUeYa8Q2FQVBQDxUS5oAJQ0SgOailqDaoEVYU6iGpH9aCuoUZQk6hPaDJaE22OdkYHoheiU9F56EJ0OboRfQx9Hn0DPYZ+jcFg6BhjjCMmABOHScesxJRg9mDaMGcwg5hRzBQWi1XHmmNdsWFYNlaMLcRWYg9hT2OHsGPYtzgiTgdni/PDxeMEuHxcOa4Zdwo3hBvHTeOV8IZ4Z3wYnotfji/FN+C78AP4Mfw0QZlgTHAlRBHSCesJFYRWwnnCPcJLIpGoR3QiRhD5xHXECuJh4kXiCPEdiUIyI3mTEkgS0lbSAdIZ0m3SSzKZbET2IMeTxeSt5CbyOfID8lsFqoKlQqACV2GtQrVCu8KQwnNFvKKhoqfiEsUViuWKRxUHFJ8p4ZWMlLyV2EprlKqVjivdVJpSpirbKIcpZymXKDcrX1J+TMFSjCi+FC6lgLKfco4ySkWo+lRvKoe6gdpAPU8do2FoxrRAWjqtmPYdrZ82qUJRmasSo7JMpVrlpIqUjtCN6IH0THop/Qh9mP5eVUvVU5WnukW1VXVI9Y3aHDUPNZ5akVqb2g219+oMdV/1DPXt6h3q9zVQGmYaERp5Gns1zms8m0Ob4zKHM6dozpE5dzRhTTPNSM2Vmvs1+zSntLS1/LWEWpVa57SeadO1PbTTtXdqn9Ke0KHquOnwdXbqnNZ5wlBheDIyGRWMHsakrqZugK5Et063X3daz1gvWi9fr03vvj5Bn6Wfor9Tv1t/0kDHINRglUGLwR1DvCHLMM1wt2Gv4RsjY6NYo01GHUaPjdWMA41XGLcY3zMhm7ibLDWpN7luijFlmWaY7jG9agab2ZulmVWbDZjD5g7mfPM95oMWaAsnC4FFvcVNJonpycxltjBHLOmWIZb5lh2Wz60MrOKttlv1Wn2ytrfOtG6wvmtDsQmyybfpsvnd1syWY1tte92ObOdnt9au0+7FXPO5vLl7596yp9qH2m+y77b/6ODoIHJodZhwNHBMcqxxvMmiscJZJayLTmgnL6e1Tiec3jk7OIudjzj/5sJ0yXBpdnk8z3geb17DvFFXPVe2a52r1I3hluS2z03qruvOdq93f+ih78H1aPQY9zT1TPc85Pncy9pL5HXM6423s/dq7zM+iI+/T5FPvy/FN9q3yveBn55fql+L36S/vf9K/zMB6IDggO0BNwO1AjmBTYGTQY5Bq4N6gknBC4Krgh+GmIWIQrpC4dCg0B2h9+YbzhfM7wgDYYFhO8LuhxuHLw3/MQITER5RHfEo0iZyVWTvAuqCxAXNC15HeUWVRt2NNomWRHfHKMYkxDTFvIn1iS2LlS60Wrh64ZU4jTh+XGc8Nj4mvjF+apHvol2LxhLsEwoThhcbL162+NISjSWZS04mKiayE48moZNik5qTPrDD2PXsqeTA5JrkSY43ZzfnKdeDu5M7wXPllfHGU1xTylIep7qm7kidSHNPK097xvfmV/FfpAek16a/yQjLOJAxkxmb2ZaFy0rKOi6gCDIEPdna2cuyB4XmwkKhdKnz0l1LJ0XBosYcKGdxTqeYJvuZ6pOYSDZKRnLdcqtz3+bF5B1dprxMsKxvudnyLcvHV/it+HYlaiVnZfcq3VXrV42s9lxdtwZak7yme63+2oK1Y+v81x1cT1ifsf6nfOv8svxXG2I3dBVoFawrGN3ov7GlUKFQVHhzk8um2s2ozfzN/VvstlRu+VTELbpcbF1cXvyhhFNy+Rubbyq+mdmasrW/1KF07zbMNsG24e3u2w+WKZetKBvdEbqjfSdjZ9HOV7sSd10qn1teu5uwW7JbWhFS0VlpULmt8kNVWtWNaq/qthrNmi01b/Zw9wzt9djbWqtVW1z7fh9/3606/7r2eqP68v2Y/bn7HzXENPR+y/q2qVGjsbjx4wHBAenByIM9TY5NTc2azaUtcIukZeJQwqGr3/l819nKbK1ro7cVHwaHJYeffJ/0/fCR4CPdR1lHW38w/KHmGPVYUTvUvrx9siOtQ9oZ1zl4POh4d5dL17EfLX88cEL3RPVJlZOlpwinCk7NnF5xeuqM8Myzs6lnR7sTu++eW3juek9ET//54PMXL/hdONfr2Xv6ouvFE5ecLx2/zLrcccXhSnuffd+xn+x/Otbv0N8+4DjQedXpatfgvMFTQ+5DZ6/5XLtwPfD6lRvzbwwORw/fuplwU3qLe+vx7czbL+7k3pm+u+4e+l7RfaX75Q80H9T/bPpzm9RBenLEZ6Tv4YKHd0c5o09/yfnlw1jBI/Kj8nGd8abHto9PTPhNXH2y6MnYU+HT6WeFvyr/WvPc5PkPv3n81je5cHLshejFzO8lL9VfHng191X3VPjUg9dZr6ffFL1Vf3vwHetd7/vY9+PTeR+wHyo+mn7s+hT86d5M1szMPwD3hPP7DQplbmRzdHJlYW0NZW5kb2JqDTkgMCBvYmoNPDwvQXV0aG9yKGF1dGhvcikvQ3JlYXRpb25EYXRlKEQ6MjAyNDExMTkxMDQ4MTNaKS9DcmVhdG9yKEFwYWNoZSBGT1AgVmVyc2lvbiAyLjgpL01vZERhdGUoRDoyMDI0MTExOTExNDgyNSswMScwMCcpL1Byb2R1Y2VyKEFwYWNoZSBGT1AgVmVyc2lvbiAyLjgpL1N1YmplY3Qoc3ViamVjdCkvVGl0bGUodGl0bGUpPj4NZW5kb2JqDXhyZWYNCjAgMTANCjAwMDAwMDAwMDAgNjU1MzUgZg0KMDAwMDA3NjI3MyAwMDAwMCBuDQowMDAwMDc2NDU1IDAwMDAwIG4NCjAwMDAwODIxMDggMDAwMDAgbg0KMDAwMDA4MjI5MCAwMDAwMCBuDQowMDAwMDg2MjMwIDAwMDAwIG4NCjAwMDAwODYyODAgMDAwMDAgbg0KMDAwMDA4NjM0NCAwMDAwMCBuDQowMDAwMDkwMTY4IDAwMDAwIG4NCjAwMDAwOTI4MzYgMDAwMDAgbg0KdHJhaWxlcg0KPDwvU2l6ZSAxMC9JRFs8NDM1NDQzNTMzMjM5MzgzNTUyNDI0NTUxNDY0MTM5NEM+PEI1ODFEMUM2NUVBMEM2NDU5N0MwNjI2N0IwRUIwMjE1Pl0+Pg0Kc3RhcnR4cmVmDQoxMTYNCiUlRU9GDQo=
                  </value>
                </observationMedia>
              </component>
            </organizer>
          </entry>
        </section>
      </component>
      
     
    </structuredBody>
  </component>
</ClinicalDocument>
```

