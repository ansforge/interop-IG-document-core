# IPS-FR - XML Representation - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **IPS-FR**

## : IPS-FR - XML Representation

[Raw xml](Binary-IPS-FR-2024.01.xml) | [Download](Binary-IPS-FR-2024.01.xml)

