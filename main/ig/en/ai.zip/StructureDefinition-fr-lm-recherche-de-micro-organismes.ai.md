# Logical model - FR LM Recherche de micro organismes - ANS IG document core v0.1.0-snapshot

## Logical Model: Logical model - FR LM Recherche de micro organismes 

 
Recherche de micro organismes 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ans.document.fr.core|current/StructureDefinition/StructureDefinition-fr-lm-recherche-de-micro-organismes.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-fr-lm-recherche-de-micro-organismes.csv), [Excel](../StructureDefinition-fr-lm-recherche-de-micro-organismes.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-lm-recherche-de-micro-organismes",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-recherche-de-micro-organismes",
  "version" : "0.1.0-snapshot",
  "name" : "FRLMRechercheDeMicroOrganismes",
  "title" : "Logical model - FR LM Recherche de micro organismes",
  "status" : "draft",
  "date" : "2026-06-29T14:20:03+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Recherche de micro organismes",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-recherche-de-micro-organismes",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-entry",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "fr-lm-recherche-de-micro-organismes",
      "path" : "fr-lm-recherche-de-micro-organismes",
      "short" : "Logical model - FR LM Recherche de micro organismes",
      "definition" : "Recherche de micro organismes"
    },
    {
      "id" : "fr-lm-recherche-de-micro-organismes.code",
      "path" : "fr-lm-recherche-de-micro-organismes.code",
      "short" : "Code de l’observation",
      "definition" : "Code de l’observation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "CodeableConcept"
      }]
    },
    {
      "id" : "fr-lm-recherche-de-micro-organismes.valeur",
      "path" : "fr-lm-recherche-de-micro-organismes.valeur",
      "short" : "Valeur de l’observation",
      "definition" : "Valeur de l’observation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    }]
  }
}

```
