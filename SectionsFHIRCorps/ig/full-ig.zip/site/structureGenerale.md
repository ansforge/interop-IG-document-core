# Structure générale document - ANS IG document core v0.1.0

* [**Table of Contents**](toc.md)
* **Structure générale document**

## Structure générale document

* [CDA](./ressourcesCDA-struc-gen.md)
* [FHIR](./ressourcesFHIR-struc-gen.md)
* [Mapping CDA / FHIR](./mappingCDA-FHIR-struc-gen.md)

