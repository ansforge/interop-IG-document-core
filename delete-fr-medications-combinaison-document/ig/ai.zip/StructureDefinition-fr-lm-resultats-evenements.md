# Modèle logique métier - FR LM Résultats d'événements - ANS IG document core v0.1.0-snapshot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Modèle logique métier - FR LM Résultats d'événements**

## Logical Model: Modèle logique métier - FR LM Résultats d'événements 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-resultats-evenements | *Version*:0.1.0-snapshot |
| Draft as of 2026-05-05 | *Computable Name*:FRLMResultatsEvenements |

 
Section Résultats d’événements 

**Utilisations:**

* Utilise ce/t/te Modèle logique: [Modèle logique métier - FR LM Corps document](StructureDefinition-fr-lm-corps-document.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.document.fr.core|current/StructureDefinition/fr-lm-resultats-evenements)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-fr-lm-resultats-evenements.csv), [Excel](StructureDefinition-fr-lm-resultats-evenements.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-lm-resultats-evenements",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-resultats-evenements",
  "version" : "0.1.0-snapshot",
  "name" : "FRLMResultatsEvenements",
  "title" : "Modèle logique métier - FR LM Résultats d'événements",
  "status" : "draft",
  "date" : "2026-05-05T14:28:34+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Section Résultats d'événements",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-resultats-evenements",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-section",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "fr-lm-resultats-evenements",
      "path" : "fr-lm-resultats-evenements",
      "short" : "Modèle logique métier - FR LM Résultats d'événements",
      "definition" : "Section Résultats d'événements"
    },
    {
      "id" : "fr-lm-resultats-evenements.sousSection",
      "path" : "fr-lm-resultats-evenements.sousSection",
      "max" : "0"
    },
    {
      "id" : "fr-lm-resultats-evenements.entree.observation",
      "path" : "fr-lm-resultats-evenements.entree.observation",
      "short" : "Entrée Simple observation",
      "definition" : "Entrée Simple observation",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-observation"
      }]
    },
    {
      "id" : "fr-lm-resultats-evenements.entree.transfertPatient",
      "path" : "fr-lm-resultats-evenements.entree.transfertPatient",
      "short" : "Entrée Transfert du patient",
      "definition" : "Entrée Transfert du patient",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-transfert-du-patient"
      }]
    },
    {
      "id" : "fr-lm-resultats-evenements.entree.probleme",
      "path" : "fr-lm-resultats-evenements.entree.probleme",
      "short" : "Entrée Problème",
      "definition" : "Entrée Problème",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-probleme"
      }]
    }]
  }
}

```
