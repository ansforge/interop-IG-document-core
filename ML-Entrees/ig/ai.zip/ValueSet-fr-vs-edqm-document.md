# ValueSet - FR ValueSet EDQM Document - ANS IG document core v0.1.0-snapsnot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ValueSet - FR ValueSet EDQM Document**

## ValueSet: ValueSet - FR ValueSet EDQM Document 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ValueSet/fr-vs-edqm-document | *Version*:0.1.0-snapsnot |
| Draft as of 2026-04-08 | *Computable Name*:FRValueSetEDQMDocument |

 
ValueSet basé sur le CodeSystem EDQM fourni par SMT 

 **References** 

* [MedicationAdministration - FR Medication Administration Document](StructureDefinition-fr-medication-administration-document.md)
* [MedicationDispense - FR Medication Dispense Document](StructureDefinition-fr-medication-dispense-document.md)
* [Medication - FR Medication Document](StructureDefinition-fr-medication-document.md)
* [MedicationRequest - FR Medication Request Document](StructureDefinition-fr-medication-request-document.md)
* [MedicationStatement - FR Medication Statement Document](StructureDefinition-fr-medication-statement-document.md)

### Définition logique (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fr-vs-edqm-document",
  "url" : "https://interop.esante.gouv.fr/ig/document/core/ValueSet/fr-vs-edqm-document",
  "version" : "0.1.0-snapsnot",
  "name" : "FRValueSetEDQMDocument",
  "title" : "ValueSet - FR ValueSet EDQM Document",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-04-08T14:07:03+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "ValueSet basé sur le CodeSystem EDQM fourni par SMT",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://smt.esante.gouv.fr/terminologie-standardterms"
    }]
  }
}

```
