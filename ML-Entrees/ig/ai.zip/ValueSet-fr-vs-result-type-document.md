# ValueSet - FR ValueSet Result Type Document - ANS IG document core v0.1.0-snapsnot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ValueSet - FR ValueSet Result Type Document**

## ValueSet: ValueSet - FR ValueSet Result Type Document 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/document/core/ValueSet/fr-vs-result-type-document | *Version*:0.1.0-snapsnot |
| Draft as of 2026-04-09 | *Computable Name*:FRValueSetResultTypeDocument |

 
ValueSet contenant les codes LOINC autorisés pour les types de résultats 

 **References** 

* [DiagnosticReport - FR Diagnostic Report Document](StructureDefinition-fr-diagnostic-report-document.md)

### Définition logique (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fr-vs-result-type-document",
  "url" : "https://interop.esante.gouv.fr/ig/document/core/ValueSet/fr-vs-result-type-document",
  "version" : "0.1.0-snapsnot",
  "name" : "FRValueSetResultTypeDocument",
  "title" : "ValueSet - FR ValueSet Result Type Document",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-04-09T12:24:05+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "ValueSet contenant les codes LOINC autorisés pour les types de résultats",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "26436-6",
        "display" : "Biologie polyvalente"
      },
      {
        "code" : "18748-4",
        "display" : "Imagerie"
      },
      {
        "code" : "26438-2",
        "display" : "Cytologie"
      },
      {
        "code" : "27898-6",
        "display" : "Pathologie"
      },
      {
        "code" : "26435-8",
        "display" : "Génétique humaine"
      }]
    }]
  }
}

```
